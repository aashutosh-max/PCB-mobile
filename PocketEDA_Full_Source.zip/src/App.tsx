/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import { PcbCanvas, SchematicCanvas } from './ui/canvas/CadCanvas';
import { BottomSheets } from './ui/components/BottomSheets';
import {
  ContextMenu,
  HomePage,
  NumericKeypad,
  Snackbar,
  ToolPalette,
  TopBar,
  ZoomControls,
} from './ui/components/EditorChrome';
import { useEditorStore } from './ui/store/useEditorStore';

export default function App() {
  const { appView, editorMode, fitViewport } = useEditorStore();

  useEffect(() => {
    fitViewport(window.innerWidth, window.innerHeight);
  }, [fitViewport]);

  return (
    <main className="relative w-full h-dvh bg-[#090d16] text-slate-100 overflow-hidden select-none touch-none">
      {appView === 'home' ? (
        <HomePage />
      ) : (
        <>
          <TopBar />
          <div className="w-full h-full">
            {editorMode === 'schematic' ? <SchematicCanvas /> : <PcbCanvas />}
          </div>
          <ToolPalette />
          <ZoomControls />
          <ContextMenu />
        </>
      )}

      <BottomSheets />
      <NumericKeypad />
      <Snackbar />
    </main>
  );
}
