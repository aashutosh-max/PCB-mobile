import { Point } from '../../core/types';

export interface GestureCallbacks {
  onTap: (screenPt: Point) => void;
  onDoubleTap: (screenPt: Point) => void;
  onLongPress: (screenPt: Point) => void;
  onDragStart: (screenPt: Point) => void;
  onDragMove: (screenPt: Point, deltaScreen: Point) => void;
  onDragEnd: (screenPt: Point) => void;
  onPanPinch: (deltaPan: Point, scaleFactor: number, centerScreen: Point) => void;
}

interface TrackedPointer {
  id: number;
  startX: number;
  startY: number;
  currX: number;
  currY: number;
  downTime: number;
}

const TAP_SLOP_PX = 10;
const DOUBLE_TAP_MS = 300;
const DOUBLE_TAP_DIST_PX = 32;
const LONG_PRESS_MS = 460;

/**
 * Unified Pointer Events gesture recognizer for touch-first mobile canvas interaction.
 * Maps Pointer Events -> tap, double-tap, long-press, 1-finger drag, 2-finger pan + pinch zoom.
 */
export class TouchGestureRecognizer {
  private pointers: Map<number, TrackedPointer> = new Map();
  private callbacks: GestureCallbacks;
  private isDragging = false;
  private isMultiTouch = false;
  private longPressTriggered = false;
  private longPressTimer: ReturnType<typeof setTimeout> | null = null;
  private lastTapTime = 0;
  private lastTapPoint: Point = { x: 0, y: 0 };
  private prevPinchDist = 0;
  private prevMidpoint: Point = { x: 0, y: 0 };

  constructor(callbacks: GestureCallbacks) {
    this.callbacks = callbacks;
  }

  private clearLongPress() {
    if (this.longPressTimer !== null) {
      clearTimeout(this.longPressTimer);
      this.longPressTimer = null;
    }
  }

  public handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    this.pointers.set(e.pointerId, {
      id: e.pointerId,
      startX: x,
      startY: y,
      currX: x,
      currY: y,
      downTime: performance.now(),
    });

    if (this.pointers.size === 1) {
      this.isDragging = false;
      this.isMultiTouch = false;
      this.longPressTriggered = false;
      this.clearLongPress();

      this.longPressTimer = setTimeout(() => {
        if (this.pointers.size === 1 && !this.isDragging && !this.isMultiTouch) {
          this.longPressTriggered = true;
          this.callbacks.onLongPress({ x, y });
        }
      }, LONG_PRESS_MS);
    } else if (this.pointers.size === 2) {
      this.clearLongPress();
      if (this.isDragging) {
        this.isDragging = false;
        this.callbacks.onDragEnd({ x, y });
      }
      this.isMultiTouch = true;
      const pts = Array.from(this.pointers.values());
      this.prevPinchDist = Math.hypot(pts[1].currX - pts[0].currX, pts[1].currY - pts[0].currY);
      this.prevMidpoint = {
        x: (pts[0].currX + pts[1].currX) / 2,
        y: (pts[0].currY + pts[1].currY) / 2,
      };
    }
  };

  public handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const tracked = this.pointers.get(e.pointerId);
    if (!tracked) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const prevX = tracked.currX;
    const prevY = tracked.currY;
    tracked.currX = x;
    tracked.currY = y;

    if (this.pointers.size === 1 && !this.isMultiTouch && !this.longPressTriggered) {
      const movedFromStart = Math.hypot(x - tracked.startX, y - tracked.startY);
      if (!this.isDragging && movedFromStart > TAP_SLOP_PX) {
        this.clearLongPress();
        this.isDragging = true;
        this.callbacks.onDragStart({ x: tracked.startX, y: tracked.startY });
      }
      if (this.isDragging) {
        this.callbacks.onDragMove({ x, y }, { x: x - prevX, y: y - prevY });
      }
    } else if (this.pointers.size >= 2) {
      const pts = Array.from(this.pointers.values());
      const p0 = pts[0];
      const p1 = pts[1];
      const dist = Math.hypot(p1.currX - p0.currX, p1.currY - p0.currY);
      const midpoint = {
        x: (p0.currX + p1.currX) / 2,
        y: (p0.currY + p1.currY) / 2,
      };

      const deltaPan = {
        x: midpoint.x - this.prevMidpoint.x,
        y: midpoint.y - this.prevMidpoint.y,
      };
      const scaleFactor =
        this.prevPinchDist > 8 && dist > 8 ? dist / this.prevPinchDist : 1;

      this.callbacks.onPanPinch(deltaPan, scaleFactor, midpoint);

      this.prevPinchDist = dist;
      this.prevMidpoint = midpoint;
    }
  };

  public handlePointerUpOrCancel = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const tracked = this.pointers.get(e.pointerId);
    this.pointers.delete(e.pointerId);
    this.clearLongPress();

    if (!tracked) return;
    const pt = { x: tracked.currX, y: tracked.currY };

    if (this.isDragging && this.pointers.size === 0) {
      this.isDragging = false;
      this.callbacks.onDragEnd(pt);
      return;
    }

    if (!this.isMultiTouch && !this.longPressTriggered && this.pointers.size === 0) {
      const moved = Math.hypot(pt.x - tracked.startX, pt.y - tracked.startY);
      if (moved <= TAP_SLOP_PX) {
        const now = performance.now();
        const dt = now - this.lastTapTime;
        const tapDist = Math.hypot(pt.x - this.lastTapPoint.x, pt.y - this.lastTapPoint.y);

        if (dt <= DOUBLE_TAP_MS && tapDist <= DOUBLE_TAP_DIST_PX) {
          this.lastTapTime = 0;
          this.callbacks.onDoubleTap(pt);
        } else {
          this.lastTapTime = now;
          this.lastTapPoint = pt;
          this.callbacks.onTap(pt);
        }
      }
    }

    if (this.pointers.size === 0) {
      this.isMultiTouch = false;
      this.isDragging = false;
      this.longPressTriggered = false;
    }
  };
}
