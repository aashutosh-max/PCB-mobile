import { create } from 'zustand';
import { runMstAStarAutorouter } from '../../core/autorouter';
import {
  createAddItemCommand,
  createAddPairedComponentCommand,
  createAlignPcbToSchematicCommand,
  createConnectPcbPadsCommand,
  createDeleteItemCommand,
  createHistoryState,
  createMoveItemCommand,
  createRotateItemCommand,
  createUpdateItemCommand,
  executeCommand,
  HistoryState,
  redoCommand,
  syncPcbNetsAndFootprints,
  undoCommand,
} from '../../core/commands';
import { runDRC } from '../../core/drc';
import {
  classifyComponentCategory,
  computeSheetBounds,
  distance,
  getAllLibraryParts,
  getComponentPinsWorld,
  getDefaultSymbolDefs,
  getOutlinePolygonPoints,
  makeDualRowIcDef,
  parseKiCadOrJsonLibrary,
  PCB_GRID,
  registerLibraryParts,
  SCHEMATIC_GRID,
  snapPoint,
  unregisterLibraryById,
  WEB_LIBRARY_CATALOG,
} from '../../core/geometry';
import {
  AntennaGeneratorOptions,
  AutoDesignatorOptions,
  autoNumberDesignators,
  DxfInsertOptions,
  generateMountingHoles,
  generatePadOrViaArray,
  generatePcbAntenna,
  generatePlanarSpiralCoil,
  generateQrOrBarcode,
  generateViaStitching,
  insertDxfIntoProject,
  insertSvgIntoProject,
  MountingHoleOptions,
  PadViaArrayOptions,
  PlanarCoilOptions,
  QrBarcodeOptions,
  SvgInsertOptions,
  ViaStitchingOptions,
} from '../../core/insertGenerators';
import { computeNetlist, computeRatsnest } from '../../core/netlist';
import {
  createBlinkerProject,
  createExampleProjects,
  createStarterProject,
  deserializeProject,
  ExampleTemplateItem,
} from '../../core/serialization';
import {
  AnyItem,
  DRCViolation,
  LayerId,
  LibraryComponentDef,
  LibraryPackage,
  Netlist,
  PcbBoardConfig,
  PcbFootprintItem,
  PcbOutlineItem,
  PcbTraceItem,
  PcbViaItem,
  PcbViewConfig,
  PhotoOverlayConfig,
  Point,
  Project,
  RatsnestLine,
  SchComponentItem,
  SchematicComponentKind,
  SchLabelItem,
  SchWireItem,
  ViewportTransform,
} from '../../core/types';

export type SchematicTool =
  | 'select'
  | 'wire'
  | 'label'
  | `place_${string}`;

export type PcbTool =
  | 'select'
  | 'trace_top'
  | 'trace_bottom'
  | 'airwire'
  | 'via'
  | 'outline'
  | 'measure'
  | `place_${string}`;

export type BottomSheetType =
  | 'none'
  | 'properties'
  | 'layers'
  | 'drc'
  | 'export'
  | 'add_part'
  | 'insert';

export type InsertSubView =
  | 'menu'
  | 'svg'
  | 'dxf'
  | 'photo'
  | 'antenna'
  | 'coil'
  | 'qr'
  | 'mounting_holes'
  | 'pad_via_array'
  | 'via_stitching'
  | 'designators';

export interface KeypadModalState {
  open: boolean;
  title: string;
  initialValue: string;
  unit: string;
  allowLetters: boolean;
  onCommit: ((val: string) => void) | null;
}

export interface ContextMenuState {
  open: boolean;
  screenPt: Point;
  worldPt: Point;
  itemId: string | null;
}

export interface SnackbarState {
  open: boolean;
  message: string;
  canUndo: boolean;
}

const STORAGE_KEY = 'pocketeda_workspace_files_v2';
const LIB_STORAGE_KEY = 'pocketeda_installed_libs_v1';

const DEFAULT_CUSTOM_MACRO: LibraryComponentDef = makeDualRowIcDef(
  'CUSTOM_FOOTPRINT_1',
  'Custom Footprint',
  'Mine',
  'User custom 4-pad macro footprint',
  'Custom_Footprint',
  'User_Macro:Custom_Footprint_4Pad',
  [
    { number: '1', name: 'P1' },
    { number: '2', name: 'P2' },
  ],
  [
    { number: '3', name: 'P3' },
    { number: '4', name: 'P4' },
  ],
  'user_macros',
  'Mine:Custom_Footprint',
  2.54,
  5.08,
  false
);

registerLibraryParts([DEFAULT_CUSTOM_MACRO]);

function loadSavedProjectsFromStorage(): Project[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveProjectsToStorage(projects: Project[]) {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(projects));
  } catch {
    // Ignore storage quota errors
  }
}

function normalizePackageCategories(pkg: LibraryPackage): LibraryPackage {
  const normalizedParts = (pkg.parts || []).map((p) => ({
    ...p,
    category:
      p.category === 'Mine'
        ? 'Mine'
        : classifyComponentCategory(
            p.title,
            p.refPrefix,
            p.description,
            p.footprint,
            pkg.name,
            p.category
          ),
  }));
  return { ...pkg, parts: normalizedParts };
}

function loadInstalledLibsFromStorage(): LibraryPackage[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = window.localStorage.getItem(LIB_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      const normalized = parsed.map((pkg) => normalizePackageCategories(pkg));
      for (const pkg of normalized) {
        if (Array.isArray(pkg.parts)) {
          registerLibraryParts(pkg.parts);
        }
      }
      return normalized;
    }
    return [];
  } catch {
    return [];
  }
}

function saveInstalledLibsToStorage(libs: LibraryPackage[]) {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(LIB_STORAGE_KEY, JSON.stringify(libs));
  } catch {
    // Ignore storage quota errors
  }
}

export function normalizeGitHubOrWebUrl(rawUrl: string): string {
  const trimmed = rawUrl.trim();
  // Convert github.com/<owner>/<repo>/blob/<branch>/<path> -> raw.githubusercontent.com/<owner>/<repo>/<branch>/<path>
  const ghBlob = /^https?:\/\/github\.com\/([^/]+)\/([^/]+)\/blob\/(.+)$/i.exec(trimmed);
  if (ghBlob) {
    return `https://raw.githubusercontent.com/${ghBlob[1]}/${ghBlob[2]}/${ghBlob[3]}`;
  }
  // Convert gitlab.com/<path>/-/blob/<branch>/<file> -> gitlab.com/<path>/-/raw/<branch>/<file>
  if (trimmed.includes('gitlab.com/') && trimmed.includes('/-/blob/')) {
    return trimmed.replace('/-/blob/', '/-/raw/');
  }
  return trimmed;
}

export interface EditorStoreState {
  appView: 'home' | 'editor';
  savedProjects: Project[];
  starterTemplates: ExampleTemplateItem[];
  installedLibraries: LibraryPackage[];
  availableParts: LibraryComponentDef[];
  recentlyUsedKinds: string[];
  favoriteKinds: string[];
  customMacros: LibraryComponentDef[];
  history: HistoryState;
  editorMode: 'schematic' | 'pcb';
  schTool: SchematicTool;
  pcbTool: PcbTool;
  activePcbLayer: LayerId;
  boardConfig: PcbBoardConfig;
  viewConfig: PcbViewConfig;
  photoOverlay: PhotoOverlayConfig;
  selectedItemId: string | null;
  activeSheet: BottomSheetType;
  insertSubView: InsertSubView;
  schViewport: ViewportTransform;
  pcbViewport: ViewportTransform;
  schInitialized: boolean;
  pcbInitialized: boolean;
  layerVisibility: Record<LayerId, boolean>;
  traceWidth: number;
  viaDiameter: number;
  viaDrill: number;
  drcViolations: DRCViolation[];
  highlightedViolation: DRCViolation | null;
  netlist: Netlist;
  ratsnest: RatsnestLine[];
  keypad: KeypadModalState;
  contextMenu: ContextMenuState;
  snackbar: SnackbarState;

  setAppView: (view: 'home' | 'editor') => void;
  setEditorMode: (mode: 'schematic' | 'pcb') => void;
  setSchTool: (tool: SchematicTool) => void;
  setPcbTool: (tool: PcbTool) => void;
  setActivePcbLayer: (layer: LayerId) => void;
  selectItem: (id: string | null) => void;
  setActiveSheet: (sheet: BottomSheetType) => void;
  openInsertSheet: (subView?: InsertSubView) => void;
  setInsertSubView: (subView: InsertSubView) => void;
  updatePhotoOverlay: (partial: Partial<PhotoOverlayConfig>) => void;
  setViewport: (mode: 'schematic' | 'pcb', vp: ViewportTransform) => void;
  zoomBy: (factor: number, screenCenter?: Point) => void;
  fitViewport: (canvasWidth: number, canvasHeight: number, targetMode?: 'schematic' | 'pcb') => void;
  centerOnWorldPoint: (pt: Point, canvasWidth: number, canvasHeight: number, targetScale?: number) => void;
  toggleLayerVisibility: (layer: LayerId) => void;
  setAllLayersVisibility: (visible: boolean) => void;
  updateBoardConfig: (partial: Partial<PcbBoardConfig>) => void;
  updateViewConfig: (partial: Partial<PcbViewConfig>) => void;
  recordRecentPart: (kind: string) => void;
  toggleFavoritePart: (kind: string) => void;
  createCustomMacro: (name: string, pinCount: number) => void;
  deleteCustomMacro: (kind: string) => void;

  insertSvgGeometry: (opts: SvgInsertOptions) => void;
  insertDxfGeometry: (opts: DxfInsertOptions) => void;
  generateBoardAntenna: (opts: AntennaGeneratorOptions) => void;
  generateBoardCoil: (opts: PlanarCoilOptions) => void;
  generateBoardQrBarcode: (opts: QrBarcodeOptions) => void;
  generateBoardMountingHoles: (opts: MountingHoleOptions) => void;
  generateBoardPadViaArray: (opts: PadViaArrayOptions) => void;
  generateBoardViaStitching: (opts: ViaStitchingOptions) => void;
  runAutoDesignators: (opts: AutoDesignatorOptions) => void;

  installWebLibrary: (pkg: LibraryPackage) => void;
  uninstallLibrary: (libraryId: string) => void;
  downloadLibraryFromUrl: (url: string) => Promise<void>;
  importLibraryText: (rawText: string, filename?: string) => void;

  placeSchematicComponent: (kind: SchematicComponentKind, worldPt: Point) => string;
  placePcbFootprint: (kind: SchematicComponentKind, worldPt: Point) => string;
  addSchematicWire: (points: Point[]) => void;
  addSchematicLabel: (text: string, worldPt: Point) => void;
  addPcbTrace: (points: Point[], layer: 'F.Cu' | 'B.Cu', net: string) => void;
  connectPcbPadsAirwire: (
    fromRefDes: string,
    fromPadNum: string,
    toRefDes: string,
    toPadNum: string,
    explicitNetName?: string
  ) => void;
  addPcbVia: (worldPt: Point, net: string) => void;
  updateBoardOutline: (
    x: number,
    y: number,
    width: number,
    height: number,
    cornerRadius?: number,
    points?: Point[]
  ) => void;
  splitBoardOutlineEdge: (edgeIndex: number) => void;
  moveBoardOutlineVertex: (vertexIndex: number, newPt: Point) => void;
  applyBoardShapePreset: (preset: 'rect' | 'rounded' | 'chamfer' | 'l_shape' | 'badge') => void;
  moveItem: (itemId: string, newPos: Point) => void;
  rotateItem: (itemId: string) => void;
  deleteItem: (itemId: string) => void;
  updateItemProps: (itemId: string, updater: (item: AnyItem) => AnyItem, desc?: string) => void;
  updateDesignRules: (partial: Partial<HistoryState['project']['rules']>) => void;
  syncPcbLayoutFromSchematic: () => void;
  deleteActiveSchematic: () => void;
  deleteStarterTemplate: (id: string) => void;
  restoreStarterTemplates: () => void;
  renameProject: (name: string) => void;
  renameSavedProject: (id: string, name: string) => void;
  undo: () => void;
  redo: () => void;
  runDrcCheck: () => void;
  focusViolation: (v: DRCViolation, canvasWidth: number, canvasHeight: number) => void;
  loadProjectJson: (json: string) => void;
  openProject: (project: Project, targetMode?: 'schematic' | 'pcb') => void;
  saveCurrentProjectToDevice: () => void;
  deleteSavedProject: (id: string) => void;
  newBlankProject: (customName?: string, stayOnHome?: boolean) => void;
  loadStarterProject: () => void;
  loadBlinkerProject: () => void;

  openKeypad: (opts: Omit<KeypadModalState, 'open'>) => void;
  closeKeypad: () => void;
  openContextMenu: (screenPt: Point, worldPt: Point, itemId: string | null) => void;
  closeContextMenu: () => void;
  showSnackbar: (message: string, canUndo?: boolean) => void;
  dismissSnackbar: () => void;
}

function recomputeDerived(project: HistoryState['project']) {
  return {
    netlist: computeNetlist(project),
    ratsnest: computeRatsnest(project),
    drcViolations: runDRC(project),
  };
}

function computeInitialViewport(project: Project, mode: 'schematic' | 'pcb'): ViewportTransform {
  const w = typeof window !== 'undefined' && window.innerWidth > 0 ? window.innerWidth : 390;
  const h = typeof window !== 'undefined' && window.innerHeight > 0 ? window.innerHeight : 780;
  const sheet = project.sheets.find((s) => s.kind === mode);
  if (!sheet) return { panX: 30, panY: 70, scale: 11 };
  const bounds = computeSheetBounds(sheet.items);
  const worldW = Math.max(15, bounds.maxX - bounds.minX);
  const worldH = Math.max(15, bounds.maxY - bounds.minY);
  const padPx = 56;
  const availW = Math.max(120, w - padPx * 2);
  const availH = Math.max(120, h - padPx * 2.4);
  const scale = Math.max(4, Math.min(45, Math.min(availW / worldW, availH / worldH)));
  const centerWorldX = (bounds.minX + bounds.maxX) / 2;
  const centerWorldY = (bounds.minY + bounds.maxY) / 2;
  return {
    panX: w / 2 - centerWorldX * scale,
    panY: h / 2 - centerWorldY * scale,
    scale,
  };
}

const initialInstalledLibs = loadInstalledLibsFromStorage();
const initialProject = createStarterProject();
const initialDerived = recomputeDerived(initialProject);

export const useEditorStore = create<EditorStoreState>((set, get) => ({
  appView: 'home',
  savedProjects: loadSavedProjectsFromStorage(),
  starterTemplates: createExampleProjects(),
  installedLibraries: initialInstalledLibs,
  availableParts: getAllLibraryParts(),
  recentlyUsedKinds: ['SW_CHERRY_MX', 'NE555', 'ESP32_WROOM'],
  favoriteKinds: [],
  customMacros: [DEFAULT_CUSTOM_MACRO],
  history: createHistoryState(initialProject),
  editorMode: 'schematic',
  schTool: 'select',
  pcbTool: 'select',
  activePcbLayer: 'B.Cu',
  boardConfig: {
    cornerRadius: 4.0,
    gridSize: 1.27,
    subdivision: 10,
    rasterType: 'grid',
    gridOrigin: 'board_corner',
    autoGroundTop: false,
    autoGroundBottom: false,
    copperFillClearance: 0.4,
    maskExpansion: 0.05,
    narrowestMaskStrip: 0.1,
    coverViasWithMask: false,
    pasteMargin: 0.0,
    stencilThickness: 0.12,
    unitSystem: 'mm',
  },
  viewConfig: {
    edgeRulers: false,
    coordinateReadout: false,
    autoScrollDragging: true,
    touchMagnifier: true,
    padLabels: 'numbers_nets',
    showDesignators: true,
    readoutPosition: 'bottom_left',
  },
  photoOverlay: {
    enabled: false,
    dataUrl: '',
    name: '',
    x: 4,
    y: 4,
    widthMm: 44,
    heightMm: 32,
    opacity: 0.55,
    flipX: false,
    flipY: false,
  },
  selectedItemId: null,
  activeSheet: 'none',
  insertSubView: 'menu',
  schViewport: computeInitialViewport(initialProject, 'schematic'),
  pcbViewport: computeInitialViewport(initialProject, 'pcb'),
  schInitialized: false,
  pcbInitialized: false,
  layerVisibility: {
    SCH: true,
    'F.SilkS': true,
    'F.Mask': false,
    'F.Cu': true,
    'B.Cu': true,
    'B.Mask': false,
    'B.SilkS': true,
    'Edge.Cuts': true,
  },
  traceWidth: 0.4,
  viaDiameter: 0.9,
  viaDrill: 0.45,
  drcViolations: initialDerived.drcViolations,
  highlightedViolation: null,
  netlist: initialDerived.netlist,
  ratsnest: initialDerived.ratsnest,
  keypad: {
    open: false,
    title: '',
    initialValue: '',
    unit: '',
    allowLetters: true,
    onCommit: null,
  },
  contextMenu: {
    open: false,
    screenPt: { x: 0, y: 0 },
    worldPt: { x: 0, y: 0 },
    itemId: null,
  },
  snackbar: {
    open: false,
    message: '',
    canUndo: false,
  },

  setAppView: (view) => {
    const currProj = get().history.project;
    const existingIdx = get().savedProjects.findIndex((p) => p.id === currProj.id);
    let nextSaved = get().savedProjects;
    if (existingIdx >= 0) {
      nextSaved = get().savedProjects.map((p) =>
        p.id === currProj.id ? { ...currProj, updatedAt: Date.now() } : p
      );
      saveProjectsToStorage(nextSaved);
    }
    set({
      appView: view,
      savedProjects: nextSaved,
      activeSheet: 'none',
      contextMenu: { ...get().contextMenu, open: false },
    });
  },

  setEditorMode: (mode) => {
    const syncedProject = syncPcbNetsAndFootprints(get().history.project);
    const derived = recomputeDerived(syncedProject);
    set({
      appView: 'editor',
      editorMode: mode,
      history: {
        ...get().history,
        project: syncedProject,
      },
      selectedItemId: null,
      contextMenu: { ...get().contextMenu, open: false },
      ...derived,
    });
    if (typeof window !== 'undefined') {
      get().fitViewport(window.innerWidth, window.innerHeight, mode);
    }
  },

  setSchTool: (tool) =>
    set({
      schTool: tool,
      contextMenu: { ...get().contextMenu, open: false },
    }),

  setPcbTool: (tool) => {
    const nextLayer =
      tool === 'trace_top'
        ? 'F.Cu'
        : tool === 'trace_bottom'
          ? 'B.Cu'
          : get().activePcbLayer;
    set({
      pcbTool: tool,
      activePcbLayer: nextLayer,
      contextMenu: { ...get().contextMenu, open: false },
    });
  },

  setActivePcbLayer: (layer) => {
    const currTool = get().pcbTool;
    let nextTool = currTool;
    if (layer === 'F.Cu' && currTool === 'trace_bottom') nextTool = 'trace_top';
    if (layer === 'B.Cu' && currTool === 'trace_top') nextTool = 'trace_bottom';
    set({
      activePcbLayer: layer,
      pcbTool: nextTool,
      layerVisibility: {
        ...get().layerVisibility,
        [layer]: true,
      },
    });
  },

  selectItem: (id) => set({ selectedItemId: id }),

  setActiveSheet: (sheet) =>
    set({
      activeSheet: sheet,
      contextMenu: { ...get().contextMenu, open: false },
    }),

  setViewport: (mode, vp) => {
    const clampedScale = Math.max(3, Math.min(65, vp.scale));
    if (mode === 'schematic') {
      set({ schViewport: { ...vp, scale: clampedScale } });
    } else {
      set({ pcbViewport: { ...vp, scale: clampedScale } });
    }
  },

  zoomBy: (factor, screenCenter) => {
    const mode = get().editorMode;
    const vp = mode === 'schematic' ? get().schViewport : get().pcbViewport;
    const center = screenCenter ?? { x: window.innerWidth / 2, y: window.innerHeight / 2 };
    const newScale = Math.max(3, Math.min(65, vp.scale * factor));
    const ratio = newScale / vp.scale;
    const newPanX = center.x - (center.x - vp.panX) * ratio;
    const newPanY = center.y - (center.y - vp.panY) * ratio;
    get().setViewport(mode, { panX: newPanX, panY: newPanY, scale: newScale });
  },

  fitViewport: (canvasWidth, canvasHeight, targetMode) => {
    const { history, editorMode } = get();
    const mode = targetMode ?? editorMode;
    const sheet = history.project.sheets.find((s) => s.kind === mode);
    if (!sheet) return;
    const w = canvasWidth > 0 ? canvasWidth : window.innerWidth || 390;
    const h = canvasHeight > 0 ? canvasHeight : window.innerHeight || 780;
    const bounds = computeSheetBounds(sheet.items);
    const worldW = Math.max(15, bounds.maxX - bounds.minX);
    const worldH = Math.max(15, bounds.maxY - bounds.minY);
    const padPx = 56;
    const availW = Math.max(120, w - padPx * 2);
    const availH = Math.max(120, h - padPx * 2.4);
    const scale = Math.max(4, Math.min(45, Math.min(availW / worldW, availH / worldH)));
    const centerWorldX = (bounds.minX + bounds.maxX) / 2;
    const centerWorldY = (bounds.minY + bounds.maxY) / 2;
    const panX = w / 2 - centerWorldX * scale;
    const panY = h / 2 - centerWorldY * scale;
    get().setViewport(mode, { panX, panY, scale });
  },

  centerOnWorldPoint: (pt, canvasWidth, canvasHeight, targetScale = 18) => {
    const mode = get().editorMode;
    const scale = Math.max(8, Math.min(45, targetScale));
    const panX = canvasWidth / 2 - pt.x * scale;
    const panY = canvasHeight / 2 - pt.y * scale;
    get().setViewport(mode, { panX, panY, scale });
  },

  toggleLayerVisibility: (layer) =>
    set((state) => ({
      layerVisibility: {
        ...state.layerVisibility,
        [layer]: !state.layerVisibility[layer],
      },
    })),

  setAllLayersVisibility: (visible) =>
    set((state) => ({
      layerVisibility: {
        ...state.layerVisibility,
        'F.SilkS': visible,
        'F.Mask': visible,
        'F.Cu': visible,
        'B.Cu': visible,
        'B.Mask': visible,
        'B.SilkS': visible,
      },
    })),

  updateBoardConfig: (partial) =>
    set((state) => {
      const nextBoard = { ...state.boardConfig, ...partial };
      if (
        partial.unitSystem &&
        partial.unitSystem !== state.boardConfig.unitSystem &&
        partial.gridSize === undefined
      ) {
        if (partial.unitSystem === 'mil') {
          // 20 mil = 0.508 mm (divides 100 mil = 2.54 mm pitch cleanly into 5 steps)
          if (Math.abs(state.boardConfig.gridSize - 0.5) < 0.02) {
            nextBoard.gridSize = 0.508;
          }
        } else {
          if (
            Math.abs(state.boardConfig.gridSize - 0.508) < 0.02 ||
            Math.abs(state.boardConfig.gridSize - 0.635) < 0.02
          ) {
            nextBoard.gridSize = 0.5;
          }
        }
      }
      if (partial.copperFillClearance !== undefined) {
        get().updateDesignRules({ minClearance: partial.copperFillClearance });
      }
      return { boardConfig: nextBoard };
    }),

  updateViewConfig: (partial) =>
    set((state) => ({
      viewConfig: { ...state.viewConfig, ...partial },
    })),

  recordRecentPart: (kind) =>
    set((state) => ({
      recentlyUsedKinds: [
        kind,
        ...state.recentlyUsedKinds.filter((k) => k !== kind),
      ].slice(0, 8),
    })),

  toggleFavoritePart: (kind) =>
    set((state) => ({
      favoriteKinds: state.favoriteKinds.includes(kind)
        ? state.favoriteKinds.filter((k) => k !== kind)
        : [kind, ...state.favoriteKinds],
    })),

  createCustomMacro: (name, pinCount) => {
    const cleanName = name.trim() || `Custom_Footprint_${get().customMacros.length + 1}`;
    if (get().customMacros.length >= 5) {
      set({
        snackbar: {
          open: true,
          message: 'Maximum 5 custom footprint macros reached',
          canUndo: false,
        },
      });
      return;
    }
    const clampedPins = Math.max(2, Math.min(16, Math.round(pinCount / 2) * 2));
    const half = clampedPins / 2;
    const leftPins = Array.from({ length: half }, (_, i) => ({
      number: String(i + 1),
      name: `P${i + 1}`,
    }));
    const rightPins = Array.from({ length: half }, (_, i) => ({
      number: String(half + i + 1),
      name: `P${half + i + 1}`,
    }));
    const kind = `CUSTOM_${cleanName.toUpperCase().replace(/[^A-Z0-9_]/g, '_')}_${Date.now()}`;
    const newMacro: LibraryComponentDef = makeDualRowIcDef(
      kind,
      cleanName,
      'Mine',
      `User custom ${clampedPins}-pad macro footprint`,
      cleanName,
      `User_Macro:${cleanName}_${clampedPins}Pad`,
      leftPins,
      rightPins,
      'user_macros',
      `Mine:${cleanName}`,
      2.54,
      5.08,
      false
    );
    registerLibraryParts([newMacro]);
    set((state) => ({
      customMacros: [...state.customMacros, newMacro],
      availableParts: getAllLibraryParts(),
      snackbar: {
        open: true,
        message: `Created macro "${cleanName}"`,
        canUndo: false,
      },
    }));
  },

  deleteCustomMacro: (kind) => {
    set((state) => ({
      customMacros: state.customMacros.filter((m) => m.kind !== kind),
      snackbar: {
        open: true,
        message: 'Removed custom macro',
        canUndo: false,
      },
    }));
  },

  installWebLibrary: (pkg) => {
    const normalized = normalizePackageCategories(pkg);
    registerLibraryParts(normalized.parts);
    const filtered = get().installedLibraries.filter((l) => l.id !== normalized.id);
    const updated = [normalized, ...filtered];
    saveInstalledLibsToStorage(updated);
    const categories = Array.from(new Set(normalized.parts.map((p) => p.category)));
    set({
      installedLibraries: updated,
      availableParts: getAllLibraryParts(),
      snackbar: {
        open: true,
        message: `Sorted ${normalized.parts.length} parts → ${categories.slice(0, 3).join(', ')}`,
        canUndo: false,
      },
    });
  },

  uninstallLibrary: (libraryId) => {
    unregisterLibraryById(libraryId);
    const updated = get().installedLibraries.filter((l) => l.id !== libraryId);
    saveInstalledLibsToStorage(updated);
    set({
      installedLibraries: updated,
      availableParts: getAllLibraryParts(),
      snackbar: {
        open: true,
        message: 'Removed library package',
        canUndo: false,
      },
    });
  },

  downloadLibraryFromUrl: async (url) => {
    const cleanUrl = normalizeGitHubOrWebUrl(url);
    if (!cleanUrl) return;

    const matchedCatalog = WEB_LIBRARY_CATALOG.find(
      (c) =>
        c.sourceUrl?.toLowerCase() === cleanUrl.toLowerCase() ||
        cleanUrl.toLowerCase().includes('kicad-footprints') ||
        cleanUrl.toLowerCase().includes(c.name.replace('.kicad_sym', '').toLowerCase())
    );

    if (cleanUrl.startsWith('git@') && matchedCatalog) {
      get().installWebLibrary(matchedCatalog);
      return;
    }

    try {
      const response = await fetch(cleanUrl);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      const text = await response.text();
      const fileName = cleanUrl.split('/').pop() || 'Web_Library.kicad_sym';
      const parsedPkg = parseKiCadOrJsonLibrary(text, fileName);
      parsedPkg.sourceUrl = cleanUrl;
      get().installWebLibrary(parsedPkg);
    } catch {
      if (matchedCatalog) {
        get().installWebLibrary(matchedCatalog);
        return;
      }
      set({
        snackbar: {
          open: true,
          message: 'Could not fetch URL (use git@gitlab.com:kicad/libraries/kicad-footprints.git or raw .kicad_sym/.kicad_mod)',
          canUndo: false,
        },
      });
    }
  },

  importLibraryText: (rawText, filename = 'Imported.kicad_sym') => {
    const pkg = parseKiCadOrJsonLibrary(rawText, filename);
    get().installWebLibrary(pkg);
  },

  placeSchematicComponent: (kind, worldPt) => {
    const { history } = get();
    const schSheet = history.project.sheets.find((s) => s.kind === 'schematic')!;
    const snapped = snapPoint(worldPt, SCHEMATIC_GRID);
    const def = getDefaultSymbolDefs(kind);

    const prefix = def.refPrefix || 'U';
    let idx = 1;
    const existingRefs = new Set(
      schSheet.items
        .filter((i): i is SchComponentItem => i.type === 'sch_component')
        .map((i) => i.props.refDes)
    );
    while (existingRefs.has(`${prefix}${idx}`)) {
      idx++;
    }
    const refDes = `${prefix}${idx}`;
    const id = `sch_${refDes}_${Date.now()}`;

    const item: SchComponentItem = {
      id,
      type: 'sch_component',
      transform: { x: snapped.x, y: snapped.y, rotation: 0, layer: 'SCH' },
      props: {
        kind,
        refDes,
        value: def.defaultValue,
        footprint: def.footprint,
        pins: def.pins,
        symbolStyle: def.symbolStyle,
      },
    };

    get().recordRecentPart(kind);
    const nextHistory = executeCommand(
      history,
      createAddItemCommand('schematic', item, `Place ${refDes}`)
    );
    const derived = recomputeDerived(nextHistory.project);
    set({
      history: nextHistory,
      selectedItemId: id,
      ...derived,
    });
    return id;
  },

  placePcbFootprint: (kind, worldPt) => {
    if (kind === 'GND' || kind === 'VCC') return '';
    const { history, boardConfig } = get();
    const schSheet = history.project.sheets.find((s) => s.kind === 'schematic')!;
    const pcbSheet = history.project.sheets.find((s) => s.kind === 'pcb')!;
    const grid = boardConfig.gridSize || PCB_GRID;
    const snappedPcb = snapPoint(worldPt, grid);
    const def = getDefaultSymbolDefs(kind);

    const prefix = def.refPrefix || 'U';
    let idx = 1;
    const existingRefs = new Set([
      ...schSheet.items
        .filter((i): i is SchComponentItem => i.type === 'sch_component')
        .map((i) => i.props.refDes),
      ...pcbSheet.items
        .filter((i): i is PcbFootprintItem => i.type === 'pcb_footprint')
        .map((i) => i.props.refDes),
    ]);
    while (existingRefs.has(`${prefix}${idx}`)) {
      idx++;
    }
    const refDes = `${prefix}${idx}`;
    const schId = `sch_${refDes}_${Date.now()}`;
    const fpId = `fp_${refDes}`;

    const schCount = schSheet.items.filter((i) => i.type === 'sch_component').length;
    const schPos = snapPoint(
      {
        x: (8 + (schCount % 4) * 7) * SCHEMATIC_GRID,
        y: (8 + Math.floor(schCount / 4) * 6) * SCHEMATIC_GRID,
      },
      SCHEMATIC_GRID
    );

    const schItem: SchComponentItem = {
      id: schId,
      type: 'sch_component',
      transform: { x: schPos.x, y: schPos.y, rotation: 0, layer: 'SCH' },
      props: {
        kind,
        refDes,
        value: def.defaultValue,
        footprint: def.footprint,
        pins: def.pins,
        symbolStyle: def.symbolStyle,
      },
    };

    const pcbItem: PcbFootprintItem = {
      id: fpId,
      type: 'pcb_footprint',
      transform: { x: snappedPcb.x, y: snappedPcb.y, rotation: 0, layer: 'F.Cu' },
      props: {
        refDes,
        value: def.defaultValue,
        footprintName: def.footprint,
        courtyard: def.courtyard,
        pads: def.pads,
      },
    };

    get().recordRecentPart(kind);
    const nextHistory = executeCommand(
      history,
      createAddPairedComponentCommand(schItem, pcbItem, `Place ${refDes}`)
    );
    const derived = recomputeDerived(nextHistory.project);
    set({
      history: nextHistory,
      selectedItemId: fpId,
      ...derived,
    });
    return fpId;
  },

  addSchematicWire: (points) => {
    if (points.length < 2) return;
    const { history } = get();
    const schSheet = history.project.sheets.find((s) => s.kind === 'schematic')!;
    const allPins: Point[] = [];
    for (const it of schSheet.items) {
      if (it.type === 'sch_component') {
        for (const p of getComponentPinsWorld(it)) {
          allPins.push(p.world);
        }
      }
    }

    const snapOrPin = (pt: Point): Point => {
      let bestPin: Point | null = null;
      let bestDist = SCHEMATIC_GRID * 0.65;
      for (const pinPt of allPins) {
        const d = distance(pt, pinPt);
        if (d <= bestDist) {
          bestDist = d;
          bestPin = pinPt;
        }
      }
      return bestPin ? { x: bestPin.x, y: bestPin.y } : snapPoint(pt, SCHEMATIC_GRID);
    };

    const startPt = snapOrPin(points[0]);
    const endPt = snapOrPin(points[points.length - 1]);
    const snappedPts =
      points.length === 3
        ? [startPt, { x: endPt.x, y: startPt.y }, endPt]
        : points.map((p) => snapOrPin(p));

    const item: SchWireItem = {
      id: `wire_${Date.now()}`,
      type: 'sch_wire',
      transform: { x: snappedPts[0].x, y: snappedPts[0].y, rotation: 0, layer: 'SCH' },
      props: { points: snappedPts },
    };
    const nextHistory = executeCommand(
      history,
      createAddItemCommand('schematic', item, 'Draw wire')
    );
    const derived = recomputeDerived(nextHistory.project);
    set({ history: nextHistory, ...derived });
  },

  addSchematicLabel: (text, worldPt) => {
    const clean = text.trim().toUpperCase();
    if (!clean) return;
    const { history } = get();
    const snapped = snapPoint(worldPt, SCHEMATIC_GRID);
    const item: SchLabelItem = {
      id: `lbl_${Date.now()}`,
      type: 'sch_label',
      transform: { x: snapped.x, y: snapped.y, rotation: 0, layer: 'SCH' },
      props: { text: clean },
    };
    const nextHistory = executeCommand(
      history,
      createAddItemCommand('schematic', item, `Add label ${clean}`)
    );
    const derived = recomputeDerived(nextHistory.project);
    set({ history: nextHistory, selectedItemId: item.id, ...derived });
  },

  addPcbTrace: (points, layer, net) => {
    if (points.length < 2) return;
    const { history, traceWidth } = get();
    const startPt = points[0];
    const endPt = points[points.length - 1];

    // Use obstacle-avoiding A* pathfinding on the selected layer so traces automatically avoid contact with other pads/traces
    let routedPoints = points;
    const astarRes = runMstAStarAutorouter(history.project, {
      layerMode: layer,
      diagonal45: true,
      gridStep: 0.4,
      traceWidth,
      specificPair: {
        from: startPt,
        to: endPt,
        net: net || `__TRACE_${Date.now()}`,
      },
    });
    if (astarRes.routedConnections > 0) {
      const pcbAfter = astarRes.project.sheets.find((s) => s.kind === 'pcb');
      const lastTrace = pcbAfter?.items
        .filter((i): i is PcbTraceItem => i.type === 'pcb_trace')
        .pop();
      if (lastTrace && lastTrace.props.points.length >= 2) {
        routedPoints = lastTrace.props.points;
      }
    }

    const item: PcbTraceItem = {
      id: `trace_${Date.now()}`,
      type: 'pcb_trace',
      transform: { x: routedPoints[0].x, y: routedPoints[0].y, rotation: 0, layer },
      props: {
        points: routedPoints,
        width: traceWidth,
        net,
      },
    };
    const nextHistory = executeCommand(
      history,
      createAddItemCommand('pcb', item, `Route ${layer} trace`)
    );
    const derived = recomputeDerived(nextHistory.project);
    set({ history: nextHistory, ...derived });
  },

  connectPcbPadsAirwire: (fromRefDes, fromPadNum, toRefDes, toPadNum, explicitNetName) => {
    if (fromRefDes === toRefDes && fromPadNum === toPadNum) return;
    const { history } = get();
    const nextHistory = executeCommand(
      history,
      createConnectPcbPadsCommand(fromRefDes, fromPadNum, toRefDes, toPadNum, explicitNetName)
    );
    const derived = recomputeDerived(nextHistory.project);
    set({
      history: nextHistory,
      snackbar: {
        open: true,
        message: `Connected airwire ${fromRefDes}.${fromPadNum} ↔ ${toRefDes}.${toPadNum}`,
        canUndo: true,
      },
      ...derived,
    });
  },

  addPcbVia: (worldPt, net) => {
    const { history, viaDiameter, viaDrill, boardConfig } = get();
    const grid = boardConfig.gridSize || PCB_GRID;
    const snapped = snapPoint(worldPt, grid);
    const item: PcbViaItem = {
      id: `via_${Date.now()}`,
      type: 'pcb_via',
      transform: { x: snapped.x, y: snapped.y, rotation: 0, layer: 'F.Cu' },
      props: {
        diameter: viaDiameter,
        drill: viaDrill,
        net,
      },
    };
    const nextHistory = executeCommand(
      history,
      createAddItemCommand('pcb', item, 'Place via')
    );
    const derived = recomputeDerived(nextHistory.project);
    set({ history: nextHistory, selectedItemId: item.id, ...derived });
  },

  updateBoardOutline: (x, y, width, height, cornerRadius, points) => {
    const { history, boardConfig } = get();
    const radius = cornerRadius ?? boardConfig.cornerRadius;
    const pcbSheet = history.project.sheets.find((s) => s.kind === 'pcb')!;
    const existing = pcbSheet.items.find((i): i is PcbOutlineItem => i.type === 'pcb_outline');
    let nextHistory: HistoryState;
    if (existing) {
      nextHistory = executeCommand(
        history,
        createUpdateItemCommand(
          'pcb',
          existing.id,
          (it) =>
            ({
              ...it,
              transform: { ...it.transform, x, y },
              props: {
                width: Math.max(5, width),
                height: Math.max(5, height),
                cornerRadius: radius,
                ...(points !== undefined ? { points } : {}),
              },
            }) as PcbOutlineItem,
          'Update board outline'
        )
      );
    } else {
      const item: PcbOutlineItem = {
        id: `pcb_outline_${Date.now()}`,
        type: 'pcb_outline',
        transform: { x, y, rotation: 0, layer: 'Edge.Cuts' },
        props: {
          width: Math.max(5, width),
          height: Math.max(5, height),
          cornerRadius: radius,
          ...(points !== undefined ? { points } : {}),
        },
      };
      nextHistory = executeCommand(
        history,
        createAddItemCommand('pcb', item, 'Set board outline')
      );
    }
    const derived = recomputeDerived(nextHistory.project);
    set({
      history: nextHistory,
      boardConfig: { ...boardConfig, cornerRadius: radius },
      ...derived,
    });
  },

  splitBoardOutlineEdge: (edgeIndex) => {
    const { history } = get();
    const pcbSheet = history.project.sheets.find((s) => s.kind === 'pcb')!;
    const existing = pcbSheet.items.find((i): i is PcbOutlineItem => i.type === 'pcb_outline');
    if (!existing) return;
    const poly = getOutlinePolygonPoints(existing);
    if (edgeIndex < 0 || edgeIndex >= poly.length) return;
    const a = poly[edgeIndex];
    const b = poly[(edgeIndex + 1) % poly.length];
    const mid: Point = {
      x: Number(((a.x + b.x) / 2).toFixed(2)),
      y: Number(((a.y + b.y) / 2).toFixed(2)),
    };
    const nextPts = [...poly.slice(0, edgeIndex + 1), mid, ...poly.slice(edgeIndex + 1)];
    get().updateBoardOutline(
      existing.transform.x,
      existing.transform.y,
      existing.props.width,
      existing.props.height,
      existing.props.cornerRadius,
      nextPts
    );
    set({
      snackbar: {
        open: true,
        message: `Split board edge (${nextPts.length} vertices — drag vertex on PCB)`,
        canUndo: true,
      },
    });
  },

  moveBoardOutlineVertex: (vertexIndex, newPt) => {
    const { history } = get();
    const pcbSheet = history.project.sheets.find((s) => s.kind === 'pcb')!;
    const existing = pcbSheet.items.find((i): i is PcbOutlineItem => i.type === 'pcb_outline');
    if (!existing) return;
    const poly = [...getOutlinePolygonPoints(existing)];
    if (vertexIndex < 0 || vertexIndex >= poly.length) return;
    poly[vertexIndex] = {
      x: Number(newPt.x.toFixed(2)),
      y: Number(newPt.y.toFixed(2)),
    };
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    for (const p of poly) {
      if (p.x < minX) minX = p.x;
      if (p.y < minY) minY = p.y;
      if (p.x > maxX) maxX = p.x;
      if (p.y > maxY) maxY = p.y;
    }
    get().updateBoardOutline(
      minX,
      minY,
      Math.max(5, maxX - minX),
      Math.max(5, maxY - minY),
      existing.props.cornerRadius,
      poly
    );
  },

  applyBoardShapePreset: (preset) => {
    const { history } = get();
    const pcbSheet = history.project.sheets.find((s) => s.kind === 'pcb')!;
    const existing = pcbSheet.items.find((i): i is PcbOutlineItem => i.type === 'pcb_outline');
    const x = existing?.transform.x ?? 4;
    const y = existing?.transform.y ?? 4;
    const w = existing?.props.width ?? 40;
    const h = existing?.props.height ?? 28;

    if (preset === 'rect') {
      get().updateBoardOutline(x, y, w, h, 0, undefined);
    } else if (preset === 'rounded') {
      get().updateBoardOutline(x, y, w, h, 4.5, undefined);
    } else if (preset === 'chamfer') {
      const c = Math.min(w, h) * 0.18;
      const pts: Point[] = [
        { x: x + c, y },
        { x: x + w - c, y },
        { x: x + w, y: y + c },
        { x: x + w, y: y + h - c },
        { x: x + w - c, y: y + h },
        { x: x + c, y: y + h },
        { x, y: y + h - c },
        { x, y: y + c },
      ];
      get().updateBoardOutline(x, y, w, h, 0, pts);
    } else if (preset === 'l_shape') {
      const pts: Point[] = [
        { x, y },
        { x: x + w * 0.62, y },
        { x: x + w * 0.62, y: y + h * 0.45 },
        { x: x + w, y: y + h * 0.45 },
        { x: x + w, y: y + h },
        { x, y: y + h },
      ];
      get().updateBoardOutline(x, y, w, h, 1.5, pts);
    } else if (preset === 'badge') {
      const pts: Point[] = [
        { x: x + w * 0.5, y },
        { x: x + w, y: y + h * 0.25 },
        { x: x + w, y: y + h * 0.75 },
        { x: x + w * 0.5, y: y + h },
        { x, y: y + h * 0.75 },
        { x, y: y + h * 0.25 },
      ];
      get().updateBoardOutline(x, y, w, h, 2.0, pts);
    }
    set({
      snackbar: {
        open: true,
        message: `Applied ${preset.replace('_', '-')} board shape`,
        canUndo: true,
      },
    });
  },

  moveItem: (itemId, newPos) => {
    const { history, editorMode } = get();
    const grid = editorMode === 'schematic' ? SCHEMATIC_GRID : PCB_GRID;
    const snapped = snapPoint(newPos, grid);
    const nextHistory = executeCommand(
      history,
      createMoveItemCommand(editorMode, itemId, snapped, 'Move item')
    );
    const derived = recomputeDerived(nextHistory.project);
    set({ history: nextHistory, ...derived });
  },

  rotateItem: (itemId) => {
    const { history, editorMode } = get();
    const nextHistory = executeCommand(
      history,
      createRotateItemCommand(editorMode, itemId, 'Rotate 90°')
    );
    const derived = recomputeDerived(nextHistory.project);
    set({ history: nextHistory, ...derived });
  },

  deleteItem: (itemId) => {
    const { history, editorMode } = get();
    const sheet = history.project.sheets.find((s) => s.kind === editorMode);
    const target = sheet?.items.find((i) => i.id === itemId);
    if (!target) return;

    const label =
      target.type === 'sch_component' || target.type === 'pcb_footprint'
        ? target.props.refDes
        : target.type.replace('sch_', '').replace('pcb_', '');

    const nextHistory = executeCommand(
      history,
      createDeleteItemCommand(editorMode, itemId, `Delete ${label}`)
    );
    const derived = recomputeDerived(nextHistory.project);
    set({
      history: nextHistory,
      selectedItemId: null,
      contextMenu: { ...get().contextMenu, open: false },
      snackbar: {
        open: true,
        message: `Deleted ${label}`,
        canUndo: true,
      },
      ...derived,
    });
  },

  updateItemProps: (itemId, updater, desc = 'Update properties') => {
    const { history, editorMode } = get();
    const nextHistory = executeCommand(
      history,
      createUpdateItemCommand(editorMode, itemId, updater, desc)
    );
    const derived = recomputeDerived(nextHistory.project);
    set({ history: nextHistory, ...derived });
  },

  updateDesignRules: (partial) => {
    const { history } = get();
    const nextProject = {
      ...history.project,
      rules: { ...history.project.rules, ...partial },
    };
    const nextHistory = {
      ...history,
      project: nextProject,
    };
    const derived = recomputeDerived(nextProject);
    set({ history: nextHistory, ...derived });
  },

  syncPcbLayoutFromSchematic: () => {
    const { history } = get();
    const nextHistory = executeCommand(history, createAlignPcbToSchematicCommand());
    const derived = recomputeDerived(nextHistory.project);
    set({
      history: nextHistory,
      snackbar: {
        open: true,
        message: 'Synced PCB footprints & nets from Schematic',
        canUndo: true,
      },
      ...derived,
    });
    if (typeof window !== 'undefined') {
      get().fitViewport(window.innerWidth, window.innerHeight, 'pcb');
    }
  },

  deleteActiveSchematic: () => {
    const { history } = get();
    const prevProject = history.project;
    const clearedSheets = prevProject.sheets.map((s) =>
      s.kind === 'schematic'
        ? { ...s, items: [] }
        : {
            ...s,
            items: s.items.filter((i) => i.type === 'pcb_outline'),
          }
    );
    const nextProject: Project = {
      ...prevProject,
      updatedAt: Date.now(),
      sheets: clearedSheets,
    };
    const nextHistory = executeCommand(history, {
      id: `cmd_del_sch_${Date.now()}`,
      description: 'Delete schematic',
      execute: () => nextProject,
    });
    const derived = recomputeDerived(nextHistory.project);
    const savedFiltered = get().savedProjects.filter((p) => p.id !== prevProject.id);
    saveProjectsToStorage(savedFiltered);
    set({
      history: nextHistory,
      savedProjects: savedFiltered,
      selectedItemId: null,
      snackbar: {
        open: true,
        message: `Deleted schematic "${prevProject.name}"`,
        canUndo: true,
      },
      ...derived,
    });
  },

  deleteStarterTemplate: (id) => {
    set((state) => ({
      starterTemplates: state.starterTemplates.filter((t) => t.id !== id),
      snackbar: {
        open: true,
        message: 'Removed example from list',
        canUndo: false,
      },
    }));
  },

  restoreStarterTemplates: () => {
    set({
      starterTemplates: createExampleProjects(),
      snackbar: {
        open: true,
        message: 'Restored all 10 example circuits',
        canUndo: false,
      },
    });
  },

  renameProject: (name) => {
    const clean = name.trim();
    if (!clean) return;
    const { history, savedProjects } = get();
    const nextProject = {
      ...history.project,
      name: clean,
      updatedAt: Date.now(),
    };
    const nextSaved = savedProjects.map((p) =>
      p.id === nextProject.id ? nextProject : p
    );
    saveProjectsToStorage(nextSaved);
    set({
      history: {
        ...history,
        project: nextProject,
      },
      savedProjects: nextSaved,
      snackbar: { open: true, message: `Renamed to ${clean}`, canUndo: false },
    });
  },

  renameSavedProject: (id, name) => {
    const clean = name.trim();
    if (!clean) return;
    const { history, savedProjects } = get();
    const nextSaved = savedProjects.map((p) =>
      p.id === id ? { ...p, name: clean, updatedAt: Date.now() } : p
    );
    saveProjectsToStorage(nextSaved);
    const isCurrent = history.project.id === id;
    set({
      savedProjects: nextSaved,
      ...(isCurrent
        ? {
            history: {
              ...history,
              project: { ...history.project, name: clean, updatedAt: Date.now() },
            },
          }
        : {}),
    });
  },

  undo: () => {
    const nextHistory = undoCommand(get().history);
    const derived = recomputeDerived(nextHistory.project);
    set({
      history: nextHistory,
      selectedItemId: null,
      snackbar: { open: false, message: '', canUndo: false },
      ...derived,
    });
  },

  redo: () => {
    const nextHistory = redoCommand(get().history);
    const derived = recomputeDerived(nextHistory.project);
    set({
      history: nextHistory,
      selectedItemId: null,
      ...derived,
    });
  },

  runDrcCheck: () => {
    const violations = runDRC(get().history.project);
    set({ drcViolations: violations, activeSheet: 'drc' });
  },

  focusViolation: (v, canvasWidth, canvasHeight) => {
    set({
      appView: 'editor',
      editorMode: 'pcb',
      pcbInitialized: true,
      highlightedViolation: v,
      selectedItemId: v.itemIds[0] ?? null,
      activeSheet: 'none',
    });
    get().centerOnWorldPoint(v.position, canvasWidth, canvasHeight, 22);
  },

  openProject: (proj, targetMode = 'schematic') => {
    const synced = syncPcbNetsAndFootprints(proj);
    const derived = recomputeDerived(synced);
    const pcbOutline = synced.sheets
      .find((s) => s.kind === 'pcb')
      ?.items.find((i): i is PcbOutlineItem => i.type === 'pcb_outline');
    const existsInSaved = get().savedProjects.some((p) => p.id === synced.id);
    const nextSaved = existsInSaved
      ? get().savedProjects.map((p) => (p.id === synced.id ? synced : p))
      : [synced, ...get().savedProjects];
    saveProjectsToStorage(nextSaved);
    set({
      appView: 'editor',
      editorMode: targetMode,
      savedProjects: nextSaved,
      history: createHistoryState(synced),
      selectedItemId: null,
      activeSheet: 'none',
      schViewport: computeInitialViewport(synced, 'schematic'),
      pcbViewport: computeInitialViewport(synced, 'pcb'),
      schInitialized: false,
      pcbInitialized: false,
      boardConfig: {
        ...get().boardConfig,
        cornerRadius: pcbOutline?.props.cornerRadius ?? get().boardConfig.cornerRadius,
      },
      ...derived,
    });
  },

  saveCurrentProjectToDevice: () => {
    const proj = { ...get().history.project, updatedAt: Date.now() };
    const existing = get().savedProjects.filter((p) => p.id !== proj.id);
    const updated = [proj, ...existing].slice(0, 30);
    saveProjectsToStorage(updated);
    set({
      savedProjects: updated,
      snackbar: { open: true, message: `Saved "${proj.name}" to My Files`, canUndo: false },
    });
  },

  deleteSavedProject: (id) => {
    const target = get().savedProjects.find((p) => p.id === id);
    const updated = get().savedProjects.filter((p) => p.id !== id);
    saveProjectsToStorage(updated);
    set({
      savedProjects: updated,
      snackbar: {
        open: true,
        message: target ? `Removed "${target.name}"` : 'Removed schematic',
        canUndo: false,
      },
    });
  },

  loadProjectJson: (json) => {
    const proj = deserializeProject(json);
    const withNewId: Project = {
      ...proj,
      id: proj.id || `proj_${Date.now()}`,
      updatedAt: Date.now(),
    };
    const updated = [withNewId, ...get().savedProjects.filter((p) => p.id !== withNewId.id)];
    saveProjectsToStorage(updated);
    set({ savedProjects: updated });
  },

  newBlankProject: (customName, stayOnHome = false) => {
    const starter = createStarterProject();
    const nextNum = get().savedProjects.length + 1;
    const blank: Project = {
      ...starter,
      id: `proj_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      name: customName?.trim() || `Schematic_${nextNum}`,
      updatedAt: Date.now(),
      sheets: starter.sheets.map((s) =>
        s.kind === 'schematic'
          ? { ...s, items: [] }
          : {
               ...s,
              items: s.items.filter((i) => i.type === 'pcb_outline'),
            }
      ),
    };
    const updated = [blank, ...get().savedProjects];
    saveProjectsToStorage(updated);
    const derived = recomputeDerived(blank);
    set({
      savedProjects: updated,
      history: createHistoryState(blank),
      selectedItemId: null,
      schViewport: computeInitialViewport(blank, 'schematic'),
      pcbViewport: computeInitialViewport(blank, 'pcb'),
      schInitialized: false,
      pcbInitialized: false,
      ...(stayOnHome ? { appView: 'home' } : { appView: 'editor', editorMode: 'schematic', activeSheet: 'none' }),
      ...derived,
      snackbar: { open: true, message: `Created "${blank.name}"`, canUndo: false },
    });
  },

  loadStarterProject: () => {
    const proj = { ...createStarterProject(), id: `proj_starter_${Date.now()}` };
    get().openProject(proj, 'schematic');
    set({
      snackbar: { open: true, message: 'Loaded Pocket LED Module', canUndo: false },
    });
  },

  loadBlinkerProject: () => {
    const proj = { ...createBlinkerProject(), id: `proj_blinker_${Date.now()}` };
    get().openProject(proj, 'schematic');
    set({
      snackbar: { open: true, message: 'Loaded NE555 Astable Blinker', canUndo: false },
    });
  },

  openInsertSheet: (subView = 'menu') =>
    set({
      activeSheet: 'insert',
      insertSubView: subView,
    }),

  setInsertSubView: (subView) =>
    set({
      insertSubView: subView,
    }),

  updatePhotoOverlay: (partial) =>
    set((s) => ({
      photoOverlay: { ...s.photoOverlay, ...partial },
    })),

  insertSvgGeometry: (opts) => {
    const cmd = {
      id: `cmd_svg_${Date.now()}`,
      description: 'Insert SVG geometry',
      execute: (proj: Project) => insertSvgIntoProject(proj, opts).project,
    };
    const res = insertSvgIntoProject(get().history.project, opts);
    const nextHistory = executeCommand(get().history, cmd);
    const derived = recomputeDerived(nextHistory.project);
    set({
      history: nextHistory,
      editorMode: 'pcb',
      activeSheet: 'none',
      ...derived,
      snackbar: { open: true, message: res.summary, canUndo: true },
    });
  },

  insertDxfGeometry: (opts) => {
    const res = insertDxfIntoProject(get().history.project, opts);
    const cmd = {
      id: `cmd_dxf_${Date.now()}`,
      description: 'Insert DXF outline',
      execute: () => res.project,
    };
    const nextHistory = executeCommand(get().history, cmd);
    const derived = recomputeDerived(nextHistory.project);
    set({
      history: nextHistory,
      editorMode: 'pcb',
      activeSheet: 'none',
      ...derived,
      snackbar: { open: true, message: res.summary, canUndo: true },
    });
  },

  generateBoardAntenna: (opts) => {
    const res = generatePcbAntenna(get().history.project, opts);
    const cmd = {
      id: `cmd_ant_${Date.now()}`,
      description: `Generate ${opts.frequencyMhz}MHz PCB Antenna`,
      execute: () => res.project,
    };
    const nextHistory = executeCommand(get().history, cmd);
    const derived = recomputeDerived(nextHistory.project);
    set({
      history: nextHistory,
      editorMode: 'pcb',
      activeSheet: 'none',
      ...derived,
      snackbar: { open: true, message: res.summary, canUndo: true },
    });
  },

  generateBoardCoil: (opts) => {
    const res = generatePlanarSpiralCoil(get().history.project, opts);
    const cmd = {
      id: `cmd_coil_${Date.now()}`,
      description: `Generate ${opts.turns}-turn Planar Spiral Coil`,
      execute: () => res.project,
    };
    const nextHistory = executeCommand(get().history, cmd);
    const derived = recomputeDerived(nextHistory.project);
    set({
      history: nextHistory,
      editorMode: 'pcb',
      activeSheet: 'none',
      ...derived,
      snackbar: { open: true, message: res.summary, canUndo: true },
    });
  },

  generateBoardQrBarcode: (opts) => {
    const res = generateQrOrBarcode(get().history.project, opts);
    const cmd = {
      id: `cmd_qr_${Date.now()}`,
      description: `Generate ${opts.format.toUpperCase()} code`,
      execute: () => res.project,
    };
    const nextHistory = executeCommand(get().history, cmd);
    const derived = recomputeDerived(nextHistory.project);
    set({
      history: nextHistory,
      editorMode: 'pcb',
      activeSheet: 'none',
      ...derived,
      snackbar: { open: true, message: res.summary, canUndo: true },
    });
  },

  generateBoardMountingHoles: (opts) => {
    const res = generateMountingHoles(get().history.project, opts);
    const cmd = {
      id: `cmd_mh_${Date.now()}`,
      description: `Add ${opts.screwStandard} mounting holes`,
      execute: () => res.project,
    };
    const nextHistory = executeCommand(get().history, cmd);
    const derived = recomputeDerived(nextHistory.project);
    set({
      history: nextHistory,
      editorMode: 'pcb',
      activeSheet: 'none',
      ...derived,
      snackbar: { open: true, message: res.summary, canUndo: true },
    });
  },

  generateBoardPadViaArray: (opts) => {
    const res = generatePadOrViaArray(get().history.project, opts);
    const cmd = {
      id: `cmd_arr_${Date.now()}`,
      description: `Generate ${opts.rows}x${opts.cols} array`,
      execute: () => res.project,
    };
    const nextHistory = executeCommand(get().history, cmd);
    const derived = recomputeDerived(nextHistory.project);
    set({
      history: nextHistory,
      editorMode: 'pcb',
      activeSheet: 'none',
      ...derived,
      snackbar: { open: true, message: res.summary, canUndo: true },
    });
  },

  generateBoardViaStitching: (opts) => {
    const res = generateViaStitching(get().history.project, opts);
    const cmd = {
      id: `cmd_stitch_${Date.now()}`,
      description: 'Generate via stitching grid',
      execute: () => res.project,
    };
    const nextHistory = executeCommand(get().history, cmd);
    const derived = recomputeDerived(nextHistory.project);
    set({
      history: nextHistory,
      editorMode: 'pcb',
      activeSheet: 'none',
      ...derived,
      snackbar: { open: true, message: res.summary, canUndo: true },
    });
  },

  runAutoDesignators: (opts) => {
    const res = autoNumberDesignators(get().history.project, opts);
    const cmd = {
      id: `cmd_desig_${Date.now()}`,
      description: 'Auto-number designators',
      execute: () => res.project,
    };
    const nextHistory = executeCommand(get().history, cmd);
    const derived = recomputeDerived(nextHistory.project);
    set({
      history: nextHistory,
      activeSheet: 'none',
      ...derived,
      snackbar: { open: true, message: res.summary, canUndo: true },
    });
  },

  openKeypad: (opts) =>
    set({
      keypad: {
        ...opts,
        open: true,
      },
    }),

  closeKeypad: () =>
    set((s) => ({
      keypad: { ...s.keypad, open: false, onCommit: null },
    })),

  openContextMenu: (screenPt, worldPt, itemId) =>
    set({
      selectedItemId: itemId,
      contextMenu: { open: true, screenPt, worldPt, itemId },
    }),

  closeContextMenu: () =>
    set((s) => ({
      contextMenu: { ...s.contextMenu, open: false },
    })),

  showSnackbar: (message, canUndo = false) =>
    set({
      snackbar: { open: true, message, canUndo },
    }),

  dismissSnackbar: () =>
    set((s) => ({
      snackbar: { ...s.snackbar, open: false },
    })),
}));
