import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  distance,
  getComponentPinsWorld,
  getDefaultSymbolDefs,
  getFootprintPadsWorld,
  getOutlinePolygonPoints,
  hitTestPCB,
  hitTestSchematic,
  PCB_GRID,
  SCHEMATIC_GRID,
  screenToWorld,
  snapPoint,
} from '../../core/geometry';
import { computeRatsnest } from '../../core/netlist';
import {
  PcbFootprintItem,
  PcbOutlineItem,
  PcbTraceItem,
  PcbViaItem,
  Point,
  SchComponentItem,
  SchematicComponentKind,
  SchLabelItem,
  SchWireItem,
  SymbolVisualStyle,
} from '../../core/types';
import { TouchGestureRecognizer } from '../gestures/gestureRecognizer';
import { useEditorStore } from '../store/useEditorStore';

function getSymbolStyle(item: SchComponentItem): SymbolVisualStyle {
  if (item.props.symbolStyle) return item.props.symbolStyle;
  const k = item.props.kind;
  if (k === 'R' || k === 'C' || k === 'LED' || k === 'GND' || k === 'VCC' || k === 'CONN2') {
    return k;
  }
  return getDefaultSymbolDefs(k).symbolStyle || 'IC';
}

function drawSymbolBody(ctx: CanvasRenderingContext2D, item: SchComponentItem, isSelected: boolean) {
  const g = SCHEMATIC_GRID;
  const style = getSymbolStyle(item);
  const strokeColor = isSelected ? '#0284c7' : '#840000';
  ctx.strokeStyle = strokeColor;
  ctx.fillStyle = strokeColor;
  ctx.lineWidth = isSelected ? 0.22 : 0.13;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  if (style === 'R') {
    ctx.beginPath();
    ctx.moveTo(-3 * g, 0);
    ctx.lineTo(-1.8 * g, 0);
    ctx.lineTo(-1.4 * g, -0.7 * g);
    ctx.lineTo(-0.7 * g, 0.7 * g);
    ctx.lineTo(0, -0.7 * g);
    ctx.lineTo(0.7 * g, 0.7 * g);
    ctx.lineTo(1.4 * g, -0.7 * g);
    ctx.lineTo(1.8 * g, 0);
    ctx.lineTo(3 * g, 0);
    ctx.stroke();
  } else if (style === 'C') {
    ctx.beginPath();
    ctx.moveTo(-3 * g, 0);
    ctx.lineTo(-0.4 * g, 0);
    ctx.moveTo(0.4 * g, 0);
    ctx.lineTo(3 * g, 0);
    ctx.moveTo(-0.4 * g, -1.15 * g);
    ctx.lineTo(-0.4 * g, 1.15 * g);
    ctx.moveTo(0.4 * g, -1.15 * g);
    ctx.lineTo(0.4 * g, 1.15 * g);
    ctx.stroke();
  } else if (style === 'LED') {
    ctx.fillStyle = isSelected ? 'rgba(2, 132, 199, 0.12)' : 'rgba(132, 0, 0, 0.08)';
    ctx.beginPath();
    ctx.moveTo(-0.85 * g, -0.95 * g);
    ctx.lineTo(-0.85 * g, 0.95 * g);
    ctx.lineTo(0.85 * g, 0);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(-3 * g, 0);
    ctx.lineTo(-0.85 * g, 0);
    ctx.moveTo(0.85 * g, 0);
    ctx.lineTo(3 * g, 0);
    ctx.moveTo(0.85 * g, -0.95 * g);
    ctx.lineTo(0.85 * g, 0.95 * g);
    ctx.moveTo(0.1 * g, -1.15 * g);
    ctx.lineTo(0.85 * g, -1.9 * g);
    ctx.moveTo(0.75 * g, -1.05 * g);
    ctx.lineTo(1.5 * g, -1.8 * g);
    ctx.stroke();
  } else if (style === 'GND') {
    ctx.beginPath();
    ctx.moveTo(0, -2 * g);
    ctx.lineTo(0, 0);
    ctx.moveTo(-1.15 * g, 0);
    ctx.lineTo(1.15 * g, 0);
    ctx.moveTo(-0.72 * g, 0.42 * g);
    ctx.lineTo(0.72 * g, 0.42 * g);
    ctx.moveTo(-0.28 * g, 0.84 * g);
    ctx.lineTo(0.28 * g, 0.84 * g);
    ctx.stroke();
  } else if (style === 'VCC') {
    ctx.beginPath();
    ctx.moveTo(0, 2 * g);
    ctx.lineTo(0, 0);
    ctx.moveTo(-0.9 * g, 0.4 * g);
    ctx.lineTo(0, -0.55 * g);
    ctx.lineTo(0.9 * g, 0.4 * g);
    ctx.stroke();
  } else if (style === 'CONN2') {
    ctx.fillStyle = '#ffffc2';
    ctx.fillRect(-1.0 * g, -1.6 * g, 2.0 * g, 3.2 * g);
    ctx.strokeRect(-1.0 * g, -1.6 * g, 2.0 * g, 3.2 * g);
    ctx.beginPath();
    ctx.moveTo(-2 * g, -g);
    ctx.lineTo(-0.3 * g, -g);
    ctx.moveTo(-2 * g, g);
    ctx.lineTo(-0.3 * g, g);
    ctx.stroke();
  } else if (style === 'SWITCH') {
    ctx.beginPath();
    ctx.moveTo(-3 * g, 0);
    ctx.lineTo(-1.0 * g, 0);
    ctx.moveTo(1.0 * g, 0);
    ctx.lineTo(3 * g, 0);
    ctx.moveTo(-1.2 * g, -0.65 * g);
    ctx.lineTo(1.2 * g, -0.65 * g);
    ctx.moveTo(0, -0.65 * g);
    ctx.lineTo(0, -1.3 * g);
    ctx.stroke();
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(-1.0 * g, 0, 0.28 * g, 0, Math.PI * 2);
    ctx.arc(1.0 * g, 0, 0.28 * g, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  } else if (style === 'CRYSTAL') {
    ctx.fillStyle = '#ffffc2';
    ctx.fillRect(-0.55 * g, -1.1 * g, 1.1 * g, 2.2 * g);
    ctx.strokeRect(-0.55 * g, -1.1 * g, 1.1 * g, 2.2 * g);
    ctx.beginPath();
    ctx.moveTo(-3 * g, 0);
    ctx.lineTo(-0.95 * g, 0);
    ctx.moveTo(-0.95 * g, -0.85 * g);
    ctx.lineTo(-0.95 * g, 0.85 * g);
    ctx.moveTo(3 * g, 0);
    ctx.lineTo(0.95 * g, 0);
    ctx.moveTo(0.95 * g, -0.85 * g);
    ctx.lineTo(0.95 * g, 0.85 * g);
    ctx.stroke();
  } else if (style === 'OPAMP') {
    ctx.fillStyle = '#ffffc2';
    ctx.beginPath();
    ctx.moveTo(-1.8 * g, -1.8 * g);
    ctx.lineTo(-1.8 * g, 1.8 * g);
    ctx.lineTo(1.8 * g, 0);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(-3 * g, -1 * g);
    ctx.lineTo(-1.8 * g, -1 * g);
    ctx.moveTo(-3 * g, 1 * g);
    ctx.lineTo(-1.8 * g, 1 * g);
    ctx.moveTo(1.8 * g, 0);
    ctx.lineTo(3 * g, 0);
    ctx.moveTo(0, -2 * g);
    ctx.lineTo(0, -0.9 * g);
    ctx.moveTo(0, 2 * g);
    ctx.lineTo(0, 0.9 * g);
    ctx.moveTo(-1.45 * g, -1 * g);
    ctx.lineTo(-1.05 * g, -1 * g);
    ctx.moveTo(-1.45 * g, 1 * g);
    ctx.lineTo(-1.05 * g, 1 * g);
    ctx.moveTo(-1.25 * g, 0.8 * g);
    ctx.lineTo(-1.25 * g, 1.2 * g);
    ctx.stroke();
  } else if (style === 'TRANSISTOR') {
    ctx.fillStyle = '#ffffc2';
    ctx.beginPath();
    ctx.arc(0, 0, 1.55 * g, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(-3 * g, 0);
    ctx.lineTo(-0.55 * g, 0);
    ctx.moveTo(-0.55 * g, -0.95 * g);
    ctx.lineTo(-0.55 * g, 0.95 * g);
    ctx.moveTo(-0.55 * g, -0.45 * g);
    ctx.lineTo(1 * g, -1.3 * g);
    ctx.lineTo(1 * g, -2 * g);
    ctx.moveTo(-0.55 * g, 0.45 * g);
    ctx.lineTo(1 * g, 1.3 * g);
    ctx.lineTo(1 * g, 2 * g);
    ctx.stroke();
  } else {
    let maxAbsY = 1.5 * g;
    for (const pin of item.props.pins) {
      if (Math.abs(pin.offset.y) > maxAbsY) {
        maxAbsY = Math.abs(pin.offset.y);
      }
    }
    const bodyHalfW = 2.6 * g;
    const bodyHalfH = maxAbsY + 0.85 * g;

    ctx.fillStyle = '#ffffc2';
    ctx.fillRect(-bodyHalfW, -bodyHalfH, bodyHalfW * 2, bodyHalfH * 2);
    ctx.strokeRect(-bodyHalfW, -bodyHalfH, bodyHalfW * 2, bodyHalfH * 2);

    ctx.beginPath();
    ctx.arc(0, -bodyHalfH, 0.45 * g, 0, Math.PI);
    ctx.stroke();

    for (const pin of item.props.pins) {
      const sign = pin.offset.x < 0 ? -1 : 1;
      ctx.beginPath();
      ctx.moveTo(pin.offset.x, pin.offset.y);
      ctx.lineTo(sign * bodyHalfW, pin.offset.y);
      ctx.stroke();

      ctx.fillStyle = '#006464';
      ctx.font = '600 0.72px ui-monospace, monospace';
      ctx.textAlign = sign < 0 ? 'left' : 'right';
      ctx.fillText(pin.name, sign * (bodyHalfW - 0.32), pin.offset.y + 0.25);

      ctx.fillStyle = '#840000';
      ctx.font = '600 0.65px ui-monospace, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(pin.number, sign * (bodyHalfW + 0.65), pin.offset.y - 0.2);
    }
  }
}

interface SchematicInteractionDraft {
  wireStart: Point | null;
  wireCurrent: Point | null;
  draggingItemId: string | null;
  dragOffsetWorld: Point;
  dragPreviewPos: Point | null;
}

export const SchematicCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [, setRenderTick] = useState(0);
  const triggerRender = () => setRenderTick((t) => t + 1);

  const {
    history,
    schTool,
    selectedItemId,
    schViewport,
    netlist,
    setViewport,
    selectItem,
    placeSchematicComponent,
    addSchematicWire,
    addSchematicLabel,
    moveItem,
    fitViewport,
    openContextMenu,
    closeContextMenu,
    openKeypad,
    setActiveSheet,
  } = useEditorStore();

  const draftRef = useRef<SchematicInteractionDraft>({
    wireStart: null,
    wireCurrent: null,
    draggingItemId: null,
    dragOffsetWorld: { x: 0, y: 0 },
    dragPreviewPos: null,
  });

  const schSheet = useMemo(
    () => history.project.sheets.find((s) => s.kind === 'schematic')!,
    [history.project]
  );

  useEffect(() => {
    const canvas = canvasRef.current;
    if (canvas && !useEditorStore.getState().schInitialized) {
      const w = canvas.clientWidth || window.innerWidth;
      const h = canvas.clientHeight || window.innerHeight;
      if (w > 0 && h > 0) {
        fitViewport(w, h, 'schematic');
        useEditorStore.setState({ schInitialized: true });
      }
    }
  }, [fitViewport, history.project.id]);

  useEffect(() => {
    if (schTool !== 'wire') {
      draftRef.current.wireStart = null;
      draftRef.current.wireCurrent = null;
      triggerRender();
    }
  }, [schTool]);

  const stateRef = useRef({
    schSheet,
    schTool,
    selectedItemId,
    schViewport,
  });
  stateRef.current = {
    schSheet,
    schTool,
    selectedItemId,
    schViewport,
  };

  const recognizer = useMemo(
    () =>
      new TouchGestureRecognizer({
        onTap: (screenPt) => {
          closeContextMenu();
          const st = stateRef.current;
          const draft = draftRef.current;
          const worldPt = screenToWorld(screenPt, st.schViewport);
          const snapped = snapPoint(worldPt, SCHEMATIC_GRID);

          if (st.schTool.startsWith('place_')) {
            const kind = st.schTool.replace('place_', '') as SchematicComponentKind;
            placeSchematicComponent(kind, snapped);
            return;
          }

          if (st.schTool === 'label') {
            openKeypad({
              title: 'Net Label Name',
              initialValue: 'SIG_1',
              unit: '',
              allowLetters: true,
              onCommit: (val) => {
                if (val.trim()) addSchematicLabel(val.trim(), snapped);
              },
            });
            return;
          }

          const hit = hitTestSchematic(st.schSheet.items, worldPt, st.schViewport.scale);

          if (st.schTool === 'wire') {
            const targetPt = hit?.pin ? hit.pin.world : snapped;
            if (!draft.wireStart) {
              draft.wireStart = targetPt;
              draft.wireCurrent = targetPt;
              triggerRender();
            } else {
              const s = draft.wireStart;
              const e = targetPt;
              if (Math.hypot(e.x - s.x, e.y - s.y) > 0.1) {
                const elbow: Point = { x: e.x, y: s.y };
                const pts =
                  Math.abs(e.x - s.x) > 0.01 && Math.abs(e.y - s.y) > 0.01
                    ? [s, elbow, e]
                    : [s, e];
                addSchematicWire(pts);
              }
              if (hit?.pin) {
                draft.wireStart = null;
                draft.wireCurrent = null;
              } else {
                draft.wireStart = e;
                draft.wireCurrent = e;
              }
              triggerRender();
            }
            return;
          }

          if (hit) {
            if (hit.pin) {
              draft.wireStart = hit.pin.world;
              draft.wireCurrent = hit.pin.world;
              useEditorStore.getState().setSchTool('wire');
              triggerRender();
              return;
            }
            selectItem(hit.item.id);
          } else {
            selectItem(null);
            setActiveSheet('none');
          }
        },

        onDoubleTap: () => {
          draftRef.current.wireStart = null;
          draftRef.current.wireCurrent = null;
          const canvas = canvasRef.current;
          if (canvas) {
            fitViewport(canvas.clientWidth, canvas.clientHeight, 'schematic');
          }
        },

        onLongPress: (screenPt) => {
          const st = stateRef.current;
          const worldPt = screenToWorld(screenPt, st.schViewport);
          const hit = hitTestSchematic(st.schSheet.items, worldPt, st.schViewport.scale);
          openContextMenu(screenPt, snapPoint(worldPt, SCHEMATIC_GRID), hit?.item.id ?? null);
        },

        onDragStart: (screenPt) => {
          closeContextMenu();
          const st = stateRef.current;
          const draft = draftRef.current;
          const worldPt = screenToWorld(screenPt, st.schViewport);
          const hit = hitTestSchematic(st.schSheet.items, worldPt, st.schViewport.scale);

          if (st.schTool === 'wire' || hit?.pin) {
            const pt = hit?.pin ? hit.pin.world : snapPoint(worldPt, SCHEMATIC_GRID);
            if (!draft.wireStart) {
              draft.wireStart = pt;
            }
            draft.wireCurrent = pt;
            draft.draggingItemId = null;
            triggerRender();
            return;
          }

          if (hit && hit.item.type !== 'sch_wire') {
            selectItem(hit.item.id);
            draft.draggingItemId = hit.item.id;
            draft.dragOffsetWorld = {
              x: worldPt.x - hit.item.transform.x,
              y: worldPt.y - hit.item.transform.y,
            };
            draft.dragPreviewPos = {
              x: hit.item.transform.x,
              y: hit.item.transform.y,
            };
            triggerRender();
          } else {
            draft.draggingItemId = null;
            draft.dragPreviewPos = null;
          }
        },

        onDragMove: (screenPt, deltaScreen) => {
          const st = stateRef.current;
          const draft = draftRef.current;
          const worldPt = screenToWorld(screenPt, st.schViewport);

          if (draft.wireStart) {
            const hit = hitTestSchematic(st.schSheet.items, worldPt, st.schViewport.scale);
            draft.wireCurrent = hit?.pin ? hit.pin.world : snapPoint(worldPt, SCHEMATIC_GRID);
            triggerRender();
            return;
          }

          if (draft.draggingItemId) {
            const rawTarget = {
              x: worldPt.x - draft.dragOffsetWorld.x,
              y: worldPt.y - draft.dragOffsetWorld.y,
            };
            draft.dragPreviewPos = snapPoint(rawTarget, SCHEMATIC_GRID);
            triggerRender();
          } else {
            const currVp = useEditorStore.getState().schViewport;
            setViewport('schematic', {
              ...currVp,
              panX: currVp.panX + deltaScreen.x,
              panY: currVp.panY + deltaScreen.y,
            });
          }
        },

        onDragEnd: () => {
          const draft = draftRef.current;
          if (draft.wireStart && draft.wireCurrent) {
            const s = draft.wireStart;
            const e = draft.wireCurrent;
            if (Math.hypot(e.x - s.x, e.y - s.y) >= SCHEMATIC_GRID * 0.5) {
              const elbow: Point = { x: e.x, y: s.y };
              const pts =
                Math.abs(e.x - s.x) > 0.01 && Math.abs(e.y - s.y) > 0.01
                  ? [s, elbow, e]
                  : [s, e];
              addSchematicWire(pts);
              draft.wireStart = null;
              draft.wireCurrent = null;
            }
          }
          if (draft.draggingItemId && draft.dragPreviewPos) {
            moveItem(draft.draggingItemId, draft.dragPreviewPos);
          }
          draft.draggingItemId = null;
          draft.dragPreviewPos = null;
          triggerRender();
        },

        onPanPinch: (deltaPan, scaleFactor, centerScreen) => {
          const vp = useEditorStore.getState().schViewport;
          const newScale = Math.max(3, Math.min(65, vp.scale * scaleFactor));
          const ratio = newScale / vp.scale;
          const panX = centerScreen.x - (centerScreen.x - vp.panX) * ratio + deltaPan.x;
          const panY = centerScreen.y - (centerScreen.y - vp.panY) * ratio + deltaPan.y;
          setViewport('schematic', { panX, panY, scale: newScale });
        },
      }),
    [
      addSchematicLabel,
      addSchematicWire,
      closeContextMenu,
      fitViewport,
      moveItem,
      openContextMenu,
      openKeypad,
      placeSchematicComponent,
      selectItem,
      setActiveSheet,
      setViewport,
    ]
  );

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let animId = 0;

    const render = () => {
      const dpr = window.devicePixelRatio || 1;
      const width = canvas.clientWidth || window.innerWidth;
      const height = canvas.clientHeight || window.innerHeight;
      if (canvas.width !== Math.floor(width * dpr) || canvas.height !== Math.floor(height * dpr)) {
        canvas.width = Math.floor(width * dpr);
        canvas.height = Math.floor(height * dpr);
      }

      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const draft = draftRef.current;

      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, width, height);

      const vp = schViewport;
      ctx.save();
      ctx.translate(vp.panX, vp.panY);
      ctx.scale(vp.scale, vp.scale);

      const startX = Math.floor(-vp.panX / vp.scale / SCHEMATIC_GRID) * SCHEMATIC_GRID;
      const endX = Math.ceil((width - vp.panX) / vp.scale / SCHEMATIC_GRID) * SCHEMATIC_GRID;
      const startY = Math.floor(-vp.panY / vp.scale / SCHEMATIC_GRID) * SCHEMATIC_GRID;
      const endY = Math.ceil((height - vp.panY) / vp.scale / SCHEMATIC_GRID) * SCHEMATIC_GRID;

      const majorStep = SCHEMATIC_GRID * 5;
      const majorStartX = Math.floor(-vp.panX / vp.scale / majorStep) * majorStep;
      const majorStartY = Math.floor(-vp.panY / vp.scale / majorStep) * majorStep;
      ctx.strokeStyle = '#f1f5f9';
      ctx.lineWidth = Math.max(0.04, 0.8 / vp.scale);
      ctx.beginPath();
      for (let x = majorStartX; x <= endX; x += majorStep) {
        ctx.moveTo(x, startY);
        ctx.lineTo(x, endY);
      }
      for (let y = majorStartY; y <= endY; y += majorStep) {
        ctx.moveTo(startX, y);
        ctx.lineTo(endX, y);
      }
      ctx.stroke();

      const step = vp.scale < 7 ? SCHEMATIC_GRID * 2 : SCHEMATIC_GRID;
      ctx.fillStyle = '#cbd5e1';
      const dotSize = Math.max(0.08, 1.25 / vp.scale);

      for (let x = startX; x <= endX; x += step) {
        for (let y = startY; y <= endY; y += step) {
          ctx.fillRect(x - dotSize / 2, y - dotSize / 2, dotSize, dotSize);
        }
      }

      ctx.strokeStyle = '#840000';
      ctx.lineWidth = 0.12;
      ctx.strokeRect(2 * SCHEMATIC_GRID, 2 * SCHEMATIC_GRID, 36 * SCHEMATIC_GRID, 22 * SCHEMATIC_GRID);
      ctx.strokeRect(24 * SCHEMATIC_GRID, 21 * SCHEMATIC_GRID, 14 * SCHEMATIC_GRID, 3 * SCHEMATIC_GRID);
      ctx.fillStyle = '#840000';
      ctx.font = '700 0.9px ui-monospace, monospace';
      ctx.textAlign = 'left';
      ctx.fillText(
        `SHEET: ${history.project.name.toUpperCase()}`,
        24.6 * SCHEMATIC_GRID,
        22.3 * SCHEMATIC_GRID
      );
      ctx.fillStyle = '#006464';
      ctx.font = '500 0.72px ui-monospace, monospace';
      ctx.fillText(
        'KiCad Eeschema · 1.27mm Grid',
        24.6 * SCHEMATIC_GRID,
        23.4 * SCHEMATIC_GRID
      );

      for (const item of schSheet.items) {
        if (item.type !== 'sch_wire') continue;
        const w = item as SchWireItem;
        const isSel = w.id === selectedItemId;
        const pts = w.props.points;
        if (pts.length < 2) continue;

        ctx.strokeStyle = isSel ? '#0284c7' : '#008400';
        ctx.lineWidth = isSel ? 0.22 : 0.11;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.beginPath();
        ctx.moveTo(pts[0].x, pts[0].y);
        for (let i = 1; i < pts.length; i++) {
          ctx.lineTo(pts[i].x, pts[i].y);
        }
        ctx.stroke();

        ctx.fillStyle = isSel ? '#0284c7' : '#008400';
        for (const pt of [pts[0], pts[pts.length - 1]]) {
          ctx.beginPath();
          ctx.arc(pt.x, pt.y, 0.16, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      for (const item of schSheet.items) {
        if (item.type !== 'sch_component') continue;
        const comp = item as SchComponentItem;
        const isSel = comp.id === selectedItemId;
        const pos =
          comp.id === draft.draggingItemId && draft.dragPreviewPos
            ? draft.dragPreviewPos
            : { x: comp.transform.x, y: comp.transform.y };

        const previewComp: SchComponentItem = {
          ...comp,
          transform: { ...comp.transform, x: pos.x, y: pos.y },
        };

        const style = getSymbolStyle(comp);
        let maxAbsY = 1.5 * SCHEMATIC_GRID;
        for (const pin of comp.props.pins) {
          if (Math.abs(pin.offset.y) > maxAbsY) {
            maxAbsY = Math.abs(pin.offset.y);
          }
        }
        const labelOffsetY = style === 'IC' ? maxAbsY + 1.45 * SCHEMATIC_GRID : 2.1;

        ctx.save();
        ctx.translate(pos.x, pos.y);
        ctx.rotate((comp.transform.rotation * Math.PI) / 180);

        if (isSel) {
          ctx.fillStyle = 'rgba(2, 132, 199, 0.08)';
          ctx.beginPath();
          ctx.arc(0, 0, style === 'IC' ? maxAbsY + 2.2 : 3.2, 0, Math.PI * 2);
          ctx.fill();
        }

        drawSymbolBody(ctx, previewComp, isSel);
        ctx.restore();

        const pins = getComponentPinsWorld(previewComp);
        for (const p of pins) {
          const pinNet = netlist.padNetMap[`${comp.props.refDes}:${p.pin.number}`];
          if (pinNet) {
            ctx.fillStyle = '#008400';
            ctx.beginPath();
            ctx.arc(p.world.x, p.world.y, 0.2, 0, Math.PI * 2);
            ctx.fill();
          } else {
            ctx.strokeStyle = '#840000';
            ctx.lineWidth = 0.1;
            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.arc(p.world.x, p.world.y, 0.24, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();
          }
        }

        ctx.textAlign = 'center';
        if (comp.props.kind !== 'GND' && comp.props.kind !== 'VCC') {
          ctx.fillStyle = '#006464';
          ctx.font = '700 1.15px ui-monospace, SFMono-Regular, Menlo, monospace';
          ctx.fillText(comp.props.refDes, pos.x, pos.y - labelOffsetY);
          ctx.fillStyle = '#008484';
          ctx.font = '600 1.0px ui-monospace, SFMono-Regular, Menlo, monospace';
          ctx.fillText(comp.props.value, pos.x, pos.y + labelOffsetY + 0.7);
        } else {
          ctx.fillStyle = '#840000';
          ctx.font = '700 1.05px ui-monospace, SFMono-Regular, Menlo, monospace';
          ctx.fillText(comp.props.value, pos.x, pos.y + (comp.props.kind === 'VCC' ? -1.2 : 2.1));
        }
      }

      for (const item of schSheet.items) {
        if (item.type !== 'sch_label') continue;
        const lbl = item as SchLabelItem;
        const isSel = lbl.id === selectedItemId;
        const pos =
          lbl.id === draft.draggingItemId && draft.dragPreviewPos
            ? draft.dragPreviewPos
            : { x: lbl.transform.x, y: lbl.transform.y };

        ctx.fillStyle = isSel ? '#0284c7' : '#008400';
        ctx.beginPath();
        ctx.arc(pos.x, pos.y, 0.22, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = isSel ? '#0284c7' : '#0f172a';
        ctx.font = '700 1.1px ui-monospace, monospace';
        ctx.textAlign = 'left';
        ctx.fillText(lbl.props.text, pos.x + 0.35, pos.y - 0.3);
      }

      if (draft.wireStart && draft.wireCurrent) {
        const elbow = { x: draft.wireCurrent.x, y: draft.wireStart.y };
        ctx.strokeStyle = '#008400';
        ctx.lineWidth = 0.14;
        ctx.setLineDash([0.35, 0.25]);
        ctx.beginPath();
        ctx.moveTo(draft.wireStart.x, draft.wireStart.y);
        ctx.lineTo(elbow.x, elbow.y);
        ctx.lineTo(draft.wireCurrent.x, draft.wireCurrent.y);
        ctx.stroke();
        ctx.setLineDash([]);

        ctx.fillStyle = '#0284c7';
        ctx.beginPath();
        ctx.arc(draft.wireStart.x, draft.wireStart.y, 0.3, 0, Math.PI * 2);
        ctx.arc(draft.wireCurrent.x, draft.wireCurrent.y, 0.3, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();

      if (schSheet.items.length === 0) {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.94)';
        const boxW = Math.min(280, width - 32);
        const boxH = 84;
        const bx = (width - boxW) / 2;
        const by = height / 2 - boxH / 2;
        ctx.beginPath();
        ctx.roundRect(bx, by, boxW, boxH, 16);
        ctx.fill();
        ctx.strokeStyle = '#cbd5e1';
        ctx.lineWidth = 1.5;
        ctx.stroke();

        ctx.fillStyle = '#0f172a';
        ctx.font = '700 14px ui-sans-serif, system-ui, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('Schematic Sheet Empty', width / 2, by + 34);
        ctx.fillStyle = '#475569';
        ctx.font = '500 12px ui-sans-serif, system-ui, sans-serif';
        ctx.fillText('Tap Library below to pick or download parts', width / 2, by + 56);
      }
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  });

  useEffect(() => {
    const handleResize = () => {
      const vp = useEditorStore.getState().schViewport;
      setViewport('schematic', { ...vp });
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [setViewport]);

  return (
    <canvas
      ref={canvasRef}
      className="w-full h-full block touch-none select-none bg-white"
      onPointerDown={recognizer.handlePointerDown}
      onPointerMove={recognizer.handlePointerMove}
      onPointerUp={recognizer.handlePointerUpOrCancel}
      onPointerCancel={recognizer.handlePointerUpOrCancel}
    />
  );
};

interface PcbInteractionDraft {
  traceStart: {
    pt: Point;
    net: string;
    refDes?: string;
    padNum?: string;
  } | null;
  traceCurrent: Point | null;
  airwireStart: {
    pt: Point;
    refDes: string;
    padNum: string;
  } | null;
  airwireCurrent: Point | null;
  outlineStart: Point | null;
  outlineCurrent: Point | null;
  measureStart: Point | null;
  measureCurrent: Point | null;
  draggingOutlineVertex: number | null;
  outlineVertexPreview: Point | null;
  draggingItemId: string | null;
  dragOffsetWorld: Point;
  dragPreviewPos: Point | null;
  lastTouchScreen: Point | null;
  lastTouchWorld: Point | null;
}

export const PcbCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const overlayImgRef = useRef<{ src: string; img: HTMLImageElement; loaded: boolean } | null>(
    null
  );
  const [, setRenderTick] = useState(0);
  const triggerRender = () => setRenderTick((t) => t + 1);

  const {
    history,
    pcbTool,
    activePcbLayer,
    boardConfig,
    viewConfig,
    photoOverlay,
    selectedItemId,
    pcbViewport,
    layerVisibility,
    netlist,
    ratsnest,
    drcViolations,
    highlightedViolation,
    traceWidth,
    setViewport,
    selectItem,
    placePcbFootprint,
    addPcbTrace,
    connectPcbPadsAirwire,
    addPcbVia,
    updateBoardOutline,
    splitBoardOutlineEdge,
    moveBoardOutlineVertex,
    moveItem,
    fitViewport,
    openContextMenu,
    closeContextMenu,
    setActiveSheet,
  } = useEditorStore();

  useEffect(() => {
    if (!photoOverlay.dataUrl) {
      overlayImgRef.current = null;
      triggerRender();
      return;
    }
    if (overlayImgRef.current?.src === photoOverlay.dataUrl) return;
    const img = new Image();
    const record = { src: photoOverlay.dataUrl, img, loaded: false };
    overlayImgRef.current = record;
    img.onload = () => {
      record.loaded = true;
      triggerRender();
    };
    img.src = photoOverlay.dataUrl;
  }, [photoOverlay.dataUrl]);

  const draftRef = useRef<PcbInteractionDraft>({
    traceStart: null,
    traceCurrent: null,
    airwireStart: null,
    airwireCurrent: null,
    outlineStart: null,
    outlineCurrent: null,
    measureStart: null,
    measureCurrent: null,
    draggingOutlineVertex: null,
    outlineVertexPreview: null,
    draggingItemId: null,
    dragOffsetWorld: { x: 0, y: 0 },
    dragPreviewPos: null,
    lastTouchScreen: null,
    lastTouchWorld: null,
  });

  const pcbSheet = useMemo(
    () => history.project.sheets.find((s) => s.kind === 'pcb')!,
    [history.project]
  );

  useEffect(() => {
    const canvas = canvasRef.current;
    if (canvas && !useEditorStore.getState().pcbInitialized) {
      const w = canvas.clientWidth || window.innerWidth;
      const h = canvas.clientHeight || window.innerHeight;
      if (w > 0 && h > 0) {
        fitViewport(w, h, 'pcb');
        useEditorStore.setState({ pcbInitialized: true });
      }
    }
  }, [fitViewport, history.project.id]);

  useEffect(() => {
    draftRef.current.traceStart = null;
    draftRef.current.traceCurrent = null;
    draftRef.current.airwireStart = null;
    draftRef.current.airwireCurrent = null;
    draftRef.current.outlineStart = null;
    draftRef.current.outlineCurrent = null;
    draftRef.current.measureStart = null;
    draftRef.current.measureCurrent = null;
    draftRef.current.draggingOutlineVertex = null;
    draftRef.current.outlineVertexPreview = null;
    triggerRender();
  }, [pcbTool]);

  const stateRef = useRef({
    pcbSheet,
    pcbTool,
    activePcbLayer,
    boardConfig,
    viewConfig,
    selectedItemId,
    pcbViewport,
    netlist,
  });
  stateRef.current = {
    pcbSheet,
    pcbTool,
    activePcbLayer,
    boardConfig,
    viewConfig,
    selectedItemId,
    pcbViewport,
    netlist,
  };

  const recognizer = useMemo(
    () =>
      new TouchGestureRecognizer({
        onTap: (screenPt) => {
          closeContextMenu();
          const st = stateRef.current;
          const draft = draftRef.current;
          const grid = st.boardConfig.gridSize || PCB_GRID;
          const worldPt = screenToWorld(screenPt, st.pcbViewport);
          const snapped = snapPoint(worldPt, grid);
          draft.lastTouchScreen = screenPt;
          draft.lastTouchWorld = snapped;

          if (st.pcbTool.startsWith('place_')) {
            const kind = st.pcbTool.replace('place_', '') as SchematicComponentKind;
            placePcbFootprint(kind, snapped);
            return;
          }

          if (st.pcbTool === 'measure') {
            if (!draft.measureStart) {
              draft.measureStart = snapped;
              draft.measureCurrent = snapped;
            } else {
              draft.measureCurrent = snapped;
            }
            triggerRender();
            return;
          }

          // Check if tapping an edge midpoint split handle on the board outline
          const outlineItem = st.pcbSheet.items.find(
            (i): i is PcbOutlineItem => i.type === 'pcb_outline'
          );
          if (
            outlineItem &&
            (st.pcbTool === 'outline' || st.selectedItemId === outlineItem.id)
          ) {
            const pts = getOutlinePolygonPoints(outlineItem);
            const handleRadius = Math.max(1.6, 22 / st.pcbViewport.scale);
            for (let i = 0; i < pts.length; i++) {
              const a = pts[i];
              const b = pts[(i + 1) % pts.length];
              const mid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
              if (distance(worldPt, mid) <= handleRadius) {
                splitBoardOutlineEdge(i);
                selectItem(outlineItem.id);
                triggerRender();
                return;
              }
            }
          }

          const hit = hitTestPCB(st.pcbSheet.items, worldPt, st.pcbViewport.scale);

          if (st.pcbTool === 'via') {
            const viaNet =
              hit?.pad && hit.item.type === 'pcb_footprint'
                ? st.netlist.padNetMap[`${hit.item.props.refDes}:${hit.pad.pad.number}`] ||
                  hit.pad.pad.net ||
                  ''
                : hit?.item.type === 'pcb_trace'
                  ? hit.item.props.net
                  : '';
            addPcbVia(snapped, viaNet);
            return;
          }

          if (st.pcbTool === 'airwire') {
            if (hit?.pad && hit.item.type === 'pcb_footprint') {
              const refDes = hit.item.props.refDes;
              const padNum = hit.pad.pad.number;
              if (!draft.airwireStart) {
                draft.airwireStart = { pt: hit.pad.world, refDes, padNum };
                draft.airwireCurrent = hit.pad.world;
                triggerRender();
              } else {
                if (
                  draft.airwireStart.refDes !== refDes ||
                  draft.airwireStart.padNum !== padNum
                ) {
                  connectPcbPadsAirwire(
                    draft.airwireStart.refDes,
                    draft.airwireStart.padNum,
                    refDes,
                    padNum
                  );
                }
                draft.airwireStart = null;
                draft.airwireCurrent = null;
                triggerRender();
              }
            } else {
              draft.airwireStart = null;
              draft.airwireCurrent = null;
              triggerRender();
            }
            return;
          }

          if (st.pcbTool === 'trace_top' || st.pcbTool === 'trace_bottom') {
            const layer: 'F.Cu' | 'B.Cu' = st.pcbTool === 'trace_top' ? 'F.Cu' : 'B.Cu';
            const snapTarget = hit?.pad
              ? hit.pad.world
              : hit?.item.type === 'pcb_via'
                ? { x: hit.item.transform.x, y: hit.item.transform.y }
                : snapped;
            const targetRefDes =
              hit?.pad && hit.item.type === 'pcb_footprint' ? hit.item.props.refDes : undefined;
            const targetPadNum = hit?.pad ? hit.pad.pad.number : undefined;
            const targetNet =
              hit?.pad && hit.item.type === 'pcb_footprint'
                ? st.netlist.padNetMap[`${hit.item.props.refDes}:${hit.pad.pad.number}`] ||
                  hit.pad.pad.net ||
                  ''
                : hit?.item.type === 'pcb_via'
                  ? hit.item.props.net
                  : '';

            if (!draft.traceStart) {
              draft.traceStart = {
                pt: snapTarget,
                net: targetNet,
                refDes: targetRefDes,
                padNum: targetPadNum,
              };
              draft.traceCurrent = snapTarget;
              triggerRender();
            } else {
              const s = draft.traceStart.pt;
              const e = snapTarget;
              let netToUse = draft.traceStart.net || targetNet;

              if (
                draft.traceStart.refDes &&
                draft.traceStart.padNum &&
                targetRefDes &&
                targetPadNum &&
                (draft.traceStart.refDes !== targetRefDes ||
                  draft.traceStart.padNum !== targetPadNum) &&
                !netToUse
              ) {
                connectPcbPadsAirwire(
                  draft.traceStart.refDes,
                  draft.traceStart.padNum,
                  targetRefDes,
                  targetPadNum
                );
                const refreshed = useEditorStore.getState().netlist;
                netToUse =
                  refreshed.padNetMap[`${targetRefDes}:${targetPadNum}`] || netToUse;
              }

              if (Math.hypot(e.x - s.x, e.y - s.y) > 0.05) {
                const dx = e.x - s.x;
                const dy = e.y - s.y;
                const diag = Math.min(Math.abs(dx), Math.abs(dy));
                const mid: Point = {
                  x: Number((s.x + Math.sign(dx) * diag).toFixed(3)),
                  y: Number((s.y + Math.sign(dy) * diag).toFixed(3)),
                };
                const pts = diag > 0.05 ? [s, mid, e] : [s, e];
                addPcbTrace(pts, layer, netToUse);
              }
              if (hit?.pad || hit?.item.type === 'pcb_via') {
                draft.traceStart = null;
                draft.traceCurrent = null;
              } else {
                draft.traceStart = { pt: e, net: netToUse };
                draft.traceCurrent = e;
              }
              triggerRender();
            }
            return;
          }

          if (hit) {
            selectItem(hit.item.id);
          } else {
            selectItem(null);
            setActiveSheet('none');
          }
        },

        onDoubleTap: () => {
          draftRef.current.traceStart = null;
          draftRef.current.traceCurrent = null;
          draftRef.current.airwireStart = null;
          draftRef.current.airwireCurrent = null;
          const canvas = canvasRef.current;
          if (canvas) {
            fitViewport(canvas.clientWidth, canvas.clientHeight, 'pcb');
          }
        },

        onLongPress: (screenPt) => {
          const st = stateRef.current;
          const worldPt = screenToWorld(screenPt, st.pcbViewport);
          const hit = hitTestPCB(st.pcbSheet.items, worldPt, st.pcbViewport.scale);
          openContextMenu(screenPt, snapPoint(worldPt, PCB_GRID), hit?.item.id ?? null);
        },

        onDragStart: (screenPt) => {
          closeContextMenu();
          const st = stateRef.current;
          const draft = draftRef.current;
          const grid = st.boardConfig.gridSize || PCB_GRID;
          const worldPt = screenToWorld(screenPt, st.pcbViewport);
          const snapped = snapPoint(worldPt, grid);
          const hit = hitTestPCB(st.pcbSheet.items, worldPt, st.pcbViewport.scale);
          draft.lastTouchScreen = screenPt;
          draft.lastTouchWorld = snapped;

          // Check if dragging a board outline vertex handle
          const outlineItem = st.pcbSheet.items.find(
            (i): i is PcbOutlineItem => i.type === 'pcb_outline'
          );
          if (
            outlineItem &&
            (st.pcbTool === 'outline' || st.selectedItemId === outlineItem.id)
          ) {
            const pts = getOutlinePolygonPoints(outlineItem);
            const handleRadius = Math.max(1.8, 24 / st.pcbViewport.scale);
            for (let i = 0; i < pts.length; i++) {
              if (distance(worldPt, pts[i]) <= handleRadius) {
                selectItem(outlineItem.id);
                draft.draggingOutlineVertex = i;
                draft.outlineVertexPreview = snapped;
                draft.outlineStart = null;
                draft.outlineCurrent = null;
                draft.draggingItemId = null;
                triggerRender();
                return;
              }
            }
          }

          if (st.pcbTool === 'outline') {
            draft.outlineStart = snapped;
            draft.outlineCurrent = snapped;
            draft.draggingItemId = null;
            triggerRender();
            return;
          }

          if (st.pcbTool === 'measure') {
            draft.measureStart = snapped;
            draft.measureCurrent = snapped;
            draft.draggingItemId = null;
            triggerRender();
            return;
          }

          if (st.pcbTool === 'airwire') {
            if (hit?.pad && hit.item.type === 'pcb_footprint') {
              if (!draft.airwireStart) {
                draft.airwireStart = {
                  pt: hit.pad.world,
                  refDes: hit.item.props.refDes,
                  padNum: hit.pad.pad.number,
                };
              }
              draft.airwireCurrent = hit.pad.world;
              draft.draggingItemId = null;
              triggerRender();
              return;
            }
          }

          if (st.pcbTool === 'trace_top' || st.pcbTool === 'trace_bottom') {
            const padWorld = hit?.pad
              ? hit.pad.world
              : hit?.item.type === 'pcb_via'
                ? { x: hit.item.transform.x, y: hit.item.transform.y }
                : snapped;
            const padRefDes =
              hit?.pad && hit.item.type === 'pcb_footprint' ? hit.item.props.refDes : undefined;
            const padNum = hit?.pad ? hit.pad.pad.number : undefined;
            const padNet =
              hit?.pad && hit.item.type === 'pcb_footprint'
                ? st.netlist.padNetMap[`${hit.item.props.refDes}:${hit.pad.pad.number}`] ||
                  hit.pad.pad.net ||
                  ''
                : hit?.item.type === 'pcb_via'
                  ? hit.item.props.net
                  : '';
            if (!draft.traceStart) {
              draft.traceStart = {
                pt: padWorld,
                net: padNet,
                refDes: padRefDes,
                padNum,
              };
            }
            draft.traceCurrent = padWorld;
            draft.draggingItemId = null;
            triggerRender();
            return;
          }

          if (hit && (hit.item.type === 'pcb_footprint' || hit.item.type === 'pcb_via')) {
            selectItem(hit.item.id);
            draft.draggingItemId = hit.item.id;
            draft.dragOffsetWorld = {
              x: worldPt.x - hit.item.transform.x,
              y: worldPt.y - hit.item.transform.y,
            };
            draft.dragPreviewPos = {
              x: hit.item.transform.x,
              y: hit.item.transform.y,
            };
            triggerRender();
          } else {
            draft.draggingItemId = null;
            draft.dragPreviewPos = null;
          }
        },

        onDragMove: (screenPt, deltaScreen) => {
          const st = stateRef.current;
          const draft = draftRef.current;
          const grid = st.boardConfig.gridSize || PCB_GRID;
          const worldPt = screenToWorld(screenPt, st.pcbViewport);
          const snapped = snapPoint(worldPt, grid);
          draft.lastTouchScreen = screenPt;
          draft.lastTouchWorld = snapped;

          // Auto-scroll while dragging near screen edges if enabled
          if (
            st.viewConfig.autoScrollDragging &&
            (draft.draggingItemId ||
              draft.draggingOutlineVertex !== null ||
              draft.traceStart ||
              draft.airwireStart ||
              draft.outlineStart)
          ) {
            const w = window.innerWidth;
            const h = window.innerHeight;
            const edgeZone = 42;
            let autoDx = 0;
            let autoDy = 0;
            if (screenPt.x < edgeZone) autoDx = 6;
            else if (screenPt.x > w - edgeZone) autoDx = -6;
            if (screenPt.y < edgeZone + 48) autoDy = 6;
            else if (screenPt.y > h - edgeZone - 56) autoDy = -6;
            if (autoDx !== 0 || autoDy !== 0) {
              const currVp = useEditorStore.getState().pcbViewport;
              setViewport('pcb', {
                ...currVp,
                panX: currVp.panX + autoDx,
                panY: currVp.panY + autoDy,
              });
            }
          }

          if (draft.draggingOutlineVertex !== null) {
            draft.outlineVertexPreview = snapped;
            triggerRender();
            return;
          }

          if (draft.outlineStart) {
            draft.outlineCurrent = snapped;
            triggerRender();
            return;
          }

          if (draft.measureStart && st.pcbTool === 'measure') {
            draft.measureCurrent = snapped;
            triggerRender();
            return;
          }

          if (draft.airwireStart) {
            const hit = hitTestPCB(st.pcbSheet.items, worldPt, st.pcbViewport.scale);
            draft.airwireCurrent = hit?.pad ? hit.pad.world : snapped;
            triggerRender();
            return;
          }

          if (draft.traceStart) {
            const hit = hitTestPCB(st.pcbSheet.items, worldPt, st.pcbViewport.scale);
            draft.traceCurrent = hit?.pad
              ? hit.pad.world
              : hit?.item.type === 'pcb_via'
                ? { x: hit.item.transform.x, y: hit.item.transform.y }
                : snapped;
            triggerRender();
            return;
          }

          if (draft.draggingItemId) {
            const raw = {
              x: worldPt.x - draft.dragOffsetWorld.x,
              y: worldPt.y - draft.dragOffsetWorld.y,
            };
            draft.dragPreviewPos = snapPoint(raw, grid);
            triggerRender();
          } else {
            const currVp = useEditorStore.getState().pcbViewport;
            setViewport('pcb', {
              ...currVp,
              panX: currVp.panX + deltaScreen.x,
              panY: currVp.panY + deltaScreen.y,
            });
          }
        },

        onDragEnd: () => {
          const st = stateRef.current;
          const draft = draftRef.current;
          draft.lastTouchScreen = null;

          if (draft.draggingOutlineVertex !== null && draft.outlineVertexPreview) {
            moveBoardOutlineVertex(draft.draggingOutlineVertex, draft.outlineVertexPreview);
            draft.draggingOutlineVertex = null;
            draft.outlineVertexPreview = null;
            triggerRender();
            return;
          }

          if (draft.outlineStart && draft.outlineCurrent) {
            const minX = Math.min(draft.outlineStart.x, draft.outlineCurrent.x);
            const minY = Math.min(draft.outlineStart.y, draft.outlineCurrent.y);
            const w = Math.abs(draft.outlineCurrent.x - draft.outlineStart.x);
            const h = Math.abs(draft.outlineCurrent.y - draft.outlineStart.y);
            if (w >= 4 && h >= 4) {
              updateBoardOutline(minX, minY, w, h, st.boardConfig.cornerRadius, undefined);
            }
            draft.outlineStart = null;
            draft.outlineCurrent = null;
            triggerRender();
            return;
          }

          if (draft.airwireStart && draft.airwireCurrent) {
            const hitEnd = hitTestPCB(
              st.pcbSheet.items,
              draft.airwireCurrent,
              st.pcbViewport.scale
            );
            if (hitEnd?.pad && hitEnd.item.type === 'pcb_footprint') {
              const toRefDes = hitEnd.item.props.refDes;
              const toPadNum = hitEnd.pad.pad.number;
              if (
                draft.airwireStart.refDes !== toRefDes ||
                draft.airwireStart.padNum !== toPadNum
              ) {
                connectPcbPadsAirwire(
                  draft.airwireStart.refDes,
                  draft.airwireStart.padNum,
                  toRefDes,
                  toPadNum
                );
                draft.airwireStart = null;
                draft.airwireCurrent = null;
              }
            }
            triggerRender();
            return;
          }

          if (draft.traceStart && draft.traceCurrent) {
            const s = draft.traceStart.pt;
            const e = draft.traceCurrent;
            if (Math.hypot(e.x - s.x, e.y - s.y) >= PCB_GRID) {
              const layer: 'F.Cu' | 'B.Cu' = st.pcbTool === 'trace_bottom' ? 'B.Cu' : 'F.Cu';
              const hitEnd = hitTestPCB(st.pcbSheet.items, e, st.pcbViewport.scale);
              const endRefDes =
                hitEnd?.pad && hitEnd.item.type === 'pcb_footprint'
                  ? hitEnd.item.props.refDes
                  : undefined;
              const endPadNum = hitEnd?.pad ? hitEnd.pad.pad.number : undefined;
              const endNet =
                hitEnd?.pad && hitEnd.item.type === 'pcb_footprint'
                  ? st.netlist.padNetMap[`${hitEnd.item.props.refDes}:${hitEnd.pad.pad.number}`] ||
                    hitEnd.pad.pad.net ||
                    ''
                  : hitEnd?.item.type === 'pcb_via'
                    ? hitEnd.item.props.net
                    : '';
              let netToUse = draft.traceStart.net || endNet;

              if (
                draft.traceStart.refDes &&
                draft.traceStart.padNum &&
                endRefDes &&
                endPadNum &&
                (draft.traceStart.refDes !== endRefDes ||
                  draft.traceStart.padNum !== endPadNum) &&
                !netToUse
              ) {
                connectPcbPadsAirwire(
                  draft.traceStart.refDes,
                  draft.traceStart.padNum,
                  endRefDes,
                  endPadNum
                );
                const refreshed = useEditorStore.getState().netlist;
                netToUse =
                  refreshed.padNetMap[`${endRefDes}:${endPadNum}`] || netToUse;
              }

              const dx = e.x - s.x;
              const dy = e.y - s.y;
              const diag = Math.min(Math.abs(dx), Math.abs(dy));
              const mid: Point = {
                x: Number((s.x + Math.sign(dx) * diag).toFixed(3)),
                y: Number((s.y + Math.sign(dy) * diag).toFixed(3)),
              };
              const pts = diag > 0.05 ? [s, mid, e] : [s, e];
              addPcbTrace(pts, layer, netToUse);
              draft.traceStart = null;
              draft.traceCurrent = null;
            }
          }

          if (draft.draggingItemId && draft.dragPreviewPos) {
            moveItem(draft.draggingItemId, draft.dragPreviewPos);
          }
          draft.draggingItemId = null;
          draft.dragPreviewPos = null;
          triggerRender();
        },

        onPanPinch: (deltaPan, scaleFactor, centerScreen) => {
          const vp = useEditorStore.getState().pcbViewport;
          const newScale = Math.max(3, Math.min(65, vp.scale * scaleFactor));
          const ratio = newScale / vp.scale;
          const panX = centerScreen.x - (centerScreen.x - vp.panX) * ratio + deltaPan.x;
          const panY = centerScreen.y - (centerScreen.y - vp.panY) * ratio + deltaPan.y;
          setViewport('pcb', { panX, panY, scale: newScale });
        },
      }),
    [
      addPcbTrace,
      addPcbVia,
      closeContextMenu,
      connectPcbPadsAirwire,
      fitViewport,
      moveBoardOutlineVertex,
      moveItem,
      openContextMenu,
      placePcbFootprint,
      selectItem,
      setActiveSheet,
      setViewport,
      splitBoardOutlineEdge,
      updateBoardOutline,
    ]
  );

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let animId = 0;

    const render = () => {
      const dpr = window.devicePixelRatio || 1;
      const width = canvas.clientWidth || window.innerWidth;
      const height = canvas.clientHeight || window.innerHeight;
      if (canvas.width !== Math.floor(width * dpr) || canvas.height !== Math.floor(height * dpr)) {
        canvas.width = Math.floor(width * dpr);
        canvas.height = Math.floor(height * dpr);
      }

      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const draft = draftRef.current;

      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.fillStyle = '#070a12';
      ctx.fillRect(0, 0, width, height);

      const vp = pcbViewport;
      ctx.save();
      ctx.translate(vp.panX, vp.panY);
      ctx.scale(vp.scale, vp.scale);

      const outlineItem = pcbSheet.items.find(
        (i): i is PcbOutlineItem => i.type === 'pcb_outline'
      );
      const originOffset =
        boardConfig.gridOrigin === 'board_corner' && outlineItem
          ? { x: outlineItem.transform.x, y: outlineItem.transform.y }
          : { x: 0, y: 0 };

      const baseGrid = boardConfig.gridSize || PCB_GRID;
      const gridStep = vp.scale < 9 ? baseGrid * 2 : baseGrid;
      const startX =
        Math.floor((-vp.panX / vp.scale - originOffset.x) / gridStep) * gridStep + originOffset.x;
      const endX =
        Math.ceil(((width - vp.panX) / vp.scale - originOffset.x) / gridStep) * gridStep +
        originOffset.x;
      const startY =
        Math.floor((-vp.panY / vp.scale - originOffset.y) / gridStep) * gridStep + originOffset.y;
      const endY =
        Math.ceil(((height - vp.panY) / vp.scale - originOffset.y) / gridStep) * gridStep +
        originOffset.y;

      if (boardConfig.rasterType === 'grid') {
        const majorStep = gridStep * (boardConfig.subdivision || 10);
        const majorStartX =
          Math.floor((-vp.panX / vp.scale - originOffset.x) / majorStep) * majorStep +
          originOffset.x;
        const majorStartY =
          Math.floor((-vp.panY / vp.scale - originOffset.y) / majorStep) * majorStep +
          originOffset.y;

        ctx.strokeStyle = 'rgba(148, 163, 184, 0.08)';
        ctx.lineWidth = Math.max(0.03, 0.6 / vp.scale);
        ctx.beginPath();
        for (let x = startX; x <= endX; x += gridStep) {
          ctx.moveTo(x, startY);
          ctx.lineTo(x, endY);
        }
        for (let y = startY; y <= endY; y += gridStep) {
          ctx.moveTo(startX, y);
          ctx.lineTo(endX, y);
        }
        ctx.stroke();

        ctx.strokeStyle = 'rgba(110, 231, 183, 0.14)';
        ctx.lineWidth = Math.max(0.05, 0.9 / vp.scale);
        ctx.beginPath();
        for (let x = majorStartX; x <= endX; x += majorStep) {
          ctx.moveTo(x, startY);
          ctx.lineTo(x, endY);
        }
        for (let y = majorStartY; y <= endY; y += majorStep) {
          ctx.moveTo(startX, y);
          ctx.lineTo(endX, y);
        }
        ctx.stroke();
      } else {
        ctx.fillStyle = 'rgba(148, 163, 184, 0.18)';
        const dotSize = Math.max(0.08, 1.3 / vp.scale);
        for (let x = startX; x <= endX; x += gridStep) {
          for (let y = startY; y <= endY; y += gridStep) {
            ctx.fillRect(x - dotSize / 2, y - dotSize / 2, dotSize, dotSize);
          }
        }
      }

      if (layerVisibility['Edge.Cuts']) {
        for (const item of pcbSheet.items) {
          if (item.type !== 'pcb_outline') continue;
          const out = item as PcbOutlineItem;
          const isSel = out.id === selectedItemId || pcbTool === 'outline';
          const radius = Math.min(
            out.props.cornerRadius ?? boardConfig.cornerRadius ?? 0,
            out.props.width / 2,
            out.props.height / 2
          );

          const rawPts = getOutlinePolygonPoints(out);
          const pts = rawPts.map((pt, idx) =>
            draft.draggingOutlineVertex === idx && draft.outlineVertexPreview
              ? draft.outlineVertexPreview
              : pt
          );
          const hasCustomPolygon =
            (out.props.points && out.props.points.length >= 3) ||
            draft.draggingOutlineVertex !== null;

          const traceOutlinePath = () => {
            ctx.beginPath();
            if (hasCustomPolygon && pts.length >= 3) {
              ctx.moveTo(pts[0].x, pts[0].y);
              for (let i = 1; i < pts.length; i++) {
                ctx.lineTo(pts[i].x, pts[i].y);
              }
              ctx.closePath();
            } else {
              ctx.roundRect(
                out.transform.x,
                out.transform.y,
                out.props.width,
                out.props.height,
                radius
              );
            }
          };

          ctx.fillStyle = 'rgba(16, 42, 29, 0.42)';
          traceOutlinePath();
          ctx.fill();

          // Render Photo Overlay if enabled ("Photo of a real board -> trace over it")
          if (
            photoOverlay.enabled &&
            photoOverlay.dataUrl &&
            overlayImgRef.current?.loaded
          ) {
            ctx.save();
            ctx.globalAlpha = Math.max(0.05, Math.min(1, photoOverlay.opacity));
            const ox = photoOverlay.x;
            const oy = photoOverlay.y;
            const ow = Math.max(4, photoOverlay.widthMm);
            const oh = Math.max(4, photoOverlay.heightMm);
            ctx.translate(ox + ow / 2, oy + oh / 2);
            ctx.scale(photoOverlay.flipX ? -1 : 1, photoOverlay.flipY ? -1 : 1);
            ctx.drawImage(overlayImgRef.current.img, -ow / 2, -oh / 2, ow, oh);
            ctx.restore();
          }

          // Optional Auto Ground Copper Pour Fill
          const pourMargin = Math.max(0.3, boardConfig.copperFillClearance);
          if (boardConfig.autoGroundBottom && layerVisibility['B.Cu']) {
            ctx.fillStyle = 'rgba(74, 222, 128, 0.12)';
            if (hasCustomPolygon) {
              traceOutlinePath();
              ctx.fill();
            } else {
              ctx.beginPath();
              ctx.roundRect(
                out.transform.x + pourMargin,
                out.transform.y + pourMargin,
                Math.max(1, out.props.width - pourMargin * 2),
                Math.max(1, out.props.height - pourMargin * 2),
                Math.max(0, radius - pourMargin)
              );
              ctx.fill();
            }
          }
          if (boardConfig.autoGroundTop && layerVisibility['F.Cu']) {
            ctx.fillStyle = 'rgba(56, 189, 248, 0.12)';
            if (hasCustomPolygon) {
              traceOutlinePath();
              ctx.fill();
            } else {
              ctx.beginPath();
              ctx.roundRect(
                out.transform.x + pourMargin,
                out.transform.y + pourMargin,
                Math.max(1, out.props.width - pourMargin * 2),
                Math.max(1, out.props.height - pourMargin * 2),
                Math.max(0, radius - pourMargin)
              );
              ctx.fill();
            }
          }

          ctx.strokeStyle = isSel ? '#6ee7b7' : '#fb923c';
          ctx.lineWidth = isSel ? 0.35 : 0.24;
          traceOutlinePath();
          ctx.stroke();

          // Interactive Vertex & Midpoint Split Handles when outline tool or selected
          if (isSel && pts.length >= 3) {
            const vRadius = Math.max(0.45, 5.5 / vp.scale);
            const mRadius = Math.max(0.34, 4.2 / vp.scale);

            // Edge midpoint split handles (+)
            for (let i = 0; i < pts.length; i++) {
              const a = pts[i];
              const b = pts[(i + 1) % pts.length];
              const mid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
              ctx.fillStyle = '#fb923c';
              ctx.beginPath();
              ctx.arc(mid.x, mid.y, mRadius, 0, Math.PI * 2);
              ctx.fill();
            }

            // Corner/vertex drag handles
            for (let i = 0; i < pts.length; i++) {
              const p = pts[i];
              ctx.fillStyle = draft.draggingOutlineVertex === i ? '#6ee7b7' : '#fb923c';
              ctx.strokeStyle = '#ffffff';
              ctx.lineWidth = Math.max(0.12, 1.5 / vp.scale);
              ctx.beginPath();
              ctx.arc(p.x, p.y, vRadius, 0, Math.PI * 2);
              ctx.fill();
              ctx.stroke();
            }
          }

          ctx.fillStyle = '#fb923c';
          ctx.font = '500 1.0px ui-monospace, monospace';
          ctx.textAlign = 'left';
          const unitLabel =
            boardConfig.unitSystem === 'mil'
              ? `${(out.props.width * 39.3701).toFixed(0)} × ${(out.props.height * 39.3701).toFixed(0)} mil`
              : `${out.props.width.toFixed(1)} × ${out.props.height.toFixed(1)} mm`;
          ctx.fillText(
            hasCustomPolygon ? `${unitLabel} (${pts.length} pts)` : unitLabel,
            out.transform.x + 0.5,
            out.transform.y - 0.5
          );
        }
      }

      const drawTracesForLayer = (layer: 'B.Cu' | 'F.Cu', color: string) => {
        if (!layerVisibility[layer]) return;
        for (const item of pcbSheet.items) {
          if (item.type !== 'pcb_trace' || item.transform.layer !== layer) continue;
          const tr = item as PcbTraceItem;
          const pts = tr.props.points;
          if (pts.length < 2) continue;
          const isSel = tr.id === selectedItemId;

          ctx.strokeStyle = isSel ? '#facc15' : color;
          ctx.lineWidth = tr.props.width;
          ctx.lineCap = 'round';
          ctx.lineJoin = 'round';
          ctx.beginPath();
          ctx.moveTo(pts[0].x, pts[0].y);
          for (let i = 1; i < pts.length; i++) {
            ctx.lineTo(pts[i].x, pts[i].y);
          }
          ctx.stroke();
        }
      };

      // Screenshot 9 Layer Palette: Copper Bottom = Green (#4ade80), Copper Top = Blue (#38bdf8)
      drawTracesForLayer('B.Cu', '#4ade80');
      drawTracesForLayer('F.Cu', '#38bdf8');

      for (const item of pcbSheet.items) {
        if (item.type !== 'pcb_footprint') continue;
        const fp = item as PcbFootprintItem;
        const isSel = fp.id === selectedItemId;
        const pos =
          fp.id === draft.draggingItemId && draft.dragPreviewPos
            ? draft.dragPreviewPos
            : { x: fp.transform.x, y: fp.transform.y };

        const previewFp: PcbFootprintItem = {
          ...fp,
          transform: { ...fp.transform, x: pos.x, y: pos.y },
        };

        const isRot = fp.transform.rotation === 90 || fp.transform.rotation === 270;
        const cw = isRot ? fp.props.courtyard.height : fp.props.courtyard.width;
        const ch = isRot ? fp.props.courtyard.width : fp.props.courtyard.height;

        if (layerVisibility['B.SilkS']) {
          ctx.strokeStyle = 'rgba(250, 204, 21, 0.35)';
          ctx.lineWidth = 0.1;
          ctx.strokeRect(pos.x - cw / 2 - 0.15, pos.y - ch / 2 - 0.15, cw + 0.3, ch + 0.3);
        }

        if (layerVisibility['F.SilkS']) {
          ctx.strokeStyle = isSel ? '#6ee7b7' : 'rgba(248, 113, 113, 0.78)';
          ctx.lineWidth = isSel ? 0.24 : 0.15;
          ctx.strokeRect(pos.x - cw / 2, pos.y - ch / 2, cw, ch);

          if (viewConfig.showDesignators) {
            ctx.fillStyle = '#f87171';
            ctx.font = '700 1.05px ui-monospace, monospace';
            ctx.textAlign = 'center';
            ctx.fillText(fp.props.refDes, pos.x, pos.y - ch / 2 - 0.45);

            ctx.fillStyle = '#94a3b8';
            ctx.font = '600 0.82px ui-monospace, monospace';
            ctx.fillText(fp.props.value, pos.x, pos.y + ch / 2 + 1.0);
          }
        }

        const pads = getFootprintPadsWorld(previewFp);
        for (const p of pads) {
          const isThru = p.pad.layers.length > 1;
          const drawW = isRot ? p.pad.height : p.pad.width;
          const drawH = isRot ? p.pad.width : p.pad.height;

          // Optional Solder Mask aperture ring
          if (layerVisibility['F.Mask'] || layerVisibility['B.Mask']) {
            const exp = boardConfig.maskExpansion || 0.05;
            ctx.strokeStyle = layerVisibility['F.Mask']
              ? 'rgba(232, 121, 249, 0.7)'
              : 'rgba(192, 132, 252, 0.7)';
            ctx.lineWidth = 0.08;
            if (p.pad.shape === 'circle') {
              ctx.beginPath();
              ctx.arc(p.world.x, p.world.y, drawW / 2 + exp, 0, Math.PI * 2);
              ctx.stroke();
            } else {
              ctx.strokeRect(
                p.world.x - drawW / 2 - exp,
                p.world.y - drawH / 2 - exp,
                drawW + exp * 2,
                drawH + exp * 2
              );
            }
          }

          const padColor = isThru
            ? '#f59e0b'
            : p.pad.layers[0] === 'F.Cu'
              ? '#38bdf8'
              : '#4ade80';
          ctx.fillStyle = padColor;

          if (p.pad.shape === 'circle') {
            ctx.beginPath();
            ctx.arc(p.world.x, p.world.y, drawW / 2, 0, Math.PI * 2);
            ctx.fill();
          } else {
            ctx.fillRect(
              p.world.x - drawW / 2,
              p.world.y - drawH / 2,
              drawW,
              drawH
            );
          }

          // Solder paste stencil preview on SMD pads when pasteMargin is configured
          if (!isThru && boardConfig.pasteMargin !== 0) {
            const pasteW = Math.max(0.15, drawW + boardConfig.pasteMargin * 2);
            const pasteH = Math.max(0.15, drawH + boardConfig.pasteMargin * 2);
            ctx.strokeStyle = 'rgba(226, 232, 240, 0.65)';
            ctx.lineWidth = 0.05;
            ctx.strokeRect(
              p.world.x - pasteW / 2,
              p.world.y - pasteH / 2,
              pasteW,
              pasteH
            );
          }

          if (p.pad.drill) {
            ctx.fillStyle = '#070a12';
            ctx.beginPath();
            ctx.arc(p.world.x, p.world.y, p.pad.drill / 2, 0, Math.PI * 2);
            ctx.fill();
          }

          const netName =
            netlist.padNetMap[`${fp.props.refDes}:${p.pad.number}`] || p.pad.net || '';
          if (vp.scale >= 8.5 && viewConfig.padLabels !== 'off') {
            ctx.fillStyle = '#ffffff';
            ctx.font = '700 0.52px ui-monospace, monospace';
            ctx.textAlign = 'center';
            const labelText =
              viewConfig.padLabels === 'numbers_nets' && netName
                ? `${p.pad.number}:${netName}`
                : p.pad.number;
            ctx.fillText(labelText, p.world.x, p.world.y + 0.18);
          }
        }
      }

      for (const item of pcbSheet.items) {
        if (item.type !== 'pcb_via') continue;
        const via = item as PcbViaItem;
        const isSel = via.id === selectedItemId;
        const pos =
          via.id === draft.draggingItemId && draft.dragPreviewPos
            ? draft.dragPreviewPos
            : { x: via.transform.x, y: via.transform.y };

        ctx.fillStyle = isSel ? '#6ee7b7' : '#cbd5e1';
        ctx.beginPath();
        ctx.arc(pos.x, pos.y, via.props.diameter / 2, 0, Math.PI * 2);
        ctx.fill();

        if (!boardConfig.coverViasWithMask) {
          ctx.fillStyle = '#070a12';
          ctx.beginPath();
          ctx.arc(pos.x, pos.y, via.props.drill / 2, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      const activeRatsnest =
        draft.draggingItemId && draft.dragPreviewPos
          ? computeRatsnest({
              ...history.project,
              sheets: history.project.sheets.map((s) =>
                s.kind === 'pcb'
                  ? {
                      ...s,
                      items: s.items.map((it) =>
                        it.id === draft.draggingItemId
                          ? {
                              ...it,
                              transform: {
                                ...it.transform,
                                x: draft.dragPreviewPos!.x,
                                y: draft.dragPreviewPos!.y,
                              },
                            }
                          : it
                      ),
                    }
                  : s
              ),
            })
          : ratsnest;

      ctx.strokeStyle = 'rgba(250, 204, 21, 0.88)';
      ctx.lineWidth = Math.max(0.09, 1.35 / vp.scale);
      ctx.setLineDash([0.35, 0.25]);
      for (const rat of activeRatsnest) {
        ctx.beginPath();
        ctx.moveTo(rat.from.x, rat.from.y);
        ctx.lineTo(rat.to.x, rat.to.y);
        ctx.stroke();
      }
      ctx.setLineDash([]);

      for (const v of drcViolations) {
        if (v.type === 'unrouted_net') continue;
        const isHighlighted = highlightedViolation?.id === v.id;
        ctx.strokeStyle = isHighlighted ? '#38bdf8' : '#f43f5e';
        ctx.lineWidth = isHighlighted ? 0.25 : 0.16;
        ctx.beginPath();
        ctx.arc(v.position.x, v.position.y, isHighlighted ? 1.4 : 0.9, 0, Math.PI * 2);
        ctx.stroke();
      }

      if (highlightedViolation) {
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 0.22;
        ctx.beginPath();
        ctx.arc(highlightedViolation.position.x, highlightedViolation.position.y, 2.1, 0, Math.PI * 2);
        ctx.stroke();
      }

      if (draft.traceStart && draft.traceCurrent) {
        const s = draft.traceStart.pt;
        const e = draft.traceCurrent;
        const dx = e.x - s.x;
        const dy = e.y - s.y;
        const diag = Math.min(Math.abs(dx), Math.abs(dy));
        const mid: Point = {
          x: s.x + Math.sign(dx) * diag,
          y: s.y + Math.sign(dy) * diag,
        };
        ctx.strokeStyle = pcbTool === 'trace_bottom' ? '#4ade80' : '#38bdf8';
        ctx.lineWidth = traceWidth;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.beginPath();
        ctx.moveTo(s.x, s.y);
        ctx.lineTo(mid.x, mid.y);
        ctx.lineTo(e.x, e.y);
        ctx.stroke();

        ctx.fillStyle = '#6ee7b7';
        ctx.beginPath();
        ctx.arc(s.x, s.y, 0.35, 0, Math.PI * 2);
        ctx.arc(e.x, e.y, 0.35, 0, Math.PI * 2);
        ctx.fill();
      }

      if (draft.airwireStart && draft.airwireCurrent) {
        ctx.strokeStyle = '#facc15';
        ctx.lineWidth = 0.18;
        ctx.setLineDash([0.3, 0.2]);
        ctx.beginPath();
        ctx.moveTo(draft.airwireStart.pt.x, draft.airwireStart.pt.y);
        ctx.lineTo(draft.airwireCurrent.x, draft.airwireCurrent.y);
        ctx.stroke();
        ctx.setLineDash([]);

        ctx.fillStyle = '#facc15';
        ctx.beginPath();
        ctx.arc(draft.airwireStart.pt.x, draft.airwireStart.pt.y, 0.4, 0, Math.PI * 2);
        ctx.arc(draft.airwireCurrent.x, draft.airwireCurrent.y, 0.4, 0, Math.PI * 2);
        ctx.fill();
      }

      if (draft.outlineStart && draft.outlineCurrent) {
        const minX = Math.min(draft.outlineStart.x, draft.outlineCurrent.x);
        const minY = Math.min(draft.outlineStart.y, draft.outlineCurrent.y);
        const w = Math.abs(draft.outlineCurrent.x - draft.outlineStart.x);
        const h = Math.abs(draft.outlineCurrent.y - draft.outlineStart.y);
        ctx.strokeStyle = '#fb923c';
        ctx.lineWidth = 0.25;
        ctx.setLineDash([0.5, 0.3]);
        ctx.strokeRect(minX, minY, w, h);
        ctx.setLineDash([]);
      }

      if (draft.measureStart && draft.measureCurrent) {
        const s = draft.measureStart;
        const e = draft.measureCurrent;
        const dx = Math.abs(e.x - s.x);
        const dy = Math.abs(e.y - s.y);
        const dist = Math.hypot(dx, dy);
        const isMil = boardConfig.unitSystem === 'mil';
        const factor = isMil ? 39.3700787 : 1;
        const unit = isMil ? 'mil' : 'mm';

        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = Math.max(0.16, 2.0 / vp.scale);
        ctx.setLineDash([0.35, 0.2]);
        ctx.beginPath();
        ctx.moveTo(s.x, s.y);
        ctx.lineTo(e.x, e.y);
        ctx.stroke();
        ctx.setLineDash([]);

        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(s.x, s.y, Math.max(0.35, 4.2 / vp.scale), 0, Math.PI * 2);
        ctx.arc(e.x, e.y, Math.max(0.35, 4.2 / vp.scale), 0, Math.PI * 2);
        ctx.fill();

        const midX = (s.x + e.x) / 2;
        const midY = (s.y + e.y) / 2 - Math.max(1.2, 15 / vp.scale);
        const fontSize = Math.max(0.9, 11.5 / vp.scale);
        const label = isMil
          ? `${(dist * factor).toFixed(1)} mil (${(dist / 25.4).toFixed(3)} in) · ΔX ${(dx * factor).toFixed(0)}, ΔY ${(dy * factor).toFixed(0)}`
          : `${dist.toFixed(2)} ${unit} (${(dist * 39.3700787).toFixed(0)} mil) · ΔX ${dx.toFixed(2)}, ΔY ${dy.toFixed(2)}`;

        ctx.font = `700 ${fontSize}px ui-monospace, monospace`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        const textWidth = ctx.measureText(label).width;
        const padX = Math.max(0.6, 7 / vp.scale);
        const boxW = textWidth + padX * 2;
        const boxH = fontSize * 1.75;

        ctx.fillStyle = 'rgba(7, 10, 18, 0.92)';
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.75)';
        ctx.lineWidth = Math.max(0.08, 1.1 / vp.scale);
        ctx.beginPath();
        ctx.roundRect(midX - boxW / 2, midY - boxH / 2, boxW, boxH, Math.max(0.3, 4 / vp.scale));
        ctx.fill();
        ctx.stroke();

        // White distance text as requested
        ctx.fillStyle = '#ffffff';
        ctx.fillText(label, midX, midY);
        ctx.textBaseline = 'alphabetic';
      }

      ctx.restore();

      // Top-center white measurement readout banner when Measure tool is active
      if (pcbTool === 'measure' && draft.measureStart && draft.measureCurrent) {
        const s = draft.measureStart;
        const e = draft.measureCurrent;
        const dx = Math.abs(e.x - s.x);
        const dy = Math.abs(e.y - s.y);
        const dist = Math.hypot(dx, dy);
        const isMil = boardConfig.unitSystem === 'mil';
        const hudText = isMil
          ? `Distance: ${(dist * 39.3700787).toFixed(1)} mil (${(dist / 25.4).toFixed(3)} in / ${dist.toFixed(2)} mm)  |  ΔX: ${(dx * 39.3700787).toFixed(1)} mil  ΔY: ${(dy * 39.3700787).toFixed(1)} mil`
          : `Distance: ${dist.toFixed(2)} mm (${(dist * 39.3700787).toFixed(1)} mil / ${(dist / 25.4).toFixed(3)} in)  |  ΔX: ${dx.toFixed(2)} mm  ΔY: ${dy.toFixed(2)} mm`;

        ctx.font = '700 11px ui-monospace, monospace';
        const tw = Math.min(width - 24, ctx.measureText(hudText).width + 22);
        const hx = (width - tw) / 2;
        const hy = viewConfig.edgeRulers ? 72 : 58;

        ctx.fillStyle = 'rgba(13, 19, 18, 0.94)';
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.65)';
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.roundRect(hx, hy, tw, 28, 9);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'center';
        ctx.fillText(hudText, width / 2, hy + 18);
      }

      // View Option: Edge Rulers (with dynamic Metric mm & Imperial mil scaling)
      if (viewConfig.edgeRulers) {
        const isMil = boardConfig.unitSystem === 'mil';
        ctx.fillStyle = 'rgba(13, 19, 18, 0.88)';
        ctx.fillRect(0, 48, width, 18);
        ctx.fillRect(0, 66, 26, height - 66);

        // Corner unit badge (mm or mil)
        ctx.fillStyle = '#ffffff';
        ctx.font = '700 8px ui-monospace, monospace';
        ctx.textAlign = 'center';
        ctx.fillText(isMil ? 'mil' : 'mm', 13, 60);

        ctx.fillStyle = '#6ee7b7';
        ctx.font = '600 9px ui-monospace, monospace';
        ctx.textAlign = 'center';

        if (isMil) {
          // Imperial ruler ticks in mils (1 mil = 0.0254 mm)
          const stepMil = vp.scale > 22 ? 50 : vp.scale > 10 ? 100 : vp.scale > 5 ? 200 : 500;
          const stepWorldMm = stepMil * 0.0254;
          const firstIdxX = Math.floor(-vp.panX / vp.scale / stepWorldMm);
          const lastIdxX = Math.ceil((width - vp.panX) / vp.scale / stepWorldMm);
          for (let idx = firstIdxX; idx <= lastIdxX; idx++) {
            const worldX = idx * stepWorldMm;
            const sx = vp.panX + worldX * vp.scale;
            if (sx >= 30 && sx <= width - 10) {
              ctx.fillText(`${idx * stepMil}`, sx, 60);
            }
          }
          const firstIdxY = Math.floor(-vp.panY / vp.scale / stepWorldMm);
          const lastIdxY = Math.ceil((height - vp.panY) / vp.scale / stepWorldMm);
          for (let idx = firstIdxY; idx <= lastIdxY; idx++) {
            const worldY = idx * stepWorldMm;
            const sy = vp.panY + worldY * vp.scale;
            if (sy >= 78 && sy <= height - 80) {
              ctx.fillText(`${idx * stepMil}`, 13, sy + 3);
            }
          }
        } else {
          // Metric ruler ticks in mm
          const stepMm = vp.scale > 24 ? 1 : vp.scale > 12 ? 2 : vp.scale > 5 ? 5 : 10;
          const firstMmX = Math.floor(-vp.panX / vp.scale / stepMm) * stepMm;
          const lastMmX = Math.ceil((width - vp.panX) / vp.scale / stepMm) * stepMm;
          for (let mm = firstMmX; mm <= lastMmX; mm += stepMm) {
            const sx = vp.panX + mm * vp.scale;
            if (sx >= 30 && sx <= width - 10) {
              ctx.fillText(`${mm}`, sx, 60);
            }
          }
          const firstMmY = Math.floor(-vp.panY / vp.scale / stepMm) * stepMm;
          const lastMmY = Math.ceil((height - vp.panY) / vp.scale / stepMm) * stepMm;
          for (let mm = firstMmY; mm <= lastMmY; mm += stepMm) {
            const sy = vp.panY + mm * vp.scale;
            if (sy >= 78 && sy <= height - 80) {
              ctx.fillText(`${mm}`, 13, sy + 3);
            }
          }
        }
      }

      // Live Physical Scale Bar (Metric mm / Imperial mil & inch)
      {
        const isMil = boardConfig.unitSystem === 'mil';
        let barWorldMm = 5;
        let barLabel = '5 mm';
        if (isMil) {
          const milSteps = [10, 20, 50, 100, 200, 500, 1000, 2000];
          let chosenMil = 200;
          for (const m of milSteps) {
            const px = m * 0.0254 * vp.scale;
            if (px >= 48 && px <= 120) {
              chosenMil = m;
              break;
            }
            if (px < 48) chosenMil = m;
          }
          barWorldMm = chosenMil * 0.0254;
          barLabel =
            chosenMil >= 100
              ? `${chosenMil} mil (${(chosenMil / 1000).toFixed(2)} in)`
              : `${chosenMil} mil`;
        } else {
          const mmSteps = [0.5, 1, 2, 5, 10, 20, 50];
          let chosenMm = 5;
          for (const m of mmSteps) {
            const px = m * vp.scale;
            if (px >= 48 && px <= 120) {
              chosenMm = m;
              break;
            }
            if (px < 48) chosenMm = m;
          }
          barWorldMm = chosenMm;
          barLabel = `${chosenMm} mm`;
        }

        const barPx = Math.max(36, Math.min(130, barWorldMm * vp.scale));
        const boxW = Math.max(barPx + 20, 96);
        const bx = width - boxW - 74;
        const by = height - 46;

        if (bx > 16) {
          ctx.fillStyle = 'rgba(13, 19, 18, 0.9)';
          ctx.strokeStyle = 'rgba(110, 231, 183, 0.3)';
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.roundRect(bx, by, boxW, 30, 8);
          ctx.fill();
          ctx.stroke();

          ctx.fillStyle = '#ffffff';
          ctx.font = '700 10px ui-monospace, monospace';
          ctx.textAlign = 'center';
          ctx.fillText(barLabel, bx + boxW / 2, by + 13);

          const lineX1 = bx + (boxW - barPx) / 2;
          const lineX2 = lineX1 + barPx;
          const lineY = by + 22;
          ctx.strokeStyle = '#6ee7b7';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(lineX1, lineY - 3);
          ctx.lineTo(lineX1, lineY + 3);
          ctx.moveTo(lineX1, lineY);
          ctx.lineTo(lineX2, lineY);
          ctx.moveTo(lineX2, lineY - 3);
          ctx.lineTo(lineX2, lineY + 3);
          ctx.stroke();
        }
      }

      // View Option: Coordinate Readout
      if (viewConfig.coordinateReadout) {
        const pt =
          draft.lastTouchWorld ||
          screenToWorld({ x: width / 2, y: height / 2 }, vp);
        const isMil = boardConfig.unitSystem === 'mil';
        const factor = isMil ? 39.3700787 : 1;
        const unit = isMil ? 'mil' : 'mm';
        const text = `X: ${(pt.x * factor).toFixed(isMil ? 0 : 2)}  Y: ${(pt.y * factor).toFixed(isMil ? 0 : 2)} ${unit}`;

        const pos = viewConfig.readoutPosition;
        const rx = pos.includes('right') ? width - 156 : viewConfig.edgeRulers ? 32 : 12;
        const ry = pos.includes('top') ? (viewConfig.edgeRulers ? 72 : 58) : height - 118;

        ctx.fillStyle = 'rgba(20, 29, 27, 0.92)';
        ctx.strokeStyle = 'rgba(110, 231, 183, 0.35)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.roundRect(rx, ry, 144, 26, 8);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = '#6ee7b7';
        ctx.font = '600 11px ui-monospace, monospace';
        ctx.textAlign = 'center';
        ctx.fillText(text, rx + 72, ry + 17);
      }

      // View Option: Touch Magnifier Loupe during active touch manipulation
      if (
        viewConfig.touchMagnifier &&
        draft.lastTouchScreen &&
        draft.lastTouchWorld &&
        (draft.draggingItemId || draft.traceStart || draft.airwireStart)
      ) {
        const isMil = boardConfig.unitSystem === 'mil';
        const factor = isMil ? 39.3700787 : 1;
        const lx = Math.min(Math.max(48, draft.lastTouchScreen.x), width - 48);
        const ly = Math.max(82, draft.lastTouchScreen.y - 68);
        ctx.fillStyle = 'rgba(13, 19, 18, 0.94)';
        ctx.strokeStyle = '#6ee7b7';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(lx, ly, 30, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        ctx.strokeStyle = 'rgba(110, 231, 183, 0.5)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(lx - 18, ly);
        ctx.lineTo(lx + 18, ly);
        ctx.moveTo(lx, ly - 18);
        ctx.lineTo(lx, ly + 18);
        ctx.stroke();

        ctx.fillStyle = '#ffffff';
        ctx.font = '700 9px ui-monospace, monospace';
        ctx.textAlign = 'center';
        ctx.fillText(
          `${(draft.lastTouchWorld.x * factor).toFixed(isMil ? 0 : 1)},${(draft.lastTouchWorld.y * factor).toFixed(isMil ? 0 : 1)}`,
          lx,
          ly + 20
        );
      }
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  });

  useEffect(() => {
    const handleResize = () => {
      const vp = useEditorStore.getState().pcbViewport;
      setViewport('pcb', { ...vp });
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [setViewport]);

  return (
    <canvas
      ref={canvasRef}
      className="w-full h-full block touch-none select-none bg-[#070a12]"
      onPointerDown={recognizer.handlePointerDown}
      onPointerMove={recognizer.handlePointerMove}
      onPointerUp={recognizer.handlePointerUpOrCancel}
      onPointerCancel={recognizer.handlePointerUpOrCancel}
    />
  );
};
