import React, { useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  BookmarkCheck,
  Camera,
  Check,
  CircleDot,
  CloudDownload,
  Compass,
  Cpu,
  Download,
  FileCode2,
  FilePlus2,
  Folder,
  FolderOpen,
  GitCommit,
  Globe,
  Grid,
  Hash,
  Home,
  Image as ImageIcon,
  Layers,
  Maximize2,
  Minus,
  MousePointer,
  Pencil,
  Plus,
  PlusCircle,
  PlusSquare,
  QrCode,
  Radio,
  Redo2,
  RefreshCw,
  RotateCcw,
  RotateCw,
  Ruler,
  Share2,
  Sliders,
  Sparkles,
  SquareDashed,
  Tag,
  Trash2,
  Undo2,
  X,
  Zap,
} from 'lucide-react';
import { runDRC } from '../../core/drc';
import {
  OFFICIAL_FOOTPRINT_CATEGORIES,
  WEB_LIBRARY_CATALOG,
} from '../../core/geometry';
import { computeNetlist } from '../../core/netlist';
import { PcbTool, SchematicTool, useEditorStore } from '../store/useEditorStore';

const HOMEPAGE_BG_ASSET =
  '/assets/aistudio/8714023d5c6681e18b0ebe51220c0744_10c3b948.jpg';

export const HomePage: React.FC = () => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const libFileInputRef = useRef<HTMLInputElement | null>(null);
  const [homeTab, setHomeTab] = useState<'my_files' | 'examples' | 'imports'>('my_files');
  const [webUrl, setWebUrl] = useState<string>(
    'git@gitlab.com:kicad/libraries/kicad-footprints.git'
  );
  const [downloadingUrl, setDownloadingUrl] = useState(false);

  const {
    history,
    savedProjects,
    starterTemplates,
    installedLibraries,
    availableParts,
    setActiveSheet,
    newBlankProject,
    loadProjectJson,
    openProject,
    saveCurrentProjectToDevice,
    deleteSavedProject,
    renameSavedProject,
    deleteStarterTemplate,
    restoreStarterTemplates,
    installWebLibrary,
    uninstallLibrary,
    downloadLibraryFromUrl,
    importLibraryText,
    openKeypad,
    showSnackbar,
  } = useEditorStore();

  const installedIds = new Set(installedLibraries.map((l) => l.id));

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        loadProjectJson(String(reader.result));
        showSnackbar('Project imported into My Files', false);
        setHomeTab('my_files');
      } catch {
        showSnackbar('Invalid project JSON file', false);
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleLibFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        importLibraryText(String(reader.result), file.name);
      } catch (err) {
        showSnackbar(
          err instanceof Error
            ? err.message
            : 'Invalid .kicad_sym, .kicad_mod, or .json file',
          false
        );
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="relative w-full h-dvh bg-neutral-950 text-neutral-100 overflow-y-auto pt-safe pb-safe pl-safe pr-safe select-none">
      {/* Clearly Visible Monochrome Circuit Artwork Background */}
      <img
        src={HOMEPAGE_BG_ASSET}
        alt="PocketEDA Monochrome Circuit Matrix Background"
        className="fixed inset-0 w-full h-full object-cover grayscale contrast-125 brightness-110 opacity-85 pointer-events-none select-none z-0"
      />
      <div className="fixed inset-0 bg-neutral-950/35 pointer-events-none z-0" />

      <div className="relative z-10 max-w-lg mx-auto px-4 py-4 space-y-4 pb-12">
        {/* Top Minimalist Grayscale Header Bar */}
        <div className="flex items-center justify-between p-3 rounded-2xl bg-neutral-950/75 backdrop-blur-sm border border-white/20">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-neutral-900/90 border border-white/25 flex items-center justify-center text-white">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-base font-extrabold uppercase tracking-widest text-white">
                PocketEDA
              </h1>
              <p className="text-[11px] font-mono text-neutral-300">
                MINIMALIST CAD · {availableParts.length} KICAD PARTS
              </p>
            </div>
          </div>
        </div>

        {/* 3-Tab Minimalist Segmented Navigation: My Files | Examples | Imports */}
        <div className="grid grid-cols-3 bg-neutral-950/75 backdrop-blur-sm border border-white/20 rounded-xl p-1 gap-1">
          <button
            type="button"
            onPointerUp={() => setHomeTab('my_files')}
            className={`min-h-[44px] rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
              homeTab === 'my_files'
                ? 'bg-white text-neutral-950'
                : 'text-neutral-200 hover:text-white'
            }`}
          >
            <Folder className="w-3.5 h-3.5 shrink-0" />
            <span>My Files ({savedProjects.length})</span>
          </button>

          <button
            type="button"
            onPointerUp={() => setHomeTab('examples')}
            className={`min-h-[44px] rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
              homeTab === 'examples'
                ? 'bg-white text-neutral-950'
                : 'text-neutral-200 hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 shrink-0" />
            <span>Examples ({starterTemplates.length})</span>
          </button>

          <button
            type="button"
            onPointerUp={() => setHomeTab('imports')}
            className={`min-h-[44px] rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
              homeTab === 'imports'
                ? 'bg-white text-neutral-950'
                : 'text-neutral-200 hover:text-white'
            }`}
          >
            <CloudDownload className="w-3.5 h-3.5 shrink-0" />
            <span>Imports ({installedLibraries.length})</span>
          </button>
        </div>

        {/* ================================================================ */}
        {/* TAB 1: MY FILES                                                  */}
        {/* ================================================================ */}
        {homeTab === 'my_files' && (
          <div className="space-y-4">
            {/* Stack of All User Schematics — Only shown after creating or opening a file */}
            {savedProjects.map((proj, index) => {
              const projSch = proj.sheets.find((s) => s.kind === 'schematic');
              const projPcb = proj.sheets.find((s) => s.kind === 'pcb');
              const projCompCount =
                projSch?.items.filter((i) => i.type === 'sch_component').length ?? 0;
              const projTraceCount =
                projPcb?.items.filter((i) => i.type === 'pcb_trace').length ?? 0;
              const projNetlist = computeNetlist(proj);
              const projDrc = runDRC(proj);
              const isActive = history.project.id === proj.id;

              return (
                <div
                  key={proj.id}
                  className={`rounded-2xl bg-neutral-950/75 backdrop-blur-sm border p-4 space-y-4 transition-all ${
                    isActive ? 'border-white/35' : 'border-white/20'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <span className="text-[10px] font-mono uppercase tracking-widest text-neutral-300">
                        {index === 0 || isActive
                          ? 'Active Workspace'
                          : `Schematic Workspace #${savedProjects.length - index}`}
                      </span>
                      <div className="flex items-center gap-2 mt-1">
                        <input
                          type="text"
                          inputMode="text"
                          aria-label={`Project Name ${proj.name}`}
                          value={proj.name}
                          onChange={(e) => renameSavedProject(proj.id, e.target.value)}
                          className="w-full max-w-[190px] min-h-[38px] px-2.5 rounded-lg bg-neutral-900/90 border border-white/25 text-sm font-bold text-white focus:outline-none focus:border-white"
                        />
                        <button
                          type="button"
                          aria-label={`Rename ${proj.name}`}
                          onPointerUp={() =>
                            openKeypad({
                              title: 'Project Name',
                              initialValue: proj.name,
                              unit: '',
                              allowLetters: true,
                              onCommit: (val) => renameSavedProject(proj.id, val),
                            })
                          }
                          className="w-9 h-9 rounded-lg bg-neutral-900/90 border border-white/20 text-neutral-200 flex items-center justify-center shrink-0 active:scale-95"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="text-right font-mono text-xs text-neutral-200">
                        <div>
                          {projCompCount} Parts · {projNetlist.nets.length} Nets
                        </div>
                        <div className="text-neutral-400">
                          {projTraceCount} Traces · {projDrc.length} DRC
                        </div>
                      </div>
                      <button
                        type="button"
                        aria-label={`Delete ${proj.name}`}
                        onPointerUp={() => deleteSavedProject(proj.id)}
                        className="w-11 h-11 rounded-xl bg-neutral-900/90 border border-white/20 text-neutral-200 flex items-center justify-center shrink-0 active:scale-95 transition-transform"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2.5">
                    <button
                      type="button"
                      onPointerUp={() => openProject(proj, 'schematic')}
                      className="min-h-[54px] px-3 rounded-xl bg-white text-neutral-950 font-bold text-xs flex flex-col items-center justify-center gap-0.5 active:scale-98 transition-transform"
                    >
                      <span className="text-sm font-extrabold tracking-tight">
                        Open Schematic
                      </span>
                      <span className="text-[11px] text-neutral-600 font-mono">
                        Sheet Capture
                      </span>
                    </button>

                    <button
                      type="button"
                      onPointerUp={() => openProject(proj, 'pcb')}
                      className="min-h-[54px] px-3 rounded-xl bg-neutral-900/95 border border-white/30 text-white font-bold text-xs flex flex-col items-center justify-center gap-0.5 active:scale-98 transition-transform"
                    >
                      <span className="text-sm font-extrabold tracking-tight">
                        Open PCB Layout
                      </span>
                      <span className="text-[11px] text-neutral-300 font-mono">
                        2-Layer + DRC
                      </span>
                    </button>
                  </div>
                </div>
              );
            })}

            {/* Red-Circled Section: Moves down each time a new file is placed above */}
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onPointerUp={() => newBlankProject(undefined, true)}
                className="min-h-[58px] p-3 rounded-xl bg-neutral-950/72 backdrop-blur-sm border border-white/20 flex flex-col justify-center text-left active:scale-98 transition-transform"
              >
                <div className="flex items-center gap-1.5 text-white text-xs font-bold">
                  <FilePlus2 className="w-4 h-4 shrink-0" />
                  <span>New Blank</span>
                </div>
                <div className="text-[11px] font-mono text-neutral-300 mt-0.5">
                  Empty Board
                </div>
              </button>

              <button
                type="button"
                onPointerUp={() => setActiveSheet('add_part')}
                className="min-h-[58px] p-3 rounded-xl bg-neutral-950/72 backdrop-blur-sm border border-white/25 flex flex-col justify-center text-left active:scale-98 transition-transform"
              >
                <div className="flex items-center gap-1.5 text-white text-xs font-bold">
                  <PlusSquare className="w-4 h-4 shrink-0" />
                  <span>Footprints</span>
                </div>
                <div className="text-[11px] font-mono text-neutral-300 mt-0.5">
                  {availableParts.length} Preset Parts
                </div>
              </button>

              <button
                type="button"
                onPointerUp={() => saveCurrentProjectToDevice()}
                className="min-h-[58px] p-3 rounded-xl bg-neutral-950/72 backdrop-blur-sm border border-white/20 flex flex-col justify-center text-left active:scale-98 transition-transform"
              >
                <div className="flex items-center gap-1.5 text-white text-xs font-bold">
                  <BookmarkCheck className="w-4 h-4 shrink-0" />
                  <span>Save Active</span>
                </div>
                <div className="text-[11px] font-mono text-neutral-300 mt-0.5">
                  Local Storage
                </div>
              </button>
            </div>

            {/* Saved on Device Summary Bar */}
            <div className="space-y-2.5">
              <div className="flex items-center justify-between px-2 py-1.5 rounded-lg bg-neutral-950/70 backdrop-blur-xs border border-white/15">
                <h3 className="text-[11px] font-mono uppercase tracking-widest text-neutral-200">
                  Saved on Device ({savedProjects.length})
                </h3>
                <button
                  type="button"
                  onPointerUp={() => setHomeTab('examples')}
                  className="text-xs font-mono text-white underline underline-offset-4"
                >
                  Browse 10 Examples →
                </button>
              </div>
              {savedProjects.length === 0 && (
                <div className="p-5 rounded-2xl bg-neutral-950/72 backdrop-blur-sm border border-white/20 text-center text-xs text-neutral-200">
                  No schematics yet. Tap &ldquo;New Blank&rdquo; above to create a new file, or open one of the 10 pre-routed circuits in the Examples tab.
                </div>
              )}
            </div>
          </div>
        )}

        {/* ================================================================ */}
        {/* TAB 2: EXAMPLES (10 READY-TO-OPEN CIRCUITS)                      */}
        {/* ================================================================ */}
        {homeTab === 'examples' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-neutral-950/75 backdrop-blur-sm border border-white/20">
              <div>
                <h3 className="text-[11px] font-mono uppercase tracking-widest text-white">
                  Reference Schematics & 2-Layer PCBs ({starterTemplates.length})
                </h3>
                <p className="text-[11px] text-neutral-300 mt-0.5">
                  Tap SCH or PCB on any example to open its schematic or routed board
                </p>
              </div>
              {starterTemplates.length < 10 && (
                <button
                  type="button"
                  onPointerUp={() => restoreStarterTemplates()}
                  className="min-h-[38px] px-3 rounded-lg bg-neutral-900 border border-white/25 text-white text-xs font-bold flex items-center gap-1.5 shrink-0 active:scale-95"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Restore All 10</span>
                </button>
              )}
            </div>

            {starterTemplates.length === 0 ? (
              <div className="p-6 rounded-2xl bg-neutral-950/75 backdrop-blur-sm border border-white/20 text-center space-y-3">
                <div className="text-xs text-neutral-300">
                  All example circuits were removed from this list.
                </div>
                <button
                  type="button"
                  onPointerUp={() => restoreStarterTemplates()}
                  className="min-h-[44px] px-4 rounded-xl bg-white text-neutral-950 text-xs font-extrabold inline-flex items-center gap-2 active:scale-95"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Restore All 10 Examples</span>
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-2">
                {starterTemplates.map((tpl, idx) => (
                  <div
                    key={tpl.id}
                    className="p-3.5 rounded-xl bg-neutral-950/75 backdrop-blur-sm border border-white/20 flex items-center justify-between gap-2.5"
                  >
                    <button
                      type="button"
                      onPointerUp={() => openProject(tpl.project, 'schematic')}
                      className="flex-1 flex items-start gap-3 text-left min-w-0"
                    >
                      <div className="w-10 h-10 rounded-lg bg-neutral-900 border border-white/20 text-neutral-100 flex items-center justify-center shrink-0 mt-0.5">
                        {idx % 2 === 0 ? (
                          <Zap className="w-4 h-4" />
                        ) : (
                          <Sparkles className="w-4 h-4" />
                        )}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-sm font-bold text-white">
                            {tpl.name}
                          </span>
                          {tpl.category && (
                            <span className="px-1.5 py-0.5 rounded bg-neutral-900 border border-white/20 text-[10px] font-mono text-neutral-200">
                              {tpl.category}
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-neutral-300 mt-0.5 leading-snug">
                          {tpl.description}
                        </div>
                      </div>
                    </button>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onPointerUp={() => openProject(tpl.project, 'schematic')}
                        className="min-h-[40px] px-2.5 rounded-lg bg-white text-neutral-950 text-xs font-extrabold active:scale-95"
                      >
                        SCH
                      </button>
                      <button
                        type="button"
                        onPointerUp={() => openProject(tpl.project, 'pcb')}
                        className="min-h-[40px] px-2.5 rounded-lg bg-neutral-900 border border-white/25 text-white text-xs font-bold active:scale-95"
                      >
                        PCB
                      </button>
                      <button
                        type="button"
                        aria-label={`Delete ${tpl.name}`}
                        onPointerUp={() => deleteStarterTemplate(tpl.id)}
                        className="w-10 h-10 rounded-lg bg-neutral-900 border border-white/15 text-neutral-300 flex items-center justify-center active:scale-95"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ================================================================ */}
        {/* TAB 3: IMPORTS (KICAD-FOOTPRINTS.GIT & SYMBOL IMPORTER)          */}
        {/* ================================================================ */}
        {homeTab === 'imports' && (
          <div className="space-y-4">
            {/* GitLab / GitHub / Web URL Library Importer */}
            <div className="p-4 rounded-2xl bg-neutral-950/75 backdrop-blur-sm border border-white/20 space-y-3">
              <div className="flex items-center justify-between">
                <div className="text-xs font-bold text-white flex items-center gap-2">
                  <Globe className="w-4 h-4" />
                  <span>KiCad Git / .kicad_mod / .kicad_sym Importer</span>
                </div>
                <span className="text-[10px] font-mono text-neutral-300">
                  Auto-sorts into 20 folders
                </span>
              </div>

              <p className="text-xs text-neutral-300 leading-relaxed">
                All official footprints from{' '}
                <code className="text-white font-mono">
                  git@gitlab.com:kicad/libraries/kicad-footprints.git
                </code>{' '}
                are preloaded into the Preset Official Library ({availableParts.length}{' '}
                parts). You can also sync custom{' '}
                <code className="text-white font-mono">.kicad_mod</code>,{' '}
                <code className="text-white font-mono">.kicad_sym</code>, or{' '}
                <code className="text-white font-mono">.json</code> libraries below.
              </p>

              <div className="flex items-center gap-2">
                <input
                  type="text"
                  inputMode="url"
                  value={webUrl}
                  onChange={(e) => setWebUrl(e.target.value)}
                  placeholder="git@gitlab.com:kicad/libraries/kicad-footprints.git"
                  className="flex-1 min-h-[44px] px-3 rounded-lg bg-neutral-900/95 border border-white/25 text-xs font-mono text-white focus:outline-none focus:border-white"
                />
                <button
                  type="button"
                  disabled={downloadingUrl}
                  onPointerUp={async () => {
                    setDownloadingUrl(true);
                    await downloadLibraryFromUrl(webUrl);
                    setDownloadingUrl(false);
                  }}
                  className="min-h-[44px] px-3.5 rounded-lg bg-white text-neutral-950 font-extrabold text-xs shrink-0 active:scale-95"
                >
                  {downloadingUrl ? 'Sorting...' : 'Fetch & Sort'}
                </button>
              </div>

              <div className="grid grid-cols-3 gap-2 pt-1">
                <button
                  type="button"
                  onPointerUp={() => libFileInputRef.current?.click()}
                  className="min-h-[44px] px-2.5 rounded-lg bg-neutral-900/95 border border-white/20 text-neutral-100 text-xs font-bold flex items-center justify-center gap-1.5 active:scale-95"
                >
                  <FolderOpen className="w-4 h-4 shrink-0" />
                  <span>.kicad_mod / sym</span>
                </button>

                <button
                  type="button"
                  onPointerUp={() => {
                    const sampleKicadSym = `(kicad_symbol_lib (version 20220914) (generator kicad_symbol_editor)
  (symbol "ULN2003A" (in_bom yes) (on_board yes)
    (property "Reference" "U")
    (property "Value" "ULN2003A")
    (property "Footprint" "Package_DIP:DIP-16")
    (property "Description" "7-Channel Darlington Transistor Array IC")
    (symbol "ULN2003A_1_1"
      (pin input line (at -7.62 3.81 0) (length 2.54) (name "IN1") (number "1"))
      (pin input line (at -7.62 1.27 0) (length 2.54) (name "IN2") (number "2"))
      (pin input line (at -7.62 -1.27 0) (length 2.54) (name "IN3") (number "3"))
      (pin power_in line (at -7.62 -3.81 0) (length 2.54) (name "GND") (number "8"))
      (pin power_in line (at 7.62 3.81 180) (length 2.54) (name "COM") (number "9"))
      (pin open_collector line (at 7.62 1.27 180) (length 2.54) (name "OUT3") (number "14"))
      (pin open_collector line (at 7.62 -1.27 180) (length 2.54) (name "OUT2") (number "15"))
      (pin open_collector line (at 7.62 -3.81 180) (length 2.54) (name "OUT1") (number "16"))
    )
  )
  (symbol "TMP102" (in_bom yes) (on_board yes)
    (property "Reference" "U")
    (property "Value" "TMP102")
    (property "Footprint" "Package_TO_SOT_SMD:SOT-563")
    (property "Description" "Digital I2C Temperature Sensor")
    (symbol "TMP102_1_1"
      (pin bidirectional line (at -7.62 2.54 0) (length 2.54) (name "SDA") (number "1"))
      (pin input line (at -7.62 0 0) (length 2.54) (name "SCL") (number "6"))
      (pin power_in line (at -7.62 -2.54 0) (length 2.54) (name "GND") (number "2"))
      (pin power_in line (at 7.62 2.54 180) (length 2.54) (name "V+") (number "5"))
    )
  )
)`;
                    importLibraryText(sampleKicadSym, 'GitHub_Sample_Pack.kicad_sym');
                  }}
                  className="min-h-[44px] px-2.5 rounded-lg bg-neutral-900/95 border border-white/20 text-neutral-100 text-xs font-bold flex items-center justify-center gap-1.5 active:scale-95"
                >
                  <FileCode2 className="w-4 h-4 shrink-0" />
                  <span>Sample Pack</span>
                </button>

                <button
                  type="button"
                  onPointerUp={() => fileInputRef.current?.click()}
                  className="min-h-[44px] px-2.5 rounded-lg bg-neutral-900/95 border border-white/20 text-neutral-100 text-xs font-bold flex items-center justify-center gap-1.5 active:scale-95"
                >
                  <FolderOpen className="w-4 h-4 shrink-0" />
                  <span>Project .json</span>
                </button>
              </div>

              <input
                ref={libFileInputRef}
                type="file"
                accept=".kicad_sym,.kicad_mod,.mod,.sym,.json,application/json,text/plain"
                className="hidden"
                onChange={handleLibFileUpload}
              />
              <input
                ref={fileInputRef}
                type="file"
                accept=".json,application/json"
                className="hidden"
                onChange={handleFileUpload}
              />
            </div>

            {/* Curated KiCad Official Repositories */}
            <div className="space-y-2.5">
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-neutral-950/75 backdrop-blur-sm border border-white/20">
                <h3 className="text-[11px] font-mono uppercase tracking-widest text-white">
                  KiCad Official Repositories ({WEB_LIBRARY_CATALOG.length})
                </h3>
                <button
                  type="button"
                  onPointerUp={() => {
                    for (const pkg of WEB_LIBRARY_CATALOG) {
                      installWebLibrary(pkg);
                    }
                  }}
                  className="min-h-[36px] px-3 rounded-lg bg-white text-neutral-950 text-xs font-extrabold active:scale-95"
                >
                  Sync All Packs
                </button>
              </div>

              <div className="space-y-2">
                {WEB_LIBRARY_CATALOG.map((pkg) => {
                  const isPreloadedRepo = pkg.id === 'kicad_footprints_git_full';
                  const isInstalled = isPreloadedRepo || installedIds.has(pkg.id);
                  const targetFolders = Array.from(
                    new Set(pkg.parts.map((p) => p.category))
                  )
                    .slice(0, 6)
                    .join(', ');
                  return (
                    <div
                      key={pkg.id}
                      className="p-3.5 rounded-xl bg-neutral-950/75 backdrop-blur-sm border border-white/20 flex items-center justify-between gap-3"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-mono font-bold text-xs text-white truncate">
                            {pkg.name}
                          </span>
                          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-neutral-900 border border-white/20 text-neutral-200">
                            {pkg.parts.length} parts
                          </span>
                        </div>
                        <div className="text-xs text-neutral-300 mt-0.5">
                          {pkg.description}
                        </div>
                        <div className="text-[11px] font-mono text-neutral-200 mt-1">
                          Folders: {targetFolders}
                          {pkg.parts.length > 20 ? ' + all 20 categories' : ''}
                        </div>
                      </div>

                      {isInstalled ? (
                        <div className="flex items-center gap-1 shrink-0">
                          <span className="min-h-[38px] px-2.5 rounded-lg bg-neutral-900 border border-white/25 text-white text-xs font-bold flex items-center gap-1">
                            <Check className="w-3.5 h-3.5" />
                            <span>{isPreloadedRepo ? 'Preset' : 'Sorted'}</span>
                          </span>
                          {!isPreloadedRepo && (
                            <button
                              type="button"
                              aria-label="Uninstall library"
                              onPointerUp={() => uninstallLibrary(pkg.id)}
                              className="w-10 h-10 rounded-lg bg-neutral-900 border border-white/15 text-neutral-300 flex items-center justify-center active:scale-95"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      ) : (
                        <button
                          type="button"
                          onPointerUp={() => installWebLibrary(pkg)}
                          className="min-h-[40px] px-3.5 rounded-lg bg-white text-neutral-950 text-xs font-extrabold flex items-center gap-1.5 shrink-0 active:scale-95"
                        >
                          <CloudDownload className="w-4 h-4" />
                          <span>Import</span>
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Live 20-Folder Category Sorting Breakdown */}
            <div className="p-4 rounded-2xl bg-neutral-950/75 backdrop-blur-sm border border-white/20 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold uppercase tracking-wider text-white">
                    Preset Official Library ({availableParts.length} Total Parts)
                  </div>
                  <div className="text-[11px] font-mono text-neutral-300">
                    kicad-footprints.git sorted across 20 categories
                  </div>
                </div>
                <button
                  type="button"
                  onPointerUp={() => setActiveSheet('add_part')}
                  className="min-h-[38px] px-3 rounded-lg bg-white text-neutral-950 text-xs font-extrabold active:scale-95"
                >
                  Open Library
                </button>
              </div>

              <div className="grid grid-cols-2 gap-1.5">
                {OFFICIAL_FOOTPRINT_CATEGORIES.map((cat) => {
                  const count = availableParts.filter((p) => p.category === cat).length;
                  return (
                    <button
                      key={cat}
                      type="button"
                      onPointerUp={() => setActiveSheet('add_part')}
                      className="min-h-[38px] px-2.5 py-1.5 rounded-lg bg-neutral-900/90 border border-white/15 flex items-center justify-between text-left active:scale-98"
                    >
                      <span className="text-xs text-neutral-100 truncate pr-1">
                        {cat}
                      </span>
                      <span className="text-xs font-mono font-bold text-white shrink-0">
                        {count}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Local Hosting Source & Production Bundle (.zip) */}
            <div className="p-4 rounded-2xl bg-neutral-950/75 backdrop-blur-sm border border-white/25 space-y-2.5">
              <div>
                <div className="text-xs font-bold uppercase tracking-wider text-white">
                  Local Hosting Bundle (.zip)
                </div>
                <div className="text-[11px] text-neutral-300 mt-0.5">
                  Includes all TypeScript/React source files, assets, and pre-built dist/ folder for local hosting
                </div>
              </div>
              <a
                href="/PocketEDA_Source.zip"
                download="PocketEDA_Full_Source.zip"
                className="w-full min-h-[48px] px-4 rounded-xl bg-white text-neutral-950 text-xs font-extrabold flex items-center justify-center gap-2 active:scale-98 transition-transform"
              >
                <Download className="w-4 h-4" />
                <span>Download Full Project (.zip)</span>
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export const TopBar: React.FC = () => {
  const {
    history,
    editorMode,
    activeSheet,
    drcViolations,
    selectedItemId,
    setAppView,
    setEditorMode,
    setActiveSheet,
    syncPcbLayoutFromSchematic,
    undo,
    redo,
  } = useEditorStore();

  const errorCount = drcViolations.filter((v) => v.severity === 'error').length;
  const warnCount = drcViolations.filter((v) => v.severity === 'warning').length;

  return (
    <header className="fixed top-0 left-0 right-0 z-30 pt-safe pl-safe pr-safe bg-[#0d1312]/95 backdrop-blur-md border-b border-[#24322f]">
      <div className="h-13 px-2 flex items-center gap-1.5 overflow-x-auto no-scrollbar flex-nowrap">
        <button
          type="button"
          onPointerUp={() => setAppView('home')}
          aria-label="Home Page"
          className="min-w-[44px] min-h-[44px] px-2.5 flex items-center justify-center gap-1 rounded-xl bg-[#141d1b] text-slate-200 border border-[#24322f] shrink-0 active:scale-95 transition-transform"
        >
          <Home className="w-4 h-4 text-[#6ee7b7]" />
        </button>

        <div className="flex items-center bg-[#141d1b] p-0.5 rounded-xl border border-[#24322f] shrink-0">
          <button
            type="button"
            onPointerUp={() => setEditorMode('schematic')}
            className={`min-h-[40px] min-w-[48px] px-2.5 rounded-lg text-xs font-bold tracking-tight transition-transform active:scale-95 ${
              editorMode === 'schematic'
                ? 'bg-[#6ee7b7] text-slate-950 shadow-sm'
                : 'text-slate-300'
            }`}
          >
            SCH
          </button>
          <button
            type="button"
            onPointerUp={() => setEditorMode('pcb')}
            className={`min-h-[40px] min-w-[48px] px-2.5 rounded-lg text-xs font-bold tracking-tight transition-transform active:scale-95 ${
              editorMode === 'pcb'
                ? 'bg-[#6ee7b7] text-slate-950 shadow-sm'
                : 'text-slate-300'
            }`}
          >
            PCB
          </button>
        </div>

        <button
          type="button"
          disabled={history.past.length === 0}
          onPointerUp={() => history.past.length > 0 && undo()}
          aria-label="Undo"
          className={`min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl shrink-0 transition-transform active:scale-95 ${
            history.past.length > 0
              ? 'text-slate-100 bg-[#141d1b] border border-[#24322f]'
              : 'text-slate-600 bg-[#141d1b]/40'
          }`}
        >
          <Undo2 className="w-4 h-4" />
        </button>

        <button
          type="button"
          disabled={history.future.length === 0}
          onPointerUp={() => history.future.length > 0 && redo()}
          aria-label="Redo"
          className={`min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl shrink-0 transition-transform active:scale-95 ${
            history.future.length > 0
              ? 'text-slate-100 bg-[#141d1b] border border-[#24322f]'
              : 'text-slate-600 bg-[#141d1b]/40'
          }`}
        >
          <Redo2 className="w-4 h-4" />
        </button>

        <button
          type="button"
          onPointerUp={() =>
            setActiveSheet(activeSheet === 'add_part' ? 'none' : 'add_part')
          }
          aria-label="Footprints Library"
          className={`min-h-[44px] px-3 flex items-center justify-center gap-1.5 rounded-xl text-xs font-bold shrink-0 active:scale-95 transition-transform ${
            activeSheet === 'add_part'
              ? 'bg-[#6ee7b7] text-slate-950'
              : 'bg-[#141d1b] text-[#6ee7b7] border border-[#24322f]'
          }`}
        >
          <PlusSquare className="w-4 h-4 shrink-0" />
          <span>Footprints</span>
        </button>

        <button
          type="button"
          onPointerUp={() =>
            setActiveSheet(activeSheet === 'layers' ? 'none' : 'layers')
          }
          aria-label="Board Settings & Layers"
          className={`min-h-[44px] px-3 flex items-center justify-center gap-1.5 rounded-xl text-xs font-bold shrink-0 transition-transform active:scale-95 ${
            activeSheet === 'layers'
              ? 'bg-[#6ee7b7] text-slate-950'
              : 'bg-[#141d1b] text-slate-200 border border-[#24322f]'
          }`}
        >
          <Layers className="w-4 h-4 shrink-0 text-[#6ee7b7]" />
          <span>Board Settings</span>
        </button>

        {editorMode === 'pcb' && (
          <button
            type="button"
            onPointerUp={() => syncPcbLayoutFromSchematic()}
            aria-label="Sync PCB Layout from Schematic"
            className="min-h-[44px] px-3 flex items-center justify-center gap-1.5 rounded-xl bg-[#141d1b] text-[#6ee7b7] border border-[#24322f] text-xs font-bold shrink-0 active:scale-95 transition-transform"
          >
            <RotateCw className="w-3.5 h-3.5 shrink-0" />
            <span>Sync Netlist</span>
          </button>
        )}

        <button
          type="button"
          onPointerUp={() =>
            setActiveSheet(activeSheet === 'properties' ? 'none' : 'properties')
          }
          aria-label="Properties"
          className={`min-h-[44px] px-3 flex items-center justify-center gap-1.5 rounded-xl text-xs font-bold shrink-0 transition-transform active:scale-95 ${
            activeSheet === 'properties'
              ? 'bg-sky-500 text-slate-950'
              : selectedItemId
                ? 'bg-[#141d1b] text-sky-400 border border-sky-500/40'
                : 'bg-[#141d1b] text-slate-300 border border-[#24322f]'
          }`}
        >
          <Sliders className="w-4 h-4 shrink-0" />
          <span>Props</span>
        </button>

        <button
          type="button"
          onPointerUp={() => setActiveSheet(activeSheet === 'drc' ? 'none' : 'drc')}
          aria-label="Design Rule Check"
          className={`min-h-[44px] px-3 flex items-center justify-center gap-1.5 rounded-xl text-xs font-mono font-bold tabular-nums shrink-0 transition-transform active:scale-95 ${
            activeSheet === 'drc'
              ? 'bg-amber-500 text-slate-950'
              : errorCount > 0
                ? 'bg-rose-950/90 text-rose-300 border border-rose-500/40'
                : 'bg-[#141d1b] text-slate-200 border border-[#24322f]'
          }`}
        >
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span>DRC ({errorCount + warnCount})</span>
        </button>

        <button
          type="button"
          onPointerUp={() => setActiveSheet(activeSheet === 'export' ? 'none' : 'export')}
          aria-label="Export Gerber and KiCad"
          className={`min-h-[44px] px-3 flex items-center justify-center gap-1.5 rounded-xl text-xs font-bold shrink-0 transition-transform active:scale-95 ${
            activeSheet === 'export'
              ? 'bg-[#6ee7b7] text-slate-950'
              : 'bg-[#141d1b] text-[#6ee7b7] border border-[#24322f]'
          }`}
        >
          <Download className="w-4 h-4 shrink-0" />
          <span>Export</span>
        </button>
      </div>
    </header>
  );
};

export const ToolPalette: React.FC = () => {
  const {
    editorMode,
    schTool,
    pcbTool,
    activeSheet,
    selectedItemId,
    setSchTool,
    setPcbTool,
    setActiveSheet,
    openInsertSheet,
    rotateItem,
    deleteItem,
  } = useEditorStore();

  const schTools: { id: SchematicTool; label: string; icon?: React.ReactNode }[] = [
    { id: 'select', label: 'Select', icon: <MousePointer className="w-4 h-4" /> },
    { id: 'wire', label: 'Wire', icon: <GitCommit className="w-4 h-4" /> },
    { id: 'label', label: 'Net', icon: <Tag className="w-4 h-4" /> },
  ];

  const pcbTools: {
    id: PcbTool;
    label: string;
    colorClass?: string;
    icon?: React.ReactNode;
  }[] = [
    { id: 'select', label: 'Move', icon: <MousePointer className="w-4 h-4" /> },
    { id: 'trace_top', label: 'F.Cu', colorClass: 'text-[#38bdf8]' },
    { id: 'trace_bottom', label: 'B.Cu', colorClass: 'text-[#4ade80]' },
    {
      id: 'airwire',
      label: 'Airwire',
      colorClass: 'text-amber-300',
      icon: <Share2 className="w-4 h-4" />,
    },
    { id: 'via', label: 'Via', icon: <CircleDot className="w-4 h-4" /> },
    { id: 'outline', label: 'Edge', icon: <SquareDashed className="w-4 h-4" /> },
    { id: 'measure', label: 'Measure', icon: <Ruler className="w-4 h-4" /> },
  ];

  const activePartLabel =
    editorMode === 'schematic' && schTool.startsWith('place_')
      ? `Place ${schTool.replace('place_', '')}`
      : editorMode === 'pcb' && pcbTool.startsWith('place_')
        ? `Place ${pcbTool.replace('place_', '')}`
        : 'Footprints';

  const isPlacingPart =
    (editorMode === 'schematic' && schTool.startsWith('place_')) ||
    (editorMode === 'pcb' && pcbTool.startsWith('place_'));

  return (
    <div className="fixed bottom-safe left-safe z-20 flex flex-col gap-2 max-w-[calc(100vw-84px)]">
      {selectedItemId && (
        <div className="flex items-center gap-1.5 bg-[#0d1312]/95 backdrop-blur-md p-1.5 rounded-2xl border border-[#24322f] shadow-xl self-start">
          <button
            type="button"
            onPointerUp={() => rotateItem(selectedItemId)}
            className="min-w-[48px] min-h-[48px] px-3 rounded-xl bg-[#141d1b] text-slate-100 flex items-center justify-center gap-1.5 text-xs font-semibold active:scale-95 transition-transform"
          >
            <RotateCw className="w-4 h-4 text-[#6ee7b7]" />
            <span>Rot</span>
          </button>
          <button
            type="button"
            onPointerUp={() => setActiveSheet('properties')}
            className="min-w-[48px] min-h-[48px] px-3 rounded-xl bg-[#141d1b] text-slate-100 flex items-center justify-center gap-1.5 text-xs font-semibold active:scale-95 transition-transform"
          >
            <Sliders className="w-4 h-4 text-sky-400" />
            <span>Edit</span>
          </button>
          <button
            type="button"
            onPointerUp={() => deleteItem(selectedItemId)}
            className="min-w-[48px] min-h-[48px] px-3 rounded-xl bg-rose-950/80 text-rose-300 border border-rose-500/30 flex items-center justify-center gap-1.5 text-xs font-semibold active:scale-95 transition-transform"
          >
            <Trash2 className="w-4 h-4" />
            <span>Del</span>
          </button>
        </div>
      )}

      <div className="flex items-center gap-1 overflow-x-auto no-scrollbar bg-[#0d1312]/95 backdrop-blur-md p-1.5 rounded-2xl border border-[#24322f] shadow-2xl">
        {/* Primary Insert Menu Launcher ("Insert — Add geometry to the current board") */}
        <button
          type="button"
          onPointerUp={() => openInsertSheet('menu')}
          className={`min-w-[54px] min-h-[48px] px-3 rounded-xl flex flex-col items-center justify-center gap-0.5 text-[11px] font-bold shrink-0 active:scale-95 transition-transform ${
            activeSheet === 'insert'
              ? 'bg-[#6ee7b7] text-slate-950 shadow-md'
              : 'bg-[#141d1b] text-[#6ee7b7] border border-[#6ee7b7]/30'
          }`}
        >
          <PlusCircle className="w-4 h-4" />
          <span>Insert</span>
        </button>

        {/* Footprints Library Button */}
        <button
          type="button"
          onPointerUp={() => setActiveSheet('add_part')}
          className={`min-w-[54px] min-h-[48px] px-3 rounded-xl flex flex-col items-center justify-center gap-0.5 text-[11px] font-bold shrink-0 active:scale-95 transition-transform ${
            isPlacingPart || activeSheet === 'add_part'
              ? 'bg-[#6ee7b7] text-slate-950 shadow-md'
              : 'bg-[#141d1b] text-[#6ee7b7]'
          }`}
        >
          <PlusSquare className="w-4 h-4" />
          <span>{activePartLabel}</span>
        </button>

        {editorMode === 'schematic' ? (
          <>
            {schTools.map((t) => {
              const active = schTool === t.id;
              return (
                <button
                  key={t.id}
                  type="button"
                  onPointerUp={() => setSchTool(t.id)}
                  className={`min-w-[48px] min-h-[48px] px-3 rounded-xl flex flex-col items-center justify-center gap-0.5 text-[11px] font-bold tracking-tight shrink-0 transition-transform active:scale-95 ${
                    active
                      ? 'bg-[#6ee7b7] text-slate-950 shadow-md'
                      : 'bg-[#141d1b] text-slate-200'
                  }`}
                >
                  {t.icon}
                  <span>{t.label}</span>
                </button>
              );
            })}
            <button
              type="button"
              onPointerUp={() => setSchTool('place_VCC')}
              className={`min-w-[48px] min-h-[48px] px-2.5 rounded-xl flex flex-col items-center justify-center gap-0.5 text-[11px] font-bold shrink-0 active:scale-95 ${
                schTool === 'place_VCC'
                  ? 'bg-[#6ee7b7] text-slate-950'
                  : 'bg-[#141d1b] text-amber-300'
              }`}
            >
              <Zap className="w-4 h-4" />
              <span>VCC</span>
            </button>
            <button
              type="button"
              onPointerUp={() => setSchTool('place_GND')}
              className={`min-w-[48px] min-h-[48px] px-2.5 rounded-xl flex flex-col items-center justify-center gap-0.5 text-[11px] font-bold shrink-0 active:scale-95 ${
                schTool === 'place_GND'
                  ? 'bg-[#6ee7b7] text-slate-950'
                  : 'bg-[#141d1b] text-emerald-300'
              }`}
            >
              <Minus className="w-4 h-4" />
              <span>GND</span>
            </button>
          </>
        ) : (
          <>
            {pcbTools.map((t) => {
              const active = pcbTool === t.id;
              return (
                <button
                  key={t.id}
                  type="button"
                  onPointerUp={() => setPcbTool(t.id)}
                  className={`min-w-[48px] min-h-[48px] px-2.5 rounded-xl flex flex-col items-center justify-center gap-0.5 text-[11px] font-bold tracking-tight shrink-0 transition-transform active:scale-95 ${
                    active
                      ? 'bg-[#6ee7b7] text-slate-950 shadow-md'
                      : `bg-[#141d1b] ${t.colorClass || 'text-slate-200'}`
                  }`}
                >
                  {t.icon || <Cpu className="w-4 h-4" />}
                  <span>{t.label}</span>
                </button>
              );
            })}
          </>
        )}
      </div>
    </div>
  );
};

export const ZoomControls: React.FC = () => {
  const { zoomBy, fitViewport, boardConfig, updateBoardConfig } = useEditorStore();
  const isMil = boardConfig.unitSystem === 'mil';

  return (
    <div className="fixed bottom-safe right-safe z-20 flex flex-col gap-1.5 bg-[#0d1312]/95 backdrop-blur-md p-1.5 rounded-2xl border border-[#24322f] shadow-2xl">
      <button
        type="button"
        aria-label="Toggle Metric mm or Imperial mil"
        onPointerUp={() =>
          updateBoardConfig({ unitSystem: isMil ? 'mm' : 'mil' })
        }
        className="w-12 h-11 rounded-xl bg-[#141d1b] border border-[#6ee7b7]/35 text-[#6ee7b7] font-mono text-[11px] font-extrabold flex flex-col items-center justify-center leading-none active:scale-95 transition-transform"
      >
        <span>{isMil ? 'MIL' : 'MM'}</span>
        <span className="text-[8px] text-slate-400 mt-0.5">
          {isMil ? 'IMP' : 'MET'}
        </span>
      </button>
      <button
        type="button"
        aria-label="Zoom In"
        onPointerUp={() => zoomBy(1.25)}
        className="w-12 h-12 rounded-xl bg-[#141d1b] text-slate-100 flex items-center justify-center active:scale-95 transition-transform"
      >
        <Plus className="w-5 h-5" />
      </button>
      <button
        type="button"
        aria-label="Zoom Out"
        onPointerUp={() => zoomBy(0.8)}
        className="w-12 h-12 rounded-xl bg-[#141d1b] text-slate-100 flex items-center justify-center active:scale-95 transition-transform"
      >
        <Minus className="w-5 h-5" />
      </button>
      <button
        type="button"
        aria-label="Fit to Screen"
        onPointerUp={() => fitViewport(window.innerWidth, window.innerHeight)}
        className="w-12 h-12 rounded-xl bg-[#141d1b] text-[#6ee7b7] flex items-center justify-center active:scale-95 transition-transform"
      >
        <Maximize2 className="w-4 h-4" />
      </button>
    </div>
  );
};

export const ContextMenu: React.FC = () => {
  const {
    contextMenu,
    closeContextMenu,
    rotateItem,
    deleteItem,
    setActiveSheet,
    fitViewport,
  } = useEditorStore();

  if (!contextMenu.open) return null;

  const left = Math.min(Math.max(12, contextMenu.screenPt.x - 80), window.innerWidth - 176);
  const top = Math.min(Math.max(64, contextMenu.screenPt.y - 60), window.innerHeight - 190);

  return (
    <div className="fixed inset-0 z-40" onPointerUp={() => closeContextMenu()}>
      <div
        style={{ left: `${left}px`, top: `${top}px` }}
        className="fixed w-44 bg-[#141d1b]/95 backdrop-blur-md border border-[#24322f] rounded-2xl p-1.5 shadow-2xl flex flex-col gap-1"
        onPointerUp={(e) => e.stopPropagation()}
      >
        {contextMenu.itemId ? (
          <>
            <button
              type="button"
              onPointerUp={() => {
                rotateItem(contextMenu.itemId!);
                closeContextMenu();
              }}
              className="min-h-[44px] px-3 rounded-xl bg-[#1b2422] text-slate-100 text-xs font-semibold flex items-center gap-2.5 active:scale-95"
            >
              <RotateCw className="w-4 h-4 text-[#6ee7b7]" />
              <span>Rotate 90°</span>
            </button>
            <button
              type="button"
              onPointerUp={() => {
                setActiveSheet('properties');
                closeContextMenu();
              }}
              className="min-h-[44px] px-3 rounded-xl bg-[#1b2422] text-slate-100 text-xs font-semibold flex items-center gap-2.5 active:scale-95"
            >
              <Sliders className="w-4 h-4 text-sky-400" />
              <span>Properties</span>
            </button>
            <button
              type="button"
              onPointerUp={() => {
                deleteItem(contextMenu.itemId!);
                closeContextMenu();
              }}
              className="min-h-[44px] px-3 rounded-xl bg-rose-950/80 text-rose-300 text-xs font-semibold flex items-center gap-2.5 active:scale-95"
            >
              <Trash2 className="w-4 h-4" />
              <span>Delete</span>
            </button>
          </>
        ) : (
          <button
            type="button"
            onPointerUp={() => {
              fitViewport(window.innerWidth, window.innerHeight);
              closeContextMenu();
            }}
            className="min-h-[44px] px-3 rounded-xl bg-[#1b2422] text-slate-100 text-xs font-semibold flex items-center gap-2.5 active:scale-95"
          >
            <Maximize2 className="w-4 h-4 text-[#6ee7b7]" />
            <span>Fit Board to View</span>
          </button>
        )}
      </div>
    </div>
  );
};

export const NumericKeypad: React.FC = () => {
  const { keypad, closeKeypad } = useEditorStore();
  const [val, setVal] = useState(keypad.initialValue);
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (keypad.open) {
      setVal(keypad.initialValue);
      setTimeout(() => {
        inputRef.current?.focus();
        inputRef.current?.select();
      }, 40);
    }
  }, [keypad.open, keypad.initialValue]);

  if (!keypad.open) return null;

  const handleCommit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (keypad.onCommit) {
      keypad.onCommit(val);
    }
    closeKeypad();
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex flex-col justify-end"
      onPointerUp={(e) => {
        if (e.target === e.currentTarget) closeKeypad();
      }}
    >
      <form
        onSubmit={handleCommit}
        className="w-full bg-[#141d1b] border-t border-[#24322f] rounded-t-3xl p-4 pb-safe space-y-3 shadow-2xl"
        onPointerUp={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-300">{keypad.title}</span>
          <button
            type="button"
            onPointerUp={closeKeypad}
            className="w-11 h-11 rounded-xl bg-[#1b2422] text-slate-300 flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="h-14 px-4 rounded-2xl bg-[#0d1312] border border-[#6ee7b7]/60 flex items-center justify-between gap-2">
          <input
            ref={inputRef}
            type={keypad.allowLetters ? 'text' : 'number'}
            step="any"
            inputMode={keypad.allowLetters ? 'text' : 'decimal'}
            enterKeyHint="done"
            autoFocus
            value={val}
            onChange={(e) => setVal(e.target.value)}
            placeholder={keypad.initialValue || 'Enter value...'}
            className="flex-1 bg-transparent font-mono text-xl font-bold text-[#6ee7b7] tracking-wider focus:outline-none"
          />
          {keypad.unit && (
            <span className="text-xs font-mono text-slate-400 shrink-0">
              {keypad.unit}
            </span>
          )}
        </div>

        <button
          type="submit"
          className="w-full min-h-[52px] rounded-2xl bg-[#6ee7b7] text-slate-950 font-bold text-base flex items-center justify-center gap-2 active:scale-98"
        >
          <Check className="w-5 h-5" />
          <span>Apply Value</span>
        </button>
      </form>
    </div>
  );
};

export const Snackbar: React.FC = () => {
  const { snackbar, undo, dismissSnackbar } = useEditorStore();

  useEffect(() => {
    if (!snackbar.open) return;
    const timer = setTimeout(() => {
      dismissSnackbar();
    }, 4500);
    return () => clearTimeout(timer);
  }, [snackbar.open, snackbar.message, dismissSnackbar]);

  if (!snackbar.open) return null;

  return (
    <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 bg-[#141d1b]/95 backdrop-blur-md border border-[#24322f] text-slate-100 px-3.5 py-1.5 rounded-2xl shadow-2xl min-h-[46px]">
      <span className="text-xs font-medium whitespace-nowrap">{snackbar.message}</span>
      {snackbar.canUndo && (
        <button
          type="button"
          onPointerUp={() => undo()}
          className="min-h-[38px] px-3 rounded-xl bg-[#6ee7b7] text-slate-950 font-bold text-xs flex items-center gap-1 active:scale-95"
        >
          <Undo2 className="w-3.5 h-3.5" />
          <span>Undo</span>
        </button>
      )}
      <button
        type="button"
        onPointerUp={() => dismissSnackbar()}
        aria-label="Dismiss"
        className="min-w-[36px] min-h-[36px] flex items-center justify-center text-slate-400"
      >
        <X className="w-4 h-4" />
      </button>
    </div>
  );
};
