import React, { useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  Box,
  Camera,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  CircleDot,
  CloudDownload,
  Compass,
  Cpu,
  Eye,
  EyeOff,
  FileCode2,
  FileSpreadsheet,
  Folder,
  Grid,
  Hash,
  History,
  Image as ImageIcon,
  Info,
  Layers,
  MoreVertical,
  Pencil,
  Plus,
  QrCode,
  Radio,
  RefreshCw,
  RotateCw,
  Search,
  Share2,
  Sliders,
  Sparkles,
  Star,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import { OFFICIAL_FOOTPRINT_CATEGORIES } from '../../core/geometry';
import {
  createZipArchive,
  generateBomCsv,
  generateCopperGerber,
  generateExcellonDrill,
  generateFabGerber,
  generateGerberBundle,
  generateKicadPcb,
  generateKicadSch,
  generateMaskGerber,
  generateOutlineGerber,
  generatePasteGerber,
  generateSilkscreenGerber,
} from '../../core/gerber';
import {
  AntennaGeneratorOptions,
  computeAntennaMetrics,
  computePlanarCoilMetrics,
  createSampleBoardPhotoDataUrl,
  DxfInsertOptions,
  MountingHoleOptions,
  PadViaArrayOptions,
  PlanarCoilOptions,
  QrBarcodeOptions,
  SCREW_PRESETS,
  SvgInsertOptions,
  ViaStitchingOptions,
} from '../../core/insertGenerators';
import { serializeProject } from '../../core/serialization';
import {
  AnyItem,
  LayerId,
  PcbFootprintItem,
  PcbOutlineItem,
  PcbTraceItem,
  PcbViaItem,
  SchComponentItem,
  SchLabelItem,
} from '../../core/types';
import { useEditorStore } from '../store/useEditorStore';

async function shareOrDownloadFile(filename: string, content: string, mimeType = 'text/plain') {
  const blob = new Blob([content], { type: mimeType });
  const file = new File([blob], filename, { type: mimeType });

  if (
    typeof navigator !== 'undefined' &&
    navigator.canShare &&
    navigator.canShare({ files: [file] })
  ) {
    try {
      await navigator.share({
        title: filename,
        files: [file],
      });
      return;
    } catch {
      // Fall back to direct download
    }
  }

  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

const ToggleSwitch: React.FC<{
  checked: boolean;
  onChange: () => void;
}> = ({ checked, onChange }) => (
  <button
    type="button"
    role="switch"
    aria-checked={checked}
    onPointerUp={onChange}
    className={`w-13 h-7 rounded-full p-1 transition-colors flex items-center shrink-0 ${
      checked ? 'bg-[#6ee7b7] justify-end' : 'bg-[#2a3633] justify-start'
    }`}
  >
    <span
      className={`w-5 h-5 rounded-full transition-transform ${
        checked ? 'bg-[#0d1312]' : 'bg-slate-400'
      }`}
    />
  </button>
);

const PhoneInputField: React.FC<{
  value: string;
  inputMode?: 'text' | 'decimal' | 'numeric';
  onCommit: (val: string) => void;
  className?: string;
  ariaLabel?: string;
}> = ({ value, inputMode = 'decimal', onCommit, className, ariaLabel }) => {
  const [draft, setDraft] = useState(value);
  useEffect(() => {
    setDraft(value);
  }, [value]);

  return (
    <input
      type="text"
      inputMode={inputMode}
      enterKeyHint="done"
      aria-label={ariaLabel}
      value={draft}
      onChange={(e) => {
        setDraft(e.target.value);
        onCommit(e.target.value);
      }}
      onBlur={() => onCommit(draft)}
      onKeyDown={(e) => {
        if (e.key === 'Enter') {
          onCommit(draft);
          (e.currentTarget as HTMLInputElement).blur();
        }
      }}
      className={
        className ??
        'w-full min-h-[48px] px-3.5 rounded-xl bg-[#0d1312] border border-[#2f3e3b] text-left font-mono text-base text-slate-100 focus:outline-none focus:border-[#6ee7b7]'
      }
    />
  );
};

export const BottomSheets: React.FC = () => {
  // Footprints Sheet State (Official / Mine)
  const [fpTab, setFpTab] = useState<'official' | 'mine'>('official');
  const [recentOpen, setRecentOpen] = useState<boolean>(true);
  const [expandedFolders, setExpandedFolders] = useState<Record<string, boolean>>({});
  const [searchOpen, setSearchOpen] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [macroMenuOpen, setMacroMenuOpen] = useState<string | null>(null);

  // Board Settings Sheet State (Layers / Board / View)
  const [settingsTab, setSettingsTab] = useState<'layers' | 'board' | 'view'>('layers');
  const cornerDragStartRef = useRef<{ startX: number; startY: number; startRadius: number } | null>(
    null
  );

  // Insert Sheet Interactive State
  const svgFileInputRef = useRef<HTMLInputElement | null>(null);
  const dxfFileInputRef = useRef<HTMLInputElement | null>(null);
  const photoFileInputRef = useRef<HTMLInputElement | null>(null);

  const [svgOpts, setSvgOpts] = useState<SvgInsertOptions>({
    preset: 'oshw_gear',
    targetLayer: 'F.Cu',
    sizeMm: 12,
    traceWidthMm: 0.35,
  });
  const [dxfOpts, setDxfOpts] = useState<DxfInsertOptions>({
    preset: 'arduino_shield',
    targetLayer: 'Edge.Cuts',
    scaleFactor: 1,
  });
  const [antOpts, setAntOpts] = useState<AntennaGeneratorOptions>({
    frequencyMhz: 2450,
    topology: 'mifa',
    layer: 'F.Cu',
    traceWidthMm: 0.45,
  });
  const [coilOpts, setCoilOpts] = useState<PlanarCoilOptions>({
    turns: 6,
    traceWidthMm: 0.35,
    spacingMm: 0.35,
    innerDiameterMm: 4.0,
    shape: 'octagonal',
    layer: 'F.Cu',
  });
  const [qrOpts, setQrOpts] = useState<QrBarcodeOptions>({
    text: 'POCKETEDA-V1',
    format: 'qr',
    sizeMm: 10,
    layer: 'F.SilkS',
  });
  const [mhOpts, setMhOpts] = useState<MountingHoleOptions>({
    screwStandard: 'M3',
    drillMm: 3.2,
    keepoutDiameterMm: 6.4,
    placement: 'corners_4',
    cornerInsetMm: 3.5,
    platedGrounded: true,
  });
  const [arrOpts, setArrOpts] = useState<PadViaArrayOptions>({
    mode: 'smd_pads',
    rows: 2,
    cols: 4,
    pitchXMm: 2.54,
    pitchYMm: 2.54,
    padWidthMm: 1.4,
    padHeightMm: 1.4,
    drillMm: 0.8,
    numbering: 'row_major',
    layer: 'F.Cu',
    net: '',
  });
  const [stitchOpts, setStitchOpts] = useState<ViaStitchingOptions>({
    mode: 'full_pour_grid',
    net: 'GND',
    pitchMm: 3.5,
    edgeInsetMm: 1.8,
    viaDiameterMm: 0.8,
    viaDrillMm: 0.4,
    clearanceMm: 0.45,
  });
  const [desigDirection, setDesigDirection] = useState<'top_to_bottom' | 'left_to_right'>(
    'top_to_bottom'
  );
  const [desigStartIdx, setDesigStartIdx] = useState<number>(1);

  const {
    history,
    editorMode,
    activeSheet,
    insertSubView,
    selectedItemId,
    activePcbLayer,
    boardConfig,
    viewConfig,
    photoOverlay,
    layerVisibility,
    drcViolations,
    availableParts,
    recentlyUsedKinds,
    favoriteKinds,
    customMacros,
    setActiveSheet,
    setInsertSubView,
    updatePhotoOverlay,
    insertSvgGeometry,
    insertDxfGeometry,
    generateBoardAntenna,
    generateBoardCoil,
    generateBoardQrBarcode,
    generateBoardMountingHoles,
    generateBoardPadViaArray,
    generateBoardViaStitching,
    runAutoDesignators,
    setEditorMode,
    setActivePcbLayer,
    toggleLayerVisibility,
    setAllLayersVisibility,
    updateBoardConfig,
    updateViewConfig,
    toggleFavoritePart,
    createCustomMacro,
    deleteCustomMacro,
    updateBoardOutline,
    splitBoardOutlineEdge,
    applyBoardShapePreset,
    rotateItem,
    deleteItem,
    updateItemProps,
    openKeypad,
    focusViolation,
    runDrcCheck,
    setSchTool,
    setPcbTool,
    newBlankProject,
    loadStarterProject,
    showSnackbar,
  } = useEditorStore();

  if (activeSheet === 'none') return null;

  const currentSheet = history.project.sheets.find((s) => s.kind === editorMode);
  const selectedItem: AnyItem | undefined = currentSheet?.items.find(
    (i) => i.id === selectedItemId
  );

  const pcbSheet = history.project.sheets.find((s) => s.kind === 'pcb');
  const outlineItem = pcbSheet?.items.find(
    (i): i is PcbOutlineItem => i.type === 'pcb_outline'
  );
  const boardX = outlineItem?.transform.x ?? 4;
  const boardY = outlineItem?.transform.y ?? 4;
  const boardW = outlineItem?.props.width ?? 50.0;
  const boardH = outlineItem?.props.height ?? 50.0;

  const isMil = boardConfig.unitSystem === 'mil';
  const unitLabel = isMil ? 'mil' : 'mm';
  const MM_TO_MIL = 39.3700787;
  const toUnitStr = (valMm: number, decMm = 2, decMil = 1) =>
    isMil ? (valMm * MM_TO_MIL).toFixed(decMil) : valMm.toFixed(decMm);
  const fromUnitVal = (valUser: number) =>
    isMil ? Number((valUser / MM_TO_MIL).toFixed(4)) : valUser;

  // 6-layer rows with color swatches
  const pcbLayersList: {
    id: LayerId;
    name: string;
    swatchClass: string;
    hasDot?: boolean;
  }[] = [
    { id: 'F.SilkS', name: 'Silkscreen Top', swatchClass: 'bg-[#f87171]' },
    { id: 'F.Mask', name: 'Solder Mask Top', swatchClass: 'bg-[#e879f9]' },
    { id: 'F.Cu', name: 'Copper Top', swatchClass: 'bg-[#38bdf8]', hasDot: true },
    { id: 'B.Cu', name: 'Copper Bottom', swatchClass: 'bg-[#4ade80]', hasDot: true },
    { id: 'B.Mask', name: 'Solder Mask Bottom', swatchClass: 'bg-[#c084fc]' },
    { id: 'B.SilkS', name: 'Silkscreen Bottom', swatchClass: 'bg-[#facc15]' },
  ];

  const selectPartForPlacement = (kind: string) => {
    if (editorMode === 'schematic') {
      setSchTool(`place_${kind}`);
    } else {
      setPcbTool(`place_${kind}`);
    }
    setActiveSheet('none');
  };

  const modeFilteredParts = availableParts.filter((p) =>
    editorMode === 'pcb' ? p.pcbAllowed : true
  );

  const queryClean = searchQuery.trim().toLowerCase();
  const searchFilteredParts = queryClean
    ? modeFilteredParts.filter(
        (p) =>
          p.title.toLowerCase().includes(queryClean) ||
          p.description.toLowerCase().includes(queryClean) ||
          p.footprint.toLowerCase().includes(queryClean) ||
          p.category.toLowerCase().includes(queryClean)
      )
    : modeFilteredParts;

  const recentParts = recentlyUsedKinds
    .map((k) => availableParts.find((p) => p.kind === k))
    .filter((p): p is NonNullable<typeof p> => Boolean(p));

  const totalPartsBadge = availableParts.length;

  // ============================================================================
  // 1. FOOTPRINTS FULL-SCREEN / HIGH SHEET (Official | Mine)
  // ============================================================================
  if (activeSheet === 'add_part') {
    return (
      <div className="fixed inset-0 z-40 bg-[#0d1312] text-slate-100 flex flex-col pt-safe pb-safe pl-safe pr-safe select-none">
        {/* Top Header */}
        <div className="h-14 px-4 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-4">
            <button
              type="button"
              onPointerUp={() => setActiveSheet('none')}
              aria-label="Close Footprints"
              className="w-11 h-11 rounded-xl flex items-center justify-center text-slate-200 active:scale-95"
            >
              <X className="w-6 h-6" />
            </button>
            <div>
              <h2 className="text-xl font-bold text-[#6ee7b7] tracking-tight">
                Footprints
              </h2>
              <p className="text-[10px] font-mono text-slate-400">
                git@gitlab.com:kicad/libraries/kicad-footprints.git
              </p>
            </div>
          </div>

          <button
            type="button"
            aria-label="Create Custom Footprint Macro"
            onPointerUp={() => {
              setFpTab('mine');
              openKeypad({
                title: 'New Custom Footprint Name',
                initialValue: `Custom_FP_${customMacros.length + 1}`,
                unit: '',
                allowLetters: true,
                onCommit: (val) => createCustomMacro(val, 4),
              });
            }}
            className="w-11 h-11 rounded-xl flex items-center justify-center text-slate-200 active:scale-95"
          >
            <Sparkles className="w-5 h-5" />
          </button>
        </div>

        {/* 2-Tab Segmented Bar: Official | Mine */}
        <div className="px-4 pt-1 pb-2 shrink-0">
          <div className="grid grid-cols-2 bg-[#242e2c] rounded-2xl overflow-hidden">
            {(['official', 'mine'] as const).map((tab) => {
              const active = fpTab === tab;
              const label =
                tab === 'official'
                  ? `Official (${availableParts.length})`
                  : `Mine (${customMacros.length + favoriteKinds.length})`;
              return (
                <button
                  key={tab}
                  type="button"
                  onPointerUp={() => setFpTab(tab)}
                  className={`min-h-[48px] relative flex items-center justify-center text-sm font-bold transition-colors ${
                    active ? 'text-white' : 'text-slate-300'
                  }`}
                >
                  <span>{label}</span>
                  {active && (
                    <span className="absolute bottom-0 left-3 right-3 h-[3px] rounded-t-full bg-[#6ee7b7]" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto px-4 py-2 flex flex-col">
          {fpTab === 'official' && (
            <div className="flex-1 flex flex-col space-y-3">
              <div className="flex items-center justify-between py-1">
                <h3 className="text-base font-bold text-white">Official library</h3>
                <button
                  type="button"
                  aria-label="Search library"
                  onPointerUp={() => setSearchOpen((s) => !s)}
                  className="w-11 h-11 rounded-xl flex items-center justify-center text-slate-300 active:scale-95"
                >
                  <Search className="w-5 h-5" />
                </button>
              </div>

              {searchOpen && (
                <div className="flex items-center gap-2 bg-[#1b2422] border border-[#2f3e3b] rounded-2xl px-3 py-1.5">
                  <Search className="w-4 h-4 text-[#6ee7b7] shrink-0" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Filter footprints (e.g. Cherry, 0805, NE555, QFN)..."
                    className="w-full min-h-[38px] bg-transparent text-sm text-white focus:outline-none"
                  />
                  {searchQuery && (
                    <button
                      type="button"
                      onPointerUp={() => setSearchQuery('')}
                      className="w-9 h-9 flex items-center justify-center text-slate-400"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
              )}

              <div className="bg-[#232c2a] rounded-2xl overflow-hidden divide-y divide-white/5 shadow-xl">
                {/* Recently used collapsible section */}
                {!queryClean && (
                  <div className="bg-[#283330]/60">
                    <button
                      type="button"
                      onPointerUp={() => setRecentOpen((o) => !o)}
                      className="w-full min-h-[52px] px-4 flex items-center justify-between text-left active:bg-white/5"
                    >
                      <div className="flex items-center gap-3">
                        {recentOpen ? (
                          <ChevronDown className="w-4 h-4 text-slate-300" />
                        ) : (
                          <ChevronRight className="w-4 h-4 text-slate-300" />
                        )}
                        <History className="w-5 h-5 text-[#6ee7b7]" />
                        <span className="text-base font-bold text-slate-100">
                          Recently used
                        </span>
                      </div>
                      <span className="text-xs font-mono text-slate-400">
                        {recentParts.length}
                      </span>
                    </button>

                    {recentOpen && (
                      <div className="pb-2">
                        {recentParts.map((part) => {
                          const isFav = favoriteKinds.includes(part.kind);
                          return (
                            <div
                              key={part.kind}
                              className="min-h-[48px] pl-11 pr-3 flex items-center justify-between gap-2 active:bg-white/5"
                            >
                              <button
                                type="button"
                                onPointerUp={() => selectPartForPlacement(part.kind)}
                                className="flex-1 min-h-[44px] flex items-center gap-3 text-left"
                              >
                                <Cpu className="w-5 h-5 text-slate-300 shrink-0" />
                                <div>
                                  <div className="text-sm font-medium text-slate-100">
                                    {part.title}
                                  </div>
                                  <div className="text-[11px] text-slate-400">
                                    {part.description}
                                  </div>
                                </div>
                              </button>
                              <button
                                type="button"
                                aria-label="Favorite footprint"
                                onPointerUp={() => toggleFavoritePart(part.kind)}
                                className="w-11 h-11 flex items-center justify-center text-slate-400 active:scale-95"
                              >
                                <Star
                                  className={`w-5 h-5 ${
                                    isFav ? 'fill-[#6ee7b7] text-[#6ee7b7]' : ''
                                  }`}
                                />
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}

                {/* 20 Official Category Folders */}
                {OFFICIAL_FOOTPRINT_CATEGORIES.map((category) => {
                  const categoryParts = searchFilteredParts.filter(
                    (p) => p.category === category
                  );
                  if (queryClean && categoryParts.length === 0) return null;
                  const isOpen = Boolean(expandedFolders[category]) || Boolean(queryClean);

                  return (
                    <div key={category}>
                      <button
                        type="button"
                        onPointerUp={() =>
                          setExpandedFolders((prev) => ({
                            ...prev,
                            [category]: !prev[category],
                          }))
                        }
                        className="w-full min-h-[54px] px-4 flex items-center justify-between text-left active:bg-white/5"
                      >
                        <div className="flex items-center gap-3.5">
                          {isOpen ? (
                            <ChevronDown className="w-4 h-4 text-slate-300" />
                          ) : (
                            <ChevronRight className="w-4 h-4 text-slate-300" />
                          )}
                          <Folder className="w-5 h-5 fill-slate-300 text-slate-300" />
                          <span className="text-base font-medium text-slate-100">
                            {category}
                          </span>
                        </div>
                        <span className="text-xs font-mono text-[#6ee7b7]">
                          {categoryParts.length}
                        </span>
                      </button>

                      {isOpen && (
                        <div className="bg-[#1b2321] py-1 divide-y divide-white/5">
                          {categoryParts.map((part) => {
                            const isFav = favoriteKinds.includes(part.kind);
                            return (
                              <div
                                key={part.kind}
                                className="min-h-[52px] pl-11 pr-3 flex items-center justify-between gap-2 active:bg-white/5"
                              >
                                <button
                                  type="button"
                                  onPointerUp={() => selectPartForPlacement(part.kind)}
                                  className="flex-1 min-h-[48px] py-1.5 flex items-center gap-3 text-left min-w-0"
                                >
                                  <Cpu className="w-4 h-4 text-[#6ee7b7] shrink-0" />
                                  <div className="min-w-0">
                                    <div className="text-sm font-semibold text-slate-100 truncate">
                                      {part.title}
                                    </div>
                                    <div className="text-[11px] text-slate-400 truncate">
                                      {part.description} · {part.footprint}
                                    </div>
                                  </div>
                                </button>
                                <button
                                  type="button"
                                  aria-label="Star footprint"
                                  onPointerUp={() => toggleFavoritePart(part.kind)}
                                  className="w-11 h-11 flex items-center justify-center text-slate-400 active:scale-95"
                                >
                                  <Star
                                    className={`w-4 h-4 ${
                                      isFav ? 'fill-[#6ee7b7] text-[#6ee7b7]' : ''
                                    }`}
                                  />
                                </button>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {fpTab === 'mine' && (
            <div className="flex-1 flex flex-col space-y-3">
              <div className="flex items-center justify-between py-1">
                <h3 className="text-base font-bold text-white">My footprints</h3>
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1.5 rounded-xl bg-[#232c2a] text-xs font-semibold text-slate-200">
                    {customMacros.length} / 5 macros
                  </span>
                  <button
                    type="button"
                    aria-label="Search my footprints"
                    onPointerUp={() => setSearchOpen((s) => !s)}
                    className="w-10 h-10 rounded-xl flex items-center justify-center text-slate-300 active:scale-95"
                  >
                    <Search className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="flex-1 bg-[#232c2a] rounded-2xl p-3 flex flex-col justify-between min-h-[380px]">
                <div className="space-y-1">
                  {customMacros.map((macro) => (
                    <div key={macro.kind} className="relative">
                      <div className="min-h-[52px] px-3 rounded-xl flex items-center justify-between hover:bg-white/5">
                        <button
                          type="button"
                          onPointerUp={() => selectPartForPlacement(macro.kind)}
                          className="flex-1 min-h-[48px] flex items-center gap-3.5 text-left"
                        >
                          <Box className="w-5 h-5 text-slate-300 shrink-0" />
                          <span className="text-base font-medium text-slate-100">
                            {macro.title}
                          </span>
                        </button>
                        <button
                          type="button"
                          aria-label="Macro options"
                          onPointerUp={() =>
                            setMacroMenuOpen(
                              macroMenuOpen === macro.kind ? null : macro.kind
                            )
                          }
                          className="w-11 h-11 rounded-xl flex items-center justify-center text-slate-300 active:scale-95"
                        >
                          <MoreVertical className="w-5 h-5" />
                        </button>
                      </div>

                      {macroMenuOpen === macro.kind && (
                        <div className="mx-3 mb-2 p-2 rounded-xl bg-[#141d1b] border border-[#2f3e3b] flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onPointerUp={() => selectPartForPlacement(macro.kind)}
                            className="min-h-[40px] px-3 rounded-lg bg-[#6ee7b7] text-slate-950 text-xs font-bold"
                          >
                            Place on Board
                          </button>
                          {customMacros.length > 1 && (
                            <button
                              type="button"
                              onPointerUp={() => {
                                deleteCustomMacro(macro.kind);
                                setMacroMenuOpen(null);
                              }}
                              className="min-h-[40px] px-3 rounded-lg bg-rose-950 text-rose-300 text-xs font-bold"
                            >
                              Delete
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  ))}

                  {favoriteKinds.map((favKind) => {
                    const part = availableParts.find((p) => p.kind === favKind);
                    if (!part) return null;
                    return (
                      <div
                        key={part.kind}
                        className="min-h-[52px] px-3 rounded-xl flex items-center justify-between"
                      >
                        <button
                          type="button"
                          onPointerUp={() => selectPartForPlacement(part.kind)}
                          className="flex-1 min-h-[48px] flex items-center gap-3.5 text-left"
                        >
                          <Star className="w-5 h-5 fill-[#6ee7b7] text-[#6ee7b7] shrink-0" />
                          <span className="text-base font-medium text-slate-100">
                            {part.title}
                          </span>
                        </button>
                        <button
                          type="button"
                          onPointerUp={() => toggleFavoritePart(part.kind)}
                          className="w-11 h-11 flex items-center justify-center text-slate-400"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    );
                  })}
                </div>

                {customMacros.length < 5 && (
                  <button
                    type="button"
                    onPointerUp={() =>
                      openKeypad({
                        title: 'New Custom Footprint Name',
                        initialValue: `Custom_FP_${customMacros.length + 1}`,
                        unit: '',
                        allowLetters: true,
                        onCommit: (val) => createCustomMacro(val, 6),
                      })
                    }
                    className="min-h-[46px] px-4 rounded-xl bg-[#182220] border border-[#2f3e3b] text-[#6ee7b7] text-xs font-bold flex items-center justify-center gap-2 self-center active:scale-95"
                  >
                    <Plus className="w-4 h-4" />
                    <span>New Custom Footprint Macro</span>
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer Status Bar */}
        <div className="h-11 flex items-center justify-center gap-2 text-xs text-slate-300 shrink-0">
          <span>{totalPartsBadge} preset parts · kicad-footprints.git synced</span>
          <Info className="w-4 h-4 text-slate-400" />
        </div>
      </div>
    );
  }

  // ============================================================================
  // 2. BOARD SETTINGS FULL-SCREEN / HIGH SHEET
  // ============================================================================
  if (activeSheet === 'layers') {
    return (
      <div className="fixed inset-0 z-40 bg-[#0d1312] text-slate-100 flex flex-col pt-safe pb-safe pl-safe pr-safe select-none">
        {/* Top Header */}
        <div className="h-14 px-5 flex items-center justify-between shrink-0">
          <h2 className="text-xl font-bold text-slate-100 tracking-tight">
            Board Settings
          </h2>
          <button
            type="button"
            onPointerUp={() => setActiveSheet('none')}
            aria-label="Close Board Settings"
            className="w-11 h-11 rounded-xl flex items-center justify-center text-slate-300 active:scale-95"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* 3-Tab Navigation: Layers | Board | View */}
        <div className="grid grid-cols-3 border-b border-[#24322f] px-2 shrink-0">
          <button
            type="button"
            onPointerUp={() => setSettingsTab('layers')}
            className={`min-h-[60px] relative flex flex-col items-center justify-center gap-1 text-xs font-bold ${
              settingsTab === 'layers' ? 'text-[#6ee7b7]' : 'text-slate-400'
            }`}
          >
            <Layers className="w-5 h-5" />
            <span>Layers</span>
            {settingsTab === 'layers' && (
              <span className="absolute bottom-0 left-4 right-4 h-[3px] rounded-t-full bg-[#6ee7b7]" />
            )}
          </button>

          <button
            type="button"
            onPointerUp={() => setSettingsTab('board')}
            className={`min-h-[60px] relative flex flex-col items-center justify-center gap-1 text-xs font-bold ${
              settingsTab === 'board' ? 'text-[#6ee7b7]' : 'text-slate-400'
            }`}
          >
            <Sliders className="w-5 h-5" />
            <span>Board</span>
            {settingsTab === 'board' && (
              <span className="absolute bottom-0 left-4 right-4 h-[3px] rounded-t-full bg-[#6ee7b7]" />
            )}
          </button>

          <button
            type="button"
            onPointerUp={() => setSettingsTab('view')}
            className={`min-h-[60px] relative flex flex-col items-center justify-center gap-1 text-xs font-bold ${
              settingsTab === 'view' ? 'text-[#6ee7b7]' : 'text-slate-400'
            }`}
          >
            <Eye className="w-5 h-5" />
            <span>View</span>
            {settingsTab === 'view' && (
              <span className="absolute bottom-0 left-4 right-4 h-[3px] rounded-t-full bg-[#6ee7b7]" />
            )}
          </button>
        </div>

        {/* Settings Tab Content */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
          {/* TAB 1: LAYERS */}
          {settingsTab === 'layers' && (
            <div className="space-y-4">
              <div className="space-y-2.5">
                {pcbLayersList.map((layer) => {
                  const isVisible = layerVisibility[layer.id];
                  const isActiveLayer = activePcbLayer === layer.id;

                  return (
                    <div
                      key={layer.id}
                      className="min-h-[62px] px-4 rounded-2xl bg-[#182220] flex items-center justify-between gap-3"
                    >
                      <button
                        type="button"
                        onPointerUp={() => setActivePcbLayer(layer.id)}
                        className="flex-1 min-h-[52px] flex items-center gap-3.5 text-left"
                      >
                        <span
                          className={`w-6 h-6 rounded-full shrink-0 ${layer.swatchClass}`}
                        />
                        <span className="text-base font-medium text-slate-100">
                          {layer.name}
                        </span>
                        {layer.hasDot && (
                          <span className="w-2 h-2 rounded-full bg-[#6ee7b7]" />
                        )}
                      </button>

                      <div className="flex items-center gap-2">
                        {/* Radio Circle for Active Layer */}
                        <button
                          type="button"
                          aria-label={`Select ${layer.name} as active layer`}
                          onPointerUp={() => setActivePcbLayer(layer.id)}
                          className="w-11 h-11 flex items-center justify-center active:scale-95"
                        >
                          <span
                            className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                              isActiveLayer
                                ? 'border-[#6ee7b7]'
                                : 'border-slate-400'
                            }`}
                          >
                            {isActiveLayer && (
                              <span className="w-2.5 h-2.5 rounded-full bg-[#6ee7b7]" />
                            )}
                          </span>
                        </button>

                        {/* Eye Visibility Toggle */}
                        <button
                          type="button"
                          aria-label={`Toggle ${layer.name} visibility`}
                          onPointerUp={() => toggleLayerVisibility(layer.id)}
                          className="w-11 h-11 flex items-center justify-center active:scale-95"
                        >
                          {isVisible ? (
                            <Eye className="w-5 h-5 text-[#6ee7b7]" />
                          ) : (
                            <EyeOff className="w-5 h-5 text-slate-500" />
                          )}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Show All / Hide All */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  type="button"
                  onPointerUp={() => setAllLayersVisibility(true)}
                  className="min-h-[48px] rounded-full bg-[#6ee7b7] text-slate-950 font-bold text-sm flex items-center justify-center gap-2 active:scale-98"
                >
                  <Eye className="w-4 h-4" />
                  <span>Show All</span>
                </button>

                <button
                  type="button"
                  onPointerUp={() => setAllLayersVisibility(false)}
                  className="min-h-[48px] rounded-full bg-[#242e2c] text-slate-200 font-bold text-sm flex items-center justify-center gap-2 active:scale-98"
                >
                  <EyeOff className="w-4 h-4 text-slate-400" />
                  <span>Hide All</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: BOARD CONFIGURATION */}
          {settingsTab === 'board' && (
            <div className="space-y-4 pb-6">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-slate-100">
                  Board configuration
                </h3>
                <div className="flex items-center gap-1 bg-[#182220] p-1 rounded-xl border border-[#2f3e3b]">
                  {(['mm', 'mil'] as const).map((u) => {
                    const active = boardConfig.unitSystem === u;
                    return (
                      <button
                        key={u}
                        type="button"
                        onPointerUp={() => updateBoardConfig({ unitSystem: u })}
                        className={`min-h-[34px] px-3 rounded-lg text-xs font-bold ${
                          active
                            ? 'bg-[#6ee7b7] text-slate-950'
                            : 'text-slate-300'
                        }`}
                      >
                        {u === 'mm' ? 'mm' : 'Imperial (mil)'}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Card 1: Board Dimensions & Shape Preview */}
              <div className="p-4 rounded-2xl bg-[#182220] space-y-4">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-bold text-slate-100">
                    Board Dimensions ({unitLabel})
                  </div>
                  <span className="text-[11px] font-mono text-slate-400">
                    {isMil
                      ? `${(boardW / 25.4).toFixed(2)} × ${(boardH / 25.4).toFixed(2)} in`
                      : `${(boardW * MM_TO_MIL).toFixed(0)} × ${(boardH * MM_TO_MIL).toFixed(0)} mil`}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <div className="text-xs text-slate-400 mb-1.5">
                      Width ({unitLabel})
                    </div>
                    <PhoneInputField
                      ariaLabel={`Board Width (${unitLabel})`}
                      value={toUnitStr(boardW, 1, 0)}
                      inputMode="decimal"
                      onCommit={(v) => {
                        const n = parseFloat(v);
                        const mmVal = fromUnitVal(n);
                        if (!isNaN(mmVal) && mmVal >= 5) {
                          updateBoardOutline(boardX, boardY, mmVal, boardH);
                        }
                      }}
                    />
                  </div>

                  <div>
                    <div className="text-xs text-slate-400 mb-1.5">
                      Height ({unitLabel})
                    </div>
                    <PhoneInputField
                      ariaLabel={`Board Height (${unitLabel})`}
                      value={toUnitStr(boardH, 1, 0)}
                      inputMode="decimal"
                      onCommit={(v) => {
                        const n = parseFloat(v);
                        const mmVal = fromUnitVal(n);
                        if (!isNaN(mmVal) && mmVal >= 5) {
                          updateBoardOutline(boardX, boardY, boardW, mmVal);
                        }
                      }}
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <div className="text-sm font-bold text-slate-100">Board shape</div>
                    <span className="text-[11px] font-mono text-[#fb923c]">
                      {outlineItem?.props.points && outlineItem.props.points.length >= 3
                        ? `${outlineItem.props.points.length} vertices`
                        : `${toUnitStr(boardConfig.cornerRadius, 1, 0)} ${unitLabel} radius`}
                    </span>
                  </div>
                  <div className="text-xs text-slate-400">
                    Drag corners to round · tap edge dot to split · or pick a preset
                  </div>
                </div>

                {/* Orange Board Shape Interactive Preview */}
                <div
                  onPointerMove={(e) => {
                    if (!cornerDragStartRef.current) return;
                    const dx = e.clientX - cornerDragStartRef.current.startX;
                    const dy = e.clientY - cornerDragStartRef.current.startY;
                    const delta = (dx + dy) * 0.15;
                    const nextR = Math.max(
                      0,
                      Math.min(
                        20,
                        Number((cornerDragStartRef.current.startRadius + delta).toFixed(1))
                      )
                    );
                    updateBoardOutline(boardX, boardY, boardW, boardH, nextR, undefined);
                  }}
                  onPointerUp={() => {
                    cornerDragStartRef.current = null;
                  }}
                  onPointerCancel={() => {
                    cornerDragStartRef.current = null;
                  }}
                  className="w-full py-5 rounded-2xl bg-[#0d1312] flex flex-col items-center justify-center gap-3 touch-none select-none"
                >
                  <div className="relative w-44 h-44 flex items-center justify-center">
                    <div
                      style={{
                        borderRadius: `${Math.min(48, boardConfig.cornerRadius * 4.5)}px`,
                      }}
                      className="w-36 h-36 border-2 border-[#fb923c] bg-[#fb923c]/15 relative flex items-center justify-center"
                    >
                      <button
                        type="button"
                        onPointerUp={() =>
                          openKeypad({
                            title: `Corner Radius (${unitLabel})`,
                            initialValue: toUnitStr(boardConfig.cornerRadius, 1, 0),
                            unit: unitLabel,
                            allowLetters: false,
                            onCommit: (v) => {
                              const n = parseFloat(v);
                              const mmVal = fromUnitVal(n);
                              if (!isNaN(mmVal) && mmVal >= 0 && mmVal <= 25) {
                                updateBoardOutline(boardX, boardY, boardW, boardH, mmVal, undefined);
                              }
                            },
                          })
                        }
                        className="px-2.5 py-1 rounded-lg bg-[#0d1312]/90 border border-[#fb923c]/40 text-[11px] font-mono text-[#fb923c]"
                      >
                        R {toUnitStr(boardConfig.cornerRadius, 1, 0)} {unitLabel}
                      </button>

                      {/* 4 Draggable Corner Handles */}
                      {[
                        '-top-2.5 -left-2.5',
                        '-top-2.5 -right-2.5',
                        '-bottom-2.5 -left-2.5',
                        '-bottom-2.5 -right-2.5',
                      ].map((posClass, idx) => (
                        <span
                          key={idx}
                          onPointerDown={(e) => {
                            e.stopPropagation();
                            (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
                            cornerDragStartRef.current = {
                              startX: e.clientX,
                              startY: e.clientY,
                              startRadius: boardConfig.cornerRadius,
                            };
                          }}
                          className={`w-5 h-5 rounded-full bg-[#fb923c] border-2 border-white absolute ${posClass} cursor-grab active:scale-125 transition-transform`}
                        />
                      ))}

                      {/* 4 Tappable Midpoint Edge Dots */}
                      {[
                        { idx: 0, cls: '-top-2 left-1/2 -translate-x-1/2' },
                        { idx: 1, cls: 'top-1/2 -right-2 -translate-y-1/2' },
                        { idx: 2, cls: '-bottom-2 left-1/2 -translate-x-1/2' },
                        { idx: 3, cls: 'top-1/2 -left-2 -translate-y-1/2' },
                      ].map((edge) => (
                        <button
                          key={edge.idx}
                          type="button"
                          aria-label={`Split board edge ${edge.idx + 1}`}
                          onPointerUp={(e) => {
                            e.stopPropagation();
                            splitBoardOutlineEdge(edge.idx);
                          }}
                          className={`w-4 h-4 rounded-full bg-[#fb923c] border border-[#0d1312] absolute ${edge.cls} active:scale-125 transition-transform`}
                        />
                      ))}
                    </div>
                  </div>
                  <span className="text-xs font-mono text-[#fb923c]">
                    {toUnitStr(boardConfig.cornerRadius, 1, 0)} {unitLabel} ·{' '}
                    {outlineItem?.props.points?.length ?? 4} pts
                  </span>
                </div>

                {/* Quick Board Shape Presets */}
                <div className="grid grid-cols-5 gap-1.5">
                  {(
                    [
                      { id: 'rect', label: 'Rect' },
                      { id: 'rounded', label: 'Round' },
                      { id: 'chamfer', label: 'Chamfer' },
                      { id: 'l_shape', label: 'L-Board' },
                      { id: 'badge', label: 'Hexagon' },
                    ] as const
                  ).map((preset) => (
                    <button
                      key={preset.id}
                      type="button"
                      onPointerUp={() => applyBoardShapePreset(preset.id)}
                      className="min-h-[38px] px-1.5 rounded-xl bg-[#0d1312] border border-[#2f3e3b] text-[11px] font-bold text-slate-200 active:scale-95 active:border-[#fb923c]"
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>

                <button
                  type="button"
                  onPointerUp={() => {
                    setEditorMode('pcb');
                    setPcbTool('outline');
                    setActiveSheet('none');
                  }}
                  className="w-full min-h-[48px] rounded-full bg-[#242e2c] text-[#6ee7b7] font-bold text-sm flex items-center justify-center gap-2 active:scale-98"
                >
                  <Pencil className="w-4 h-4" />
                  <span>Edit outline on PCB</span>
                </button>
              </div>

              {/* Card 2: Grid Settings */}
              <div className="p-4 rounded-2xl bg-[#182220] space-y-4">
                <div className="text-sm font-bold text-slate-100">
                  Grid Settings ({unitLabel})
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <div className="text-xs text-slate-400 mb-1.5">
                      Grid Size ({unitLabel})
                    </div>
                    <PhoneInputField
                      ariaLabel={`Grid Size (${unitLabel})`}
                      value={toUnitStr(boardConfig.gridSize, 3, 1)}
                      inputMode="decimal"
                      onCommit={(v) => {
                        const n = parseFloat(v);
                        const mmVal = fromUnitVal(n);
                        if (!isNaN(mmVal) && mmVal >= 0.05 && mmVal <= 25.4) {
                          updateBoardConfig({ gridSize: mmVal });
                        }
                      }}
                    />
                  </div>

                  <div>
                    <div className="text-xs text-slate-400 mb-1.5">Subdivision</div>
                    <PhoneInputField
                      ariaLabel="Subdivision"
                      value={boardConfig.subdivision.toString()}
                      inputMode="numeric"
                      onCommit={(v) => {
                        const n = parseInt(v, 10);
                        if (!isNaN(n) && n >= 1 && n <= 20) {
                          updateBoardConfig({ subdivision: n });
                        }
                      }}
                    />
                  </div>
                </div>

                {/* Quick Metric & Imperial Grid Presets */}
                <div className="grid grid-cols-4 gap-1.5">
                  {(isMil
                    ? [
                        { mm: 0.254, label: '10 mil' },
                        { mm: 0.508, label: '20 mil' },
                        { mm: 1.27, label: '50 mil' },
                        { mm: 2.54, label: '100 mil' },
                      ]
                    : [
                        { mm: 0.25, label: '0.25 mm' },
                        { mm: 0.5, label: '0.50 mm' },
                        { mm: 1.0, label: '1.00 mm' },
                        { mm: 2.54, label: '2.54 mm' },
                      ]
                  ).map((preset) => {
                    const active = Math.abs(boardConfig.gridSize - preset.mm) < 0.01;
                    return (
                      <button
                        key={preset.label}
                        type="button"
                        onPointerUp={() => updateBoardConfig({ gridSize: preset.mm })}
                        className={`min-h-[38px] rounded-xl font-mono text-xs font-bold ${
                          active
                            ? 'bg-[#283834] text-[#6ee7b7] border border-[#6ee7b7]/50'
                            : 'bg-[#0d1312] text-slate-300 border border-[#2f3e3b]'
                        }`}
                      >
                        {preset.label}
                      </button>
                    );
                  })}
                </div>

                <div>
                  <div className="text-xs text-slate-400 mb-1.5">Raster Type</div>
                  <div className="grid grid-cols-2 gap-2.5">
                    {(['grid', 'dots'] as const).map((rt) => {
                      const active = boardConfig.rasterType === rt;
                      return (
                        <button
                          key={rt}
                          type="button"
                          onPointerUp={() => updateBoardConfig({ rasterType: rt })}
                          className={`min-h-[46px] rounded-full font-bold text-sm flex items-center justify-center gap-1.5 ${
                            active
                              ? 'bg-[#283834] text-[#6ee7b7] border border-[#6ee7b7]/50'
                              : 'bg-[#0d1312] text-slate-300 border border-[#2f3e3b]'
                          }`}
                        >
                          {active && <Check className="w-4 h-4" />}
                          <span>{rt === 'grid' ? 'Grid' : 'Dots'}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="pt-1 border-t border-white/5 flex items-center justify-between">
                  <div>
                    <div className="text-sm font-medium text-slate-200">
                      Grid origin
                    </div>
                    <div className="text-xs text-slate-400">
                      {boardConfig.gridOrigin === 'board_corner'
                        ? 'At board corner'
                        : 'Custom center'}
                    </div>
                  </div>
                  <button
                    type="button"
                    onPointerUp={() =>
                      updateBoardConfig({
                        gridOrigin:
                          boardConfig.gridOrigin === 'board_corner'
                            ? 'custom'
                            : 'board_corner',
                      })
                    }
                    className="min-h-[40px] px-4 rounded-xl border border-[#2f3e3b] text-[#6ee7b7] text-xs font-bold"
                  >
                    Set...
                  </button>
                </div>
              </div>

              {/* Card 3: Copper Fill */}
              <div className="p-4 rounded-2xl bg-[#182220] space-y-4">
                <div className="text-sm font-bold text-slate-100">Copper Fill</div>
                <div className="text-xs text-slate-400">Auto ground layers</div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 rounded-xl bg-[#0d1312] border border-[#2f3e3b] flex items-center justify-between">
                    <span className="text-sm font-medium text-slate-200">Top</span>
                    <ToggleSwitch
                      checked={boardConfig.autoGroundTop}
                      onChange={() =>
                        updateBoardConfig({
                          autoGroundTop: !boardConfig.autoGroundTop,
                        })
                      }
                    />
                  </div>

                  <div className="p-3 rounded-xl bg-[#0d1312] border border-[#2f3e3b] flex items-center justify-between">
                    <span className="text-sm font-medium text-slate-200">
                      Bottom
                    </span>
                    <ToggleSwitch
                      checked={boardConfig.autoGroundBottom}
                      onChange={() =>
                        updateBoardConfig({
                          autoGroundBottom: !boardConfig.autoGroundBottom,
                        })
                      }
                    />
                  </div>
                </div>

                <div>
                  <div className="text-xs text-slate-400 mb-1.5">
                    Clearance ({unitLabel})
                  </div>
                  <PhoneInputField
                    ariaLabel={`Copper Fill Clearance (${unitLabel})`}
                    value={toUnitStr(boardConfig.copperFillClearance, 2, 1)}
                    inputMode="decimal"
                    onCommit={(v) => {
                      const n = parseFloat(v);
                      const mmVal = fromUnitVal(n);
                      if (!isNaN(mmVal) && mmVal >= 0.05) {
                        updateBoardConfig({ copperFillClearance: mmVal });
                      }
                    }}
                  />
                </div>
              </div>

              {/* Card 4: Solder Mask */}
              <div className="p-4 rounded-2xl bg-[#182220] space-y-4">
                <div className="text-sm font-bold text-slate-100">Solder mask</div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <div className="text-xs text-slate-400 mb-1.5">
                      Mask expansion ({unitLabel})
                    </div>
                    <PhoneInputField
                      ariaLabel={`Mask expansion (${unitLabel})`}
                      value={toUnitStr(boardConfig.maskExpansion, 2, 1)}
                      inputMode="decimal"
                      onCommit={(v) => {
                        const n = parseFloat(v);
                        const mmVal = fromUnitVal(n);
                        if (!isNaN(mmVal) && mmVal >= 0) {
                          updateBoardConfig({ maskExpansion: mmVal });
                        }
                      }}
                    />
                  </div>

                  <div>
                    <div className="text-xs text-slate-400 mb-1.5">
                      Narrowest mask strip ({unitLabel})
                    </div>
                    <PhoneInputField
                      ariaLabel={`Narrowest mask strip (${unitLabel})`}
                      value={toUnitStr(boardConfig.narrowestMaskStrip, 2, 1)}
                      inputMode="decimal"
                      onCommit={(v) => {
                        const n = parseFloat(v);
                        const mmVal = fromUnitVal(n);
                        if (!isNaN(mmVal) && mmVal >= 0) {
                          updateBoardConfig({ narrowestMaskStrip: mmVal });
                        }
                      }}
                    />
                  </div>
                </div>

                <div className="pt-1 flex items-center justify-between gap-3">
                  <div>
                    <div className="text-sm font-medium text-slate-100">
                      Cover vias with mask
                    </div>
                    <div className="text-xs text-slate-400">
                      Tent vias instead of leaving solder mask openings
                    </div>
                  </div>
                  <ToggleSwitch
                    checked={boardConfig.coverViasWithMask}
                    onChange={() =>
                      updateBoardConfig({
                        coverViasWithMask: !boardConfig.coverViasWithMask,
                      })
                    }
                  />
                </div>
              </div>

              {/* Card 5: Solder Paste */}
              <div className="p-4 rounded-2xl bg-[#182220] space-y-4">
                <div className="text-sm font-bold text-slate-100">Solder paste</div>

                <div>
                  <div className="text-xs text-slate-400 mb-1.5">
                    Paste margin ({unitLabel})
                  </div>
                  <PhoneInputField
                    ariaLabel={`Paste margin (${unitLabel})`}
                    value={toUnitStr(boardConfig.pasteMargin, 2, 1)}
                    inputMode="decimal"
                    onCommit={(v) => {
                      const n = parseFloat(v);
                      const mmVal = fromUnitVal(n);
                      if (!isNaN(mmVal)) {
                        updateBoardConfig({ pasteMargin: mmVal });
                      }
                    }}
                  />
                  <div className="text-[11px] text-slate-400 mt-1">
                    Negative values shrink the stencil opening
                  </div>
                </div>

                <div>
                  <div className="text-xs text-slate-400 mb-2">
                    Stencil thickness ({unitLabel})
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {[0.1, 0.12, 0.15, 0.18, 0.2].map((thick) => {
                      const active =
                        Math.abs(boardConfig.stencilThickness - thick) < 0.005;
                      return (
                        <button
                          key={thick}
                          type="button"
                          onPointerUp={() =>
                            updateBoardConfig({ stencilThickness: thick })
                          }
                          className={`min-h-[40px] px-3.5 rounded-xl font-mono text-xs font-bold flex items-center gap-1.5 ${
                            active
                              ? 'bg-[#283834] text-[#6ee7b7] border border-[#6ee7b7]/50'
                              : 'bg-[#0d1312] text-slate-300 border border-[#2f3e3b]'
                          }`}
                        >
                          {active && <Check className="w-3.5 h-3.5" />}
                          <span>
                            {isMil
                              ? `${(thick * MM_TO_MIL).toFixed(1)} mil`
                              : `${thick.toFixed(2)} mm`}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Card 6: Unit System */}
              <div className="p-4 rounded-2xl bg-[#182220] space-y-3">
                <div className="text-sm font-bold text-slate-100">Unit System</div>
                <div className="grid grid-cols-2 gap-3">
                  {(['mm', 'mil'] as const).map((u) => {
                    const active = boardConfig.unitSystem === u;
                    return (
                      <button
                        key={u}
                        type="button"
                        onPointerUp={() => updateBoardConfig({ unitSystem: u })}
                        className={`min-h-[46px] rounded-full font-bold text-sm flex items-center justify-center gap-1.5 ${
                          active
                            ? 'bg-[#283834] text-[#6ee7b7] border border-[#6ee7b7]/50'
                            : 'bg-[#0d1312] text-slate-300 border border-[#2f3e3b]'
                        }`}
                      >
                        {active && <Check className="w-4 h-4" />}
                        <span>{u === 'mm' ? 'Metric (mm)' : 'Imperial (mil)'}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: VIEW OPTIONS */}
          {settingsTab === 'view' && (
            <div className="space-y-3.5 pb-6">
              <h3 className="text-base font-bold text-slate-100">View options</h3>

              <div className="p-4 rounded-2xl bg-[#182220] flex items-center justify-between gap-3">
                <div>
                  <div className="text-sm font-bold text-slate-100">
                    Edge rulers
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5">
                    Show measurement rulers along the top and left edges
                  </div>
                </div>
                <ToggleSwitch
                  checked={viewConfig.edgeRulers}
                  onChange={() =>
                    updateViewConfig({ edgeRulers: !viewConfig.edgeRulers })
                  }
                />
              </div>

              <div className="p-4 rounded-2xl bg-[#182220] flex items-center justify-between gap-3">
                <div>
                  <div className="text-sm font-bold text-slate-100">
                    Coordinate readout
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5">
                    Show cursor coordinates on the canvas
                  </div>
                </div>
                <ToggleSwitch
                  checked={viewConfig.coordinateReadout}
                  onChange={() =>
                    updateViewConfig({
                      coordinateReadout: !viewConfig.coordinateReadout,
                    })
                  }
                />
              </div>

              <div className="p-4 rounded-2xl bg-[#182220] flex items-center justify-between gap-3">
                <div>
                  <div className="text-sm font-bold text-slate-100">
                    Auto-scroll while dragging
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5">
                    Pan the board when dragging near the screen edge
                  </div>
                </div>
                <ToggleSwitch
                  checked={viewConfig.autoScrollDragging}
                  onChange={() =>
                    updateViewConfig({
                      autoScrollDragging: !viewConfig.autoScrollDragging,
                    })
                  }
                />
              </div>

              <div className="p-4 rounded-2xl bg-[#182220] flex items-center justify-between gap-3">
                <div>
                  <div className="text-sm font-bold text-slate-100">
                    Touch magnifier
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5">
                    Show a loupe above your finger when dragging or routing
                  </div>
                </div>
                <ToggleSwitch
                  checked={viewConfig.touchMagnifier}
                  onChange={() =>
                    updateViewConfig({
                      touchMagnifier: !viewConfig.touchMagnifier,
                    })
                  }
                />
              </div>

              {/* Pad Labels */}
              <div className="p-4 rounded-2xl bg-[#182220] space-y-3">
                <div>
                  <div className="text-sm font-bold text-slate-100">
                    Pad labels
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5">
                    Show pin numbers and net names on component pads
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {(
                    [
                      { id: 'off', label: 'Off' },
                      { id: 'numbers', label: 'Numbers' },
                      { id: 'numbers_nets', label: 'Numbers + nets' },
                    ] as const
                  ).map((opt) => {
                    const active = viewConfig.padLabels === opt.id;
                    return (
                      <button
                        key={opt.id}
                        type="button"
                        onPointerUp={() =>
                          updateViewConfig({ padLabels: opt.id })
                        }
                        className={`min-h-[44px] px-2 rounded-full text-xs font-bold flex items-center justify-center gap-1 ${
                          active
                            ? 'bg-[#283834] text-[#6ee7b7] border border-[#6ee7b7]/50'
                            : 'bg-[#0d1312] text-slate-300 border border-[#2f3e3b]'
                        }`}
                      >
                        {active && <Check className="w-3.5 h-3.5 shrink-0" />}
                        <span className="truncate">{opt.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Show Designators */}
              <div className="p-4 rounded-2xl bg-[#182220] flex items-center justify-between gap-3">
                <div>
                  <div className="text-sm font-bold text-slate-100">
                    Show designators
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5">
                    Display component labels like R1, U2 on the board
                  </div>
                </div>
                <ToggleSwitch
                  checked={viewConfig.showDesignators}
                  onChange={() =>
                    updateViewConfig({
                      showDesignators: !viewConfig.showDesignators,
                    })
                  }
                />
              </div>

              {/* Readout Position */}
              <div className="p-4 rounded-2xl bg-[#182220] space-y-3">
                <div className="text-sm font-bold text-slate-100">
                  Readout position
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {(
                    [
                      { id: 'top_left', label: 'Top left' },
                      { id: 'top_right', label: 'Top right' },
                      { id: 'bottom_left', label: 'Bottom left' },
                      { id: 'bottom_right', label: 'Bottom right' },
                    ] as const
                  ).map((pos) => {
                    const active = viewConfig.readoutPosition === pos.id;
                    return (
                      <button
                        key={pos.id}
                        type="button"
                        onPointerUp={() =>
                          updateViewConfig({
                            readoutPosition: pos.id,
                            coordinateReadout: true,
                          })
                        }
                        className={`min-h-[52px] px-2 rounded-2xl text-xs font-bold flex items-center justify-center text-center leading-tight ${
                          active
                            ? 'bg-[#283834] text-[#6ee7b7] border border-[#6ee7b7]/50'
                            : 'bg-[#0d1312] text-slate-300 border border-[#2f3e3b]'
                        }`}
                      >
                        {pos.label}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ============================================================================
  // 2B. INSERT GEOMETRY SHEET (MATCHING SCREENSHOTS 1 & 2)
  // ============================================================================
  if (activeSheet === 'insert') {
    const antMetrics = computeAntennaMetrics(antOpts);
    const coilMetrics = computePlanarCoilMetrics(coilOpts);

    const handleSvgFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        insertSvgGeometry({
          ...svgOpts,
          svgText: String(reader.result || ''),
        });
      };
      reader.readAsText(file);
      e.target.value = '';
    };

    const handleDxfFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        insertDxfGeometry({
          ...dxfOpts,
          dxfText: String(reader.result || ''),
        });
      };
      reader.readAsText(file);
      e.target.value = '';
    };

    const handlePhotoFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        updatePhotoOverlay({
          enabled: true,
          dataUrl: String(reader.result || ''),
          name: file.name,
          x: boardX,
          y: boardY,
          widthMm: boardW,
          heightMm: boardH,
        });
        setEditorMode('pcb');
        showSnackbar(`Loaded photo overlay "${file.name}"`, false);
      };
      reader.readAsDataURL(file);
      e.target.value = '';
    };

    return (
      <div
        className="fixed inset-0 z-40 bg-black/60 backdrop-blur-xs flex flex-col justify-end"
        onPointerUp={(e) => {
          if (e.target === e.currentTarget) {
            setActiveSheet('none');
          }
        }}
      >
        <input
          ref={svgFileInputRef}
          type="file"
          accept=".svg,image/svg+xml"
          className="hidden"
          onChange={handleSvgFileUpload}
        />
        <input
          ref={dxfFileInputRef}
          type="file"
          accept=".dxf,application/dxf,text/plain"
          className="hidden"
          onChange={handleDxfFileUpload}
        />
        <input
          ref={photoFileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handlePhotoFileUpload}
        />

        <div
          className="w-full max-h-[88dvh] bg-[#0e1413] border-t border-[#24322f] rounded-t-3xl flex flex-col overflow-hidden pb-safe shadow-2xl"
          onPointerUp={(e) => e.stopPropagation()}
        >
          {/* Top Drag Handle Pill */}
          <div className="pt-3 pb-1 flex justify-center shrink-0">
            <div className="w-11 h-1.5 rounded-full bg-slate-400/50" />
          </div>

          <div className="px-5 pb-6 overflow-y-auto space-y-5">
            {insertSubView === 'menu' ? (
              <>
                {/* Main Header matching Screenshots */}
                <div className="flex items-start justify-between pt-1">
                  <div>
                    <h2 className="text-2xl font-bold text-slate-100 tracking-tight">
                      Insert
                    </h2>
                    <p className="text-sm text-slate-400 mt-0.5">
                      Add geometry to the current board
                    </p>
                  </div>
                  <button
                    type="button"
                    aria-label="Close Insert sheet"
                    onPointerUp={() => setActiveSheet('none')}
                    className="w-10 h-10 rounded-xl bg-[#1c2422] text-slate-300 flex items-center justify-center active:scale-95"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* SECTION 1: FROM FILE */}
                <div className="space-y-3">
                  <div className="text-xs font-extrabold uppercase tracking-wider text-[#6ee7b7]">
                    FROM FILE
                  </div>

                  {/* 1. SVG */}
                  <button
                    type="button"
                    onPointerUp={() => setInsertSubView('svg')}
                    className="w-full rounded-2xl bg-[#1c2422] border border-[#2a3633]/60 px-4 py-4 flex items-center gap-4 text-left active:scale-99 transition-transform"
                  >
                    <ImageIcon className="w-6 h-6 text-[#6ee7b7] shrink-0" />
                    <div className="min-w-0 flex-1">
                      <div className="text-base font-bold text-slate-100">SVG</div>
                      <div className="text-xs text-slate-400 mt-0.5">
                        Vector graphic → copper, silk or milling
                      </div>
                    </div>
                  </button>

                  {/* 2. DXF */}
                  <button
                    type="button"
                    onPointerUp={() => setInsertSubView('dxf')}
                    className="w-full rounded-2xl bg-[#1c2422] border border-[#2a3633]/60 px-4 py-4 flex items-center gap-4 text-left active:scale-99 transition-transform"
                  >
                    <Compass className="w-6 h-6 text-[#6ee7b7] shrink-0" />
                    <div className="min-w-0 flex-1">
                      <div className="text-base font-bold text-slate-100">DXF</div>
                      <div className="text-xs text-slate-400 mt-0.5">
                        CAD outline → board shape, copper or milling
                      </div>
                    </div>
                  </button>

                  {/* 3. Photo overlay */}
                  <button
                    type="button"
                    onPointerUp={() => setInsertSubView('photo')}
                    className="w-full rounded-2xl bg-[#1c2422] border border-[#2a3633]/60 px-4 py-4 flex items-center gap-4 text-left active:scale-99 transition-transform"
                  >
                    <Camera className="w-6 h-6 text-[#6ee7b7] shrink-0" />
                    <div className="min-w-0 flex-1">
                      <div className="text-base font-bold text-slate-100">
                        Photo overlay
                      </div>
                      <div className="text-xs text-slate-400 mt-0.5">
                        Photo of a real board → trace over it
                      </div>
                    </div>
                  </button>
                </div>

                {/* SECTION 2: GENERATE */}
                <div className="space-y-3 pt-1">
                  <div className="text-xs font-extrabold uppercase tracking-wider text-[#6ee7b7]">
                    GENERATE
                  </div>

                  {/* 4. Antenna */}
                  <button
                    type="button"
                    onPointerUp={() => setInsertSubView('antenna')}
                    className="w-full rounded-2xl bg-[#1c2422] border border-[#2a3633]/60 px-4 py-4 flex items-center gap-4 text-left active:scale-99 transition-transform"
                  >
                    <Radio className="w-6 h-6 text-[#6ee7b7] shrink-0" />
                    <div className="min-w-0 flex-1">
                      <div className="text-base font-bold text-slate-100">Antenna</div>
                      <div className="text-xs text-slate-400 mt-0.5">
                        PCB antenna for a target frequency
                      </div>
                    </div>
                  </button>

                  {/* 5. Coil */}
                  <button
                    type="button"
                    onPointerUp={() => setInsertSubView('coil')}
                    className="w-full rounded-2xl bg-[#1c2422] border border-[#2a3633]/60 px-4 py-4 flex items-center gap-4 text-left active:scale-99 transition-transform"
                  >
                    <RefreshCw className="w-6 h-6 text-[#6ee7b7] shrink-0" />
                    <div className="min-w-0 flex-1">
                      <div className="text-base font-bold text-slate-100">Coil</div>
                      <div className="text-xs text-slate-400 mt-0.5">
                        Planar spiral inductor with computed value
                      </div>
                    </div>
                  </button>

                  {/* 6. QR / barcode */}
                  <button
                    type="button"
                    onPointerUp={() => setInsertSubView('qr')}
                    className="w-full rounded-2xl bg-[#1c2422] border border-[#2a3633]/60 px-4 py-4 flex items-center gap-4 text-left active:scale-99 transition-transform"
                  >
                    <QrCode className="w-6 h-6 text-[#6ee7b7] shrink-0" />
                    <div className="min-w-0 flex-1">
                      <div className="text-base font-bold text-slate-100">
                        QR / barcode
                      </div>
                      <div className="text-xs text-slate-400 mt-0.5">
                        QR, Data Matrix or barcode in silk or copper
                      </div>
                    </div>
                  </button>

                  {/* 7. Mounting holes */}
                  <button
                    type="button"
                    onPointerUp={() => setInsertSubView('mounting_holes')}
                    className="w-full rounded-2xl bg-[#1c2422] border border-[#2a3633]/60 px-4 py-4 flex items-center gap-4 text-left active:scale-99 transition-transform"
                  >
                    <CircleDot className="w-6 h-6 text-[#6ee7b7] shrink-0" />
                    <div className="min-w-0 flex-1">
                      <div className="text-base font-bold text-slate-100">
                        Mounting holes
                      </div>
                      <div className="text-xs text-slate-400 mt-0.5">
                        Corner or custom holes with screw keep-out
                      </div>
                    </div>
                  </button>

                  {/* 8. Pad & via array */}
                  <button
                    type="button"
                    onPointerUp={() => setInsertSubView('pad_via_array')}
                    className="w-full rounded-2xl bg-[#1c2422] border border-[#2a3633]/60 px-4 py-4 flex items-center gap-4 text-left active:scale-99 transition-transform"
                  >
                    <Grid className="w-6 h-6 text-[#6ee7b7] shrink-0" />
                    <div className="min-w-0 flex-1">
                      <div className="text-base font-bold text-slate-100">
                        Pad &amp; via array
                      </div>
                      <div className="text-xs text-slate-400 mt-0.5">
                        Rectangular grid of pads or vias with exact pitch
                      </div>
                    </div>
                  </button>

                  {/* 9. Via stitching */}
                  <button
                    type="button"
                    onPointerUp={() => setInsertSubView('via_stitching')}
                    className="w-full rounded-2xl bg-[#1c2422] border border-[#2a3633]/60 px-4 py-4 flex items-center gap-4 text-left active:scale-99 transition-transform"
                  >
                    <svg
                      viewBox="0 0 24 24"
                      className="w-6 h-6 text-[#6ee7b7] shrink-0 fill-current"
                    >
                      <circle cx="12" cy="5" r="2" />
                      <circle cx="7" cy="9" r="2" />
                      <circle cx="12" cy="11" r="2" />
                      <circle cx="17" cy="10" r="2" />
                      <circle cx="6" cy="15" r="2" />
                      <circle cx="11" cy="17" r="2" />
                      <circle cx="16" cy="16" r="2" />
                    </svg>
                    <div className="min-w-0 flex-1">
                      <div className="text-base font-bold text-slate-100">
                        Via stitching
                      </div>
                      <div className="text-xs text-slate-400 mt-0.5">
                        Fill a pour or edge with a via grid
                      </div>
                    </div>
                  </button>

                  {/* 10. Add designators */}
                  <button
                    type="button"
                    onPointerUp={() => setInsertSubView('designators')}
                    className="w-full rounded-2xl bg-[#1c2422] border border-[#2a3633]/60 px-4 py-4 flex items-center gap-4 text-left active:scale-99 transition-transform"
                  >
                    <Hash className="w-6 h-6 text-[#6ee7b7] shrink-0" />
                    <div className="min-w-0 flex-1">
                      <div className="text-base font-bold text-slate-100">
                        Add designators
                      </div>
                      <div className="text-xs text-slate-400 mt-0.5">
                        Number the parts: R1, C1, U1...
                      </div>
                    </div>
                  </button>
                </div>
              </>
            ) : (
              /* SUB-VIEW CONFIGURATION HEADER */
              <div className="space-y-4">
                <div className="flex items-center justify-between pt-1">
                  <button
                    type="button"
                    onPointerUp={() => setInsertSubView('menu')}
                    className="min-h-[42px] px-3 rounded-xl bg-[#1c2422] border border-[#2a3633] text-[#6ee7b7] text-xs font-bold flex items-center gap-1.5 active:scale-95"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>All Insert Tools</span>
                  </button>
                  <button
                    type="button"
                    onPointerUp={() => setActiveSheet('none')}
                    className="w-10 h-10 rounded-xl bg-[#1c2422] text-slate-300 flex items-center justify-center active:scale-95"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* ====================================================== */}
                {/* SUB-VIEW 1: SVG                                        */}
                {/* ====================================================== */}
                {insertSubView === 'svg' && (
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-lg font-bold text-slate-100">
                        Insert SVG Vector Graphic
                      </h3>
                      <p className="text-xs text-slate-400">
                        Convert an SVG file or built-in vector mark to copper, silkscreen, or board milling
                      </p>
                    </div>

                    <div className="space-y-2">
                      <div className="text-xs font-bold text-slate-300">Target Layer</div>
                      <div className="grid grid-cols-4 gap-1.5">
                        {(['F.Cu', 'B.Cu', 'F.SilkS', 'Edge.Cuts'] as const).map((lyr) => (
                          <button
                            key={lyr}
                            type="button"
                            onPointerUp={() => setSvgOpts({ ...svgOpts, targetLayer: lyr })}
                            className={`min-h-[42px] rounded-xl text-xs font-bold ${
                              svgOpts.targetLayer === lyr
                                ? 'bg-[#6ee7b7] text-slate-950'
                                : 'bg-[#1c2422] text-slate-200 border border-[#2a3633]'
                            }`}
                          >
                            {lyr === 'Edge.Cuts' ? 'Milling' : lyr}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <div className="text-xs text-slate-400">
                          Target Width ({unitLabel})
                        </div>
                        <PhoneInputField
                          value={toUnitStr(svgOpts.sizeMm, 1, 0)}
                          onCommit={(v) => {
                            const n = parseFloat(v);
                            const mmVal = fromUnitVal(n);
                            if (!isNaN(mmVal) && mmVal >= 2)
                              setSvgOpts({ ...svgOpts, sizeMm: mmVal });
                          }}
                        />
                      </div>
                      <div className="space-y-1">
                        <div className="text-xs text-slate-400">
                          Stroke Width ({unitLabel})
                        </div>
                        <PhoneInputField
                          value={toUnitStr(svgOpts.traceWidthMm, 2, 1)}
                          onCommit={(v) => {
                            const n = parseFloat(v);
                            const mmVal = fromUnitVal(n);
                            if (!isNaN(mmVal) && mmVal >= 0.1)
                              setSvgOpts({ ...svgOpts, traceWidthMm: mmVal });
                          }}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="text-xs font-bold text-slate-300">
                        Preset PCB Vector Symbols
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        {(
                          [
                            { id: 'oshw_gear', label: 'OSHW Gear Logo' },
                            { id: 'esd_bolt', label: 'ESD Warning Bolt' },
                            { id: 'ce_mark', label: 'CE Compliance Mark' },
                            { id: 'wifi_wave', label: 'RF / Wi-Fi Emblem' },
                          ] as const
                        ).map((p) => (
                          <button
                            key={p.id}
                            type="button"
                            onPointerUp={() => setSvgOpts({ ...svgOpts, preset: p.id })}
                            className={`min-h-[44px] px-3 rounded-xl text-xs font-bold text-left ${
                              svgOpts.preset === p.id
                                ? 'bg-[#6ee7b7]/20 border border-[#6ee7b7] text-[#6ee7b7]'
                                : 'bg-[#1c2422] border border-[#2a3633] text-slate-200'
                            }`}
                          >
                            {p.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2.5 pt-2">
                      <button
                        type="button"
                        onPointerUp={() => svgFileInputRef.current?.click()}
                        className="min-h-[50px] px-3 rounded-2xl bg-[#1c2422] border border-[#6ee7b7]/50 text-[#6ee7b7] font-bold text-xs flex items-center justify-center gap-2 active:scale-95"
                      >
                        <Upload className="w-4 h-4" />
                        <span>Upload .SVG File</span>
                      </button>
                      <button
                        type="button"
                        onPointerUp={() => insertSvgGeometry(svgOpts)}
                        className="min-h-[50px] px-3 rounded-2xl bg-[#6ee7b7] text-slate-950 font-extrabold text-xs flex items-center justify-center gap-2 active:scale-95"
                      >
                        <Check className="w-4 h-4" />
                        <span>Insert Vector</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* ====================================================== */}
                {/* SUB-VIEW 2: DXF                                        */}
                {/* ====================================================== */}
                {insertSubView === 'dxf' && (
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-lg font-bold text-slate-100">
                        Insert DXF CAD Outline
                      </h3>
                      <p className="text-xs text-slate-400">
                        Import a mechanical DXF profile or apply a standard form-factor board contour
                      </p>
                    </div>

                    <div className="space-y-2">
                      <div className="text-xs font-bold text-slate-300">Target Destination</div>
                      <div className="grid grid-cols-3 gap-2">
                        {(
                          [
                            { id: 'Edge.Cuts', label: 'Board Shape' },
                            { id: 'F.Cu', label: 'Top Copper' },
                            { id: 'B.Cu', label: 'Bottom Copper' },
                          ] as const
                        ).map((t) => (
                          <button
                            key={t.id}
                            type="button"
                            onPointerUp={() => setDxfOpts({ ...dxfOpts, targetLayer: t.id })}
                            className={`min-h-[44px] rounded-xl text-xs font-bold ${
                              dxfOpts.targetLayer === t.id
                                ? 'bg-[#6ee7b7] text-slate-950'
                                : 'bg-[#1c2422] text-slate-200 border border-[#2a3633]'
                            }`}
                          >
                            {t.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* DXF Metric (mm) & Imperial (inch / mil) Scaling */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="text-xs font-bold text-slate-300">
                          DXF Unit Scaling (mm / Imperial)
                        </div>
                        <span className="text-[11px] font-mono text-[#6ee7b7]">
                          ×{dxfOpts.scaleFactor ?? 1}
                        </span>
                      </div>
                      <div className="grid grid-cols-3 gap-2">
                        {[
                          { factor: 1, label: 'Metric (mm)' },
                          { factor: 25.4, label: 'Imperial (inch)' },
                          { factor: 0.0254, label: 'Imperial (mil)' },
                        ].map((sc) => {
                          const active =
                            Math.abs((dxfOpts.scaleFactor ?? 1) - sc.factor) < 0.0001;
                          return (
                            <button
                              key={sc.label}
                              type="button"
                              onPointerUp={() =>
                                setDxfOpts({ ...dxfOpts, scaleFactor: sc.factor })
                              }
                              className={`min-h-[42px] px-2 rounded-xl text-xs font-bold ${
                                active
                                  ? 'bg-[#6ee7b7] text-slate-950'
                                  : 'bg-[#1c2422] text-slate-200 border border-[#2a3633]'
                              }`}
                            >
                              {sc.label}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="text-xs font-bold text-slate-300">
                        Standard CAD Mechanical Profiles
                      </div>
                      <div className="space-y-2">
                        {(
                          [
                            {
                              id: 'arduino_shield',
                              title: 'Arduino Uno Shield Profile',
                              desc: '68.6 × 53.3 mm (2700 × 2100 mil) notched contour',
                            },
                            {
                              id: 'rpi_hat',
                              title: 'Raspberry Pi HAT Outline',
                              desc: '65 × 56 mm (2559 × 2205 mil) with ribbon slot cutout',
                            },
                            {
                              id: 'm2_card_edge',
                              title: 'M.2 2242 Module Card Edge',
                              desc: '22 × 42 mm (866 × 1654 mil) with screw notch',
                            },
                            {
                              id: 'flanged_enclosure',
                              title: 'Flanged Enclosure PCB',
                              desc: '52 × 36 mm (2047 × 1417 mil) with mounting tabs',
                            },
                            {
                              id: 'eurocard_100x80',
                              title: 'Chamfered Eurocard Profile',
                              desc: '80 × 50 mm (3150 × 1969 mil) 45° corner-chamfered',
                            },
                          ] as const
                        ).map((p) => (
                          <button
                            key={p.id}
                            type="button"
                            onPointerUp={() => setDxfOpts({ ...dxfOpts, preset: p.id })}
                            className={`w-full p-3 rounded-xl text-left border ${
                              dxfOpts.preset === p.id
                                ? 'bg-[#6ee7b7]/15 border-[#6ee7b7] text-slate-100'
                                : 'bg-[#1c2422] border-[#2a3633] text-slate-200'
                            }`}
                          >
                            <div className="text-xs font-bold">{p.title}</div>
                            <div className="text-[11px] text-slate-400">{p.desc}</div>
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2.5 pt-2">
                      <button
                        type="button"
                        onPointerUp={() => dxfFileInputRef.current?.click()}
                        className="min-h-[50px] px-3 rounded-2xl bg-[#1c2422] border border-[#6ee7b7]/50 text-[#6ee7b7] font-bold text-xs flex items-center justify-center gap-2 active:scale-95"
                      >
                        <Upload className="w-4 h-4" />
                        <span>Upload .DXF File</span>
                      </button>
                      <button
                        type="button"
                        onPointerUp={() => insertDxfGeometry(dxfOpts)}
                        className="min-h-[50px] px-3 rounded-2xl bg-[#6ee7b7] text-slate-950 font-extrabold text-xs flex items-center justify-center gap-2 active:scale-95"
                      >
                        <Check className="w-4 h-4" />
                        <span>Apply CAD Outline</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* ====================================================== */}
                {/* SUB-VIEW 3: PHOTO OVERLAY                              */}
                {/* ====================================================== */}
                {insertSubView === 'photo' && (
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-lg font-bold text-slate-100">
                        Photo Overlay (Reverse-Engineer Board)
                      </h3>
                      <p className="text-xs text-slate-400">
                        Place a photograph of a real PCB underneath the canvas to align pads and trace over copper
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-2.5">
                      <button
                        type="button"
                        onPointerUp={() => photoFileInputRef.current?.click()}
                        className="min-h-[50px] px-3 rounded-2xl bg-[#6ee7b7] text-slate-950 font-extrabold text-xs flex items-center justify-center gap-2 active:scale-95"
                      >
                        <Camera className="w-4 h-4" />
                        <span>Choose Board Photo</span>
                      </button>
                      <button
                        type="button"
                        onPointerUp={() => {
                          updatePhotoOverlay({
                            enabled: true,
                            dataUrl: createSampleBoardPhotoDataUrl(),
                            name: 'Reference_PCB_Photo.svg',
                            x: boardX,
                            y: boardY,
                            widthMm: boardW,
                            heightMm: boardH,
                          });
                          setEditorMode('pcb');
                          showSnackbar('Loaded sample PCB photo overlay', false);
                        }}
                        className="min-h-[50px] px-3 rounded-2xl bg-[#1c2422] border border-[#6ee7b7]/50 text-[#6ee7b7] font-bold text-xs flex items-center justify-center gap-2 active:scale-95"
                      >
                        <Sparkles className="w-4 h-4" />
                        <span>Load Sample Photo</span>
                      </button>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-[#1c2422] border border-[#2a3633] space-y-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-xs font-bold text-slate-100">
                            Show Photo Overlay on PCB
                          </div>
                          <div className="text-[11px] text-slate-400">
                            {photoOverlay.name || 'No photo loaded yet'}
                          </div>
                        </div>
                        <ToggleSwitch
                          checked={photoOverlay.enabled}
                          onChange={() =>
                            updatePhotoOverlay({ enabled: !photoOverlay.enabled })
                          }
                        />
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-xs text-slate-300">
                          <span>Overlay Opacity</span>
                          <span className="font-mono text-[#6ee7b7]">
                            {Math.round(photoOverlay.opacity * 100)}%
                          </span>
                        </div>
                        <input
                          type="range"
                          min="0.1"
                          max="1"
                          step="0.05"
                          value={photoOverlay.opacity}
                          onChange={(e) =>
                            updatePhotoOverlay({ opacity: parseFloat(e.target.value) })
                          }
                          className="w-full accent-[#6ee7b7]"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2.5">
                        <div className="space-y-1">
                          <div className="text-xs text-slate-400">
                            Width ({unitLabel})
                          </div>
                          <PhoneInputField
                            value={toUnitStr(photoOverlay.widthMm, 1, 0)}
                            onCommit={(v) => {
                              const n = parseFloat(v);
                              const mmVal = fromUnitVal(n);
                              if (!isNaN(mmVal) && mmVal >= 4)
                                updatePhotoOverlay({ widthMm: mmVal });
                            }}
                          />
                        </div>
                        <div className="space-y-1">
                          <div className="text-xs text-slate-400">
                            Height ({unitLabel})
                          </div>
                          <PhoneInputField
                            value={toUnitStr(photoOverlay.heightMm, 1, 0)}
                            onCommit={(v) => {
                              const n = parseFloat(v);
                              const mmVal = fromUnitVal(n);
                              if (!isNaN(mmVal) && mmVal >= 4)
                                updatePhotoOverlay({ heightMm: mmVal });
                            }}
                          />
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-1">
                        <span className="text-xs text-slate-300">
                          Mirror Horizontally (Bottom Side Photo)
                        </span>
                        <ToggleSwitch
                          checked={photoOverlay.flipX}
                          onChange={() => updatePhotoOverlay({ flipX: !photoOverlay.flipX })}
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* ====================================================== */}
                {/* SUB-VIEW 4: ANTENNA GENERATOR                          */}
                {/* ====================================================== */}
                {insertSubView === 'antenna' && (
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-lg font-bold text-slate-100">
                        PCB Antenna Generator
                      </h3>
                      <p className="text-xs text-slate-400">
                        Synthesize a quarter-wave FR-4 meandered antenna tuned to your target RF frequency
                      </p>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-[#1c2422] border border-[#6ee7b7]/35 grid grid-cols-3 gap-2 text-center font-mono">
                      <div>
                        <div className="text-[10px] text-slate-400">FREE-SPACE λ0</div>
                        <div className="text-sm font-bold text-slate-100">
                          {antMetrics.wavelengthFreeSpaceMm} mm
                        </div>
                      </div>
                      <div>
                        <div className="text-[10px] text-slate-400">FR-4 λeff / 4</div>
                        <div className="text-sm font-bold text-[#6ee7b7]">
                          {antMetrics.quarterWaveEffectiveMm} mm
                        </div>
                      </div>
                      <div>
                        <div className="text-[10px] text-slate-400">FOOTPRINT</div>
                        <div className="text-sm font-bold text-sky-400">
                          {antMetrics.widthMm}×{antMetrics.heightMm}mm
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="text-xs font-bold text-slate-300">
                        Target Frequency Band Presets
                      </div>
                      <div className="grid grid-cols-4 gap-1.5">
                        {[
                          { mhz: 2450, label: '2.4 GHz BLE/WiFi' },
                          { mhz: 915, label: '915 MHz LoRa' },
                          { mhz: 868, label: '868 MHz ISM' },
                          { mhz: 433, label: '433 MHz RF' },
                        ].map((b) => (
                          <button
                            key={b.mhz}
                            type="button"
                            onPointerUp={() =>
                              setAntOpts({ ...antOpts, frequencyMhz: b.mhz })
                            }
                            className={`min-h-[44px] px-2 rounded-xl text-[11px] font-bold ${
                              antOpts.frequencyMhz === b.mhz
                                ? 'bg-[#6ee7b7] text-slate-950'
                                : 'bg-[#1c2422] text-slate-200 border border-[#2a3633]'
                            }`}
                          >
                            {b.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <div className="text-xs text-slate-400">Frequency (MHz)</div>
                        <PhoneInputField
                          value={antOpts.frequencyMhz.toString()}
                          onCommit={(v) => {
                            const n = parseFloat(v);
                            if (!isNaN(n) && n >= 100)
                              setAntOpts({ ...antOpts, frequencyMhz: n });
                          }}
                        />
                      </div>
                      <div className="space-y-1">
                        <div className="text-xs text-slate-400">Trace Width (mm)</div>
                        <PhoneInputField
                          value={antOpts.traceWidthMm.toString()}
                          onCommit={(v) => {
                            const n = parseFloat(v);
                            if (!isNaN(n) && n >= 0.15)
                              setAntOpts({ ...antOpts, traceWidthMm: n });
                          }}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                      {(
                        [
                          { id: 'mifa', label: 'MIFA (Feed+GND)' },
                          { id: 'inverted_f', label: 'Inverted-F' },
                          { id: 'meander_monopole', label: 'Monopole' },
                        ] as const
                      ).map((top) => (
                        <button
                          key={top.id}
                          type="button"
                          onPointerUp={() =>
                            setAntOpts({ ...antOpts, topology: top.id })
                          }
                          className={`min-h-[42px] px-2 rounded-xl text-xs font-bold ${
                            antOpts.topology === top.id
                              ? 'bg-[#6ee7b7] text-slate-950'
                              : 'bg-[#1c2422] text-slate-200 border border-[#2a3633]'
                          }`}
                        >
                          {top.label}
                        </button>
                      ))}
                    </div>

                    <button
                      type="button"
                      onPointerUp={() => generateBoardAntenna(antOpts)}
                      className="w-full min-h-[52px] rounded-2xl bg-[#6ee7b7] text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 active:scale-98"
                    >
                      <Radio className="w-4 h-4" />
                      <span>Generate {antOpts.frequencyMhz} MHz PCB Antenna</span>
                    </button>
                  </div>
                )}

                {/* ====================================================== */}
                {/* SUB-VIEW 5: PLANAR SPIRAL COIL GENERATOR               */}
                {/* ====================================================== */}
                {insertSubView === 'coil' && (
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-lg font-bold text-slate-100">
                        Planar Spiral Inductor (Coil)
                      </h3>
                      <p className="text-xs text-slate-400">
                        Real-time Wheeler / Mohan planar spiral inductance calculator &amp; copper trace generator
                      </p>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-[#1c2422] border border-[#6ee7b7]/35 grid grid-cols-3 gap-2 text-center font-mono">
                      <div>
                        <div className="text-[10px] text-slate-400">INDUCTANCE L</div>
                        <div className="text-sm font-bold text-[#6ee7b7]">
                          {coilMetrics.inductanceNh >= 1000
                            ? `${coilMetrics.inductanceUh} µH`
                            : `${coilMetrics.inductanceNh} nH`}
                        </div>
                      </div>
                      <div>
                        <div className="text-[10px] text-slate-400">OUTER DIAM</div>
                        <div className="text-sm font-bold text-slate-100">
                          {coilMetrics.outerDiameterMm} mm
                        </div>
                      </div>
                      <div>
                        <div className="text-[10px] text-slate-400">EST. R_DC</div>
                        <div className="text-sm font-bold text-amber-300">
                          {coilMetrics.dcResistanceOhm} Ω
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                      {(
                        [
                          { id: 'square', label: 'Square' },
                          { id: 'octagonal', label: 'Octagonal' },
                          { id: 'circular', label: 'Circular' },
                        ] as const
                      ).map((sh) => (
                        <button
                          key={sh.id}
                          type="button"
                          onPointerUp={() => setCoilOpts({ ...coilOpts, shape: sh.id })}
                          className={`min-h-[42px] rounded-xl text-xs font-bold ${
                            coilOpts.shape === sh.id
                              ? 'bg-[#6ee7b7] text-slate-950'
                              : 'bg-[#1c2422] text-slate-200 border border-[#2a3633]'
                          }`}
                        >
                          {sh.label}
                        </button>
                      ))}
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <div className="text-xs text-slate-400">Number of Turns (N)</div>
                        <PhoneInputField
                          inputMode="numeric"
                          value={coilOpts.turns.toString()}
                          onCommit={(v) => {
                            const n = parseInt(v, 10);
                            if (!isNaN(n) && n >= 1 && n <= 35)
                              setCoilOpts({ ...coilOpts, turns: n });
                          }}
                        />
                      </div>
                      <div className="space-y-1">
                        <div className="text-xs text-slate-400">Inner Diameter (mm)</div>
                        <PhoneInputField
                          value={coilOpts.innerDiameterMm.toString()}
                          onCommit={(v) => {
                            const n = parseFloat(v);
                            if (!isNaN(n) && n >= 1)
                              setCoilOpts({ ...coilOpts, innerDiameterMm: n });
                          }}
                        />
                      </div>
                      <div className="space-y-1">
                        <div className="text-xs text-slate-400">Trace Width (mm)</div>
                        <PhoneInputField
                          value={coilOpts.traceWidthMm.toString()}
                          onCommit={(v) => {
                            const n = parseFloat(v);
                            if (!isNaN(n) && n >= 0.12)
                              setCoilOpts({ ...coilOpts, traceWidthMm: n });
                          }}
                        />
                      </div>
                      <div className="space-y-1">
                        <div className="text-xs text-slate-400">Turn Spacing (mm)</div>
                        <PhoneInputField
                          value={coilOpts.spacingMm.toString()}
                          onCommit={(v) => {
                            const n = parseFloat(v);
                            if (!isNaN(n) && n >= 0.12)
                              setCoilOpts({ ...coilOpts, spacingMm: n });
                          }}
                        />
                      </div>
                    </div>

                    <button
                      type="button"
                      onPointerUp={() => generateBoardCoil(coilOpts)}
                      className="w-full min-h-[52px] rounded-2xl bg-[#6ee7b7] text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 active:scale-98"
                    >
                      <RefreshCw className="w-4 h-4" />
                      <span>
                        Insert {coilOpts.turns}-Turn Spiral Coil (
                        {coilMetrics.inductanceNh >= 1000
                          ? `${coilMetrics.inductanceUh} µH`
                          : `${coilMetrics.inductanceNh} nH`}
                        )
                      </span>
                    </button>
                  </div>
                )}

                {/* ====================================================== */}
                {/* SUB-VIEW 6: QR / BARCODE GENERATOR                     */}
                {/* ====================================================== */}
                {insertSubView === 'qr' && (
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-lg font-bold text-slate-100">
                        QR / Data Matrix / Barcode
                      </h3>
                      <p className="text-xs text-slate-400">
                        Encode board serial numbers, URLs, or revision strings directly in silkscreen or copper
                      </p>
                    </div>

                    <div className="space-y-1">
                      <div className="text-xs text-slate-400">Payload Text / URL / Serial</div>
                      <PhoneInputField
                        inputMode="text"
                        value={qrOpts.text}
                        onCommit={(v) => setQrOpts({ ...qrOpts, text: v })}
                      />
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                      {(
                        [
                          { id: 'qr', label: 'QR Code' },
                          { id: 'datamatrix', label: 'Data Matrix' },
                          { id: 'barcode128', label: 'Barcode 128' },
                        ] as const
                      ).map((f) => (
                        <button
                          key={f.id}
                          type="button"
                          onPointerUp={() => setQrOpts({ ...qrOpts, format: f.id })}
                          className={`min-h-[42px] rounded-xl text-xs font-bold ${
                            qrOpts.format === f.id
                              ? 'bg-[#6ee7b7] text-slate-950'
                              : 'bg-[#1c2422] text-slate-200 border border-[#2a3633]'
                          }`}
                        >
                          {f.label}
                        </button>
                      ))}
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <div className="text-xs text-slate-400">Overall Width (mm)</div>
                        <PhoneInputField
                          value={qrOpts.sizeMm.toString()}
                          onCommit={(v) => {
                            const n = parseFloat(v);
                            if (!isNaN(n) && n >= 4) setQrOpts({ ...qrOpts, sizeMm: n });
                          }}
                        />
                      </div>
                      <div className="space-y-1">
                        <div className="text-xs text-slate-400">Target Layer</div>
                        <div className="grid grid-cols-3 gap-1">
                          {(['F.SilkS', 'F.Cu', 'B.Cu'] as const).map((l) => (
                            <button
                              key={l}
                              type="button"
                              onPointerUp={() => setQrOpts({ ...qrOpts, layer: l })}
                              className={`min-h-[48px] rounded-xl text-xs font-bold ${
                                qrOpts.layer === l
                                  ? 'bg-[#6ee7b7] text-slate-950'
                                  : 'bg-[#1c2422] text-slate-200 border border-[#2a3633]'
                              }`}
                            >
                              {l}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onPointerUp={() => generateBoardQrBarcode(qrOpts)}
                      className="w-full min-h-[52px] rounded-2xl bg-[#6ee7b7] text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 active:scale-98"
                    >
                      <QrCode className="w-4 h-4" />
                      <span>Insert {qrOpts.format.toUpperCase()} on Board</span>
                    </button>
                  </div>
                )}

                {/* ====================================================== */}
                {/* SUB-VIEW 7: MOUNTING HOLES                             */}
                {/* ====================================================== */}
                {insertSubView === 'mounting_holes' && (
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-lg font-bold text-slate-100">
                        Mounting Holes with Screw Keep-Out
                      </h3>
                      <p className="text-xs text-slate-400">
                        Place corner or center mechanical mounting holes with standard metric screw head keep-out
                      </p>
                    </div>

                    <div className="grid grid-cols-4 gap-2">
                      {(['M2', 'M2.5', 'M3', 'M4'] as const).map((std) => (
                        <button
                          key={std}
                          type="button"
                          onPointerUp={() =>
                            setMhOpts({
                              ...mhOpts,
                              screwStandard: std,
                              drillMm: SCREW_PRESETS[std].drillMm,
                              keepoutDiameterMm: SCREW_PRESETS[std].keepoutDiameterMm,
                            })
                          }
                          className={`min-h-[44px] rounded-xl text-xs font-bold ${
                            mhOpts.screwStandard === std
                              ? 'bg-[#6ee7b7] text-slate-950'
                              : 'bg-[#1c2422] text-slate-200 border border-[#2a3633]'
                          }`}
                        >
                          {std}
                        </button>
                      ))}
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                      {(
                        [
                          { id: 'corners_4', label: 'All 4 Corners' },
                          { id: 'corners_2', label: '2 Diagonal' },
                          { id: 'single_center', label: 'Single Hole' },
                        ] as const
                      ).map((pl) => (
                        <button
                          key={pl.id}
                          type="button"
                          onPointerUp={() => setMhOpts({ ...mhOpts, placement: pl.id })}
                          className={`min-h-[42px] rounded-xl text-xs font-bold ${
                            mhOpts.placement === pl.id
                              ? 'bg-[#6ee7b7] text-slate-950'
                              : 'bg-[#1c2422] text-slate-200 border border-[#2a3633]'
                          }`}
                        >
                          {pl.label}
                        </button>
                      ))}
                    </div>

                    <div className="grid grid-cols-3 gap-2.5">
                      <div className="space-y-1">
                        <div className="text-xs text-slate-400">Drill (mm)</div>
                        <PhoneInputField
                          value={mhOpts.drillMm.toString()}
                          onCommit={(v) => {
                            const n = parseFloat(v);
                            if (!isNaN(n) && n >= 0.8) setMhOpts({ ...mhOpts, drillMm: n });
                          }}
                        />
                      </div>
                      <div className="space-y-1">
                        <div className="text-xs text-slate-400">Keep-Out (mm)</div>
                        <PhoneInputField
                          value={mhOpts.keepoutDiameterMm.toString()}
                          onCommit={(v) => {
                            const n = parseFloat(v);
                            if (!isNaN(n) && n >= 1.5)
                              setMhOpts({ ...mhOpts, keepoutDiameterMm: n });
                          }}
                        />
                      </div>
                      <div className="space-y-1">
                        <div className="text-xs text-slate-400">Corner Inset</div>
                        <PhoneInputField
                          value={mhOpts.cornerInsetMm.toString()}
                          onCommit={(v) => {
                            const n = parseFloat(v);
                            if (!isNaN(n) && n >= 1.5)
                              setMhOpts({ ...mhOpts, cornerInsetMm: n });
                          }}
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-3 rounded-xl bg-[#1c2422] border border-[#2a3633]">
                      <span className="text-xs text-slate-200">
                        Plated Annular Ring Connected to GND
                      </span>
                      <ToggleSwitch
                        checked={mhOpts.platedGrounded}
                        onChange={() =>
                          setMhOpts({ ...mhOpts, platedGrounded: !mhOpts.platedGrounded })
                        }
                      />
                    </div>

                    <button
                      type="button"
                      onPointerUp={() => generateBoardMountingHoles(mhOpts)}
                      className="w-full min-h-[52px] rounded-2xl bg-[#6ee7b7] text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 active:scale-98"
                    >
                      <CircleDot className="w-4 h-4" />
                      <span>Place {mhOpts.screwStandard} Mounting Holes</span>
                    </button>
                  </div>
                )}

                {/* ====================================================== */}
                {/* SUB-VIEW 8: PAD & VIA ARRAY                            */}
                {/* ====================================================== */}
                {insertSubView === 'pad_via_array' && (
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-lg font-bold text-slate-100">
                        Pad &amp; Via Array Generator
                      </h3>
                      <p className="text-xs text-slate-400">
                        Generate a rectangular grid of SMD pads, through-hole pads, or vias with exact X/Y pitch
                      </p>
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                      {(
                        [
                          { id: 'smd_pads', label: 'SMD Pads' },
                          { id: 'tht_pads', label: 'THT Pads' },
                          { id: 'vias', label: 'Via Grid' },
                        ] as const
                      ).map((m) => (
                        <button
                          key={m.id}
                          type="button"
                          onPointerUp={() => setArrOpts({ ...arrOpts, mode: m.id })}
                          className={`min-h-[42px] rounded-xl text-xs font-bold ${
                            arrOpts.mode === m.id
                              ? 'bg-[#6ee7b7] text-slate-950'
                              : 'bg-[#1c2422] text-slate-200 border border-[#2a3633]'
                          }`}
                        >
                          {m.label}
                        </button>
                      ))}
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <div className="text-xs text-slate-400">Rows</div>
                        <PhoneInputField
                          inputMode="numeric"
                          value={arrOpts.rows.toString()}
                          onCommit={(v) => {
                            const n = parseInt(v, 10);
                            if (!isNaN(n) && n >= 1 && n <= 20)
                              setArrOpts({ ...arrOpts, rows: n });
                          }}
                        />
                      </div>
                      <div className="space-y-1">
                        <div className="text-xs text-slate-400">Columns</div>
                        <PhoneInputField
                          inputMode="numeric"
                          value={arrOpts.cols.toString()}
                          onCommit={(v) => {
                            const n = parseInt(v, 10);
                            if (!isNaN(n) && n >= 1 && n <= 20)
                              setArrOpts({ ...arrOpts, cols: n });
                          }}
                        />
                      </div>
                      <div className="space-y-1">
                        <div className="text-xs text-slate-400">Pitch X (mm)</div>
                        <PhoneInputField
                          value={arrOpts.pitchXMm.toString()}
                          onCommit={(v) => {
                            const n = parseFloat(v);
                            if (!isNaN(n) && n >= 0.4)
                              setArrOpts({ ...arrOpts, pitchXMm: n });
                          }}
                        />
                      </div>
                      <div className="space-y-1">
                        <div className="text-xs text-slate-400">Pitch Y (mm)</div>
                        <PhoneInputField
                          value={arrOpts.pitchYMm.toString()}
                          onCommit={(v) => {
                            const n = parseFloat(v);
                            if (!isNaN(n) && n >= 0.4)
                              setArrOpts({ ...arrOpts, pitchYMm: n });
                          }}
                        />
                      </div>
                      <div className="space-y-1">
                        <div className="text-xs text-slate-400">Pad / Via Size (mm)</div>
                        <PhoneInputField
                          value={arrOpts.padWidthMm.toString()}
                          onCommit={(v) => {
                            const n = parseFloat(v);
                            if (!isNaN(n) && n >= 0.25)
                              setArrOpts({ ...arrOpts, padWidthMm: n, padHeightMm: n });
                          }}
                        />
                      </div>
                      <div className="space-y-1">
                        <div className="text-xs text-slate-400">Pin Numbering</div>
                        <div className="grid grid-cols-2 gap-1">
                          {(
                            [
                              { id: 'row_major', label: '1..N' },
                              { id: 'bga_alpha', label: 'A1..B2' },
                            ] as const
                          ).map((num) => (
                            <button
                              key={num.id}
                              type="button"
                              onPointerUp={() =>
                                setArrOpts({ ...arrOpts, numbering: num.id })
                              }
                              className={`min-h-[48px] rounded-xl text-xs font-bold ${
                                arrOpts.numbering === num.id
                                  ? 'bg-[#6ee7b7] text-slate-950'
                                  : 'bg-[#1c2422] text-slate-200 border border-[#2a3633]'
                              }`}
                            >
                              {num.label}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onPointerUp={() => generateBoardPadViaArray(arrOpts)}
                      className="w-full min-h-[52px] rounded-2xl bg-[#6ee7b7] text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 active:scale-98"
                    >
                      <Grid className="w-4 h-4" />
                      <span>
                        Insert {arrOpts.rows}×{arrOpts.cols} Array ({arrOpts.rows * arrOpts.cols}{' '}
                        elements)
                      </span>
                    </button>
                  </div>
                )}

                {/* ====================================================== */}
                {/* SUB-VIEW 9: VIA STITCHING                              */}
                {/* ====================================================== */}
                {insertSubView === 'via_stitching' && (
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-lg font-bold text-slate-100">
                        Via Stitching Generator
                      </h3>
                      <p className="text-xs text-slate-400">
                        Fill a copper pour or board perimeter with stitching vias while automatically avoiding pads and traces
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      {(
                        [
                          { id: 'full_pour_grid', label: 'Full Pour Grid' },
                          { id: 'edge_perimeter', label: 'Board Edge Ring' },
                        ] as const
                      ).map((m) => (
                        <button
                          key={m.id}
                          type="button"
                          onPointerUp={() => setStitchOpts({ ...stitchOpts, mode: m.id })}
                          className={`min-h-[44px] rounded-xl text-xs font-bold ${
                            stitchOpts.mode === m.id
                              ? 'bg-[#6ee7b7] text-slate-950'
                              : 'bg-[#1c2422] text-slate-200 border border-[#2a3633]'
                          }`}
                        >
                          {m.label}
                        </button>
                      ))}
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <div className="text-xs text-slate-400">Target Net</div>
                        <PhoneInputField
                          inputMode="text"
                          value={stitchOpts.net}
                          onCommit={(v) => setStitchOpts({ ...stitchOpts, net: v })}
                        />
                      </div>
                      <div className="space-y-1">
                        <div className="text-xs text-slate-400">Grid Pitch (mm)</div>
                        <PhoneInputField
                          value={stitchOpts.pitchMm.toString()}
                          onCommit={(v) => {
                            const n = parseFloat(v);
                            if (!isNaN(n) && n >= 1.2)
                              setStitchOpts({ ...stitchOpts, pitchMm: n });
                          }}
                        />
                      </div>
                      <div className="space-y-1">
                        <div className="text-xs text-slate-400">Via Diameter (mm)</div>
                        <PhoneInputField
                          value={stitchOpts.viaDiameterMm.toString()}
                          onCommit={(v) => {
                            const n = parseFloat(v);
                            if (!isNaN(n) && n >= 0.45)
                              setStitchOpts({ ...stitchOpts, viaDiameterMm: n });
                          }}
                        />
                      </div>
                      <div className="space-y-1">
                        <div className="text-xs text-slate-400">Obstacle Clearance (mm)</div>
                        <PhoneInputField
                          value={stitchOpts.clearanceMm.toString()}
                          onCommit={(v) => {
                            const n = parseFloat(v);
                            if (!isNaN(n) && n >= 0.2)
                              setStitchOpts({ ...stitchOpts, clearanceMm: n });
                          }}
                        />
                      </div>
                    </div>

                    <button
                      type="button"
                      onPointerUp={() => generateBoardViaStitching(stitchOpts)}
                      className="w-full min-h-[52px] rounded-2xl bg-[#6ee7b7] text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 active:scale-98"
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>Generate Via Stitching ({stitchOpts.net || 'GND'})</span>
                    </button>
                  </div>
                )}

                {/* ====================================================== */}
                {/* SUB-VIEW 10: ADD DESIGNATORS                           */}
                {/* ====================================================== */}
                {insertSubView === 'designators' && (
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-lg font-bold text-slate-100">
                        Add &amp; Auto-Number Designators
                      </h3>
                      <p className="text-xs text-slate-400">
                        Automatically number all schematic and PCB parts (R1, C1, U1, D1, J1...) by geometric position
                      </p>
                    </div>

                    <div className="space-y-2">
                      <div className="text-xs font-bold text-slate-300">
                        Geometric Sort Order
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onPointerUp={() => setDesigDirection('top_to_bottom')}
                          className={`min-h-[46px] px-3 rounded-xl text-xs font-bold ${
                            desigDirection === 'top_to_bottom'
                              ? 'bg-[#6ee7b7] text-slate-950'
                              : 'bg-[#1c2422] text-slate-200 border border-[#2a3633]'
                          }`}
                        >
                          Top → Bottom, Left → Right
                        </button>
                        <button
                          type="button"
                          onPointerUp={() => setDesigDirection('left_to_right')}
                          className={`min-h-[46px] px-3 rounded-xl text-xs font-bold ${
                            desigDirection === 'left_to_right'
                              ? 'bg-[#6ee7b7] text-slate-950'
                              : 'bg-[#1c2422] text-slate-200 border border-[#2a3633]'
                          }`}
                        >
                          Left → Right, Top → Bottom
                        </button>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <div className="text-xs text-slate-400">
                        Starting Number Index (e.g. 1 for R1, 100 for R100)
                      </div>
                      <PhoneInputField
                        inputMode="numeric"
                        value={desigStartIdx.toString()}
                        onCommit={(v) => {
                          const n = parseInt(v, 10);
                          if (!isNaN(n) && n >= 1) setDesigStartIdx(n);
                        }}
                      />
                    </div>

                    <button
                      type="button"
                      onPointerUp={() =>
                        runAutoDesignators({
                          direction: desigDirection,
                          startIndex: desigStartIdx,
                        })
                      }
                      className="w-full min-h-[52px] rounded-2xl bg-[#6ee7b7] text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 active:scale-98"
                    >
                      <Hash className="w-4 h-4" />
                      <span>Number All Parts (R{desigStartIdx}, C{desigStartIdx}, U{desigStartIdx}...)</span>
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // ============================================================================
  // 3. SLIDE-UP BOTTOM SHEETS FOR PROPERTIES, DRC, AND EXPORT
  // ============================================================================
  return (
    <div
      className="fixed inset-0 z-40 bg-black/60 backdrop-blur-xs flex flex-col justify-end"
      onPointerUp={(e) => {
        if (e.target === e.currentTarget) {
          setActiveSheet('none');
        }
      }}
    >
      <div
        className="w-full max-h-[82dvh] bg-[#0d1312] border-t border-[#24322f] rounded-t-3xl flex flex-col overflow-hidden pb-safe shadow-2xl"
        onPointerUp={(e) => e.stopPropagation()}
      >
        <div className="pt-2.5 pb-2 px-4 border-b border-[#24322f] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-1.5 rounded-full bg-slate-700 mr-1" />
            <h2 className="text-sm font-bold text-[#6ee7b7] tracking-tight">
              {activeSheet === 'properties' && 'Item Properties'}
              {activeSheet === 'drc' && 'Design Rule Check (DRC)'}
              {activeSheet === 'export' && 'Manufacturing & Project'}
            </h2>
          </div>
          <button
            type="button"
            onPointerUp={() => setActiveSheet('none')}
            aria-label="Close sheet"
            className="w-11 h-11 rounded-xl bg-[#182220] text-slate-300 flex items-center justify-center active:scale-95"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 overflow-y-auto space-y-4 text-sm">
          {/* PROPERTIES SHEET */}
          {activeSheet === 'properties' && (
            <>
              {!selectedItem ? (
                <div className="py-8 text-center text-slate-400">
                  Tap any component, trace, via, or label on the canvas to inspect and edit its properties.
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center justify-between bg-[#182220] p-3 rounded-2xl border border-[#24322f]">
                    <div>
                      <div className="text-xs text-slate-400">Selected Element</div>
                      <div className="font-mono font-bold text-slate-100">
                        {selectedItem.type} · ({toUnitStr(selectedItem.transform.x, 2, 0)},{' '}
                        {toUnitStr(selectedItem.transform.y, 2, 0)} {unitLabel})
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onPointerUp={() => rotateItem(selectedItem.id)}
                        className="min-w-[44px] min-h-[44px] px-3 rounded-xl bg-[#242e2c] text-[#6ee7b7] font-semibold flex items-center gap-1 active:scale-95"
                      >
                        <RotateCw className="w-4 h-4" />
                        <span>{selectedItem.transform.rotation}°</span>
                      </button>
                      <button
                        type="button"
                        onPointerUp={() => {
                          deleteItem(selectedItem.id);
                          setActiveSheet('none');
                        }}
                        className="min-w-[44px] min-h-[44px] px-3 rounded-xl bg-rose-950 text-rose-300 flex items-center justify-center active:scale-95"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {(selectedItem.type === 'sch_component' ||
                    selectedItem.type === 'pcb_footprint') && (
                    <div className="grid grid-cols-2 gap-2.5">
                      <div className="p-3 rounded-2xl bg-[#182220] border border-[#24322f] space-y-1">
                        <div className="text-xs text-slate-400">Designator</div>
                        <PhoneInputField
                          ariaLabel="Designator"
                          inputMode="text"
                          value={(selectedItem as SchComponentItem | PcbFootprintItem).props.refDes}
                          onCommit={(val) => {
                            if (!val.trim()) return;
                            updateItemProps(
                              selectedItem.id,
                              (it) =>
                                ({
                                  ...it,
                                  props: { ...it.props, refDes: val.trim().toUpperCase() },
                                }) as AnyItem,
                              'Update RefDes'
                            );
                          }}
                          className="w-full min-h-[40px] px-2.5 rounded-xl bg-[#0d1312] border border-[#2f3e3b] font-mono font-bold text-[#6ee7b7] text-base focus:outline-none focus:border-[#6ee7b7]"
                        />
                      </div>

                      <div className="p-3 rounded-2xl bg-[#182220] border border-[#24322f] space-y-1">
                        <div className="text-xs text-slate-400">Value / Part</div>
                        <PhoneInputField
                          ariaLabel="Component Value"
                          inputMode="text"
                          value={(selectedItem as SchComponentItem | PcbFootprintItem).props.value}
                          onCommit={(val) => {
                            if (!val.trim()) return;
                            updateItemProps(
                              selectedItem.id,
                              (it) =>
                                ({
                                  ...it,
                                  props: { ...it.props, value: val.trim() },
                                }) as AnyItem,
                              'Update Value'
                            );
                          }}
                          className="w-full min-h-[40px] px-2.5 rounded-xl bg-[#0d1312] border border-[#2f3e3b] font-mono font-bold text-sky-400 text-base focus:outline-none focus:border-sky-400"
                        />
                      </div>
                    </div>
                  )}

                  {selectedItem.type === 'sch_label' && (
                    <div className="p-3 rounded-2xl bg-[#182220] border border-[#24322f] space-y-1">
                      <div className="text-xs text-slate-400">Net Name</div>
                      <PhoneInputField
                        ariaLabel="Net Name"
                        inputMode="text"
                        value={(selectedItem as SchLabelItem).props.text}
                        onCommit={(val) => {
                          if (!val.trim()) return;
                          updateItemProps(
                            selectedItem.id,
                            (it) =>
                              ({
                                ...it,
                                props: { text: val.trim().toUpperCase() },
                              }) as AnyItem,
                            'Rename Net Label'
                          );
                        }}
                        className="w-full min-h-[42px] px-3 rounded-xl bg-[#0d1312] border border-[#2f3e3b] font-mono font-bold text-amber-400 text-base focus:outline-none focus:border-amber-400"
                      />
                    </div>
                  )}

                  {selectedItem.type === 'pcb_trace' && (
                    <div className="p-3 rounded-2xl bg-[#182220] border border-[#24322f] space-y-1">
                      <div className="text-xs text-slate-400">
                        Copper Trace Width ({unitLabel})
                      </div>
                      <PhoneInputField
                        ariaLabel={`Copper Trace Width (${unitLabel})`}
                        inputMode="decimal"
                        value={toUnitStr((selectedItem as PcbTraceItem).props.width, 2, 1)}
                        onCommit={(val) => {
                          const num = parseFloat(val);
                          const mmVal = fromUnitVal(num);
                          if (!isNaN(mmVal) && mmVal >= 0.1 && mmVal <= 5) {
                            updateItemProps(
                              selectedItem.id,
                              (it) =>
                                ({
                                  ...it,
                                  props: { ...it.props, width: mmVal },
                                }) as AnyItem,
                              'Change Trace Width'
                            );
                          }
                        }}
                        className="w-full min-h-[42px] px-3 rounded-xl bg-[#0d1312] border border-[#2f3e3b] font-mono font-bold text-[#6ee7b7] text-base focus:outline-none focus:border-[#6ee7b7]"
                      />
                    </div>
                  )}

                  {selectedItem.type === 'pcb_via' && (
                    <div className="grid grid-cols-2 gap-2.5">
                      <div className="p-3 rounded-2xl bg-[#182220] border border-[#24322f] space-y-1">
                        <div className="text-xs text-slate-400">
                          Via Diameter ({unitLabel})
                        </div>
                        <PhoneInputField
                          ariaLabel={`Via Diameter (${unitLabel})`}
                          inputMode="decimal"
                          value={toUnitStr((selectedItem as PcbViaItem).props.diameter, 2, 1)}
                          onCommit={(val) => {
                            const num = parseFloat(val);
                            const mmVal = fromUnitVal(num);
                            if (!isNaN(mmVal) && mmVal >= 0.3) {
                              updateItemProps(
                                selectedItem.id,
                                (it) =>
                                  ({
                                    ...it,
                                    props: { ...it.props, diameter: mmVal },
                                  }) as AnyItem
                              );
                            }
                          }}
                          className="w-full min-h-[40px] px-2.5 rounded-xl bg-[#0d1312] border border-[#2f3e3b] font-mono font-bold text-[#6ee7b7] text-base focus:outline-none focus:border-[#6ee7b7]"
                        />
                      </div>
                      <div className="p-3 rounded-2xl bg-[#182220] border border-[#24322f] space-y-1">
                        <div className="text-xs text-slate-400">
                          Via Drill ({unitLabel})
                        </div>
                        <PhoneInputField
                          ariaLabel={`Via Drill (${unitLabel})`}
                          inputMode="decimal"
                          value={toUnitStr((selectedItem as PcbViaItem).props.drill, 2, 1)}
                          onCommit={(val) => {
                            const num = parseFloat(val);
                            const mmVal = fromUnitVal(num);
                            if (!isNaN(mmVal) && mmVal >= 0.15) {
                              updateItemProps(
                                selectedItem.id,
                                (it) =>
                                  ({
                                    ...it,
                                    props: { ...it.props, drill: mmVal },
                                  }) as AnyItem
                              );
                            }
                          }}
                          className="w-full min-h-[40px] px-2.5 rounded-xl bg-[#0d1312] border border-[#2f3e3b] font-mono font-bold text-sky-400 text-base focus:outline-none focus:border-sky-400"
                        />
                      </div>
                    </div>
                  )}

                  {selectedItem.type === 'pcb_outline' && (
                    <div className="grid grid-cols-2 gap-2.5">
                      <div className="p-3 rounded-2xl bg-[#182220] border border-[#24322f] space-y-1">
                        <div className="text-xs text-slate-400">
                          Board Width ({unitLabel})
                        </div>
                        <PhoneInputField
                          ariaLabel={`Board Width (${unitLabel})`}
                          inputMode="decimal"
                          value={toUnitStr((selectedItem as PcbOutlineItem).props.width, 1, 0)}
                          onCommit={(val) => {
                            const num = parseFloat(val);
                            const mmVal = fromUnitVal(num);
                            if (!isNaN(mmVal) && mmVal >= 5) {
                              updateItemProps(
                                selectedItem.id,
                                (it) =>
                                  ({
                                    ...it,
                                    props: { ...it.props, width: mmVal },
                                  }) as AnyItem
                              );
                            }
                          }}
                          className="w-full min-h-[40px] px-2.5 rounded-xl bg-[#0d1312] border border-[#2f3e3b] font-mono font-bold text-amber-400 text-base focus:outline-none focus:border-amber-400"
                        />
                      </div>
                      <div className="p-3 rounded-2xl bg-[#182220] border border-[#24322f] space-y-1">
                        <div className="text-xs text-slate-400">
                          Board Height ({unitLabel})
                        </div>
                        <PhoneInputField
                          ariaLabel={`Board Height (${unitLabel})`}
                          inputMode="decimal"
                          value={toUnitStr((selectedItem as PcbOutlineItem).props.height, 1, 0)}
                          onCommit={(val) => {
                            const num = parseFloat(val);
                            const mmVal = fromUnitVal(num);
                            if (!isNaN(mmVal) && mmVal >= 5) {
                              updateItemProps(
                                selectedItem.id,
                                (it) =>
                                  ({
                                    ...it,
                                    props: { ...it.props, height: mmVal },
                                  }) as AnyItem
                              );
                            }
                          }}
                          className="w-full min-h-[40px] px-2.5 rounded-xl bg-[#0d1312] border border-[#2f3e3b] font-mono font-bold text-amber-400 text-base focus:outline-none focus:border-amber-400"
                        />
                      </div>
                    </div>
                  )}
                </div>
              )}
            </>
          )}

          {/* DRC SLIDE-UP SHEET */}
          {activeSheet === 'drc' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400">
                  Tap any violation to jump & highlight on PCB
                </span>
                <button
                  type="button"
                  onPointerUp={() => runDrcCheck()}
                  className="min-h-[44px] px-3.5 rounded-xl bg-[#6ee7b7] text-slate-950 font-bold text-xs active:scale-95"
                >
                  Re-run DRC
                </button>
              </div>

              {drcViolations.length === 0 ? (
                <div className="p-6 rounded-2xl bg-[#182220] border border-[#6ee7b7]/30 flex flex-col items-center text-center gap-2">
                  <CheckCircle2 className="w-8 h-8 text-[#6ee7b7]" />
                  <div className="font-bold text-slate-100">Zero DRC Violations</div>
                  <div className="text-xs text-slate-400">
                    All nets are routed and copper clearances meet design rules.
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  {drcViolations.map((v) => (
                    <button
                      key={v.id}
                      type="button"
                      onPointerUp={() =>
                        focusViolation(v, window.innerWidth, window.innerHeight)
                      }
                      className="w-full min-h-[56px] p-3 rounded-2xl bg-[#182220] border border-[#24322f] flex items-start gap-3 text-left active:scale-98"
                    >
                      <AlertTriangle
                        className={`w-5 h-5 shrink-0 mt-0.5 ${
                          v.severity === 'error' ? 'text-rose-400' : 'text-amber-400'
                        }`}
                      />
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-slate-100 text-xs leading-snug">
                          {v.message}
                        </div>
                        <div className="text-[11px] font-mono text-slate-400 mt-1">
                          Layer: {v.layer} · ({v.position.x.toFixed(1)}, {v.position.y.toFixed(1)}{' '}
                          mm)
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* EXPORT & PROJECT MANAGEMENT SHEET */}
          {activeSheet === 'export' && (
            <div className="space-y-3.5">
              <div className="text-xs font-semibold text-slate-400">
                KiCad & Gerber Fabrication Exports
              </div>
              <div className="grid grid-cols-1 gap-2">
                <button
                  type="button"
                  onPointerUp={() => {
                    const base = history.project.name.replace(/\s+/g, '_');
                    const bundle = generateGerberBundle(history.project);
                    const zipBytes = createZipArchive([
                      { name: `${base}-F_Cu.gtl`, content: bundle.topCopper },
                      { name: `${base}-B_Cu.gbl`, content: bundle.bottomCopper },
                      { name: `${base}-F_Mask.gts`, content: bundle.topMask },
                      { name: `${base}-B_Mask.gbs`, content: bundle.bottomMask },
                      { name: `${base}-F_Paste.gtp`, content: bundle.topPaste },
                      { name: `${base}-B_Paste.gbp`, content: bundle.bottomPaste },
                      { name: `${base}-F_SilkS.gto`, content: bundle.topSilkscreen },
                      { name: `${base}-B_SilkS.gbo`, content: bundle.bottomSilkscreen },
                      { name: `${base}-F_Fab.gbr`, content: bundle.topFab },
                      { name: `${base}-Edge_Cuts.gm1`, content: bundle.boardOutline },
                      { name: `${base}.drl`, content: bundle.drillExcellon },
                      { name: `${base}.kicad_pcb`, content: bundle.kicadPcb },
                      { name: `${base}.kicad_sch`, content: bundle.kicadSch },
                    ]);
                    const blob = new Blob([zipBytes.buffer as ArrayBuffer], {
                      type: 'application/zip',
                    });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `${base}_All_Layers_Gerbers.zip`;
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    setTimeout(() => URL.revokeObjectURL(url), 1500);
                  }}
                  className="min-h-[54px] px-4 rounded-2xl bg-[#6ee7b7] text-slate-950 font-extrabold flex items-center justify-between active:scale-98"
                >
                  <div className="flex items-center gap-3">
                    <CloudDownload className="w-5 h-5" />
                    <span>Export All Layers Gerber + KiCad Bundle (.zip)</span>
                  </div>
                  <Share2 className="w-4 h-4" />
                </button>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onPointerUp={() => {
                      const base = history.project.name.replace(/\s+/g, '_');
                      const pcbContent = generateKicadPcb(history.project);
                      shareOrDownloadFile(`${base}.kicad_pcb`, pcbContent, 'text/plain');
                    }}
                    className="min-h-[52px] px-3.5 rounded-2xl bg-[#182220] border border-[#6ee7b7]/50 text-[#6ee7b7] font-bold text-xs flex items-center justify-between active:scale-98"
                  >
                    <div className="flex items-center gap-2">
                      <FileCode2 className="w-4 h-4 shrink-0" />
                      <span>KiCad PCB (.kicad_pcb)</span>
                    </div>
                    <Share2 className="w-3.5 h-3.5 shrink-0" />
                  </button>

                  <button
                    type="button"
                    onPointerUp={() => {
                      const base = history.project.name.replace(/\s+/g, '_');
                      const schContent = generateKicadSch(history.project);
                      shareOrDownloadFile(`${base}.kicad_sch`, schContent, 'text/plain');
                    }}
                    className="min-h-[52px] px-3.5 rounded-2xl bg-[#182220] border border-[#6ee7b7]/50 text-[#6ee7b7] font-bold text-xs flex items-center justify-between active:scale-98"
                  >
                    <div className="flex items-center gap-2">
                      <FileCode2 className="w-4 h-4 shrink-0" />
                      <span>KiCad Sch (.kicad_sch)</span>
                    </div>
                    <Share2 className="w-3.5 h-3.5 shrink-0" />
                  </button>
                </div>

                {/* Individual Gerber Layer Files */}
                <div className="p-3 rounded-2xl bg-[#182220] border border-[#24322f] space-y-2">
                  <div className="text-xs font-semibold text-slate-300">
                    All Individual Gerber RS-274X &amp; Drill Layers
                  </div>
                  <div className="grid grid-cols-3 gap-1.5">
                    <button
                      type="button"
                      onPointerUp={() => {
                        const base = history.project.name.replace(/\s+/g, '_');
                        shareOrDownloadFile(
                          `${base}-F_Cu.gtl`,
                          generateCopperGerber(history.project, 'F.Cu')
                        );
                      }}
                      className="min-h-[42px] px-2 rounded-xl bg-[#0d1312] border border-[#2f3e3b] text-xs font-mono font-bold text-[#f87171] active:scale-95"
                    >
                      F.Cu (.gtl)
                    </button>
                    <button
                      type="button"
                      onPointerUp={() => {
                        const base = history.project.name.replace(/\s+/g, '_');
                        shareOrDownloadFile(
                          `${base}-B_Cu.gbl`,
                          generateCopperGerber(history.project, 'B.Cu')
                        );
                      }}
                      className="min-h-[42px] px-2 rounded-xl bg-[#0d1312] border border-[#2f3e3b] text-xs font-mono font-bold text-[#60a5fa] active:scale-95"
                    >
                      B.Cu (.gbl)
                    </button>
                    <button
                      type="button"
                      onPointerUp={() => {
                        const base = history.project.name.replace(/\s+/g, '_');
                        shareOrDownloadFile(
                          `${base}-F_Mask.gts`,
                          generateMaskGerber(history.project, 'F.Mask')
                        );
                      }}
                      className="min-h-[42px] px-2 rounded-xl bg-[#0d1312] border border-[#2f3e3b] text-xs font-mono font-bold text-purple-300 active:scale-95"
                    >
                      F.Mask (.gts)
                    </button>
                    <button
                      type="button"
                      onPointerUp={() => {
                        const base = history.project.name.replace(/\s+/g, '_');
                        shareOrDownloadFile(
                          `${base}-B_Mask.gbs`,
                          generateMaskGerber(history.project, 'B.Mask')
                        );
                      }}
                      className="min-h-[42px] px-2 rounded-xl bg-[#0d1312] border border-[#2f3e3b] text-xs font-mono font-bold text-indigo-300 active:scale-95"
                    >
                      B.Mask (.gbs)
                    </button>
                    <button
                      type="button"
                      onPointerUp={() => {
                        const base = history.project.name.replace(/\s+/g, '_');
                        shareOrDownloadFile(
                          `${base}-F_Paste.gtp`,
                          generatePasteGerber(history.project, 'F.Paste')
                        );
                      }}
                      className="min-h-[42px] px-2 rounded-xl bg-[#0d1312] border border-[#2f3e3b] text-xs font-mono font-bold text-slate-300 active:scale-95"
                    >
                      F.Paste (.gtp)
                    </button>
                    <button
                      type="button"
                      onPointerUp={() => {
                        const base = history.project.name.replace(/\s+/g, '_');
                        shareOrDownloadFile(
                          `${base}-F_SilkS.gto`,
                          generateSilkscreenGerber(history.project, 'F.SilkS')
                        );
                      }}
                      className="min-h-[42px] px-2 rounded-xl bg-[#0d1312] border border-[#2f3e3b] text-xs font-mono font-bold text-[#fef08a] active:scale-95"
                    >
                      F.SilkS (.gto)
                    </button>
                    <button
                      type="button"
                      onPointerUp={() => {
                        const base = history.project.name.replace(/\s+/g, '_');
                        shareOrDownloadFile(
                          `${base}-B_SilkS.gbo`,
                          generateSilkscreenGerber(history.project, 'B.SilkS')
                        );
                      }}
                      className="min-h-[42px] px-2 rounded-xl bg-[#0d1312] border border-[#2f3e3b] text-xs font-mono font-bold text-amber-200 active:scale-95"
                    >
                      B.SilkS (.gbo)
                    </button>
                    <button
                      type="button"
                      onPointerUp={() => {
                        const base = history.project.name.replace(/\s+/g, '_');
                        shareOrDownloadFile(
                          `${base}-F_Fab.gbr`,
                          generateFabGerber(history.project)
                        );
                      }}
                      className="min-h-[42px] px-2 rounded-xl bg-[#0d1312] border border-[#2f3e3b] text-xs font-mono font-bold text-cyan-300 active:scale-95"
                    >
                      F.Fab (.gbr)
                    </button>
                    <button
                      type="button"
                      onPointerUp={() => {
                        const base = history.project.name.replace(/\s+/g, '_');
                        shareOrDownloadFile(
                          `${base}-Edge_Cuts.gm1`,
                          generateOutlineGerber(history.project)
                        );
                      }}
                      className="min-h-[42px] px-2 rounded-xl bg-[#0d1312] border border-[#2f3e3b] text-xs font-mono font-bold text-[#fb923c] active:scale-95"
                    >
                      Outline (.gm1)
                    </button>
                    <button
                      type="button"
                      onPointerUp={() => {
                        const base = history.project.name.replace(/\s+/g, '_');
                        shareOrDownloadFile(
                          `${base}.drl`,
                          generateExcellonDrill(history.project)
                        );
                      }}
                      className="col-span-3 min-h-[42px] px-2 rounded-xl bg-[#0d1312] border border-[#2f3e3b] text-xs font-mono font-bold text-[#6ee7b7] active:scale-95"
                    >
                      Excellon Through-Hole + Via Drill (.drl)
                    </button>
                  </div>
                </div>

                <button
                  type="button"
                  onPointerUp={() => {
                    const csv = generateBomCsv(history.project);
                    shareOrDownloadFile(
                      `${history.project.name.replace(/\s+/g, '_')}_BOM.csv`,
                      csv,
                      'text/csv'
                    );
                  }}
                  className="min-h-[50px] px-4 rounded-2xl bg-[#182220] border border-[#24322f] text-slate-100 font-semibold flex items-center justify-between active:scale-98"
                >
                  <div className="flex items-center gap-3">
                    <FileSpreadsheet className="w-5 h-5 text-sky-400" />
                    <span>Export Bill of Materials (CSV)</span>
                  </div>
                  <Share2 className="w-4 h-4 text-slate-400" />
                </button>

                <button
                  type="button"
                  onPointerUp={() => {
                    const json = serializeProject(history.project);
                    shareOrDownloadFile(
                      `${history.project.name.replace(/\s+/g, '_')}.pocketeda.json`,
                      json,
                      'application/json'
                    );
                  }}
                  className="min-h-[50px] px-4 rounded-2xl bg-[#182220] border border-[#24322f] text-slate-100 font-semibold flex items-center justify-between active:scale-98"
                >
                  <div className="flex items-center gap-3">
                    <FileCode2 className="w-5 h-5 text-amber-400" />
                    <span>Save Project JSON</span>
                  </div>
                  <Share2 className="w-4 h-4 text-slate-400" />
                </button>

                <a
                  href="/PocketEDA_Source.zip"
                  download="PocketEDA_Full_Source.zip"
                  className="min-h-[54px] px-4 rounded-2xl bg-white text-slate-950 font-extrabold flex items-center justify-between active:scale-98"
                >
                  <div className="flex items-center gap-3">
                    <CloudDownload className="w-5 h-5" />
                    <span>Download Full App Source Code (.zip)</span>
                  </div>
                  <Share2 className="w-4 h-4" />
                </a>
              </div>

              <div className="pt-2 text-xs font-semibold text-slate-400">Project Workspace</div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onPointerUp={() => loadStarterProject()}
                  className="min-h-[48px] px-3 rounded-2xl bg-[#182220] border border-[#24322f] text-slate-200 font-semibold text-xs flex items-center justify-center active:scale-95"
                >
                  Demo Circuit
                </button>

                <button
                  type="button"
                  onPointerUp={() => newBlankProject()}
                  className="min-h-[48px] px-3 rounded-2xl bg-rose-950/60 border border-rose-500/30 text-rose-300 font-semibold text-xs flex items-center justify-center active:scale-95"
                >
                  New Blank
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
