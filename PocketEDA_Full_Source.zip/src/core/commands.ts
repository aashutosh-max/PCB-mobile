import { getDefaultSymbolDefs, PCB_GRID, snapPoint } from './geometry';
import { computeNetlist } from './netlist';
import {
  AnyItem,
  Command,
  PcbFootprintItem,
  Point,
  Project,
  Rotation,
  SchComponentItem,
} from './types';

export const MAX_HISTORY = 60;

export interface HistoryState {
  project: Project;
  past: { project: Project; description: string }[];
  future: { project: Project; description: string }[];
}

export function createHistoryState(initialProject: Project): HistoryState {
  return {
    project: initialProject,
    past: [],
    future: [],
  };
}

export function executeCommand(state: HistoryState, command: Command): HistoryState {
  const nextProject = command.execute(state.project);
  if (nextProject === state.project) return state;

  const nextPast = [...state.past, { project: state.project, description: command.description }];
  if (nextPast.length > MAX_HISTORY) {
    nextPast.shift();
  }

  return {
    project: {
      ...nextProject,
      updatedAt: Date.now(),
    },
    past: nextPast,
    future: [],
  };
}

export function undoCommand(state: HistoryState): HistoryState {
  if (state.past.length === 0) return state;
  const previous = state.past[state.past.length - 1];
  const nextPast = state.past.slice(0, state.past.length - 1);
  const nextFuture = [
    { project: state.project, description: previous.description },
    ...state.future,
  ].slice(0, MAX_HISTORY);

  return {
    project: previous.project,
    past: nextPast,
    future: nextFuture,
  };
}

export function redoCommand(state: HistoryState): HistoryState {
  if (state.future.length === 0) return state;
  const next = state.future[0];
  const nextFuture = state.future.slice(1);
  const nextPast = [
    ...state.past,
    { project: state.project, description: next.description },
  ].slice(-MAX_HISTORY);

  return {
    project: next.project,
    past: nextPast,
    future: nextFuture,
  };
}

function updateSheetItems(
  project: Project,
  sheetKind: 'schematic' | 'pcb',
  updater: (items: AnyItem[]) => AnyItem[]
): Project {
  return {
    ...project,
    sheets: project.sheets.map((sheet) =>
      sheet.kind === sheetKind ? { ...sheet, items: updater(sheet.items) } : sheet
    ),
  };
}

export function createAddItemCommand(
  sheetKind: 'schematic' | 'pcb',
  item: AnyItem,
  description = `Add ${item.type}`
): Command {
  return {
    id: `cmd_add_${item.id}`,
    description,
    execute(project: Project): Project {
      const updated = updateSheetItems(project, sheetKind, (items) => [...items, item]);
      return syncPcbNetsAndFootprints(updated);
    },
  };
}

export function createAddPairedComponentCommand(
  schItem: SchComponentItem,
  pcbItem?: PcbFootprintItem,
  description = `Place ${schItem.props.refDes}`
): Command {
  return {
    id: `cmd_pair_${schItem.id}`,
    description,
    execute(project: Project): Project {
      let updated = updateSheetItems(project, 'schematic', (items) => [...items, schItem]);
      if (pcbItem) {
        updated = updateSheetItems(updated, 'pcb', (items) => [...items, pcbItem]);
      }
      return syncPcbNetsAndFootprints(updated);
    },
  };
}

export function createConnectPcbPadsCommand(
  fromRefDes: string,
  fromPadNum: string,
  toRefDes: string,
  toPadNum: string,
  explicitNetName?: string
): Command {
  return {
    id: `cmd_airwire_${fromRefDes}_${fromPadNum}_${toRefDes}_${toPadNum}_${Date.now()}`,
    description: `Connect ${fromRefDes}.${fromPadNum} to ${toRefDes}.${toPadNum}`,
    execute(project: Project): Project {
      const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');
      if (!pcbSheet) return project;

      const netlist = computeNetlist(project);
      let existingFromNet = netlist.padNetMap[`${fromRefDes}:${fromPadNum}`] || '';
      let existingToNet = netlist.padNetMap[`${toRefDes}:${toPadNum}`] || '';

      for (const item of pcbSheet.items) {
        if (item.type !== 'pcb_footprint') continue;
        if (item.props.refDes === fromRefDes) {
          const pad = item.props.pads.find((p) => p.number === fromPadNum);
          if (pad?.net && !existingFromNet) existingFromNet = pad.net;
        }
        if (item.props.refDes === toRefDes) {
          const pad = item.props.pads.find((p) => p.number === toPadNum);
          if (pad?.net && !existingToNet) existingToNet = pad.net;
        }
      }

      let targetNet = explicitNetName || existingFromNet || existingToNet;
      if (!targetNet) {
        const usedNets = new Set<string>(netlist.nets.map((n) => n.name));
        for (const item of pcbSheet.items) {
          if (item.type === 'pcb_footprint') {
            for (const p of item.props.pads) {
              if (p.net) usedNets.add(p.net);
            }
          } else if (item.type === 'pcb_trace' && item.props.net) {
            usedNets.add(item.props.net);
          }
        }
        let idx = 1;
        while (usedNets.has(`NET_${idx}`)) idx++;
        targetNet = `NET_${idx}`;
      }

      const mergeNet =
        existingFromNet && existingToNet && existingFromNet !== existingToNet
          ? existingToNet
          : null;

      return updateSheetItems(project, 'pcb', (items) =>
        items.map((item) => {
          if (item.type === 'pcb_footprint') {
            const nextPads = item.props.pads.map((pad) => {
              const isFrom = item.props.refDes === fromRefDes && pad.number === fromPadNum;
              const isTo = item.props.refDes === toRefDes && pad.number === toPadNum;
              const isMerged = mergeNet && pad.net === mergeNet;
              if (isFrom || isTo || isMerged) {
                return { ...pad, net: targetNet };
              }
              return pad;
            });
            return {
              ...item,
              props: {
                ...item.props,
                pads: nextPads,
              },
            };
          }
          if (item.type === 'pcb_trace' && mergeNet && item.props.net === mergeNet) {
            return {
              ...item,
              props: { ...item.props, net: targetNet },
            };
          }
          return item;
        })
      );
    },
  };
}

export function createDeleteItemCommand(
  sheetKind: 'schematic' | 'pcb',
  itemId: string,
  description = 'Delete item'
): Command {
  return {
    id: `cmd_del_${itemId}_${Date.now()}`,
    description,
    execute(project: Project): Project {
      const targetSheet = project.sheets.find((s) => s.kind === sheetKind);
      const targetItem = targetSheet?.items.find((i) => i.id === itemId);
      let updated = updateSheetItems(project, sheetKind, (items) =>
        items.filter((i) => i.id !== itemId)
      );
      if (sheetKind === 'schematic' && targetItem && targetItem.type === 'sch_component') {
        const refDes = targetItem.props.refDes;
        updated = updateSheetItems(updated, 'pcb', (items) =>
          items.filter((i) => !(i.type === 'pcb_footprint' && i.props.refDes === refDes))
        );
      } else if (sheetKind === 'pcb' && targetItem && targetItem.type === 'pcb_footprint') {
        const refDes = targetItem.props.refDes;
        updated = updateSheetItems(updated, 'schematic', (items) =>
          items.filter((i) => !(i.type === 'sch_component' && i.props.refDes === refDes))
        );
      }
      return syncPcbNetsAndFootprints(updated);
    },
  };
}

export function createMoveItemCommand(
  sheetKind: 'schematic' | 'pcb',
  itemId: string,
  newPos: Point,
  description = 'Move item'
): Command {
  return {
    id: `cmd_move_${itemId}_${Date.now()}`,
    description,
    execute(project: Project): Project {
      const updated = updateSheetItems(project, sheetKind, (items) =>
        items.map((item) => {
          if (item.id !== itemId) return item;
          if (item.type === 'sch_wire' || item.type === 'pcb_trace') {
            const dx = newPos.x - item.transform.x;
            const dy = newPos.y - item.transform.y;
            return {
              ...item,
              transform: { ...item.transform, x: newPos.x, y: newPos.y },
              props: {
                ...item.props,
                points: item.props.points.map((p) => ({ x: p.x + dx, y: p.y + dy })),
              },
            } as AnyItem;
          }
          return {
            ...item,
            transform: { ...item.transform, x: newPos.x, y: newPos.y },
          };
        })
      );
      return syncPcbNetsAndFootprints(updated);
    },
  };
}

export function createRotateItemCommand(
  sheetKind: 'schematic' | 'pcb',
  itemId: string,
  description = 'Rotate 90°'
): Command {
  return {
    id: `cmd_rot_${itemId}_${Date.now()}`,
    description,
    execute(project: Project): Project {
      const updated = updateSheetItems(project, sheetKind, (items) =>
        items.map((item) => {
          if (item.id !== itemId) return item;
          const nextRotation = (((item.transform.rotation + 90) % 360) as Rotation);
          return {
            ...item,
            transform: { ...item.transform, rotation: nextRotation },
          };
        })
      );
      return syncPcbNetsAndFootprints(updated);
    },
  };
}

export function createUpdateItemCommand(
  sheetKind: 'schematic' | 'pcb',
  itemId: string,
  updater: (item: AnyItem) => AnyItem,
  description = 'Update properties'
): Command {
  return {
    id: `cmd_upd_${itemId}_${Date.now()}`,
    description,
    execute(project: Project): Project {
      const targetSheet = project.sheets.find((s) => s.kind === sheetKind);
      const beforeItem = targetSheet?.items.find((i) => i.id === itemId);
      const afterItem = beforeItem ? updater(beforeItem) : null;

      let updated = updateSheetItems(project, sheetKind, (items) =>
        items.map((item) => (item.id === itemId ? updater(item) : item))
      );

      // Keep paired Schematic <-> PCB component refDes and value in lockstep
      if (
        sheetKind === 'schematic' &&
        beforeItem?.type === 'sch_component' &&
        afterItem?.type === 'sch_component'
      ) {
        const oldRef = beforeItem.props.refDes;
        const newRef = afterItem.props.refDes;
        const newVal = afterItem.props.value;
        updated = updateSheetItems(updated, 'pcb', (items) =>
          items.map((it) =>
            it.type === 'pcb_footprint' && it.props.refDes === oldRef
              ? {
                  ...it,
                  id: `fp_${newRef}`,
                  props: { ...it.props, refDes: newRef, value: newVal },
                }
              : it
          )
        );
      } else if (
        sheetKind === 'pcb' &&
        beforeItem?.type === 'pcb_footprint' &&
        afterItem?.type === 'pcb_footprint'
      ) {
        const oldRef = beforeItem.props.refDes;
        const newRef = afterItem.props.refDes;
        const newVal = afterItem.props.value;
        updated = updateSheetItems(updated, 'schematic', (items) =>
          items.map((it) =>
            it.type === 'sch_component' && it.props.refDes === oldRef
              ? {
                  ...it,
                  props: { ...it.props, refDes: newRef, value: newVal },
                }
              : it
          )
        );
      }

      return syncPcbNetsAndFootprints(updated);
    },
  };
}

function computeMappedPcbPosition(
  comp: SchComponentItem,
  existingPositions: { x: number; y: number; w: number; h: number }[],
  board: { x: number; y: number; width: number; height: number },
  courtyard: { width: number; height: number }
): Point {
  const normX = Math.max(0.08, Math.min(0.92, (comp.transform.x - 8) / 34));
  const normY = Math.max(0.12, Math.min(0.88, (comp.transform.y - 6) / 22));
  const marginX = Math.min(5, board.width * 0.16);
  const marginY = Math.min(4.5, board.height * 0.18);
  const basePt = snapPoint(
    {
      x: board.x + marginX + normX * Math.max(8, board.width - marginX * 2),
      y: board.y + marginY + normY * Math.max(6, board.height - marginY * 2),
    },
    PCB_GRID
  );

  const overlaps = (pt: Point) =>
    existingPositions.some(
      (ex) =>
        Math.abs(pt.x - ex.x) < (courtyard.width + ex.w) / 2 + 1.0 &&
        Math.abs(pt.y - ex.y) < (courtyard.height + ex.h) / 2 + 1.0
    );

  if (!overlaps(basePt)) return basePt;

  for (let radius = 1; radius <= 16; radius++) {
    const step = radius * 2.5;
    const candidates: Point[] = [
      { x: basePt.x + step, y: basePt.y },
      { x: basePt.x - step, y: basePt.y },
      { x: basePt.x, y: basePt.y + step },
      { x: basePt.x, y: basePt.y - step },
      { x: basePt.x + step, y: basePt.y + step },
      { x: basePt.x - step, y: basePt.y + step },
      { x: basePt.x + step, y: basePt.y - step },
      { x: basePt.x - step, y: basePt.y - step },
    ];
    for (const c of candidates) {
      const snapped = snapPoint(c, PCB_GRID);
      if (!overlaps(snapped)) {
        return snapped;
      }
    }
  }

  return basePt;
}

/**
 * Keeps PCB footprints, pad counts, and pad net assignments synchronized with the Schematic sheet,
 * while preserving PCB-level airwires (`pad.net`) and copper traces created directly in the PCB editor.
 */
export function syncPcbNetsAndFootprints(project: Project): Project {
  const schSheet = project.sheets.find((s) => s.kind === 'schematic');
  const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');
  if (!schSheet || !pcbSheet) return project;

  const netlist = computeNetlist(project);
  const schComponents = schSheet.items.filter(
    (i): i is SchComponentItem =>
      i.type === 'sch_component' && i.props.kind !== 'GND' && i.props.kind !== 'VCC'
  );

  const schMap = new Map<string, SchComponentItem>();
  for (const comp of schComponents) {
    schMap.set(comp.props.refDes, comp);
  }

  const outlineItem = pcbSheet.items.find((i) => i.type === 'pcb_outline');
  const boardRect =
    outlineItem && outlineItem.type === 'pcb_outline'
      ? {
          x: outlineItem.transform.x,
          y: outlineItem.transform.y,
          width: outlineItem.props.width,
          height: outlineItem.props.height,
        }
      : { x: 4, y: 4, width: 32, height: 22 };

  const existingFootprints = new Map<string, PcbFootprintItem>();
  const occupiedBoxes: { x: number; y: number; w: number; h: number }[] = [];

  for (const item of pcbSheet.items) {
    if (item.type === 'pcb_footprint' && schMap.has(item.props.refDes)) {
      existingFootprints.set(item.props.refDes, item);
      occupiedBoxes.push({
        x: item.transform.x,
        y: item.transform.y,
        w: item.props.courtyard.width,
        h: item.props.courtyard.height,
      });
    }
  }

  const nextPcbItems: AnyItem[] = pcbSheet.items
    .filter((item) => {
      if (item.type === 'pcb_footprint') {
        return schMap.has(item.props.refDes);
      }
      return true;
    })
    .map((item) => {
      if (item.type !== 'pcb_footprint') return item;
      const comp = schMap.get(item.props.refDes)!;
      const def = getDefaultSymbolDefs(comp.props.kind, comp.props.pins);
      const sourcePads =
        item.props.pads.length === comp.props.pins.length ? item.props.pads : def.pads;
      const updatedPads = sourcePads.map((pad) => ({
        ...pad,
        net: netlist.padNetMap[`${item.props.refDes}:${pad.number}`] || pad.net || '',
      }));
      return {
        ...item,
        props: {
          ...item.props,
          value: comp.props.value,
          footprintName: comp.props.footprint || item.props.footprintName || def.footprint,
          courtyard:
            item.props.pads.length === comp.props.pins.length
              ? item.props.courtyard
              : def.courtyard,
          pads: updatedPads,
        },
      };
    });

  for (const comp of schComponents) {
    if (existingFootprints.has(comp.props.refDes)) continue;
    const def = getDefaultSymbolDefs(comp.props.kind, comp.props.pins);
    const pos = computeMappedPcbPosition(comp, occupiedBoxes, boardRect, def.courtyard);
    occupiedBoxes.push({
      x: pos.x,
      y: pos.y,
      w: def.courtyard.width,
      h: def.courtyard.height,
    });

    const updatedPads = def.pads.map((pad) => ({
      ...pad,
      net: netlist.padNetMap[`${comp.props.refDes}:${pad.number}`] || pad.net || '',
    }));

    const newFp: PcbFootprintItem = {
      id: `fp_${comp.props.refDes}`,
      type: 'pcb_footprint',
      transform: {
        x: pos.x,
        y: pos.y,
        rotation: comp.transform.rotation,
        layer: 'F.Cu',
      },
      props: {
        refDes: comp.props.refDes,
        value: comp.props.value,
        footprintName: comp.props.footprint || def.footprint,
        courtyard: def.courtyard,
        pads: updatedPads,
      },
    };
    nextPcbItems.push(newFp);
  }

  return {
    ...project,
    sheets: project.sheets.map((s) =>
      s.kind === 'pcb' ? { ...s, items: nextPcbItems } : s
    ),
  };
}

/**
 * Re-aligns all PCB footprints to match the relative coordinates and rotations of their paired Schematic symbols.
 */
export function createAlignPcbToSchematicCommand(): Command {
  return {
    id: `cmd_align_pcb_${Date.now()}`,
    description: 'Sync PCB layout with Schematic',
    execute(project: Project): Project {
      const synced = syncPcbNetsAndFootprints(project);
      const schSheet = synced.sheets.find((s) => s.kind === 'schematic');
      const pcbSheet = synced.sheets.find((s) => s.kind === 'pcb');
      if (!schSheet || !pcbSheet) return synced;

      const schComponents = schSheet.items.filter(
        (i): i is SchComponentItem =>
          i.type === 'sch_component' && i.props.kind !== 'GND' && i.props.kind !== 'VCC'
      );
      if (schComponents.length === 0) return synced;

      const schMap = new Map<string, SchComponentItem>();
      let minSchX = Infinity;
      let maxSchX = -Infinity;
      let minSchY = Infinity;
      let maxSchY = -Infinity;

      for (const c of schComponents) {
        schMap.set(c.props.refDes, c);
        if (c.transform.x < minSchX) minSchX = c.transform.x;
        if (c.transform.x > maxSchX) maxSchX = c.transform.x;
        if (c.transform.y < minSchY) minSchY = c.transform.y;
        if (c.transform.y > maxSchY) maxSchY = c.transform.y;
      }

      const outlineItem = pcbSheet.items.find((i) => i.type === 'pcb_outline');
      const board =
        outlineItem && outlineItem.type === 'pcb_outline'
          ? {
              x: outlineItem.transform.x,
              y: outlineItem.transform.y,
              width: outlineItem.props.width,
              height: outlineItem.props.height,
            }
          : { x: 4, y: 4, width: 34, height: 24 };

      const occupied: { x: number; y: number; w: number; h: number }[] = [];
      const spanX = Math.max(12, maxSchX - minSchX);
      const spanY = Math.max(10, maxSchY - minSchY);

      const nextItems = pcbSheet.items.map((item) => {
        if (item.type !== 'pcb_footprint') return item;
        const comp = schMap.get(item.props.refDes);
        if (!comp) return item;

        const nx = schComponents.length === 1 ? 0.5 : (comp.transform.x - minSchX) / spanX;
        const ny = schComponents.length === 1 ? 0.5 : (comp.transform.y - minSchY) / spanY;
        const padX = Math.min(6, board.width * 0.2);
        const padY = Math.min(5, board.height * 0.22);

        const target = snapPoint(
          {
            x: board.x + padX + nx * Math.max(8, board.width - padX * 2),
            y: board.y + padY + ny * Math.max(6, board.height - padY * 2),
          },
          PCB_GRID
        );

        const pos = computeMappedPcbPosition(
          { ...comp, transform: { ...comp.transform, x: 8 + nx * 34, y: 6 + ny * 22 } },
          occupied,
          board,
          item.props.courtyard
        );
        const finalPos = occupied.length === 0 ? target : pos;

        occupied.push({
          x: finalPos.x,
          y: finalPos.y,
          w: item.props.courtyard.width,
          h: item.props.courtyard.height,
        });

        return {
          ...item,
          transform: {
            ...item.transform,
            x: finalPos.x,
            y: finalPos.y,
            rotation: comp.transform.rotation,
          },
        };
      });

      return {
        ...synced,
        sheets: synced.sheets.map((s) =>
          s.kind === 'pcb' ? { ...s, items: nextItems } : s
        ),
      };
    },
  };
}
