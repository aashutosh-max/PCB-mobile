import { runMstAStarAutorouter } from './autorouter';
import { syncPcbNetsAndFootprints } from './commands';
import {
  distance,
  distanceToSegment,
  getComponentPinsWorld,
  getDefaultSymbolDefs,
  SCHEMATIC_GRID,
} from './geometry';
import { Point, Project, SchComponentItem, SchLabelItem, SchWireItem } from './types';

export function serializeProject(project: Project): string {
  return JSON.stringify(project, null, 2);
}

export function deserializeProject(jsonString: string): Project {
  const parsed = JSON.parse(jsonString);
  if (!parsed || typeof parsed !== 'object') {
    throw new Error('Invalid project file: not a JSON object');
  }
  if (!Array.isArray(parsed.sheets)) {
    throw new Error('Invalid project file: missing sheets array');
  }
  const hasSch = parsed.sheets.some((s: { kind?: string }) => s.kind === 'schematic');
  const hasPcb = parsed.sheets.some((s: { kind?: string }) => s.kind === 'pcb');
  if (!hasSch || !hasPcb) {
    throw new Error('Invalid project file: requires both schematic and pcb sheets');
  }
  const project: Project = {
    id: parsed.id || `proj_${Date.now()}`,
    name: parsed.name || 'Imported PCB Project',
    version: parsed.version || 1,
    updatedAt: parsed.updatedAt || Date.now(),
    rules: {
      minTraceWidth: parsed.rules?.minTraceWidth ?? 0.25,
      minClearance: parsed.rules?.minClearance ?? 0.2,
      minViaDiameter: parsed.rules?.minViaDiameter ?? 0.8,
      minViaDrill: parsed.rules?.minViaDrill ?? 0.4,
      minAnnularRing: parsed.rules?.minAnnularRing ?? 0.15,
    },
    sheets: parsed.sheets,
  };
  return syncPcbNetsAndFootprints(project);
}

interface ExamplePartSpec {
  kind: string;
  refDes: string;
  value: string;
  schX: number;
  schY: number;
  schRot?: 0 | 90 | 180 | 270;
  pcbX: number;
  pcbY: number;
  pcbRot?: 0 | 90 | 180 | 270;
}

interface ExampleNetSpec {
  name: string;
  pins: string[]; // e.g. ['U1.3', 'R1.1']
}

/**
 * Routes clean orthogonal schematic wires on the 1.27mm schematic grid while avoiding foreign pins
 * and component bodies, ensuring every single pin in every example is 100% electrically connected.
 */
function buildCleanSchematicWiresAndLabels(
  projectId: string,
  schComponents: SchComponentItem[],
  nets: ExampleNetSpec[]
): { wires: SchWireItem[]; labels: SchLabelItem[] } {
  const g = SCHEMATIC_GRID;
  const cols = 48;
  const rows = 30;

  interface PinInfo {
    id: string; // RefDes.PinNum
    comp: SchComponentItem;
    world: Point;
    gx: number;
    gy: number;
    net: string;
  }

  const pinNetLookup = new Map<string, string>();
  for (const net of nets) {
    for (const pRef of net.pins) {
      pinNetLookup.set(pRef, net.name);
    }
  }

  const allPins: PinInfo[] = [];
  for (const comp of schComponents) {
    for (const pw of getComponentPinsWorld(comp)) {
      const id = `${comp.props.refDes}.${pw.pin.number}`;
      const gx = Math.round(pw.world.x / g);
      const gy = Math.round(pw.world.y / g);
      allPins.push({
        id,
        comp,
        world: pw.world,
        gx,
        gy,
        net: pinNetLookup.get(id) || '',
      });
    }
  }

  const wires: SchWireItem[] = [];
  const labels: SchLabelItem[] = [];
  let wireCounter = 1;
  let labelCounter = 1;

  // Track used schematic grid cells by net name so wires of different nets never touch or overlap
  const cellOwnerNet = new Map<number, string>();
  for (const p of allPins) {
    cellOwnerNet.set(p.gy * cols + p.gx, p.net || `__PIN_${p.id}`);
  }

  // Block interior of IC and component symbol bodies so wires route cleanly around symbols
  const bodyBlocked = new Set<number>();
  for (const comp of schComponents) {
    if (comp.props.kind === 'VCC' || comp.props.kind === 'GND') continue;
    const cx = Math.round(comp.transform.x / g);
    const cy = Math.round(comp.transform.y / g);
    const isIc = comp.props.pins.length >= 4;
    const rx = isIc ? 3 : comp.transform.rotation === 90 || comp.transform.rotation === 270 ? 1 : 2;
    const ry = isIc ? 2 : comp.transform.rotation === 90 || comp.transform.rotation === 270 ? 2 : 1;
    for (let dy = -ry; dy <= ry; dy++) {
      for (let dx = -rx; dx <= rx; dx++) {
        const gx = cx + dx;
        const gy = cy + dy;
        if (gx >= 0 && gx < cols && gy >= 0 && gy < rows) {
          bodyBlocked.add(gy * cols + gx);
        }
      }
    }
  }
  // Ensure actual pin locations are not bodyBlocked
  for (const p of allPins) {
    bodyBlocked.delete(p.gy * cols + p.gx);
  }

  const routeGridManhattan = (
    start: PinInfo,
    goal: PinInfo,
    netName: string
  ): Point[] | null => {
    const startIdx = start.gy * cols + start.gx;
    const goalIdx = goal.gy * cols + goal.gx;
    if (startIdx === goalIdx) return [start.world, goal.world];

    const total = cols * rows;
    const gScore = new Float32Array(total).fill(Infinity);
    const cameFrom = new Int32Array(total).fill(-1);
    const cameDir = new Int8Array(total).fill(-1);
    const closed = new Uint8Array(total);

    gScore[startIdx] = 0;
    const open: number[] = [startIdx];
    const dirs = [
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1],
    ];

    while (open.length > 0) {
      let bestPos = 0;
      let bestF = Infinity;
      for (let i = 0; i < open.length; i++) {
        const idx = open[i];
        const gx = idx % cols;
        const gy = (idx / cols) | 0;
        const h = Math.abs(goal.gx - gx) + Math.abs(goal.gy - gy);
        const f = gScore[idx] + h;
        if (f < bestF) {
          bestF = f;
          bestPos = i;
        }
      }

      const curr = open.splice(bestPos, 1)[0];
      if (curr === goalIdx) {
        const gridPts: Point[] = [];
        let c = curr;
        while (c !== -1) {
          const gx = c % cols;
          const gy = (c / cols) | 0;
          gridPts.push({ x: Number((gx * g).toFixed(4)), y: Number((gy * g).toFixed(4)) });
          c = cameFrom[c];
        }
        gridPts.reverse();
        gridPts[0] = { ...start.world };
        gridPts[gridPts.length - 1] = { ...goal.world };

        // Simplify collinear grid points
        const simplified: Point[] = [gridPts[0]];
        for (let i = 1; i < gridPts.length - 1; i++) {
          const prev = simplified[simplified.length - 1];
          const mid = gridPts[i];
          const nxt = gridPts[i + 1];
          const collinearX = Math.abs(prev.x - mid.x) < 1e-3 && Math.abs(mid.x - nxt.x) < 1e-3;
          const collinearY = Math.abs(prev.y - mid.y) < 1e-3 && Math.abs(mid.y - nxt.y) < 1e-3;
          if (collinearX || collinearY) continue;
          simplified.push(mid);
        }
        simplified.push(gridPts[gridPts.length - 1]);

        // Verify no foreign pin, foreign wire, or foreign label is within 0.45mm of any segment
        for (let i = 0; i < simplified.length - 1; i++) {
          const segA = simplified[i];
          const segB = simplified[i + 1];
          for (const otherPin of allPins) {
            if (otherPin.net === netName) continue;
            if (distanceToSegment(otherPin.world, segA, segB).dist <= 0.45) {
              return null;
            }
          }
          for (const existingW of wires) {
            const wPts = existingW.props.points;
            for (const wp of wPts) {
              if (
                distance(wp, start.world) > 0.45 &&
                distance(wp, goal.world) > 0.45 &&
                distanceToSegment(wp, segA, segB).dist <= 0.45
              ) {
                return null;
              }
            }
            for (let j = 0; j < wPts.length - 1; j++) {
              if (
                (distance(segA, start.world) > 0.45 &&
                  distance(segA, goal.world) > 0.45 &&
                  distanceToSegment(segA, wPts[j], wPts[j + 1]).dist <= 0.45) ||
                (distance(segB, start.world) > 0.45 &&
                  distance(segB, goal.world) > 0.45 &&
                  distanceToSegment(segB, wPts[j], wPts[j + 1]).dist <= 0.45)
              ) {
                return null;
              }
            }
          }
          for (const existingLbl of labels) {
            if (existingLbl.props.text === netName) continue;
            const lPt = { x: existingLbl.transform.x, y: existingLbl.transform.y };
            if (distanceToSegment(lPt, segA, segB).dist <= 0.45) {
              return null;
            }
          }
        }

        // Claim grid cells for this net
        let mark = curr;
        while (mark !== -1) {
          cellOwnerNet.set(mark, netName);
          mark = cameFrom[mark];
        }
        return simplified;
      }

      closed[curr] = 1;
      const gx = curr % cols;
      const gy = (curr / cols) | 0;
      const prevD = cameDir[curr];

      for (let d = 0; d < 4; d++) {
        const nx = gx + dirs[d][0];
        const ny = gy + dirs[d][1];
        if (nx < 1 || nx >= cols - 1 || ny < 1 || ny >= rows - 1) continue;
        const nIdx = ny * cols + nx;
        if (closed[nIdx]) continue;
        if (nIdx !== goalIdx && bodyBlocked.has(nIdx)) continue;

        const owner = cellOwnerNet.get(nIdx);
        if (owner && owner !== netName) continue;

        const bendCost = prevD !== -1 && prevD !== d ? 0.4 : 0;
        const tentative = gScore[curr] + 1 + bendCost;
        if (tentative < gScore[nIdx]) {
          gScore[nIdx] = tentative;
          cameFrom[nIdx] = curr;
          cameDir[nIdx] = d;
          if (!open.includes(nIdx)) open.push(nIdx);
        }
      }
    }

    return null;
  };

  const makePinStubAndLabel = (pin: PinInfo, netName: string) => {
    const cx = pin.comp.transform.x;
    const cy = pin.comp.transform.y;
    const dx = pin.world.x - cx;
    const dy = pin.world.y - cy;
    let stepX = 0;
    let stepY = 0;
    if (Math.abs(dx) >= Math.abs(dy)) {
      stepX = dx >= 0 ? g : -g;
    } else {
      stepY = dy >= 0 ? g : -g;
    }
    const stubEnd: Point = {
      x: Number((pin.world.x + stepX).toFixed(4)),
      y: Number((pin.world.y + stepY).toFixed(4)),
    };
    const stubCell = Math.round(stubEnd.y / g) * cols + Math.round(stubEnd.x / g);
    const cellOwner = cellOwnerNet.get(stubCell);
    const hitsForeignPin = allPins.some(
      (op) => op.net !== netName && distance(op.world, stubEnd) <= 0.5
    );
    const hitsForeignWire = wires.some((w) =>
      w.props.points.some((wp, idx, arr) => {
        if (distance(wp, pin.world) <= 0.1) return false;
        if (distance(wp, stubEnd) <= 0.45) return true;
        if (idx < arr.length - 1) {
          return distanceToSegment(stubEnd, wp, arr[idx + 1]).dist <= 0.45;
        }
        return false;
      })
    );
    if (!hitsForeignPin && !hitsForeignWire && (!cellOwner || cellOwner === netName)) {
      cellOwnerNet.set(stubCell, netName);
      wires.push({
        id: `sch_w_${projectId}_${wireCounter++}`,
        type: 'sch_wire',
        transform: { x: pin.world.x, y: pin.world.y, rotation: 0, layer: 'SCH' },
        props: { points: [pin.world, stubEnd] },
      });
      labels.push({
        id: `sch_lbl_${projectId}_${labelCounter++}`,
        type: 'sch_label',
        transform: { x: stubEnd.x, y: stubEnd.y, rotation: 0, layer: 'SCH' },
        props: { text: netName },
      });
    } else {
      labels.push({
        id: `sch_lbl_${projectId}_${labelCounter++}`,
        type: 'sch_label',
        transform: { x: pin.world.x, y: pin.world.y, rotation: 0, layer: 'SCH' },
        props: { text: netName },
      });
    }
  };

  for (const net of nets) {
    const netPins = net.pins
      .map((ref) => allPins.find((p) => p.id === ref))
      .filter((p): p is PinInfo => Boolean(p));
    if (netPins.length === 0) continue;

    // Sort pins left-to-right, top-to-bottom for clean schematic chaining
    const sorted = [...netPins].sort((a, b) => a.world.x - b.world.x || a.world.y - b.world.y);

    let labeledAny = false;
    for (let i = 0; i < sorted.length - 1; i++) {
      const pA = sorted[i];
      const pB = sorted[i + 1];
      const manhattanDist = Math.abs(pB.gx - pA.gx) + Math.abs(pB.gy - pA.gy);
      const routedPts =
        manhattanDist <= 22 ? routeGridManhattan(pA, pB, net.name) : null;

      if (routedPts && routedPts.length >= 2) {
        wires.push({
          id: `sch_w_${projectId}_${wireCounter++}`,
          type: 'sch_wire',
          transform: { x: routedPts[0].x, y: routedPts[0].y, rotation: 0, layer: 'SCH' },
          props: { points: routedPts },
        });
        if (!labeledAny && net.name !== 'GND' && !net.name.startsWith('+')) {
          const midPt = routedPts[Math.floor(routedPts.length / 2)];
          labels.push({
            id: `sch_lbl_${projectId}_${labelCounter++}`,
            type: 'sch_label',
            transform: { x: midPt.x, y: midPt.y, rotation: 0, layer: 'SCH' },
            props: { text: net.name },
          });
          labeledAny = true;
        }
      } else {
        // Connect via clean KiCad net label stubs so wires never cross foreign pins
        makePinStubAndLabel(pA, net.name);
        makePinStubAndLabel(pB, net.name);
        labeledAny = true;
      }
    }
  }

  return { wires, labels };
}

function makeCompleteExampleProject(
  id: string,
  name: string,
  boardW: number,
  boardH: number,
  cornerRadius: number,
  parts: ExamplePartSpec[],
  nets: ExampleNetSpec[],
  outlinePoints?: { x: number; y: number }[]
): Project {
  const g = SCHEMATIC_GRID;
  const schComponents: SchComponentItem[] = [];
  const pcbItems: Project['sheets'][number]['items'] = [
    {
      id: `pcb_outline_${id}`,
      type: 'pcb_outline',
      transform: { x: 4, y: 4, rotation: 0, layer: 'Edge.Cuts' },
      props: {
        width: boardW,
        height: boardH,
        cornerRadius,
        ...(outlinePoints ? { points: outlinePoints } : {}),
      },
    },
  ];

  for (const p of parts) {
    const def = getDefaultSymbolDefs(p.kind);
    schComponents.push({
      id: `sch_${id}_${p.refDes}`,
      type: 'sch_component',
      transform: {
        x: p.schX * g,
        y: p.schY * g,
        rotation: p.schRot ?? 0,
        layer: 'SCH',
      },
      props: {
        kind: p.kind,
        refDes: p.refDes,
        value: p.value,
        footprint: def.footprint,
        pins: def.pins,
        symbolStyle: def.symbolStyle,
      },
    });

    if (p.kind !== 'VCC' && p.kind !== 'GND' && def.pads.length > 0) {
      pcbItems.push({
        id: `fp_${p.refDes}`,
        type: 'pcb_footprint',
        transform: {
          x: p.pcbX,
          y: p.pcbY,
          rotation: p.pcbRot ?? 0,
          layer: 'F.Cu',
        },
        props: {
          refDes: p.refDes,
          value: p.value,
          footprintName: def.footprint,
          courtyard: def.courtyard,
          pads: def.pads,
        },
      });
    }
  }

  const { wires, labels } = buildCleanSchematicWiresAndLabels(id, schComponents, nets);

  const synced = syncPcbNetsAndFootprints({
    id,
    name,
    version: 1,
    updatedAt: Date.now(),
    rules: {
      minTraceWidth: 0.25,
      minClearance: 0.2,
      minViaDiameter: 0.8,
      minViaDrill: 0.4,
      minAnnularRing: 0.15,
    },
    sheets: [
      {
        id: 'sheet_sch',
        name: 'Main Schematic',
        kind: 'schematic',
        items: [...schComponents, ...wires, ...labels],
      },
      {
        id: 'sheet_pcb',
        name: '2-Layer Board',
        kind: 'pcb',
        items: pcbItems,
      },
    ],
  });

  // Pre-route the PCB using our obstacle-avoiding MST + A* router so copper traces avoid touching non-connected pads/traces
  const routed = runMstAStarAutorouter(synced, {
    framework: '@tscircuit/routing',
    gridStep: 0.25,
    layerMode: 'multi',
    diagonal45: true,
    traceWidth: 0.35,
  });

  return routed.project;
}

/**
 * 1. Starter LED indicator circuit project with 100% connected schematic and obstacle-free routed PCB.
 */
export function createStarterProject(): Project {
  return makeCompleteExampleProject(
    'proj_starter_led',
    'Pocket LED Module',
    34,
    24,
    3.5,
    [
      { kind: 'CONN2', refDes: 'J1', value: '5V_IN', schX: 8, schY: 12, pcbX: 9, pcbY: 16 },
      { kind: 'C', refDes: 'C1', value: '100nF', schX: 14, schY: 14, schRot: 90, pcbX: 16, pcbY: 16, pcbRot: 90 },
      { kind: 'R', refDes: 'R1', value: '330R', schX: 21, schY: 11, pcbX: 23, pcbY: 12 },
      { kind: 'LED', refDes: 'D1', value: 'GREEN', schX: 30, schY: 11, pcbX: 31, pcbY: 16, pcbRot: 90 },
      { kind: 'VCC', refDes: 'PWR1', value: '+5V', schX: 14, schY: 7, pcbX: 0, pcbY: 0 },
      { kind: 'GND', refDes: 'GND1', value: 'GND', schX: 14, schY: 20, pcbX: 0, pcbY: 0 },
    ],
    [
      { name: '+5V', pins: ['PWR1.1', 'J1.1', 'C1.1', 'R1.1'] },
      { name: 'LED_DRIVE', pins: ['R1.2', 'D1.1'] },
      { name: 'GND', pins: ['GND1.1', 'J1.2', 'C1.2', 'D1.2'] },
    ]
  );
}

/**
 * 2. NE555 Astable LED Blinker circuit with all 8 pins of the NE555 timer properly connected and routed.
 */
export function createBlinkerProject(): Project {
  return makeCompleteExampleProject(
    'proj_starter_555',
    'NE555 Astable Blinker',
    42,
    28,
    3.5,
    [
      { kind: 'NE555', refDes: 'U1', value: 'NE555', schX: 20, schY: 13, pcbX: 22, pcbY: 18 },
      { kind: 'R', refDes: 'R1', value: '10k', schX: 29, schY: 10, pcbX: 34, pcbY: 11 },
      { kind: 'R', refDes: 'R2', value: '47k', schX: 29, schY: 14, pcbX: 34, pcbY: 17 },
      { kind: 'C', refDes: 'C1', value: '10uF', schX: 29, schY: 18, pcbX: 34, pcbY: 23 },
      { kind: 'C_0603_SMD', refDes: 'C2', value: '10nF', schX: 20, schY: 19, pcbX: 22, pcbY: 27 },
      { kind: 'LED', refDes: 'D1', value: 'AMBER', schX: 10, schY: 14, pcbX: 11, pcbY: 18, pcbRot: 90 },
      { kind: 'VCC', refDes: 'PWR1', value: '+5V', schX: 20, schY: 7, pcbX: 0, pcbY: 0 },
      { kind: 'GND', refDes: 'GND1', value: 'GND', schX: 10, schY: 20, pcbX: 0, pcbY: 0 },
    ],
    [
      { name: '+5V', pins: ['PWR1.1', 'U1.8', 'U1.4', 'R1.1'] },
      { name: 'DIS_CHRG', pins: ['R1.2', 'U1.7', 'R2.1'] },
      { name: 'TIMING_RC', pins: ['R2.2', 'U1.6', 'U1.2', 'C1.1'] },
      { name: 'CTRL_CV', pins: ['U1.5', 'C2.1'] },
      { name: 'TIMER_OUT', pins: ['U1.3', 'D1.1'] },
      { name: 'GND', pins: ['GND1.1', 'U1.1', 'D1.2', 'C1.2', 'C2.2'] },
    ]
  );
}

export interface ExampleTemplateItem {
  id: string;
  name: string;
  category: string;
  description: string;
  project: Project;
}

/**
 * Returns 10 complete, ready-to-open example projects with full Schematics + 2-Layer PCBs.
 * Every pin of every component in all 10 examples is connected and routed with obstacle-avoiding traces.
 */
export function createExampleProjects(): ExampleTemplateItem[] {
  return [
    {
      id: 'ex_01_led_indicator',
      name: '1. Pocket LED Indicator',
      category: 'Beginner · Basics',
      description: '5V Header · 330R Resistor · Green LED · 100nF Decoupling Cap',
      project: createStarterProject(),
    },
    {
      id: 'ex_02_ne555_blinker',
      name: '2. NE555 Astable Blinker',
      category: 'Timers & Oscillators',
      description: 'DIP-8 NE555 Timer IC · Dual RC Timing Network · Amber Status LED',
      project: createBlinkerProject(),
    },
    {
      id: 'ex_03_ams1117_ldo',
      name: '3. AMS1117 3.3V Power Supply',
      category: 'Power Management',
      description: 'DC Input · AMS1117-3.3 SOT-223 LDO · Bulk & Ceramic Caps · Power LED',
      project: makeCompleteExampleProject(
        'proj_ex_ams1117',
        'AMS1117 3.3V Regulated Supply',
        40,
        26,
        3.0,
        [
          { kind: 'CONN2', refDes: 'J1', value: 'VIN_5V', schX: 8, schY: 12, pcbX: 9, pcbY: 17 },
          { kind: 'CP_RADIAL_5MM', refDes: 'C1', value: '10uF', schX: 13, schY: 14, schRot: 90, pcbX: 15, pcbY: 17, pcbRot: 90 },
          { kind: 'U_AMS1117_3V3', refDes: 'U1', value: 'AMS1117-3.3', schX: 21, schY: 12, pcbX: 23, pcbY: 17 },
          { kind: 'C', refDes: 'C2', value: '100nF', schX: 29, schY: 14, schRot: 90, pcbX: 31, pcbY: 12 },
          { kind: 'R', refDes: 'R1', value: '1k', schX: 35, schY: 11, pcbX: 31, pcbY: 20 },
          { kind: 'LED_0805_SMD', refDes: 'D1', value: '3V3_OK', schX: 35, schY: 16, pcbX: 38, pcbY: 20, pcbRot: 90 },
          { kind: 'VCC', refDes: 'PWR1', value: '+3V3', schX: 29, schY: 7, pcbX: 0, pcbY: 0 },
          { kind: 'GND', refDes: 'GND1', value: 'GND', schX: 21, schY: 20, pcbX: 0, pcbY: 0 },
        ],
        [
          { name: 'VIN_5V', pins: ['J1.1', 'C1.1', 'U1.3'] },
          { name: '+3V3', pins: ['PWR1.1', 'U1.2', 'U1.4', 'C2.1', 'R1.1'] },
          { name: 'LED_3V3', pins: ['R1.2', 'D1.1'] },
          { name: 'GND', pins: ['GND1.1', 'J1.2', 'C1.2', 'U1.1', 'C2.2', 'D1.2'] },
        ]
      ),
    },
    {
      id: 'ex_04_esp32_weather',
      name: '4. ESP32-C3 Wi-Fi Weather Node',
      category: 'IoT & Wireless',
      description: 'ESP32-C3-MINI Module · Bosch BME280 I2C Sensor · Pull-up Resistors · Reset Switch',
      project: makeCompleteExampleProject(
        'proj_ex_esp32_bme280',
        'ESP32-C3 Weather Sensor Node',
        46,
        30,
        4.0,
        [
          { kind: 'ESP32_WROOM', refDes: 'U1', value: 'ESP32-C3', schX: 16, schY: 13, pcbX: 19, pcbY: 19 },
          { kind: 'U_BME280_SENS', refDes: 'U2', value: 'BME280', schX: 31, schY: 13, pcbX: 36, pcbY: 19 },
          { kind: 'R_0603_SMD', refDes: 'R1', value: '4.7k', schX: 24, schY: 8, pcbX: 28, pcbY: 11 },
          { kind: 'R_0603_SMD', refDes: 'R2', value: '4.7k', schX: 24, schY: 18, pcbX: 28, pcbY: 27 },
          { kind: 'C', refDes: 'C1', value: '100nF', schX: 8, schY: 11, pcbX: 9, pcbY: 12 },
          { kind: 'SW_TACT_6MM', refDes: 'SW1', value: 'RST', schX: 8, schY: 16, pcbX: 9, pcbY: 24 },
          { kind: 'LED_0603_SMD', refDes: 'D1', value: 'WIFI_OK', schX: 24, schY: 22, pcbX: 36, pcbY: 11 },
          { kind: 'VCC', refDes: 'PWR1', value: '+3V3', schX: 16, schY: 6, pcbX: 0, pcbY: 0 },
          { kind: 'GND', refDes: 'GND1', value: 'GND', schX: 16, schY: 22, pcbX: 0, pcbY: 0 },
        ],
        [
          { name: '+3V3', pins: ['PWR1.1', 'U1.2', 'U2.1', 'R1.1', 'R2.1', 'C1.1'] },
          { name: 'I2C_SDA', pins: ['U1.5', 'R1.2', 'U2.4'] },
          { name: 'I2C_SCL', pins: ['U1.6', 'R2.2', 'U2.3'] },
          { name: 'CHIP_EN', pins: ['SW1.1', 'U1.3'] },
          { name: 'WIFI_LED', pins: ['U1.4', 'D1.1'] },
          { name: 'GND', pins: ['GND1.1', 'U1.1', 'U2.2', 'C1.2', 'SW1.2', 'D1.2'] },
        ]
      ),
    },
    {
      id: 'ex_05_lm358_preamp',
      name: '5. LM358 Audio Mic Preamplifier',
      category: 'Audio & Analog',
      description: 'Electret Condenser Mic · LM358 Dual Op-Amp · Gain Trimmer · 3.5mm Audio Jack',
      project: makeCompleteExampleProject(
        'proj_ex_lm358_preamp',
        'LM358 Electret Mic Preamp',
        44,
        28,
        3.5,
        [
          { kind: 'MK_ELECTRET_9MM', refDes: 'MK1', value: 'ELECTRET', schX: 8, schY: 15, pcbX: 10, pcbY: 18 },
          { kind: 'R', refDes: 'R1', value: '10k_BIAS', schX: 14, schY: 9, pcbX: 16, pcbY: 11 },
          { kind: 'C', refDes: 'C1', value: '1uF', schX: 15, schY: 15, pcbX: 16, pcbY: 23 },
          { kind: 'LM358_DUAL_OPAMP', refDes: 'U1', value: 'LM358', schX: 23, schY: 14, pcbX: 24, pcbY: 18 },
          { kind: 'RV_TRIM_3296W', refDes: 'RV1', value: '100k_GAIN', schX: 23, schY: 8, pcbX: 24, pcbY: 9 },
          { kind: 'CP_RADIAL_5MM', refDes: 'C2', value: '10uF', schX: 31, schY: 14, pcbX: 33, pcbY: 12 },
          { kind: 'J_AUDIO_35MM', refDes: 'J1', value: 'LINE_OUT', schX: 39, schY: 14, pcbX: 39, pcbY: 20 },
          { kind: 'VCC', refDes: 'PWR1', value: '+5V', schX: 14, schY: 5, pcbX: 0, pcbY: 0 },
          { kind: 'GND', refDes: 'GND1', value: 'GND', schX: 23, schY: 21, pcbX: 0, pcbY: 0 },
        ],
        [
          { name: '+5V', pins: ['PWR1.1', 'R1.1', 'U1.8'] },
          { name: 'MIC_RAW', pins: ['MK1.1', 'R1.2', 'C1.1'] },
          { name: 'OP_IN_POS', pins: ['C1.2', 'U1.3'] },
          { name: 'OP_IN_NEG', pins: ['U1.2', 'RV1.1'] },
          { name: 'AMP_OUT', pins: ['U1.1', 'RV1.2', 'C2.1'] },
          { name: 'LINE_SIG', pins: ['C2.2', 'J1.2', 'J1.3'] },
          { name: 'GND', pins: ['GND1.1', 'MK1.2', 'U1.4', 'J1.1', 'J1.4'] },
        ]
      ),
    },
    {
      id: 'ex_06_atmega328_core',
      name: '6. ATmega328P Minimal MCU Core',
      category: 'Microcontrollers',
      description: 'ATmega328P AVR MCU · 16MHz HC-49 Crystal · 22pF Load Caps · ICSP Header',
      project: makeCompleteExampleProject(
        'proj_ex_atmega328',
        'ATmega328P Core Breakout',
        44,
        28,
        2.5,
        [
          { kind: 'U_ATMEGA328P', refDes: 'U1', value: 'ATmega328P', schX: 21, schY: 13, pcbX: 23, pcbY: 18 },
          { kind: 'XTAL_HC49', refDes: 'Y1', value: '16MHz', schX: 10, schY: 14, pcbX: 11, pcbY: 18, pcbRot: 90 },
          { kind: 'C_0603_SMD', refDes: 'C1', value: '22pF', schX: 10, schY: 10, pcbX: 11, pcbY: 11 },
          { kind: 'C_0603_SMD', refDes: 'C2', value: '22pF', schX: 10, schY: 18, pcbX: 11, pcbY: 25 },
          { kind: 'R', refDes: 'R1', value: '10k_RST', schX: 21, schY: 7, pcbX: 23, pcbY: 9 },
          { kind: 'CONN_1X04', refDes: 'J1', value: 'UART_ISP', schX: 34, schY: 13, pcbX: 38, pcbY: 18 },
          { kind: 'LED_0805_SMD', refDes: 'D1', value: 'SCK_LED', schX: 31, schY: 7, pcbX: 32, pcbY: 10 },
          { kind: 'VCC', refDes: 'PWR1', value: '+5V', schX: 14, schY: 6, pcbX: 0, pcbY: 0 },
          { kind: 'GND', refDes: 'GND1', value: 'GND', schX: 21, schY: 21, pcbX: 0, pcbY: 0 },
        ],
        [
          { name: '+5V', pins: ['PWR1.1', 'R1.1', 'U1.8', 'J1.1'] },
          { name: 'MCU_RST', pins: ['R1.2', 'U1.1'] },
          { name: 'XTAL1', pins: ['C1.1', 'Y1.1', 'U1.2'] },
          { name: 'XTAL2', pins: ['C2.1', 'Y1.2', 'U1.3'] },
          { name: 'SPI_SCK', pins: ['U1.7', 'D1.1'] },
          { name: 'SPI_MISO', pins: ['U1.6', 'J1.3'] },
          { name: 'SPI_MOSI', pins: ['U1.5', 'J1.2'] },
          { name: 'GND', pins: ['GND1.1', 'C1.2', 'C2.2', 'U1.4', 'D1.2', 'J1.4'] },
        ]
      ),
    },
    {
      id: 'ex_07_ws2812b_pixel_bar',
      name: '7. WS2812B RGB NeoPixel Stick',
      category: 'LEDs & Lighting',
      description: '3x Addressable WS2812B 5050 RGB LEDs · 100nF Decoupling Caps · 3-Pin DIN Header',
      project: makeCompleteExampleProject(
        'proj_ex_ws2812b',
        'WS2812B RGB Pixel Stick',
        48,
        22,
        5.0,
        [
          { kind: 'CONN_1X03', refDes: 'J1', value: 'PIXEL_IN', schX: 7, schY: 12, pcbX: 9, pcbY: 15 },
          { kind: 'R_0603_SMD', refDes: 'R1', value: '330R', schX: 13, schY: 12, pcbX: 15, pcbY: 15 },
          { kind: 'LED_WS2812B', refDes: 'U1', value: 'WS2812B_1', schX: 21, schY: 12, pcbX: 22, pcbY: 16 },
          { kind: 'LED_WS2812B', refDes: 'U2', value: 'WS2812B_2', schX: 30, schY: 12, pcbX: 32, pcbY: 16 },
          { kind: 'LED_WS2812B', refDes: 'U3', value: 'WS2812B_3', schX: 39, schY: 12, pcbX: 42, pcbY: 16 },
          { kind: 'C_0603_SMD', refDes: 'C1', value: '100nF', schX: 21, schY: 18, pcbX: 22, pcbY: 9 },
          { kind: 'C_0603_SMD', refDes: 'C2', value: '100nF', schX: 30, schY: 18, pcbX: 32, pcbY: 9 },
          { kind: 'VCC', refDes: 'PWR1', value: '+5V', schX: 21, schY: 6, pcbX: 0, pcbY: 0 },
          { kind: 'GND', refDes: 'GND1', value: 'GND', schX: 21, schY: 22, pcbX: 0, pcbY: 0 },
        ],
        [
          { name: '+5V', pins: ['PWR1.1', 'J1.1', 'U1.1', 'U2.1', 'U3.1', 'C1.1', 'C2.1'] },
          { name: 'DIN_RAW', pins: ['J1.2', 'R1.1'] },
          { name: 'DIN_1', pins: ['R1.2', 'U1.4'] },
          { name: 'DOUT1', pins: ['U1.2', 'U2.4'] },
          { name: 'DOUT2', pins: ['U2.2', 'U3.4', 'U3.2'] },
          { name: 'GND', pins: ['GND1.1', 'J1.3', 'U1.3', 'U2.3', 'U3.3', 'C1.2', 'C2.2'] },
        ]
      ),
    },
    {
      id: 'ex_08_relay_driver',
      name: '8. 2N2222 NPN Relay Driver',
      category: 'Power & Relays',
      description: '5V SPDT Power Relay · 2N2222 Transistor · 1N4148 Flyback Diode · Screw Terminal',
      project: makeCompleteExampleProject(
        'proj_ex_relay_driver',
        'Isolated 5V Relay Driver',
        42,
        26,
        2.0,
        [
          { kind: 'CONN2', refDes: 'J1', value: 'TRIG_IN', schX: 8, schY: 14, pcbX: 9, pcbY: 17 },
          { kind: 'R', refDes: 'R1', value: '1k', schX: 14, schY: 14, pcbX: 15, pcbY: 17 },
          { kind: 'Q_2N2222_SOT23', refDes: 'Q1', value: '2N2222', schX: 21, schY: 14, pcbX: 21, pcbY: 22 },
          { kind: 'D_1N4148', refDes: 'D1', value: '1N4148', schX: 21, schY: 8, pcbX: 17, pcbY: 9 },
          { kind: 'K_RELAY_SPDT', refDes: 'K1', value: 'SRD-05VDC', schX: 30, schY: 12, pcbX: 30, pcbY: 17 },
          { kind: 'J_SCREW_2P', refDes: 'J2', value: 'AC_LOAD', schX: 38, schY: 12, pcbX: 40, pcbY: 17, pcbRot: 90 },
          { kind: 'VCC', refDes: 'PWR1', value: '+5V', schX: 30, schY: 6, pcbX: 0, pcbY: 0 },
          { kind: 'GND', refDes: 'GND1', value: 'GND', schX: 21, schY: 20, pcbX: 0, pcbY: 0 },
        ],
        [
          { name: '+5V', pins: ['PWR1.1', 'D1.2', 'K1.1'] },
          { name: 'TRIG_SIG', pins: ['J1.1', 'R1.1'] },
          { name: 'BASE_DRV', pins: ['R1.2', 'Q1.1'] },
          { name: 'COIL_SW', pins: ['Q1.2', 'D1.1', 'K1.2'] },
          { name: 'LOAD_NO', pins: ['K1.4', 'J2.1'] },
          { name: 'LOAD_COM', pins: ['K1.3', 'J2.2'] },
          { name: 'GND', pins: ['GND1.1', 'J1.2', 'Q1.3'] },
        ]
      ),
    },
    {
      id: 'ex_09_tp4056_charger',
      name: '9. USB-C TP4056 LiPo Charger',
      category: 'Battery & USB-C',
      description: 'USB-C Receptacle · TP4056 1A Charger IC · 1.2k Prog Resistor · JST-PH Battery Out',
      project: makeCompleteExampleProject(
        'proj_ex_tp4056',
        'USB-C TP4056 LiPo Charger',
        40,
        26,
        3.5,
        [
          { kind: 'J_USB_C_PWR', refDes: 'J1', value: 'USB-C', schX: 9, schY: 12, pcbX: 10, pcbY: 17 },
          { kind: 'FUSE_PTC_1206', refDes: 'F1', value: '1A_PTC', schX: 16, schY: 9, pcbX: 17, pcbY: 11 },
          { kind: 'U_TP4056_CHARGER', refDes: 'U1', value: 'TP4056', schX: 24, schY: 13, pcbX: 24, pcbY: 17 },
          { kind: 'R_0603_SMD', refDes: 'R1', value: '1.2k_PROG', schX: 16, schY: 17, pcbX: 17, pcbY: 23 },
          { kind: 'LED_0603_SMD', refDes: 'D1', value: 'CHRG_RED', schX: 32, schY: 9, pcbX: 32, pcbY: 11 },
          { kind: 'C_1206_SMD', refDes: 'C1', value: '10uF', schX: 32, schY: 17, pcbX: 32, pcbY: 23 },
          { kind: 'J_JST_PH_2P', refDes: 'J2', value: 'LIPO_3V7', schX: 39, schY: 13, pcbX: 38, pcbY: 17, pcbRot: 90 },
          { kind: 'VCC', refDes: 'PWR1', value: 'VBUS_5V', schX: 24, schY: 6, pcbX: 0, pcbY: 0 },
          { kind: 'GND', refDes: 'GND1', value: 'GND', schX: 24, schY: 21, pcbX: 0, pcbY: 0 },
        ],
        [
          { name: 'VBUS_RAW', pins: ['J1.1', 'F1.1'] },
          { name: 'VBUS_5V', pins: ['PWR1.1', 'F1.2', 'U1.4', 'U1.8', 'D1.1'] },
          { name: 'PROG_SET', pins: ['R1.1', 'U1.2'] },
          { name: 'CHRG_STAT', pins: ['U1.7', 'U1.6', 'D1.2'] },
          { name: 'VBAT_4V2', pins: ['U1.5', 'C1.1', 'J2.1'] },
          { name: 'GND', pins: ['GND1.1', 'J1.2', 'J1.3', 'J1.4', 'R1.2', 'U1.1', 'U1.3', 'C1.2', 'J2.2'] },
        ]
      ),
    },
    {
      id: 'ex_10_oled_macro_pad',
      name: '10. SSD1306 OLED & Cherry MX Pad',
      category: 'HID & Displays',
      description: '0.96" I2C OLED Display · 2x Cherry MX Mechanical Switches · Piezo Buzzer',
      project: makeCompleteExampleProject(
        'proj_ex_oled_macropad',
        'OLED & Cherry MX Macro Pad',
        46,
        32,
        3.0,
        [
          { kind: 'OLED_SSD1306', refDes: 'DS1', value: 'SSD1306_OLED', schX: 12, schY: 12, pcbX: 15, pcbY: 12 },
          { kind: 'SW_CHERRY_MX', refDes: 'SW1', value: 'KEY_1', schX: 24, schY: 10, pcbX: 16, pcbY: 26 },
          { kind: 'SW_CHERRY_MX', refDes: 'SW2', value: 'KEY_2', schX: 24, schY: 16, pcbX: 33, pcbY: 26 },
          { kind: 'D_1N4148', refDes: 'D1', value: '1N4148', schX: 33, schY: 10, pcbX: 25, pcbY: 15 },
          { kind: 'BZ_PIEZO_12MM', refDes: 'BZ1', value: 'CLICK_BZ', schX: 39, schY: 14, pcbX: 35, pcbY: 12 },
          { kind: 'VCC', refDes: 'PWR1', value: '+3V3', schX: 12, schY: 6, pcbX: 0, pcbY: 0 },
          { kind: 'GND', refDes: 'GND1', value: 'GND', schX: 12, schY: 20, pcbX: 0, pcbY: 0 },
        ],
        [
          { name: '+3V3', pins: ['PWR1.1', 'DS1.2'] },
          { name: 'KEY_ROW1', pins: ['DS1.4', 'SW1.1'] },
          { name: 'KEY_ROW2', pins: ['DS1.3', 'SW2.1'] },
          { name: 'KEY_COL', pins: ['SW1.2', 'SW2.2', 'D1.1'] },
          { name: 'BZ_DRV', pins: ['D1.2', 'BZ1.1'] },
          { name: 'GND', pins: ['GND1.1', 'DS1.1', 'BZ1.2'] },
        ]
      ),
    },
  ];
}
