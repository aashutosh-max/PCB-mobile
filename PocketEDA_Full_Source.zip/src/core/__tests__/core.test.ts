import { describe, expect, it } from 'vitest';
import {
  createAddItemCommand,
  createHistoryState,
  createMoveItemCommand,
  createRotateItemCommand,
  executeCommand,
  redoCommand,
  undoCommand,
} from '../commands';
import { runDRC } from '../drc';
import {
  generateBomCsv,
  generateCopperGerber,
  generateExcellonDrill,
  generateOutlineGerber,
} from '../gerber';
import {
  getDefaultSymbolDefs,
  hitTestPCB,
  hitTestSchematic,
  PCB_GRID,
  rotatePoint,
  SCHEMATIC_GRID,
  snapPoint,
  transformPoint,
} from '../geometry';
import { computeNetlist, computeRatsnest } from '../netlist';
import {
  createStarterProject,
  deserializeProject,
  serializeProject,
} from '../serialization';
import { PcbTraceItem, SchComponentItem } from '../types';

describe('Core Geometry & Hit-Testing', () => {
  it('snaps coordinates to schematic (1.27mm) and PCB (0.5mm) grids', () => {
    expect(snapPoint({ x: 2.5, y: 3.9 }, SCHEMATIC_GRID)).toEqual({ x: 2.54, y: 3.81 });
    expect(snapPoint({ x: 4.24, y: 7.76 }, PCB_GRID)).toEqual({ x: 4.0, y: 8.0 });
  });

  it('rotates and transforms local offsets accurately in Y-down coordinates', () => {
    expect(rotatePoint({ x: 2, y: 0 }, 90)).toEqual({ x: -0, y: 2 });
    expect(rotatePoint({ x: 2, y: 0 }, 180)).toEqual({ x: -2, y: -0 });
    expect(
      transformPoint(
        { x: 3, y: 0 },
        { x: 10, y: 20, rotation: 90, layer: 'SCH' }
      )
    ).toEqual({ x: 10, y: 23 });
  });

  it('performs touch-slop hit-testing on schematic and PCB items', () => {
    const project = createStarterProject();
    const schItems = project.sheets.find((s) => s.kind === 'schematic')!.items;
    const pcbItems = project.sheets.find((s) => s.kind === 'pcb')!.items;

    // R1 is at (16*1.27, 10*1.27) = (20.32, 12.7)
    const schHit = hitTestSchematic(schItems, { x: 20.5, y: 12.9 }, 12, 22);
    expect(schHit).not.toBeNull();
    expect(schHit?.item.id).toBe('sch_r1');

    // PCB R1 footprint is at (20, 11)
    const pcbHit = hitTestPCB(pcbItems, { x: 20.1, y: 11.2 }, 15, 22);
    expect(pcbHit).not.toBeNull();
    expect(pcbHit?.item.id).toBe('fp_R1');
  });
});

describe('Command Pattern & Undo/Redo Stack (50+ depth)', () => {
  it('maintains immutable state and supports 55+ undo/redo steps', () => {
    const initial = createStarterProject();
    let history = createHistoryState(initial);

    for (let i = 1; i <= 55; i++) {
      history = executeCommand(
        history,
        createMoveItemCommand('pcb', 'fp_R1', { x: 20 + i * 0.5, y: 11 }, `Move ${i}`)
      );
    }

    expect(history.past.length).toBeGreaterThanOrEqual(50);
    const movedFp = history.project.sheets
      .find((s) => s.kind === 'pcb')!
      .items.find((it) => it.id === 'fp_R1')!;
    expect(movedFp.transform.x).toBe(20 + 55 * 0.5);

    // Undo 10 times
    for (let i = 0; i < 10; i++) {
      history = undoCommand(history);
    }
    const afterUndoFp = history.project.sheets
      .find((s) => s.kind === 'pcb')!
      .items.find((it) => it.id === 'fp_R1')!;
    expect(afterUndoFp.transform.x).toBe(20 + 45 * 0.5);

    // Redo 5 times
    for (let i = 0; i < 5; i++) {
      history = redoCommand(history);
    }
    const afterRedoFp = history.project.sheets
      .find((s) => s.kind === 'pcb')!
      .items.find((it) => it.id === 'fp_R1')!;
    expect(afterRedoFp.transform.x).toBe(20 + 50 * 0.5);
  });

  it('rotates items by 90 degrees and syncs new schematic components to PCB footprints', () => {
    let history = createHistoryState(createStarterProject());
    history = executeCommand(history, createRotateItemCommand('pcb', 'fp_R1'));
    const fp = history.project.sheets
      .find((s) => s.kind === 'pcb')!
      .items.find((it) => it.id === 'fp_R1')!;
    expect(fp.transform.rotation).toBe(90);

    const rDef = getDefaultSymbolDefs('R');
    const newR: SchComponentItem = {
      id: 'sch_r2',
      type: 'sch_component',
      transform: { x: 5 * SCHEMATIC_GRID, y: 5 * SCHEMATIC_GRID, rotation: 0, layer: 'SCH' },
      props: {
        kind: 'R',
        refDes: 'R2',
        value: '10k',
        footprint: rDef.footprint,
        pins: rDef.pins,
      },
    };
    history = executeCommand(history, createAddItemCommand('schematic', newR));
    const syncedFp = history.project.sheets
      .find((s) => s.kind === 'pcb')!
      .items.find((it) => it.type === 'pcb_footprint' && it.props.refDes === 'R2');
    expect(syncedFp).toBeDefined();
  });
});

describe('Union-Find Netlist & Live Ratsnest', () => {
  it('extracts nets from pins, wires, power symbols, and labels', () => {
    const project = createStarterProject();
    const netlist = computeNetlist(project);

    expect(netlist.padNetMap['R1:1']).toBe('+5V');
    expect(netlist.padNetMap['C1:1']).toBe('+5V');
    expect(netlist.padNetMap['R1:2']).toBe('LED_DRIVE');
    expect(netlist.padNetMap['D1:1']).toBe('LED_DRIVE');
    expect(netlist.padNetMap['D1:2']).toBe('GND');
    expect(netlist.padNetMap['C1:2']).toBe('GND');
  });

  it('computes ratsnest only for unrouted nets and removes routed connections', () => {
    const project = createStarterProject();
    const ratsnest = computeRatsnest(project);

    // LED_DRIVE is already routed by pcb_trace_starter_1, while +5V and GND are unrouted
    const netsInRatsnest = ratsnest.map((r) => r.net);
    expect(netsInRatsnest).toContain('+5V');
    expect(netsInRatsnest).toContain('GND');
    expect(netsInRatsnest).not.toContain('LED_DRIVE');
  });
});

describe('DRC Engine, Gerber Writer & Serialization', () => {
  it('flags trace width and clearance violations accurately', () => {
    let history = createHistoryState(createStarterProject());
    const thinTrace: PcbTraceItem = {
      id: 'trace_thin',
      type: 'pcb_trace',
      transform: { x: 15, y: 11, rotation: 0, layer: 'F.Cu' },
      props: {
        width: 0.12, // < 0.25mm rule
        net: 'GND',
        points: [
          { x: 21, y: 11.1 }, // Too close to LED_DRIVE trace at (21, 11)
          { x: 25, y: 11.1 },
        ],
      },
    };
    history = executeCommand(history, createAddItemCommand('pcb', thinTrace));
    const violations = runDRC(history.project);

    expect(violations.some((v) => v.type === 'trace_width')).toBe(true);
    expect(violations.some((v) => v.type === 'clearance')).toBe(true);
  });

  it('exports valid RS-274X Gerbers, Excellon drill, BOM CSV, and round-trip JSON', () => {
    const project = createStarterProject();
    const fCu = generateCopperGerber(project, 'F.Cu');
    const outline = generateOutlineGerber(project);
    const drill = generateExcellonDrill(project);
    const bom = generateBomCsv(project);

    expect(fCu).toContain('%FSLAX44Y44*%');
    expect(fCu).toContain('M02*');
    expect(outline).toContain('Edge.Cuts');
    expect(drill).toContain('M48');
    expect(bom).toContain('R1,R,"330R",R_0805,1');

    const json = serializeProject(project);
    const loaded = deserializeProject(json);
    expect(loaded.name).toBe(project.name);
    expect(loaded.sheets.length).toBe(2);
  });
});
