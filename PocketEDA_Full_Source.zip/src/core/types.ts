export type LayerId =
  | 'SCH'
  | 'F.Cu'
  | 'B.Cu'
  | 'F.SilkS'
  | 'B.SilkS'
  | 'F.Mask'
  | 'B.Mask'
  | 'Edge.Cuts';

export type Rotation = 0 | 90 | 180 | 270;

export interface Point {
  x: number;
  y: number;
}

export interface BoundingBox {
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
}

export interface Transform {
  x: number;
  y: number;
  rotation: Rotation;
  layer: LayerId;
}

export type SchematicComponentKind =
  | 'R'
  | 'C'
  | 'LED'
  | 'GND'
  | 'VCC'
  | 'NE555'
  | 'CONN2'
  | string;

export type SymbolVisualStyle =
  | 'R'
  | 'C'
  | 'LED'
  | 'GND'
  | 'VCC'
  | 'CONN2'
  | 'IC'
  | 'OPAMP'
  | 'TRANSISTOR'
  | 'SWITCH'
  | 'CRYSTAL';

export type ItemType =
  | 'sch_component'
  | 'sch_wire'
  | 'sch_label'
  | 'pcb_footprint'
  | 'pcb_trace'
  | 'pcb_via'
  | 'pcb_outline';

export interface PinDef {
  number: string;
  name: string;
  offset: Point;
}

export interface PadDef {
  number: string;
  offset: Point;
  width: number;
  height: number;
  shape: 'circle' | 'rect' | 'oval';
  drill?: number;
  layers: ('F.Cu' | 'B.Cu')[];
  net?: string;
}

export interface LibraryComponentDef {
  kind: string;
  title: string;
  category: string;
  description: string;
  refPrefix: string;
  defaultValue: string;
  footprint: string;
  symbolStyle: SymbolVisualStyle;
  pins: PinDef[];
  courtyard: { width: number; height: number };
  pads: PadDef[];
  pcbAllowed: boolean;
  libraryId: string;
  libraryName: string;
}

export interface LibraryPackage {
  id: string;
  name: string;
  version: string;
  author: string;
  description: string;
  sourceUrl?: string;
  parts: LibraryComponentDef[];
}

export interface SchComponentProps {
  kind: SchematicComponentKind;
  refDes: string;
  value: string;
  footprint: string;
  pins: PinDef[];
  symbolStyle?: SymbolVisualStyle;
}

export interface SchWireProps {
  points: Point[];
  net?: string;
}

export interface SchLabelProps {
  text: string;
}

export interface PcbFootprintProps {
  refDes: string;
  value: string;
  footprintName: string;
  courtyard: { width: number; height: number };
  pads: PadDef[];
}

export interface PcbTraceProps {
  points: Point[];
  width: number;
  net: string;
}

export interface PcbViaProps {
  diameter: number;
  drill: number;
  net: string;
}

export interface PcbOutlineProps {
  width: number;
  height: number;
  cornerRadius?: number;
  points?: Point[];
}

export type ItemPropsMap = {
  sch_component: SchComponentProps;
  sch_wire: SchWireProps;
  sch_label: SchLabelProps;
  pcb_footprint: PcbFootprintProps;
  pcb_trace: PcbTraceProps;
  pcb_via: PcbViaProps;
  pcb_outline: PcbOutlineProps;
};

export interface BaseItem<T extends ItemType = ItemType> {
  id: string;
  type: T;
  transform: Transform;
  props: ItemPropsMap[T];
}

export type SchComponentItem = BaseItem<'sch_component'>;
export type SchWireItem = BaseItem<'sch_wire'>;
export type SchLabelItem = BaseItem<'sch_label'>;
export type PcbFootprintItem = BaseItem<'pcb_footprint'>;
export type PcbTraceItem = BaseItem<'pcb_trace'>;
export type PcbViaItem = BaseItem<'pcb_via'>;
export type PcbOutlineItem = BaseItem<'pcb_outline'>;

export type AnyItem =
  | SchComponentItem
  | SchWireItem
  | SchLabelItem
  | PcbFootprintItem
  | PcbTraceItem
  | PcbViaItem
  | PcbOutlineItem;

export interface Sheet {
  id: string;
  name: string;
  kind: 'schematic' | 'pcb';
  items: AnyItem[];
}

export interface DesignRules {
  minTraceWidth: number;
  minClearance: number;
  minViaDiameter: number;
  minViaDrill: number;
  minAnnularRing: number;
}

export interface Project {
  id: string;
  name: string;
  version: number;
  updatedAt: number;
  rules: DesignRules;
  sheets: Sheet[];
}

export interface NetNode {
  refDes: string;
  pinNumber: string;
  position: Point;
  itemId: string;
}

export interface Net {
  name: string;
  nodes: NetNode[];
  wireIds: string[];
}

export interface Netlist {
  nets: Net[];
  padNetMap: Record<string, string>;
}

export interface RatsnestLine {
  id: string;
  net: string;
  from: Point;
  to: Point;
  fromRef: string;
  toRef: string;
}

export type DRCViolationType =
  | 'clearance'
  | 'trace_width'
  | 'via_drill'
  | 'annular_ring'
  | 'unrouted_net'
  | 'out_of_bounds'
  | 'courtyard_overlap';

export interface DRCViolation {
  id: string;
  type: DRCViolationType;
  severity: 'error' | 'warning';
  message: string;
  position: Point;
  layer: LayerId;
  itemIds: string[];
}

export interface Command {
  id: string;
  description: string;
  execute(project: Project): Project;
}

export interface ViewportTransform {
  panX: number;
  panY: number;
  scale: number;
}

export interface PcbBoardConfig {
  gridSize: number;
  subdivision: number;
  rasterType: 'grid' | 'dots';
  gridOrigin: 'board_corner' | 'custom' | 'center';
  autoGroundTop: boolean;
  autoGroundBottom: boolean;
  copperFillClearance: number;
  maskExpansion: number;
  narrowestMaskStrip: number;
  coverViasWithMask: boolean;
  pasteMargin: number;
  stencilThickness: number;
  unitSystem: 'mm' | 'mil';
  cornerRadius: number;
}

export interface PhotoOverlayConfig {
  enabled: boolean;
  dataUrl: string;
  name: string;
  x: number;
  y: number;
  widthMm: number;
  heightMm: number;
  opacity: number;
  flipX: boolean;
  flipY: boolean;
}

export interface PcbViewConfig {
  edgeRulers: boolean;
  coordinateReadout: boolean;
  autoScrollDragging: boolean;
  touchMagnifier: boolean;
  padLabels: 'off' | 'numbers' | 'numbers_nets';
  showDesignators: boolean;
  readoutPosition: 'top_left' | 'top_right' | 'bottom_left' | 'bottom_right';
}


