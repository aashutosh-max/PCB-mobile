import { runMstAStarAutorouter } from './autorouter';
import { syncPcbNetsAndFootprints } from './commands';
import { getFootprintPadsWorld, getOutlinePolygonPoints } from './geometry';
import { computeRatsnest } from './netlist';
import {
  PcbFootprintItem,
  PcbOutlineItem,
  PcbTraceItem,
  PcbViaItem,
  Project,
  SchComponentItem,
  SchLabelItem,
  SchWireItem,
} from './types';

function formatGerberCoord(mm: number): string {
  // Format 4.4 metric (%FSLAX44Y44*%) -> multiply by 10000
  const val = Math.round(mm * 10000);
  return val.toString();
}

export interface GerberBundle {
  topCopper: string; // .gtl (F.Cu)
  bottomCopper: string; // .gbl (B.Cu)
  topMask: string; // .gts (F.Mask)
  bottomMask: string; // .gbs (B.Mask)
  topPaste: string; // .gtp (F.Paste)
  bottomPaste: string; // .gbp (B.Paste)
  topSilkscreen: string; // .gto (F.SilkS)
  bottomSilkscreen: string; // .gbo (B.SilkS)
  topFab: string; // .gbr (F.Fab)
  boardOutline: string; // .gm1 (Edge.Cuts)
  drillExcellon: string; // .drl (PTH/NPTH Drill)
  kicadPcb: string; // .kicad_pcb (All layers native KiCad PCB)
  kicadSch: string; // .kicad_sch (Complete native KiCad Schematic)
}

/**
 * Simple vector stroke font for drawing RefDes / Value text on Silkscreen & Fab Gerber layers
 */
const VECTOR_GLYPHS: Record<string, [number, number, number, number][]> = {
  '0': [
    [0, 0, 1, 0],
    [1, 0, 1, 2],
    [1, 2, 0, 2],
    [0, 2, 0, 0],
  ],
  '1': [[0.5, 0, 0.5, 2]],
  '2': [
    [0, 2, 1, 2],
    [1, 2, 1, 1],
    [1, 1, 0, 1],
    [0, 1, 0, 0],
    [0, 0, 1, 0],
  ],
  '3': [
    [0, 2, 1, 2],
    [1, 2, 1, 0],
    [1, 0, 0, 0],
    [0.2, 1, 1, 1],
  ],
  '4': [
    [0, 2, 0, 1],
    [0, 1, 1, 1],
    [1, 2, 1, 0],
  ],
  '5': [
    [1, 2, 0, 2],
    [0, 2, 0, 1],
    [0, 1, 1, 1],
    [1, 1, 1, 0],
    [1, 0, 0, 0],
  ],
  '6': [
    [1, 2, 0, 2],
    [0, 2, 0, 0],
    [0, 0, 1, 0],
    [1, 0, 1, 1],
    [1, 1, 0, 1],
  ],
  '7': [
    [0, 2, 1, 2],
    [1, 2, 0.4, 0],
  ],
  '8': [
    [0, 0, 1, 0],
    [1, 0, 1, 2],
    [1, 2, 0, 2],
    [0, 2, 0, 0],
    [0, 1, 1, 1],
  ],
  '9': [
    [0, 0, 1, 0],
    [1, 0, 1, 2],
    [1, 2, 0, 2],
    [0, 2, 0, 1],
    [0, 1, 1, 1],
  ],
  A: [
    [0, 0, 0, 1.6],
    [0, 1.6, 0.5, 2],
    [0.5, 2, 1, 1.6],
    [1, 1.6, 1, 0],
    [0, 0.9, 1, 0.9],
  ],
  B: [
    [0, 0, 0, 2],
    [0, 2, 0.8, 2],
    [0.8, 2, 1, 1.5],
    [1, 1.5, 0.8, 1],
    [0, 1, 0.8, 1],
    [0.8, 1, 1, 0.5],
    [1, 0.5, 0.8, 0],
    [0.8, 0, 0, 0],
  ],
  C: [
    [1, 2, 0, 2],
    [0, 2, 0, 0],
    [0, 0, 1, 0],
  ],
  D: [
    [0, 0, 0, 2],
    [0, 2, 0.8, 2],
    [0.8, 2, 1, 1.5],
    [1, 1.5, 1, 0.5],
    [1, 0.5, 0.8, 0],
    [0.8, 0, 0, 0],
  ],
  E: [
    [1, 2, 0, 2],
    [0, 2, 0, 0],
    [0, 0, 1, 0],
    [0, 1, 0.8, 1],
  ],
  F: [
    [0, 0, 0, 2],
    [0, 2, 1, 2],
    [0, 1, 0.8, 1],
  ],
  G: [
    [1, 2, 0, 2],
    [0, 2, 0, 0],
    [0, 0, 1, 0],
    [1, 0, 1, 1],
    [1, 1, 0.5, 1],
  ],
  H: [
    [0, 0, 0, 2],
    [1, 0, 1, 2],
    [0, 1, 1, 1],
  ],
  I: [
    [0.2, 2, 0.8, 2],
    [0.5, 2, 0.5, 0],
    [0.2, 0, 0.8, 0],
  ],
  J: [
    [1, 2, 1, 0.3],
    [1, 0.3, 0.5, 0],
    [0.5, 0, 0, 0.3],
  ],
  K: [
    [0, 0, 0, 2],
    [1, 2, 0, 1],
    [0, 1, 1, 0],
  ],
  L: [
    [0, 2, 0, 0],
    [0, 0, 1, 0],
  ],
  M: [
    [0, 0, 0, 2],
    [0, 2, 0.5, 1],
    [0.5, 1, 1, 2],
    [1, 2, 1, 0],
  ],
  N: [
    [0, 0, 0, 2],
    [0, 2, 1, 0],
    [1, 0, 1, 2],
  ],
  O: [
    [0, 0, 1, 0],
    [1, 0, 1, 2],
    [1, 2, 0, 2],
    [0, 2, 0, 0],
  ],
  P: [
    [0, 0, 0, 2],
    [0, 2, 1, 2],
    [1, 2, 1, 1],
    [1, 1, 0, 1],
  ],
  Q: [
    [0, 0, 1, 0],
    [1, 0, 1, 2],
    [1, 2, 0, 2],
    [0, 2, 0, 0],
    [0.6, 0.5, 1.1, -0.2],
  ],
  R: [
    [0, 0, 0, 2],
    [0, 2, 1, 2],
    [1, 2, 1, 1],
    [1, 1, 0, 1],
    [0.4, 1, 1, 0],
  ],
  S: [
    [1, 2, 0, 2],
    [0, 2, 0, 1],
    [0, 1, 1, 1],
    [1, 1, 1, 0],
    [1, 0, 0, 0],
  ],
  T: [
    [0, 2, 1, 2],
    [0.5, 2, 0.5, 0],
  ],
  U: [
    [0, 2, 0, 0],
    [0, 0, 1, 0],
    [1, 0, 1, 2],
  ],
  V: [
    [0, 2, 0.5, 0],
    [0.5, 0, 1, 2],
  ],
  W: [
    [0, 2, 0.25, 0],
    [0.25, 0, 0.5, 1],
    [0.5, 1, 0.75, 0],
    [0.75, 0, 1, 2],
  ],
  X: [
    [0, 2, 1, 0],
    [0, 0, 1, 2],
  ],
  Y: [
    [0, 2, 0.5, 1],
    [1, 2, 0.5, 1],
    [0.5, 1, 0.5, 0],
  ],
  Z: [
    [0, 2, 1, 2],
    [1, 2, 0, 0],
    [0, 0, 1, 0],
  ],
  '-': [[0.1, 1, 0.9, 1]],
  '_': [[0, 0, 1, 0]],
  '.': [[0.4, 0, 0.6, 0.2]],
};

function drawGerberVectorText(
  text: string,
  centerX: number,
  centerY: number,
  charHeightMm = 1.0
): string[] {
  const clean = text.toUpperCase();
  const charW = charHeightMm * 0.6;
  const gap = charHeightMm * 0.25;
  const totalW = clean.length * (charW + gap) - gap;
  const startX = centerX - totalW / 2;
  const baseY = centerY - charHeightMm / 2;
  const out: string[] = [];

  for (let i = 0; i < clean.length; i++) {
    const ch = clean[i];
    const strokes = VECTOR_GLYPHS[ch];
    if (!strokes) continue;
    const ox = startX + i * (charW + gap);
    for (const [x1, y1, x2, y2] of strokes) {
      const gx1 = ox + x1 * charW;
      const gy1 = baseY - y1 * (charHeightMm / 2);
      const gx2 = ox + x2 * charW;
      const gy2 = baseY - y2 * (charHeightMm / 2);
      out.push(`X${formatGerberCoord(gx1)}Y${formatGerberCoord(-gy1)}D02*`);
      out.push(`X${formatGerberCoord(gx2)}Y${formatGerberCoord(-gy2)}D01*`);
    }
  }
  return out;
}

export function generateCopperGerber(rawProject: Project, layer: 'F.Cu' | 'B.Cu'): string {
  const project = syncPcbNetsAndFootprints(rawProject);
  const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');
  const lines: string[] = [
    `G04 PocketEDA Gerber RS-274X Export - Layer ${layer}*`,
    `%TF.FileFunction,Copper,L${layer === 'F.Cu' ? '1,Top' : '2,Bot'}*%`,
    '%FSLAX44Y44*%',
    '%MOMM*%',
    '%LPD*%',
  ];

  if (!pcbSheet) {
    lines.push('M02*');
    return lines.join('\n');
  }

  const footprints = pcbSheet.items.filter(
    (i): i is PcbFootprintItem => i.type === 'pcb_footprint'
  );
  const traces = pcbSheet.items.filter(
    (i): i is PcbTraceItem => i.type === 'pcb_trace' && i.transform.layer === layer
  );
  const vias = pcbSheet.items.filter((i): i is PcbViaItem => i.type === 'pcb_via');

  let nextAperture = 10;
  const apertureMap = new Map<string, number>();
  const apertureDefs: string[] = [];

  const getAperture = (spec: string, defLine: (code: number) => string): number => {
    if (apertureMap.has(spec)) return apertureMap.get(spec)!;
    const code = nextAperture++;
    apertureMap.set(spec, code);
    apertureDefs.push(defLine(code));
    return code;
  };

  const bodyLines: string[] = [];

  // 1. Flash footprint pads on this layer
  for (const fp of footprints) {
    const isRot90 = fp.transform.rotation === 90 || fp.transform.rotation === 270;
    const pads = getFootprintPadsWorld(fp);
    for (const p of pads) {
      if (!p.pad.layers.includes(layer)) continue;
      const w = (isRot90 ? p.pad.height : p.pad.width).toFixed(4);
      const h = (isRot90 ? p.pad.width : p.pad.height).toFixed(4);
      const shape = p.pad.shape;
      const spec =
        shape === 'circle' ? `C,${w}` : shape === 'oval' ? `O,${w}X${h}` : `R,${w}X${h}`;
      const code = getAperture(spec, (c) =>
        shape === 'circle'
          ? `%ADD${c}C,${w}*%`
          : shape === 'oval'
            ? `%ADD${c}O,${w}X${h}*%`
            : `%ADD${c}R,${w}X${h}*%`
      );
      bodyLines.push(`D${code}*`);
      bodyLines.push(`X${formatGerberCoord(p.world.x)}Y${formatGerberCoord(-p.world.y)}D03*`);
    }
  }

  // 2. Flash vias on both F.Cu and B.Cu
  for (const via of vias) {
    const d = via.props.diameter.toFixed(4);
    const spec = `C,${d}`;
    const code = getAperture(spec, (c) => `%ADD${c}C,${d}*%`);
    bodyLines.push(`D${code}*`);
    bodyLines.push(`X${formatGerberCoord(via.transform.x)}Y${formatGerberCoord(-via.transform.y)}D03*`);
  }

  // 3. Draw explicit copper traces
  for (const trace of traces) {
    const pts = trace.props.points;
    if (pts.length < 2) continue;
    const w = trace.props.width.toFixed(4);
    const spec = `C,${w}`;
    const code = getAperture(spec, (c) => `%ADD${c}C,${w}*%`);
    bodyLines.push(`D${code}*`);
    bodyLines.push('G01*');
    bodyLines.push(`X${formatGerberCoord(pts[0].x)}Y${formatGerberCoord(-pts[0].y)}D02*`);
    for (let i = 1; i < pts.length; i++) {
      bodyLines.push(`X${formatGerberCoord(pts[i].x)}Y${formatGerberCoord(-pts[i].y)}D01*`);
    }
  }

  // 4. Also route any unrouted schematic ratsnest nets using MST + A* obstacle avoidance
  const unrouted = computeRatsnest(project);
  if (unrouted.length > 0) {
    const existingTraceIds = new Set(traces.map((t) => t.id));
    const autoResult = runMstAStarAutorouter(project, {
      layerMode: 'multi',
      gridStep: 0.5,
      traceWidth: project.rules?.minTraceWidth || 0.35,
      clearance: project.rules?.minClearance || 0.25,
      diagonal45: true,
    });
    const autoPcbSheet = autoResult.project.sheets.find((s) => s.kind === 'pcb');
    const autoTracesOnLayer = (autoPcbSheet?.items ?? []).filter(
      (i): i is PcbTraceItem =>
        i.type === 'pcb_trace' && i.transform.layer === layer && !existingTraceIds.has(i.id)
    );
    for (const tr of autoTracesOnLayer) {
      const pts = tr.props.points;
      if (pts.length < 2) continue;
      const w = tr.props.width.toFixed(4);
      const spec = `C,${w}`;
      const code = getAperture(spec, (c) => `%ADD${c}C,${w}*%`);
      bodyLines.push(`D${code}*`);
      bodyLines.push('G01*');
      bodyLines.push(`X${formatGerberCoord(pts[0].x)}Y${formatGerberCoord(-pts[0].y)}D02*`);
      for (let i = 1; i < pts.length; i++) {
        bodyLines.push(`X${formatGerberCoord(pts[i].x)}Y${formatGerberCoord(-pts[i].y)}D01*`);
      }
    }
  }

  lines.push(...apertureDefs);
  lines.push(...bodyLines);
  lines.push('M02*');
  return lines.join('\n');
}

export function generateMaskGerber(
  rawProject: Project,
  layer: 'F.Mask' | 'B.Mask',
  expansionMm = 0.05
): string {
  const project = syncPcbNetsAndFootprints(rawProject);
  const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');
  const cuLayer = layer === 'F.Mask' ? 'F.Cu' : 'B.Cu';
  const lines: string[] = [
    `G04 PocketEDA Gerber RS-274X Export - Layer ${layer}*`,
    `%TF.FileFunction,Soldermask,${layer === 'F.Mask' ? 'Top' : 'Bot'}*%`,
    '%FSLAX44Y44*%',
    '%MOMM*%',
    '%LPD*%',
  ];

  if (!pcbSheet) {
    lines.push('M02*');
    return lines.join('\n');
  }

  let nextAperture = 10;
  const apertureMap = new Map<string, number>();
  const apertureDefs: string[] = [];
  const getAperture = (spec: string, defLine: (code: number) => string): number => {
    if (apertureMap.has(spec)) return apertureMap.get(spec)!;
    const code = nextAperture++;
    apertureMap.set(spec, code);
    apertureDefs.push(defLine(code));
    return code;
  };

  const bodyLines: string[] = [];
  const footprints = pcbSheet.items.filter(
    (i): i is PcbFootprintItem => i.type === 'pcb_footprint'
  );

  for (const fp of footprints) {
    const isRot90 = fp.transform.rotation === 90 || fp.transform.rotation === 270;
    const pads = getFootprintPadsWorld(fp);
    for (const p of pads) {
      if (!p.pad.layers.includes(cuLayer)) continue;
      const w = ((isRot90 ? p.pad.height : p.pad.width) + expansionMm * 2).toFixed(4);
      const h = ((isRot90 ? p.pad.width : p.pad.height) + expansionMm * 2).toFixed(4);
      const shape = p.pad.shape;
      const spec =
        shape === 'circle' ? `C,${w}` : shape === 'oval' ? `O,${w}X${h}` : `R,${w}X${h}`;
      const code = getAperture(spec, (c) =>
        shape === 'circle'
          ? `%ADD${c}C,${w}*%`
          : shape === 'oval'
            ? `%ADD${c}O,${w}X${h}*%`
            : `%ADD${c}R,${w}X${h}*%`
      );
      bodyLines.push(`D${code}*`);
      bodyLines.push(`X${formatGerberCoord(p.world.x)}Y${formatGerberCoord(-p.world.y)}D03*`);
    }
  }

  lines.push(...apertureDefs);
  lines.push(...bodyLines);
  lines.push('M02*');
  return lines.join('\n');
}

export function generatePasteGerber(
  rawProject: Project,
  layer: 'F.Paste' | 'B.Paste'
): string {
  const project = syncPcbNetsAndFootprints(rawProject);
  const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');
  const cuLayer = layer === 'F.Paste' ? 'F.Cu' : 'B.Cu';
  const lines: string[] = [
    `G04 PocketEDA Gerber RS-274X Export - Layer ${layer}*`,
    `%TF.FileFunction,Paste,${layer === 'F.Paste' ? 'Top' : 'Bot'}*%`,
    '%FSLAX44Y44*%',
    '%MOMM*%',
    '%LPD*%',
  ];

  if (!pcbSheet) {
    lines.push('M02*');
    return lines.join('\n');
  }

  let nextAperture = 10;
  const apertureMap = new Map<string, number>();
  const apertureDefs: string[] = [];
  const getAperture = (spec: string, defLine: (code: number) => string): number => {
    if (apertureMap.has(spec)) return apertureMap.get(spec)!;
    const code = nextAperture++;
    apertureMap.set(spec, code);
    apertureDefs.push(defLine(code));
    return code;
  };

  const bodyLines: string[] = [];
  const footprints = pcbSheet.items.filter(
    (i): i is PcbFootprintItem => i.type === 'pcb_footprint'
  );

  for (const fp of footprints) {
    const isRot90 = fp.transform.rotation === 90 || fp.transform.rotation === 270;
    const pads = getFootprintPadsWorld(fp);
    for (const p of pads) {
      // Paste is only applied to SMD pads (no drill hole)
      if ((p.pad.drill && p.pad.drill > 0) || !p.pad.layers.includes(cuLayer)) continue;
      const w = (isRot90 ? p.pad.height : p.pad.width).toFixed(4);
      const h = (isRot90 ? p.pad.width : p.pad.height).toFixed(4);
      const spec = `R,${w}X${h}`;
      const code = getAperture(spec, (c) => `%ADD${c}R,${w}X${h}*%`);
      bodyLines.push(`D${code}*`);
      bodyLines.push(`X${formatGerberCoord(p.world.x)}Y${formatGerberCoord(-p.world.y)}D03*`);
    }
  }

  lines.push(...apertureDefs);
  lines.push(...bodyLines);
  lines.push('M02*');
  return lines.join('\n');
}

export function generateOutlineGerber(rawProject: Project): string {
  const project = syncPcbNetsAndFootprints(rawProject);
  const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');
  const lines: string[] = [
    'G04 PocketEDA Gerber RS-274X Export - Edge.Cuts*',
    '%TF.FileFunction,Profile,NP*%',
    '%FSLAX44Y44*%',
    '%MOMM*%',
    '%LPD*%',
    '%ADD10C,0.1500*%',
    'D10*',
    'G01*',
  ];

  const outline = pcbSheet?.items.find((i): i is PcbOutlineItem => i.type === 'pcb_outline');
  if (outline) {
    const polyPts = getOutlinePolygonPoints(outline);
    if (polyPts.length >= 3) {
      lines.push(
        `X${formatGerberCoord(polyPts[0].x)}Y${formatGerberCoord(-polyPts[0].y)}D02*`
      );
      for (let i = 1; i < polyPts.length; i++) {
        lines.push(
          `X${formatGerberCoord(polyPts[i].x)}Y${formatGerberCoord(-polyPts[i].y)}D01*`
        );
      }
      lines.push(
        `X${formatGerberCoord(polyPts[0].x)}Y${formatGerberCoord(-polyPts[0].y)}D01*`
      );
    }
  }

  lines.push('M02*');
  return lines.join('\n');
}

export function generateSilkscreenGerber(
  rawProject: Project,
  layer: 'F.SilkS' | 'B.SilkS' = 'F.SilkS'
): string {
  const project = syncPcbNetsAndFootprints(rawProject);
  const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');
  const lines: string[] = [
    `G04 PocketEDA Gerber RS-274X Export - ${layer}*`,
    `%TF.FileFunction,Legend,${layer === 'F.SilkS' ? 'Top' : 'Bot'}*%`,
    '%FSLAX44Y44*%',
    '%MOMM*%',
    '%LPD*%',
    '%ADD10C,0.1500*%',
    '%ADD11C,0.4000*%',
    'D10*',
    'G01*',
  ];

  const footprints =
    pcbSheet?.items.filter((i): i is PcbFootprintItem => i.type === 'pcb_footprint') ?? [];
  for (const fp of footprints) {
    const { x, y, rotation } = fp.transform;
    const isRot = rotation === 90 || rotation === 270;
    const hw = (isRot ? fp.props.courtyard.height : fp.props.courtyard.width) / 2;
    const hh = (isRot ? fp.props.courtyard.width : fp.props.courtyard.height) / 2;
    // Component silkscreen courtyard / body outline
    lines.push('D10*');
    lines.push('G01*');
    lines.push(`X${formatGerberCoord(x - hw)}Y${formatGerberCoord(-(y - hh))}D02*`);
    lines.push(`X${formatGerberCoord(x + hw)}Y${formatGerberCoord(-(y - hh))}D01*`);
    lines.push(`X${formatGerberCoord(x + hw)}Y${formatGerberCoord(-(y + hh))}D01*`);
    lines.push(`X${formatGerberCoord(x - hw)}Y${formatGerberCoord(-(y + hh))}D01*`);
    lines.push(`X${formatGerberCoord(x - hw)}Y${formatGerberCoord(-(y - hh))}D01*`);

    // Pin 1 orientation dot
    const pads = getFootprintPadsWorld(fp);
    const pin1 = pads.find((p) => p.pad.number === '1' || p.pad.number === 'A1') || pads[0];
    if (pin1) {
      lines.push('D11*');
      lines.push(
        `X${formatGerberCoord(pin1.world.x - 0.8)}Y${formatGerberCoord(-(pin1.world.y - 0.8))}D03*`
      );
    }

    // Vector Reference Designator & Value text
    lines.push('D10*');
    lines.push('G01*');
    lines.push(...drawGerberVectorText(fp.props.refDes, x, y - hh - 0.9, 1.0));
    if (layer === 'B.SilkS') {
      lines.push(...drawGerberVectorText(fp.props.value, x, y + hh + 0.9, 0.8));
    }
  }

  lines.push('M02*');
  return lines.join('\n');
}

export function generateFabGerber(rawProject: Project): string {
  const project = syncPcbNetsAndFootprints(rawProject);
  const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');
  const lines: string[] = [
    'G04 PocketEDA Gerber RS-274X Export - F.Fab Assembly Layer*',
    '%TF.FileFunction,AssemblyDrawing,Top*%',
    '%FSLAX44Y44*%',
    '%MOMM*%',
    '%LPD*%',
    '%ADD10C,0.1200*%',
    'D10*',
    'G01*',
  ];

  const outline = pcbSheet?.items.find((i): i is PcbOutlineItem => i.type === 'pcb_outline');
  if (outline) {
    const polyPts = getOutlinePolygonPoints(outline);
    if (polyPts.length >= 3) {
      lines.push(
        `X${formatGerberCoord(polyPts[0].x)}Y${formatGerberCoord(-polyPts[0].y)}D02*`
      );
      for (let i = 1; i < polyPts.length; i++) {
        lines.push(
          `X${formatGerberCoord(polyPts[i].x)}Y${formatGerberCoord(-polyPts[i].y)}D01*`
        );
      }
      lines.push(
        `X${formatGerberCoord(polyPts[0].x)}Y${formatGerberCoord(-polyPts[0].y)}D01*`
      );
    }
  }

  const footprints =
    pcbSheet?.items.filter((i): i is PcbFootprintItem => i.type === 'pcb_footprint') ?? [];
  for (const fp of footprints) {
    const { x, y, rotation } = fp.transform;
    const isRot = rotation === 90 || rotation === 270;
    const hw = Math.max(1.0, (isRot ? fp.props.courtyard.height : fp.props.courtyard.width) / 2 - 0.25);
    const hh = Math.max(0.8, (isRot ? fp.props.courtyard.width : fp.props.courtyard.height) / 2 - 0.25);
    lines.push(`X${formatGerberCoord(x - hw)}Y${formatGerberCoord(-(y - hh))}D02*`);
    lines.push(`X${formatGerberCoord(x + hw)}Y${formatGerberCoord(-(y - hh))}D01*`);
    lines.push(`X${formatGerberCoord(x + hw)}Y${formatGerberCoord(-(y + hh))}D01*`);
    lines.push(`X${formatGerberCoord(x - hw)}Y${formatGerberCoord(-(y + hh))}D01*`);
    lines.push(`X${formatGerberCoord(x - hw)}Y${formatGerberCoord(-(y - hh))}D01*`);
    lines.push(...drawGerberVectorText(fp.props.refDes, x, y - 0.4, 0.9));
    lines.push(...drawGerberVectorText(fp.props.value, x, y + 0.7, 0.75));
  }

  lines.push('M02*');
  return lines.join('\n');
}

export function generateExcellonDrill(rawProject: Project): string {
  const project = syncPcbNetsAndFootprints(rawProject);
  const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');
  const header: string[] = ['M48', '; PocketEDA Excellon Drill File', 'METRIC,TZ'];
  const body: string[] = ['%', 'G90', 'G05'];

  const toolMap = new Map<string, number>();
  let toolIndex = 1;
  const hitsByTool = new Map<number, { x: number; y: number }[]>();

  const addHit = (drillMm: number, x: number, y: number) => {
    const key = drillMm.toFixed(2);
    if (!toolMap.has(key)) {
      const code = toolIndex++;
      toolMap.set(key, code);
      header.push(`T0${code}C${key}`);
    }
    const tCode = toolMap.get(key)!;
    const list = hitsByTool.get(tCode) ?? [];
    list.push({ x, y });
    hitsByTool.set(tCode, list);
  };

  if (pcbSheet) {
    for (const item of pcbSheet.items) {
      if (item.type === 'pcb_via') {
        addHit(item.props.drill, item.transform.x, -item.transform.y);
      } else if (item.type === 'pcb_footprint') {
        const pads = getFootprintPadsWorld(item);
        for (const p of pads) {
          if (p.pad.drill && p.pad.drill > 0) {
            addHit(p.pad.drill, p.world.x, -p.world.y);
          }
        }
      }
    }
  }

  for (const [tCode, hits] of hitsByTool.entries()) {
    body.push(`T0${tCode}`);
    for (const h of hits) {
      body.push(`X${h.x.toFixed(3)}Y${h.y.toFixed(3)}`);
    }
  }

  body.push('M30');
  return [...header, ...body].join('\n');
}

export function generateGerberBundle(rawProject: Project): GerberBundle {
  const project = syncPcbNetsAndFootprints(rawProject);
  return {
    topCopper: generateCopperGerber(project, 'F.Cu'),
    bottomCopper: generateCopperGerber(project, 'B.Cu'),
    topMask: generateMaskGerber(project, 'F.Mask'),
    bottomMask: generateMaskGerber(project, 'B.Mask'),
    topPaste: generatePasteGerber(project, 'F.Paste'),
    bottomPaste: generatePasteGerber(project, 'B.Paste'),
    topSilkscreen: generateSilkscreenGerber(project, 'F.SilkS'),
    bottomSilkscreen: generateSilkscreenGerber(project, 'B.SilkS'),
    topFab: generateFabGerber(project),
    boardOutline: generateOutlineGerber(project),
    drillExcellon: generateExcellonDrill(project),
    kicadPcb: generateKicadPcb(project),
    kicadSch: generateKicadSch(project),
  };
}

export function generateBomCsv(project: Project): string {
  const schSheet = project.sheets.find((s) => s.kind === 'schematic');
  const lines = ['RefDes,Kind,Value,Footprint,Quantity'];
  if (!schSheet) return lines.join('\n');

  const components = schSheet.items
    .filter(
      (i): i is SchComponentItem =>
        i.type === 'sch_component' && i.props.kind !== 'GND' && i.props.kind !== 'VCC'
    )
    .sort((a, b) => a.props.refDes.localeCompare(b.props.refDes));

  for (const c of components) {
    const safeVal = `"${c.props.value.replace(/"/g, '""')}"`;
    lines.push(`${c.props.refDes},${c.props.kind},${safeVal},${c.props.footprint},1`);
  }

  return lines.join('\n');
}

export function generateKicadSch(project: Project): string {
  const schSheet = project.sheets.find((s) => s.kind === 'schematic');
  const comps =
    schSheet?.items.filter((i): i is SchComponentItem => i.type === 'sch_component') ?? [];

  // Build complete (lib_symbols ...) definitions so KiCad renders every symbol graphic & pin
  const uniqueByKind = new Map<string, SchComponentItem>();
  for (const c of comps) {
    if (!uniqueByKind.has(c.props.kind)) {
      uniqueByKind.set(c.props.kind, c);
    }
  }

  const lines: string[] = [
    '(kicad_sch (version 20230121) (generator "PocketEDA")',
    '  (uuid "00000000-0000-4000-8000-000000000001")',
    '  (paper "A4")',
    '  (lib_symbols',
  ];

  for (const [kind, sample] of uniqueByKind.entries()) {
    const safeKind = kind.replace(/"/g, '');
    const prefix = sample.props.refDes.replace(/[0-9]/g, '') || 'U';
    lines.push(
      `    (symbol "PocketEDA:${safeKind}" (in_bom yes) (on_board yes)`,
      `      (property "Reference" "${prefix}" (at 0 3.81 0) (effects (font (size 1.27 1.27))))`,
      `      (property "Value" "${sample.props.value.replace(/"/g, '')}" (at 0 -3.81 0) (effects (font (size 1.27 1.27))))`,
      `      (property "Footprint" "${sample.props.footprint.replace(/"/g, '')}" (at 0 0 0) (effects (font (size 1.27 1.27)) hide))`,
      `      (symbol "${safeKind}_0_1"`,
      '        (rectangle (start -2.54 2.54) (end 2.54 -2.54) (stroke (width 0.254) (type default)) (fill (type background)))',
      '      )',
      `      (symbol "${safeKind}_1_1"`
    );
    for (const pin of sample.props.pins) {
      const angle = pin.offset.x < 0 ? 0 : pin.offset.x > 0 ? 180 : pin.offset.y < 0 ? 270 : 90;
      lines.push(
        `        (pin passive line (at ${pin.offset.x.toFixed(2)} ${(-pin.offset.y).toFixed(2)} ${angle}) (length 2.54) (name "${pin.name}" (effects (font (size 1.0 1.0)))) (number "${pin.number}" (effects (font (size 1.0 1.0)))))`
      );
    }
    lines.push('      )', '    )');
  }
  lines.push('  )');

  if (schSheet) {
    const wires = schSheet.items.filter((i): i is SchWireItem => i.type === 'sch_wire');
    for (const w of wires) {
      const pts = w.props.points;
      for (let i = 0; i < pts.length - 1; i++) {
        lines.push(
          `  (wire (pts (xy ${pts[i].x.toFixed(2)} ${pts[i].y.toFixed(2)}) (xy ${pts[i + 1].x.toFixed(2)} ${pts[i + 1].y.toFixed(2)})) (stroke (width 0.15) (type default)))`
        );
      }
    }

    const labels = schSheet.items.filter((i): i is SchLabelItem => i.type === 'sch_label');
    for (const lbl of labels) {
      lines.push(
        `  (label "${lbl.props.text}" (at ${lbl.transform.x.toFixed(2)} ${lbl.transform.y.toFixed(2)} ${lbl.transform.rotation}) (effects (font (size 1.27 1.27))))`
      );
    }

    comps.forEach((c, idx) => {
      const safeKind = c.props.kind.replace(/"/g, '');
      const uuid = `00000000-0000-4000-8000-${String(idx + 100).padStart(12, '0')}`;
      lines.push(
        `  (symbol (lib_id "PocketEDA:${safeKind}") (at ${c.transform.x.toFixed(2)} ${c.transform.y.toFixed(2)} ${c.transform.rotation}) (unit 1)`,
        '    (in_bom yes) (on_board yes)',
        `    (uuid "${uuid}")`,
        `    (property "Reference" "${c.props.refDes}" (at ${c.transform.x.toFixed(2)} ${(c.transform.y - 3.81).toFixed(2)} 0) (effects (font (size 1.27 1.27))))`,
        `    (property "Value" "${c.props.value}" (at ${c.transform.x.toFixed(2)} ${(c.transform.y + 3.81).toFixed(2)} 0) (effects (font (size 1.27 1.27))))`,
        `    (property "Footprint" "${c.props.footprint}" (at ${c.transform.x.toFixed(2)} ${c.transform.y.toFixed(2)} 0) (effects (font (size 1.27 1.27)) hide))`,
        '  )'
      );
    });
  }

  lines.push(')');
  return lines.join('\n');
}

export function generateKicadPcb(rawProject: Project): string {
  const project = syncPcbNetsAndFootprints(rawProject);
  const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');
  const lines: string[] = [
    '(kicad_pcb (version 20221018) (generator "PocketEDA")',
    '  (general (thickness 1.6))',
    '  (paper "A4")',
    '  (layers',
    '    (0 "F.Cu" signal)',
    '    (31 "B.Cu" signal)',
    '    (32 "B.Adhes" user "B.Adhesive")',
    '    (33 "F.Adhes" user "F.Adhesive")',
    '    (34 "B.Paste" user)',
    '    (35 "F.Paste" user)',
    '    (36 "B.SilkS" user "B.Silkscreen")',
    '    (37 "F.SilkS" user "F.Silkscreen")',
    '    (38 "B.Mask" user)',
    '    (39 "F.Mask" user)',
    '    (40 "Dwgs.User" user "User.Drawings")',
    '    (41 "Cmts.User" user "User.Comments")',
    '    (42 "Eco1.User" user "User.Eco1")',
    '    (43 "Eco2.User" user "User.Eco2")',
    '    (44 "Edge.Cuts" user)',
    '    (45 "Margin" user)',
    '    (46 "B.CrtYd" user "B.Courtyard")',
    '    (47 "F.CrtYd" user "F.Courtyard")',
    '    (48 "B.Fab" user)',
    '    (49 "F.Fab" user)',
    '  )',
    '  (setup',
    '    (pad_to_mask_clearance 0.05)',
    '  )',
  ];

  if (pcbSheet) {
    const netSet = new Set<string>();
    const footprints = pcbSheet.items.filter(
      (i): i is PcbFootprintItem => i.type === 'pcb_footprint'
    );
    const traces = pcbSheet.items.filter((i): i is PcbTraceItem => i.type === 'pcb_trace');
    const vias = pcbSheet.items.filter((i): i is PcbViaItem => i.type === 'pcb_via');
    const outline = pcbSheet.items.find((i): i is PcbOutlineItem => i.type === 'pcb_outline');
    const unrouted = computeRatsnest(project);

    for (const fp of footprints) {
      for (const pad of fp.props.pads) {
        if (pad.net) netSet.add(pad.net);
      }
    }
    for (const tr of traces) {
      if (tr.props.net) netSet.add(tr.props.net);
    }
    for (const v of vias) {
      if (v.props.net) netSet.add(v.props.net);
    }
    for (const rn of unrouted) {
      if (rn.net) netSet.add(rn.net);
    }

    const netNames = Array.from(netSet);
    lines.push('  (net 0 "")');
    netNames.forEach((n, idx) => {
      lines.push(`  (net ${idx + 1} "${n}")`);
    });

    const getNetIdx = (name?: string) => {
      if (!name) return 0;
      const idx = netNames.indexOf(name);
      return idx >= 0 ? idx + 1 : 0;
    };

    // Export full board outline polygon on Edge.Cuts
    if (outline) {
      const polyPts = getOutlinePolygonPoints(outline);
      for (let i = 0; i < polyPts.length; i++) {
        const a = polyPts[i];
        const b = polyPts[(i + 1) % polyPts.length];
        lines.push(
          `  (gr_line (start ${a.x.toFixed(3)} ${a.y.toFixed(3)}) (end ${b.x.toFixed(3)} ${b.y.toFixed(3)}) (stroke (width 0.15) (type default)) (layer "Edge.Cuts"))`
        );
      }
    }

    // Export footprints with F.SilkS, B.SilkS, F.Fab, F.CrtYd outlines and all SMD / THT pads
    for (const fp of footprints) {
      const hw = Math.max(1.2, fp.props.courtyard.width / 2);
      const hh = Math.max(1.0, fp.props.courtyard.height / 2);
      const fabW = Math.max(0.8, hw - 0.25);
      const fabH = Math.max(0.7, hh - 0.25);

      lines.push(
        `  (footprint "${fp.props.footprintName}" (layer "F.Cu") (at ${fp.transform.x.toFixed(3)} ${fp.transform.y.toFixed(3)} ${fp.transform.rotation})`,
        `    (fp_text reference "${fp.props.refDes}" (at 0 ${(-hh - 1.0).toFixed(2)} ${fp.transform.rotation}) (layer "F.SilkS") (effects (font (size 1 1) (thickness 0.15))))`,
        `    (fp_text value "${fp.props.value}" (at 0 ${(hh + 1.0).toFixed(2)} ${fp.transform.rotation}) (layer "F.Fab") (effects (font (size 1 1) (thickness 0.15))))`,
        `    (fp_text user "${fp.props.refDes}" (at 0 0 ${fp.transform.rotation}) (layer "F.Fab") (effects (font (size 0.8 0.8) (thickness 0.12))))`,
        // Silkscreen outline
        `    (fp_line (start ${(-fabW).toFixed(3)} ${(-fabH).toFixed(3)}) (end ${fabW.toFixed(3)} ${(-fabH).toFixed(3)}) (stroke (width 0.12) (type solid)) (layer "F.SilkS"))`,
        `    (fp_line (start ${fabW.toFixed(3)} ${(-fabH).toFixed(3)}) (end ${fabW.toFixed(3)} ${fabH.toFixed(3)}) (stroke (width 0.12) (type solid)) (layer "F.SilkS"))`,
        `    (fp_line (start ${fabW.toFixed(3)} ${fabH.toFixed(3)}) (end ${(-fabW).toFixed(3)} ${fabH.toFixed(3)}) (stroke (width 0.12) (type solid)) (layer "F.SilkS"))`,
        `    (fp_line (start ${(-fabW).toFixed(3)} ${fabH.toFixed(3)}) (end ${(-fabW).toFixed(3)} ${(-fabH).toFixed(3)}) (stroke (width 0.12) (type solid)) (layer "F.SilkS"))`,
        // Fabrication outline
        `    (fp_line (start ${(-fabW).toFixed(3)} ${(-fabH).toFixed(3)}) (end ${fabW.toFixed(3)} ${(-fabH).toFixed(3)}) (stroke (width 0.1) (type solid)) (layer "F.Fab"))`,
        `    (fp_line (start ${fabW.toFixed(3)} ${(-fabH).toFixed(3)}) (end ${fabW.toFixed(3)} ${fabH.toFixed(3)}) (stroke (width 0.1) (type solid)) (layer "F.Fab"))`,
        `    (fp_line (start ${fabW.toFixed(3)} ${fabH.toFixed(3)}) (end ${(-fabW).toFixed(3)} ${fabH.toFixed(3)}) (stroke (width 0.1) (type solid)) (layer "F.Fab"))`,
        `    (fp_line (start ${(-fabW).toFixed(3)} ${fabH.toFixed(3)}) (end ${(-fabW).toFixed(3)} ${(-fabH).toFixed(3)}) (stroke (width 0.1) (type solid)) (layer "F.Fab"))`,
        // Courtyard outline
        `    (fp_line (start ${(-hw).toFixed(3)} ${(-hh).toFixed(3)}) (end ${hw.toFixed(3)} ${(-hh).toFixed(3)}) (stroke (width 0.05) (type solid)) (layer "F.CrtYd"))`,
        `    (fp_line (start ${hw.toFixed(3)} ${(-hh).toFixed(3)}) (end ${hw.toFixed(3)} ${hh.toFixed(3)}) (stroke (width 0.05) (type solid)) (layer "F.CrtYd"))`,
        `    (fp_line (start ${hw.toFixed(3)} ${hh.toFixed(3)}) (end ${(-hw).toFixed(3)} ${hh.toFixed(3)}) (stroke (width 0.05) (type solid)) (layer "F.CrtYd"))`,
        `    (fp_line (start ${(-hw).toFixed(3)} ${hh.toFixed(3)}) (end ${(-hw).toFixed(3)} ${(-hh).toFixed(3)}) (stroke (width 0.05) (type solid)) (layer "F.CrtYd"))`
      );
      for (const pad of fp.props.pads) {
        const padType = pad.drill && pad.drill > 0 ? 'thru_hole' : 'smd';
        const layersStr =
          padType === 'thru_hole'
            ? '"*.Cu" "*.Mask"'
            : pad.layers.includes('B.Cu') && !pad.layers.includes('F.Cu')
              ? '"B.Cu" "B.Paste" "B.Mask"'
              : '"F.Cu" "F.Paste" "F.Mask"';
        const drillStr = pad.drill && pad.drill > 0 ? ` (drill ${pad.drill.toFixed(2)})` : '';
        const netNum = getNetIdx(pad.net);
        lines.push(
          `    (pad "${pad.number}" ${padType} ${pad.shape} (at ${pad.offset.x.toFixed(3)} ${pad.offset.y.toFixed(3)} ${fp.transform.rotation}) (size ${pad.width.toFixed(3)} ${pad.height.toFixed(3)})${drillStr} (layers ${layersStr}) (net ${netNum} "${pad.net ?? ''}"))`
        );
      }
      lines.push('  )');
    }

    // Export explicit copper traces on F.Cu and B.Cu
    for (const tr of traces) {
      const pts = tr.props.points;
      const netNum = getNetIdx(tr.props.net);
      for (let i = 0; i < pts.length - 1; i++) {
        lines.push(
          `  (segment (start ${pts[i].x.toFixed(3)} ${pts[i].y.toFixed(3)}) (end ${pts[i + 1].x.toFixed(3)} ${pts[i + 1].y.toFixed(3)}) (width ${tr.props.width.toFixed(3)}) (layer "${tr.transform.layer}") (net ${netNum}))`
        );
      }
    }

    // Also export obstacle-avoiding copper segments for any unrouted schematic nets so external editors see all connections
    if (unrouted.length > 0) {
      const existingTraceIds = new Set(traces.map((t) => t.id));
      const autoResult = runMstAStarAutorouter(project, {
        layerMode: 'multi',
        gridStep: 0.5,
        traceWidth: project.rules?.minTraceWidth || 0.35,
        clearance: project.rules?.minClearance || 0.25,
        diagonal45: true,
      });
      const autoPcbSheet = autoResult.project.sheets.find((s) => s.kind === 'pcb');
      const autoTraces = (autoPcbSheet?.items ?? []).filter(
        (i): i is PcbTraceItem => i.type === 'pcb_trace' && !existingTraceIds.has(i.id)
      );
      for (const tr of autoTraces) {
        const pts = tr.props.points;
        if (pts.length < 2) continue;
        const netNum = getNetIdx(tr.props.net);
        for (let i = 0; i < pts.length - 1; i++) {
          lines.push(
            `  (segment (start ${pts[i].x.toFixed(3)} ${pts[i].y.toFixed(3)}) (end ${pts[i + 1].x.toFixed(3)} ${pts[i + 1].y.toFixed(3)}) (width ${tr.props.width.toFixed(3)}) (layer "${tr.transform.layer}") (net ${netNum}))`
          );
        }
      }
    }

    for (const v of vias) {
      const netNum = getNetIdx(v.props.net);
      lines.push(
        `  (via (at ${v.transform.x.toFixed(3)} ${v.transform.y.toFixed(3)}) (size ${v.props.diameter.toFixed(3)}) (drill ${v.props.drill.toFixed(3)}) (layers "F.Cu" "B.Cu") (net ${netNum}))`
      );
    }
  }

  lines.push(')');
  return lines.join('\n');
}

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[n] = c >>> 0;
  }
  return table;
})();

function crc32Bytes(bytes: Uint8Array): number {
  let c = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) {
    c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

export function createZipArchive(files: { name: string; content: string }[]): Uint8Array {
  const encoder = new TextEncoder();
  const localParts: Uint8Array[] = [];
  const centralParts: Uint8Array[] = [];
  let offset = 0;

  for (const file of files) {
    const nameBytes = encoder.encode(file.name);
    const dataBytes = encoder.encode(file.content);
    const crc = crc32Bytes(dataBytes);

    const localHeader = new Uint8Array(30 + nameBytes.length);
    const lv = new DataView(localHeader.buffer);
    lv.setUint32(0, 0x04034b50, true);
    lv.setUint16(4, 20, true);
    lv.setUint16(6, 0, true);
    lv.setUint16(8, 0, true); // store (uncompressed)
    lv.setUint16(10, 0, true);
    lv.setUint16(12, 0, true);
    lv.setUint32(14, crc, true);
    lv.setUint32(18, dataBytes.length, true);
    lv.setUint32(22, dataBytes.length, true);
    lv.setUint16(26, nameBytes.length, true);
    lv.setUint16(28, 0, true);
    localHeader.set(nameBytes, 30);

    const centralHeader = new Uint8Array(46 + nameBytes.length);
    const cv = new DataView(centralHeader.buffer);
    cv.setUint32(0, 0x02014b50, true);
    cv.setUint16(4, 20, true);
    cv.setUint16(6, 20, true);
    cv.setUint16(8, 0, true);
    cv.setUint16(10, 0, true);
    cv.setUint16(12, 0, true);
    cv.setUint16(14, 0, true);
    cv.setUint32(16, crc, true);
    cv.setUint32(20, dataBytes.length, true);
    cv.setUint32(24, dataBytes.length, true);
    cv.setUint16(28, nameBytes.length, true);
    cv.setUint16(30, 0, true);
    cv.setUint16(32, 0, true);
    cv.setUint16(34, 0, true);
    cv.setUint16(36, 0, true);
    cv.setUint32(38, 0, true);
    cv.setUint32(42, offset, true);
    centralHeader.set(nameBytes, 46);

    localParts.push(localHeader, dataBytes);
    centralParts.push(centralHeader);
    offset += localHeader.length + dataBytes.length;
  }

  let centralSize = 0;
  for (const cp of centralParts) centralSize += cp.length;

  const eocd = new Uint8Array(22);
  const ev = new DataView(eocd.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(4, 0, true);
  ev.setUint16(6, 0, true);
  ev.setUint16(8, centralParts.length, true);
  ev.setUint16(10, centralParts.length, true);
  ev.setUint32(12, centralSize, true);
  ev.setUint32(16, offset, true);
  ev.setUint16(20, 0, true);

  const totalSize = offset + centralSize + 22;
  const out = new Uint8Array(totalSize);
  let pos = 0;
  for (const lp of localParts) {
    out.set(lp, pos);
    pos += lp.length;
  }
  for (const cp of centralParts) {
    out.set(cp, pos);
    pos += cp.length;
  }
  out.set(eocd, pos);
  return out;
}
