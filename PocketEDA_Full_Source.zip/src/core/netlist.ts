import {
  distance,
  distanceToSegment,
  getComponentPinsWorld,
  getFootprintPadsWorld,
  segmentsIntersect,
} from './geometry';
import {
  Net,
  Netlist,
  NetNode,
  PcbFootprintItem,
  PcbTraceItem,
  PcbViaItem,
  Point,
  Project,
  RatsnestLine,
  SchComponentItem,
  SchLabelItem,
  SchWireItem,
} from './types';

export class UnionFind {
  private parent: Map<string, string> = new Map();
  private rank: Map<string, number> = new Map();

  add(x: string): void {
    if (!this.parent.has(x)) {
      this.parent.set(x, x);
      this.rank.set(x, 0);
    }
  }

  find(x: string): string {
    this.add(x);
    let root = x;
    while (this.parent.get(root) !== root) {
      root = this.parent.get(root)!;
    }
    let curr = x;
    while (curr !== root) {
      const nxt = this.parent.get(curr)!;
      this.parent.set(curr, root);
      curr = nxt;
    }
    return root;
  }

  union(a: string, b: string): void {
    const rootA = this.find(a);
    const rootB = this.find(b);
    if (rootA === rootB) return;

    const rankA = this.rank.get(rootA) ?? 0;
    const rankB = this.rank.get(rootB) ?? 0;
    if (rankA < rankB) {
      this.parent.set(rootA, rootB);
    } else if (rankA > rankB) {
      this.parent.set(rootB, rootA);
    } else {
      this.parent.set(rootB, rootA);
      this.rank.set(rootA, rankA + 1);
    }
  }

  groups(): Map<string, string[]> {
    const result = new Map<string, string[]>();
    for (const key of this.parent.keys()) {
      const root = this.find(key);
      const list = result.get(root) ?? [];
      list.push(key);
      result.set(root, list);
    }
    return result;
  }
}

const EPSILON = 0.35; // mm connection tolerance

function pointTouchesWire(pt: Point, wire: SchWireItem): boolean {
  const pts = wire.props.points;
  for (let i = 0; i < pts.length; i++) {
    if (distance(pt, pts[i]) <= EPSILON) return true;
    if (i < pts.length - 1) {
      if (distanceToSegment(pt, pts[i], pts[i + 1]).dist <= EPSILON) return true;
    }
  }
  return false;
}

function wiresConnect(w1: SchWireItem, w2: SchWireItem): boolean {
  const p1 = w1.props.points;
  const p2 = w2.props.points;
  for (const pt of p1) {
    if (pointTouchesWire(pt, w2)) return true;
  }
  for (const pt of p2) {
    if (pointTouchesWire(pt, w1)) return true;
  }
  return false;
}

/**
 * Computes the schematic + PCB netlist using Union-Find over component pins, wires, power symbols, net labels, and PCB pad nets.
 */
export function computeNetlist(project: Project): Netlist {
  const schSheet = project.sheets.find((s) => s.kind === 'schematic');
  const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');
  if (!schSheet && !pcbSheet) return { nets: [], padNetMap: {} };

  const uf = new UnionFind();
  const components = schSheet
    ? schSheet.items.filter((i): i is SchComponentItem => i.type === 'sch_component')
    : [];
  const wires = schSheet
    ? schSheet.items.filter((i): i is SchWireItem => i.type === 'sch_wire')
    : [];
  const labels = schSheet
    ? schSheet.items.filter((i): i is SchLabelItem => i.type === 'sch_label')
    : [];

  interface PinRecord {
    key: string;
    comp: SchComponentItem;
    pinNumber: string;
    world: Point;
  }

  const pinRecords: PinRecord[] = [];

  for (const comp of components) {
    const pins = getComponentPinsWorld(comp);
    for (const p of pins) {
      const key = `pin:${comp.id}:${p.pin.number}`;
      uf.add(key);
      pinRecords.push({
        key,
        comp,
        pinNumber: p.pin.number,
        world: p.world,
      });

      if (comp.props.kind === 'GND') {
        const netKey = 'netname:GND';
        uf.add(netKey);
        uf.union(key, netKey);
      } else if (comp.props.kind === 'VCC') {
        const powerName = comp.props.value || '+5V';
        const netKey = `netname:${powerName}`;
        uf.add(netKey);
        uf.union(key, netKey);
      }
    }
  }

  for (const wire of wires) {
    uf.add(`wire:${wire.id}`);
  }

  for (let i = 0; i < pinRecords.length; i++) {
    for (let j = i + 1; j < pinRecords.length; j++) {
      if (distance(pinRecords[i].world, pinRecords[j].world) <= EPSILON) {
        uf.union(pinRecords[i].key, pinRecords[j].key);
      }
    }
  }

  for (const pr of pinRecords) {
    for (const wire of wires) {
      if (pointTouchesWire(pr.world, wire)) {
        uf.union(pr.key, `wire:${wire.id}`);
      }
    }
  }

  for (let i = 0; i < wires.length; i++) {
    for (let j = i + 1; j < wires.length; j++) {
      if (wiresConnect(wires[i], wires[j])) {
        uf.union(`wire:${wires[i].id}`, `wire:${wires[j].id}`);
      }
    }
  }

  for (const label of labels) {
    const cleanName = label.props.text.trim();
    if (!cleanName) continue;
    const netKey = `netname:${cleanName}`;
    uf.add(netKey);
    const labelPt = { x: label.transform.x, y: label.transform.y };

    for (const wire of wires) {
      if (pointTouchesWire(labelPt, wire)) {
        uf.union(netKey, `wire:${wire.id}`);
      }
    }
    for (const pr of pinRecords) {
      if (distance(labelPt, pr.world) <= EPSILON) {
        uf.union(netKey, pr.key);
      }
    }
  }

  const groups = uf.groups();
  const nets: Net[] = [];
  const padNetMap: Record<string, string> = {};
  let autoNetCounter = 1;

  const sortedEntries = Array.from(groups.entries()).sort((a, b) => a[0].localeCompare(b[0]));

  for (const [, members] of sortedEntries) {
    const explicitNames = members
      .filter((m) => m.startsWith('netname:'))
      .map((m) => m.slice('netname:'.length))
      .sort();

    const allGroupPins = pinRecords.filter((pr) => members.includes(pr.key));
    const memberPins = allGroupPins.filter(
      (pr) => pr.comp.props.kind !== 'GND' && pr.comp.props.kind !== 'VCC'
    );
    const memberWires = members
      .filter((m) => m.startsWith('wire:'))
      .map((m) => m.slice('wire:'.length));

    if (memberPins.length === 0 && memberWires.length === 0) continue;
    if (memberPins.length < 2 && explicitNames.length === 0 && memberWires.length === 0) continue;

    const netName = explicitNames.length > 0 ? explicitNames[0] : `NET_${autoNetCounter++}`;

    for (const pr of allGroupPins) {
      padNetMap[`${pr.comp.props.refDes}:${pr.pinNumber}`] = netName;
    }

    const nodes: NetNode[] = memberPins.map((pr) => {
      return {
        refDes: pr.comp.props.refDes,
        pinNumber: pr.pinNumber,
        position: pr.world,
        itemId: pr.comp.id,
      };
    });

    nets.push({
      name: netName,
      nodes,
      wireIds: memberWires,
    });
  }

  // Also include PCB-assigned pad nets so PCB-only airwires and routing work seamlessly
  if (pcbSheet) {
    const pcbNetGroups = new Map<string, NetNode[]>();
    for (const item of pcbSheet.items) {
      if (item.type !== 'pcb_footprint') continue;
      const padsWorld = getFootprintPadsWorld(item);
      for (const pw of padsWorld) {
        const key = `${item.props.refDes}:${pw.pad.number}`;
        if (!padNetMap[key] && pw.pad.net) {
          padNetMap[key] = pw.pad.net;
          const list = pcbNetGroups.get(pw.pad.net) ?? [];
          list.push({
            refDes: item.props.refDes,
            pinNumber: pw.pad.number,
            position: pw.world,
            itemId: item.id,
          });
          pcbNetGroups.set(pw.pad.net, list);
        }
      }
    }

    for (const [netName, nodes] of pcbNetGroups.entries()) {
      const existing = nets.find((n) => n.name === netName);
      if (existing) {
        existing.nodes.push(...nodes);
      } else if (nodes.length >= 2) {
        nets.push({
          name: netName,
          nodes,
          wireIds: [],
        });
      }
    }
  }

  return { nets, padNetMap };
}

/**
 * Computes live ratsnest lines on the PCB sheet.
 * Accounts for existing copper traces and vias so routed connections disappear from the ratsnest!
 */
export function computeRatsnest(project: Project): RatsnestLine[] {
  const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');
  if (!pcbSheet) return [];

  const netlist = computeNetlist(project);
  const footprints = pcbSheet.items.filter((i): i is PcbFootprintItem => i.type === 'pcb_footprint');
  const traces = pcbSheet.items.filter((i): i is PcbTraceItem => i.type === 'pcb_trace');
  const vias = pcbSheet.items.filter((i): i is PcbViaItem => i.type === 'pcb_via');

  interface PadInstance {
    id: string;
    refLabel: string;
    net: string;
    world: Point;
    layers: ('F.Cu' | 'B.Cu')[];
    radius: number;
  }

  const allPads: PadInstance[] = [];
  for (const fp of footprints) {
    const padsWorld = getFootprintPadsWorld(fp);
    for (const p of padsWorld) {
      const net = netlist.padNetMap[`${fp.props.refDes}:${p.pad.number}`] || p.pad.net || '';
      if (!net) continue;
      allPads.push({
        id: `pad:${fp.props.refDes}:${p.pad.number}`,
        refLabel: `${fp.props.refDes}.${p.pad.number}`,
        net,
        world: p.world,
        layers: p.pad.layers,
        radius: Math.max(p.pad.width, p.pad.height) / 2,
      });
    }
  }

  const padsByNet = new Map<string, PadInstance[]>();
  for (const pad of allPads) {
    const list = padsByNet.get(pad.net) ?? [];
    list.push(pad);
    padsByNet.set(pad.net, list);
  }

  const copperUf = new UnionFind();
  for (const pad of allPads) copperUf.add(pad.id);
  for (const trace of traces) copperUf.add(`trace:${trace.id}`);
  for (const via of vias) copperUf.add(`via:${via.id}`);

  for (const pad of allPads) {
    for (const trace of traces) {
      if (!pad.layers.includes(trace.transform.layer as 'F.Cu' | 'B.Cu')) continue;
      const pts = trace.props.points;
      const tol = pad.radius + trace.props.width / 2 + 0.15;
      for (let i = 0; i < pts.length; i++) {
        if (distance(pad.world, pts[i]) <= tol) {
          copperUf.union(pad.id, `trace:${trace.id}`);
          break;
        }
        if (i < pts.length - 1 && distanceToSegment(pad.world, pts[i], pts[i + 1]).dist <= tol) {
          copperUf.union(pad.id, `trace:${trace.id}`);
          break;
        }
      }
    }
  }

  for (const via of vias) {
    const viaPt = { x: via.transform.x, y: via.transform.y };
    for (const trace of traces) {
      const pts = trace.props.points;
      const tol = via.props.diameter / 2 + trace.props.width / 2 + 0.15;
      for (let i = 0; i < pts.length; i++) {
        if (distance(viaPt, pts[i]) <= tol) {
          copperUf.union(`via:${via.id}`, `trace:${trace.id}`);
          break;
        }
        if (i < pts.length - 1 && distanceToSegment(viaPt, pts[i], pts[i + 1]).dist <= tol) {
          copperUf.union(`via:${via.id}`, `trace:${trace.id}`);
          break;
        }
      }
    }
  }

  for (let i = 0; i < traces.length; i++) {
    for (let j = i + 1; j < traces.length; j++) {
      if (traces[i].transform.layer !== traces[j].transform.layer) continue;
      const p1 = traces[i].props.points;
      const p2 = traces[j].props.points;
      const tol = (traces[i].props.width + traces[j].props.width) / 2 + 0.1;
      let connected = false;
      for (let a = 0; a < p1.length - 1 && !connected; a++) {
        for (let b = 0; b < p2.length - 1 && !connected; b++) {
          if (
            segmentsIntersect(p1[a], p1[a + 1], p2[b], p2[b + 1]) ||
            distanceToSegment(p1[a], p2[b], p2[b + 1]).dist <= tol ||
            distanceToSegment(p1[a + 1], p2[b], p2[b + 1]).dist <= tol ||
            distanceToSegment(p2[b], p1[a], p1[a + 1]).dist <= tol ||
            distanceToSegment(p2[b + 1], p1[a], p1[a + 1]).dist <= tol
          ) {
            connected = true;
          }
        }
      }
      if (connected) {
        copperUf.union(`trace:${traces[i].id}`, `trace:${traces[j].id}`);
      }
    }
  }

  const ratsnest: RatsnestLine[] = [];

  for (const [netName, pads] of padsByNet.entries()) {
    if (pads.length < 2) continue;

    const clusterMap = new Map<string, PadInstance[]>();
    for (const p of pads) {
      const root = copperUf.find(p.id);
      const list = clusterMap.get(root) ?? [];
      list.push(p);
      clusterMap.set(root, list);
    }

    const clusters = Array.from(clusterMap.values());
    if (clusters.length <= 1) continue;

    const connectedClusterIndices = new Set<number>([0]);
    while (connectedClusterIndices.size < clusters.length) {
      let bestDist = Infinity;
      let bestFrom: PadInstance | null = null;
      let bestTo: PadInstance | null = null;
      let bestClusterIdx = -1;

      for (const cIdx of connectedClusterIndices) {
        for (let otherIdx = 0; otherIdx < clusters.length; otherIdx++) {
          if (connectedClusterIndices.has(otherIdx)) continue;
          for (const pA of clusters[cIdx]) {
            for (const pB of clusters[otherIdx]) {
              const d = distance(pA.world, pB.world);
              if (d < bestDist) {
                bestDist = d;
                bestFrom = pA;
                bestTo = pB;
                bestClusterIdx = otherIdx;
              }
            }
          }
        }
      }

      if (bestFrom && bestTo && bestClusterIdx !== -1) {
        connectedClusterIndices.add(bestClusterIdx);
        ratsnest.push({
          id: `rat_${netName}_${bestFrom.refLabel}_${bestTo.refLabel}`,
          net: netName,
          from: bestFrom.world,
          to: bestTo.world,
          fromRef: bestFrom.refLabel,
          toRef: bestTo.refLabel,
        });
      } else {
        break;
      }
    }
  }

  return ratsnest;
}
