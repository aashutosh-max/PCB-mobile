import { syncPcbNetsAndFootprints } from './commands';
import {
  distanceToSegment,
  getFootprintPadsWorld,
  getOutlinePolygonPoints,
  PCB_GRID,
  snapPoint,
} from './geometry';
import {
  AnyItem,
  PadDef,
  PcbFootprintItem,
  PcbOutlineItem,
  PcbTraceItem,
  PcbViaItem,
  Point,
  Project,
  SchComponentItem,
} from './types';

function pointInPolygon(pt: Point, poly: Point[]): boolean {
  if (poly.length < 3) return true;
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const xi = poly[i].x;
    const yi = poly[i].y;
    const xj = poly[j].x;
    const yj = poly[j].y;
    const intersect =
      yi > pt.y !== yj > pt.y &&
      pt.x < ((xj - xi) * (pt.y - yi)) / (yj - yi + 1e-12) + xi;
    if (intersect) inside = !inside;
  }
  return inside;
}

export function getBoardBounds(project: Project): {
  x: number;
  y: number;
  width: number;
  height: number;
  centerX: number;
  centerY: number;
  polygon: Point[];
} {
  const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');
  const outline = pcbSheet?.items.find((i): i is PcbOutlineItem => i.type === 'pcb_outline');
  if (!outline) {
    const poly = [
      { x: 4, y: 4 },
      { x: 48, y: 4 },
      { x: 48, y: 36 },
      { x: 4, y: 36 },
    ];
    return { x: 4, y: 4, width: 44, height: 32, centerX: 26, centerY: 20, polygon: poly };
  }
  const poly = getOutlinePolygonPoints(outline);
  return {
    x: outline.transform.x,
    y: outline.transform.y,
    width: outline.props.width,
    height: outline.props.height,
    centerX: Number((outline.transform.x + outline.props.width / 2).toFixed(2)),
    centerY: Number((outline.transform.y + outline.props.height / 2).toFixed(2)),
    polygon: poly,
  };
}

// ============================================================================
// 1. SVG IMPORT & PRESET VECTOR GEOMETRY -> COPPER, SILK, OR MILLING
// ============================================================================

export interface SvgInsertOptions {
  svgText?: string;
  preset?: 'oshw_gear' | 'esd_bolt' | 'ce_mark' | 'wifi_wave' | 'rounded_star';
  targetLayer: 'F.Cu' | 'B.Cu' | 'F.SilkS' | 'Edge.Cuts';
  sizeMm: number;
  traceWidthMm: number;
  offsetX?: number;
  offsetY?: number;
}

function getPresetPolylines(preset: NonNullable<SvgInsertOptions['preset']>): Point[][] {
  if (preset === 'esd_bolt') {
    // Triangle + Lightning Bolt
    return [
      [
        { x: 0.5, y: 0.05 },
        { x: 0.95, y: 0.9 },
        { x: 0.05, y: 0.9 },
        { x: 0.5, y: 0.05 },
      ],
      [
        { x: 0.54, y: 0.25 },
        { x: 0.38, y: 0.54 },
        { x: 0.54, y: 0.54 },
        { x: 0.44, y: 0.82 },
      ],
    ];
  }
  if (preset === 'ce_mark') {
    const cArc: Point[] = [];
    const eArc: Point[] = [];
    for (let i = 0; i <= 16; i++) {
      const a = Math.PI * 0.35 + (i / 16) * Math.PI * 1.3;
      cArc.push({ x: 0.3 + Math.cos(a) * 0.22, y: 0.5 + Math.sin(a) * 0.32 });
      eArc.push({ x: 0.75 + Math.cos(a) * 0.22, y: 0.5 + Math.sin(a) * 0.32 });
    }
    return [
      cArc,
      eArc,
      [
        { x: 0.53, y: 0.5 },
        { x: 0.78, y: 0.5 },
      ],
    ];
  }
  if (preset === 'wifi_wave') {
    const arcs: Point[][] = [];
    for (const r of [0.22, 0.38, 0.54]) {
      const pts: Point[] = [];
      for (let i = 0; i <= 14; i++) {
        const a = -Math.PI * 0.78 + (i / 14) * Math.PI * 0.56;
        pts.push({ x: 0.5 + Math.cos(a) * r, y: 0.78 + Math.sin(a) * r });
      }
      arcs.push(pts);
    }
    arcs.push([
      { x: 0.47, y: 0.78 },
      { x: 0.53, y: 0.78 },
      { x: 0.53, y: 0.84 },
      { x: 0.47, y: 0.84 },
      { x: 0.47, y: 0.78 },
    ]);
    return arcs;
  }
  if (preset === 'rounded_star') {
    const pts: Point[] = [];
    const spikes = 5;
    for (let i = 0; i <= spikes * 2; i++) {
      const r = i % 2 === 0 ? 0.46 : 0.2;
      const a = (i * Math.PI) / spikes - Math.PI / 2;
      pts.push({ x: 0.5 + Math.cos(a) * r, y: 0.5 + Math.sin(a) * r });
    }
    return [pts];
  }
  // Default: OSHW Gear contour
  const gear: Point[] = [];
  const teeth = 8;
  for (let i = 0; i <= teeth * 4; i++) {
    const step = i % 4;
    const r = step === 1 || step === 2 ? 0.46 : 0.34;
    const a = (i / (teeth * 4)) * Math.PI * 2;
    gear.push({ x: 0.5 + Math.cos(a) * r, y: 0.5 + Math.sin(a) * r });
  }
  const hole: Point[] = [];
  for (let i = 0; i <= 16; i++) {
    const a = (i / 16) * Math.PI * 2;
    hole.push({ x: 0.5 + Math.cos(a) * 0.14, y: 0.5 + Math.sin(a) * 0.14 });
  }
  return [gear, hole];
}

function parseSvgStringToPolylines(svgText: string): Point[][] {
  const polylines: Point[][] = [];

  // 1. Parse <polygon> and <polyline> points="..."
  const polyRegex = /<(?:polygon|polyline)[^>]*\bpoints=["']([^"']+)["'][^>]*>/gi;
  let match: RegExpExecArray | null;
  while ((match = polyRegex.exec(svgText)) !== null) {
    const nums = (match[1].match(/-?\d+(?:\.\d+)?/g) || []).map(Number);
    const pts: Point[] = [];
    for (let i = 0; i + 1 < nums.length; i += 2) {
      pts.push({ x: nums[i], y: nums[i + 1] });
    }
    if (pts.length >= 2) {
      if (match[0].toLowerCase().startsWith('<polygon')) {
        pts.push({ ...pts[0] });
      }
      polylines.push(pts);
    }
  }

  // 2. Parse <line x1="" y1="" x2="" y2="">
  const lineRegex = /<line[^>]*>/gi;
  while ((match = lineRegex.exec(svgText)) !== null) {
    const tag = match[0];
    const getAttr = (name: string) => {
      const m = new RegExp(`\\b${name}=["']([^"']+)["']`, 'i').exec(tag);
      return m ? parseFloat(m[1]) : 0;
    };
    const x1 = getAttr('x1');
    const y1 = getAttr('y1');
    const x2 = getAttr('x2');
    const y2 = getAttr('y2');
    if (Math.hypot(x2 - x1, y2 - y1) > 1e-3) {
      polylines.push([
        { x: x1, y: y1 },
        { x: x2, y: y2 },
      ]);
    }
  }

  // 3. Parse <rect x="" y="" width="" height="">
  const rectRegex = /<rect[^>]*>/gi;
  while ((match = rectRegex.exec(svgText)) !== null) {
    const tag = match[0];
    const getAttr = (name: string) => {
      const m = new RegExp(`\\b${name}=["']([^"']+)["']`, 'i').exec(tag);
      return m ? parseFloat(m[1]) : 0;
    };
    const x = getAttr('x');
    const y = getAttr('y');
    const w = getAttr('width');
    const h = getAttr('height');
    if (w > 0 && h > 0) {
      polylines.push([
        { x, y },
        { x: x + w, y },
        { x: x + w, y: y + h },
        { x, y: y + h },
        { x, y },
      ]);
    }
  }

  // 4. Parse <circle cx="" cy="" r="">
  const circleRegex = /<circle[^>]*>/gi;
  while ((match = circleRegex.exec(svgText)) !== null) {
    const tag = match[0];
    const getAttr = (name: string) => {
      const m = new RegExp(`\\b${name}=["']([^"']+)["']`, 'i').exec(tag);
      return m ? parseFloat(m[1]) : 0;
    };
    const cx = getAttr('cx');
    const cy = getAttr('cy');
    const r = getAttr('r');
    if (r > 0) {
      const pts: Point[] = [];
      for (let i = 0; i <= 24; i++) {
        const a = (i / 24) * Math.PI * 2;
        pts.push({ x: cx + Math.cos(a) * r, y: cy + Math.sin(a) * r });
      }
      polylines.push(pts);
    }
  }

  // 5. Parse <path d="..."> (M, L, H, V, Z commands)
  const pathRegex = /<path[^>]*\bd=["']([^"']+)["'][^>]*>/gi;
  while ((match = pathRegex.exec(svgText)) !== null) {
    const d = match[1];
    const tokens = d.match(/[a-zA-Z]|-?\d+(?:\.\d+)?/g) || [];
    let idx = 0;
    let cmd = 'M';
    let curX = 0;
    let curY = 0;
    let startX = 0;
    let startY = 0;
    let currentPoly: Point[] = [];

    const flushPoly = () => {
      if (currentPoly.length >= 2) {
        polylines.push(currentPoly);
      }
      currentPoly = [];
    };

    while (idx < tokens.length) {
      const tok = tokens[idx];
      if (/^[a-zA-Z]$/.test(tok)) {
        cmd = tok;
        idx++;
        if (cmd === 'Z' || cmd === 'z') {
          if (currentPoly.length >= 2) {
            currentPoly.push({ x: startX, y: startY });
          }
          flushPoly();
          curX = startX;
          curY = startY;
        }
        continue;
      }

      const readNum = () => (idx < tokens.length ? parseFloat(tokens[idx++]) : 0);

      if (cmd === 'M' || cmd === 'm') {
        flushPoly();
        const nx = readNum();
        const ny = readNum();
        curX = cmd === 'm' ? curX + nx : nx;
        curY = cmd === 'm' ? curY + ny : ny;
        startX = curX;
        startY = curY;
        currentPoly.push({ x: curX, y: curY });
        cmd = cmd === 'm' ? 'l' : 'L';
      } else if (cmd === 'L' || cmd === 'l') {
        const nx = readNum();
        const ny = readNum();
        curX = cmd === 'l' ? curX + nx : nx;
        curY = cmd === 'l' ? curY + ny : ny;
        currentPoly.push({ x: curX, y: curY });
      } else if (cmd === 'H' || cmd === 'h') {
        const nx = readNum();
        curX = cmd === 'h' ? curX + nx : nx;
        currentPoly.push({ x: curX, y: curY });
      } else if (cmd === 'V' || cmd === 'v') {
        const ny = readNum();
        curY = cmd === 'v' ? curY + ny : ny;
        currentPoly.push({ x: curX, y: curY });
      } else if (cmd === 'C' || cmd === 'c') {
        // Sample cubic bezier
        const x1 = cmd === 'c' ? curX + readNum() : readNum();
        const y1 = cmd === 'c' ? curY + readNum() : readNum();
        const x2 = cmd === 'c' ? curX + readNum() : readNum();
        const y2 = cmd === 'c' ? curY + readNum() : readNum();
        const x = cmd === 'c' ? curX + readNum() : readNum();
        const y = cmd === 'c' ? curY + readNum() : readNum();
        for (let s = 1; s <= 6; s++) {
          const t = s / 6;
          const mt = 1 - t;
          const bx =
            mt * mt * mt * curX +
            3 * mt * mt * t * x1 +
            3 * mt * t * t * x2 +
            t * t * t * x;
          const by =
            mt * mt * mt * curY +
            3 * mt * mt * t * y1 +
            3 * mt * t * t * y2 +
            t * t * t * y;
          currentPoly.push({ x: bx, y: by });
        }
        curX = x;
        curY = y;
      } else if (cmd === 'Q' || cmd === 'q') {
        const x1 = cmd === 'q' ? curX + readNum() : readNum();
        const y1 = cmd === 'q' ? curY + readNum() : readNum();
        const x = cmd === 'q' ? curX + readNum() : readNum();
        const y = cmd === 'q' ? curY + readNum() : readNum();
        for (let s = 1; s <= 5; s++) {
          const t = s / 5;
          const mt = 1 - t;
          currentPoly.push({
            x: mt * mt * curX + 2 * mt * t * x1 + t * t * x,
            y: mt * mt * curY + 2 * mt * t * y1 + t * t * y,
          });
        }
        curX = x;
        curY = y;
      } else {
        idx++;
      }
    }
    flushPoly();
  }

  return polylines;
}

function normalizeAndScalePolylines(
  rawPolylines: Point[][],
  targetWidthMm: number,
  centerX: number,
  centerY: number
): { polylines: Point[][]; width: number; height: number } {
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;

  for (const poly of rawPolylines) {
    for (const pt of poly) {
      if (pt.x < minX) minX = pt.x;
      if (pt.x > maxX) maxX = pt.x;
      if (pt.y < minY) minY = pt.y;
      if (pt.y > maxY) maxY = pt.y;
    }
  }

  const rawW = Math.max(1e-3, maxX - minX);
  const rawH = Math.max(1e-3, maxY - minY);
  const scale = targetWidthMm / rawW;
  const scaledW = Number((rawW * scale).toFixed(2));
  const scaledH = Number((rawH * scale).toFixed(2));
  const startX = centerX - scaledW / 2;
  const startY = centerY - scaledH / 2;

  const polylines = rawPolylines.map((poly) =>
    poly.map((pt) => ({
      x: Number((startX + (pt.x - minX) * scale).toFixed(3)),
      y: Number((startY + (pt.y - minY) * scale).toFixed(3)),
    }))
  );

  return { polylines, width: scaledW, height: scaledH };
}

export function insertSvgIntoProject(
  project: Project,
  options: SvgInsertOptions
): { project: Project; summary: string } {
  const bounds = getBoardBounds(project);
  const cx = options.offsetX ?? bounds.centerX;
  const cy = options.offsetY ?? bounds.centerY;

  let rawPolys = options.svgText
    ? parseSvgStringToPolylines(options.svgText)
    : [];
  if (rawPolys.length === 0) {
    rawPolys = getPresetPolylines(options.preset || 'oshw_gear');
  }

  const { polylines, width, height } = normalizeAndScalePolylines(
    rawPolys,
    Math.max(2, options.sizeMm),
    cx,
    cy
  );

  const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');
  if (!pcbSheet) return { project, summary: 'No PCB sheet found' };

  let nextItems: AnyItem[] = [...pcbSheet.items];

  if (options.targetLayer === 'Edge.Cuts') {
    const longestPoly = [...polylines].sort((a, b) => b.length - a.length)[0] || [];
    if (longestPoly.length >= 3) {
      let minX = Infinity;
      let minY = Infinity;
      let maxX = -Infinity;
      let maxY = -Infinity;
      for (const pt of longestPoly) {
        if (pt.x < minX) minX = pt.x;
        if (pt.x > maxX) maxX = pt.x;
        if (pt.y < minY) minY = pt.y;
        if (pt.y > maxY) maxY = pt.y;
      }
      nextItems = nextItems.map((item) =>
        item.type === 'pcb_outline'
          ? {
              ...item,
              transform: { ...item.transform, x: minX, y: minY },
              props: {
                ...item.props,
                width: Number((maxX - minX).toFixed(2)),
                height: Number((maxY - minY).toFixed(2)),
                points: longestPoly,
              },
            }
          : item
      );
    }
    return {
      project: {
        ...project,
        sheets: project.sheets.map((s) =>
          s.kind === 'pcb' ? { ...s, items: nextItems } : s
        ),
      },
      summary: `Applied SVG contour (${longestPoly.length} vertices) to Edge.Cuts`,
    };
  }

  if (options.targetLayer === 'F.SilkS') {
    // Add silkscreen graphic footprint + copper/silk strokes
    const logoIdx =
      nextItems.filter((i) => i.type === 'pcb_footprint' && i.props.refDes.startsWith('G')).length + 1;
    const fp: PcbFootprintItem = {
      id: `fp_svg_${Date.now()}`,
      type: 'pcb_footprint',
      transform: { x: cx, y: cy, rotation: 0, layer: 'F.Cu' },
      props: {
        refDes: `G${logoIdx}`,
        value: options.preset ? options.preset.toUpperCase() : 'SVG_LOGO',
        footprintName: `Silkscreen:SVG_${width.toFixed(1)}x${height.toFixed(1)}mm`,
        courtyard: { width: Math.max(2, width), height: Math.max(2, height) },
        pads: [],
      },
    };
    nextItems.push(fp);
  }

  const traceLayer: 'F.Cu' | 'B.Cu' =
    options.targetLayer === 'B.Cu' ? 'B.Cu' : 'F.Cu';
  for (let i = 0; i < polylines.length; i++) {
    const pts = polylines[i];
    if (pts.length < 2) continue;
    const tr: PcbTraceItem = {
      id: `tr_svg_${Date.now()}_${i}`,
      type: 'pcb_trace',
      transform: { x: 0, y: 0, rotation: 0, layer: traceLayer },
      props: {
        points: pts,
        width: Math.max(0.15, options.traceWidthMm),
        net: '',
      },
    };
    nextItems.push(tr);
  }

  return {
    project: {
      ...project,
      sheets: project.sheets.map((s) =>
        s.kind === 'pcb' ? { ...s, items: nextItems } : s
      ),
    },
    summary: `Inserted SVG geometry (${polylines.length} paths, ${width.toFixed(1)}×${height.toFixed(1)} mm) on ${options.targetLayer}`,
  };
}

// ============================================================================
// 2. DXF CAD OUTLINE -> BOARD SHAPE, COPPER, OR MILLING
// ============================================================================

export interface DxfInsertOptions {
  dxfText?: string;
  preset?: 'arduino_shield' | 'rpi_hat' | 'eurocard_100x80' | 'm2_card_edge' | 'flanged_enclosure';
  targetLayer: 'Edge.Cuts' | 'F.Cu' | 'B.Cu';
  scaleFactor?: number;
}

function getDxfPresetPolygon(
  preset: NonNullable<DxfInsertOptions['preset']>,
  startX: number,
  startY: number
): Point[] {
  if (preset === 'arduino_shield') {
    // Classic Arduino Uno notched board contour (68.6 x 53.3 mm)
    return [
      { x: startX, y: startY },
      { x: startX + 66.0, y: startY },
      { x: startX + 68.6, y: startY + 2.6 },
      { x: startX + 68.6, y: startY + 38.0 },
      { x: startX + 66.0, y: startY + 40.6 },
      { x: startX + 66.0, y: startY + 50.8 },
      { x: startX + 63.5, y: startY + 53.3 },
      { x: startX, y: startY + 53.3 },
    ];
  }
  if (preset === 'rpi_hat') {
    // Raspberry Pi HAT 65 x 56 mm with camera/display slot notch
    return [
      { x: startX, y: startY },
      { x: startX + 65, y: startY },
      { x: startX + 65, y: startY + 56 },
      { x: startX + 45, y: startY + 56 },
      { x: startX + 45, y: startY + 42 },
      { x: startX + 42, y: startY + 42 },
      { x: startX + 42, y: startY + 56 },
      { x: startX, y: startY + 56 },
    ];
  }
  if (preset === 'm2_card_edge') {
    // M.2 2242 Key-M card outline with semicircular mounting notch at top
    return [
      { x: startX, y: startY },
      { x: startX + 8.5, y: startY },
      { x: startX + 9.5, y: startY + 1.8 },
      { x: startX + 12.5, y: startY + 1.8 },
      { x: startX + 13.5, y: startY },
      { x: startX + 22, y: startY },
      { x: startX + 22, y: startY + 42 },
      { x: startX, y: startY + 42 },
    ];
  }
  if (preset === 'flanged_enclosure') {
    // Mounting flange tabs on left and right sides
    return [
      { x: startX + 6, y: startY },
      { x: startX + 46, y: startY },
      { x: startX + 46, y: startY + 10 },
      { x: startX + 52, y: startY + 10 },
      { x: startX + 52, y: startY + 26 },
      { x: startX + 46, y: startY + 26 },
      { x: startX + 46, y: startY + 36 },
      { x: startX + 6, y: startY + 36 },
      { x: startX + 6, y: startY + 26 },
      { x: startX, y: startY + 26 },
      { x: startX, y: startY + 10 },
      { x: startX + 6, y: startY + 10 },
    ];
  }
  // Eurocard 80 x 50 mm chamfered
  return [
    { x: startX + 3, y: startY },
    { x: startX + 77, y: startY },
    { x: startX + 80, y: startY + 3 },
    { x: startX + 80, y: startY + 47 },
    { x: startX + 77, y: startY + 50 },
    { x: startX + 3, y: startY + 50 },
    { x: startX, y: startY + 47 },
    { x: startX, y: startY + 3 },
  ];
}

function parseDxfTextToPolylines(dxfText: string, scale = 1): Point[][] {
  const lines = dxfText.replace(/\r\n/g, '\n').split('\n').map((l) => l.trim());
  const polylines: Point[][] = [];
  let i = 0;

  let currentEntity = '';
  let lwPoints: Point[] = [];
  let pendingX: number | null = null;
  let lineX1 = 0;
  let lineY1 = 0;
  let lineX2 = 0;
  let lineY2 = 0;

  const flushEntity = () => {
    if (currentEntity === 'LWPOLYLINE' && lwPoints.length >= 2) {
      polylines.push([...lwPoints]);
    } else if (currentEntity === 'LINE') {
      if (Math.hypot(lineX2 - lineX1, lineY2 - lineY1) > 1e-3) {
        polylines.push([
          { x: lineX1 * scale, y: lineY1 * scale },
          { x: lineX2 * scale, y: lineY2 * scale },
        ]);
      }
    }
    lwPoints = [];
    pendingX = null;
  };

  while (i + 1 < lines.length) {
    const code = parseInt(lines[i], 10);
    const val = lines[i + 1];
    i += 2;

    if (code === 0) {
      flushEntity();
      currentEntity = val.toUpperCase();
      continue;
    }

    if (currentEntity === 'LWPOLYLINE' || currentEntity === 'VERTEX') {
      if (code === 10) {
        pendingX = parseFloat(val) * scale;
      } else if (code === 20 && pendingX !== null) {
        lwPoints.push({ x: pendingX, y: parseFloat(val) * scale });
        pendingX = null;
      }
    } else if (currentEntity === 'LINE') {
      if (code === 10) lineX1 = parseFloat(val);
      else if (code === 20) lineY1 = parseFloat(val);
      else if (code === 11) lineX2 = parseFloat(val);
      else if (code === 21) lineY2 = parseFloat(val);
    }
  }
  flushEntity();

  // Chain connected 2-point LINE segments into closed polygon if possible
  if (polylines.length > 2 && polylines.every((p) => p.length === 2)) {
    const ordered: Point[] = [polylines[0][0], polylines[0][1]];
    const used = new Set<number>([0]);
    while (used.size < polylines.length) {
      const last = ordered[ordered.length - 1];
      let foundIdx = -1;
      let nextPt: Point | null = null;
      for (let j = 0; j < polylines.length; j++) {
        if (used.has(j)) continue;
        const [a, b] = polylines[j];
        if (Math.hypot(a.x - last.x, a.y - last.y) < 0.5) {
          foundIdx = j;
          nextPt = b;
          break;
        }
        if (Math.hypot(b.x - last.x, b.y - last.y) < 0.5) {
          foundIdx = j;
          nextPt = a;
          break;
        }
      }
      if (foundIdx === -1 || !nextPt) break;
      used.add(foundIdx);
      ordered.push(nextPt);
    }
    if (ordered.length >= 3) {
      return [ordered];
    }
  }

  return polylines;
}

export function insertDxfIntoProject(
  project: Project,
  options: DxfInsertOptions
): { project: Project; summary: string } {
  const bounds = getBoardBounds(project);
  const scale = options.scaleFactor || 1;
  const parsed = options.dxfText ? parseDxfTextToPolylines(options.dxfText, scale) : [];

  const poly =
    parsed.length > 0 && parsed[0].length >= 3
      ? parsed[0]
      : getDxfPresetPolygon(options.preset || 'arduino_shield', bounds.x, bounds.y);

  const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');
  if (!pcbSheet) return { project, summary: 'No PCB sheet found' };

  if (options.targetLayer === 'Edge.Cuts') {
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    for (const pt of poly) {
      if (pt.x < minX) minX = pt.x;
      if (pt.x > maxX) maxX = pt.x;
      if (pt.y < minY) minY = pt.y;
      if (pt.y > maxY) maxY = pt.y;
    }
    const width = Number(Math.max(4, maxX - minX).toFixed(2));
    const height = Number(Math.max(4, maxY - minY).toFixed(2));

    const nextItems = pcbSheet.items.map((item) =>
      item.type === 'pcb_outline'
        ? {
            ...item,
            transform: { ...item.transform, x: minX, y: minY },
            props: {
              ...item.props,
              width,
              height,
              cornerRadius: 0,
              points: poly,
            },
          }
        : item
    );

    return {
      project: {
        ...project,
        sheets: project.sheets.map((s) =>
          s.kind === 'pcb' ? { ...s, items: nextItems } : s
        ),
      },
      summary: `Applied DXF CAD outline (${poly.length} vertices, ${width}×${height} mm) to Edge.Cuts`,
    };
  }

  // Copper layer trace
  const closedPoly = [...poly, poly[0]];
  const trace: PcbTraceItem = {
    id: `tr_dxf_${Date.now()}`,
    type: 'pcb_trace',
    transform: { x: 0, y: 0, rotation: 0, layer: options.targetLayer },
    props: {
      points: closedPoly,
      width: 0.35,
      net: '',
    },
  };

  return {
    project: {
      ...project,
      sheets: project.sheets.map((s) =>
        s.kind === 'pcb' ? { ...s, items: [...s.items, trace] } : s
      ),
    },
    summary: `Inserted DXF CAD polyline (${poly.length} points) onto ${options.targetLayer}`,
  };
}

// ============================================================================
// 3. PHOTO OVERLAY REFERENCE IMAGE GENERATOR
// ============================================================================

export function createSampleBoardPhotoDataUrl(): string {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="440" height="320" viewBox="0 0 440 320">
    <rect width="440" height="320" rx="18" fill="#0d4a29" stroke="#d4af37" stroke-width="6"/>
    <circle cx="24" cy="24" r="10" fill="#071a10" stroke="#eab308" stroke-width="5"/>
    <circle cx="416" cy="24" r="10" fill="#071a10" stroke="#eab308" stroke-width="5"/>
    <circle cx="24" cy="296" r="10" fill="#071a10" stroke="#eab308" stroke-width="5"/>
    <circle cx="416" cy="296" r="10" fill="#071a10" stroke="#eab308" stroke-width="5"/>
    <path d="M 60 80 L 160 80 L 195 115 L 340 115" fill="none" stroke="#1ec96b" stroke-width="8" stroke-linecap="round"/>
    <path d="M 60 160 L 145 160 L 185 200 L 360 200" fill="none" stroke="#1ec96b" stroke-width="8" stroke-linecap="round"/>
    <path d="M 90 245 L 260 245 L 300 160 L 380 160" fill="none" stroke="#1ec96b" stroke-width="6" stroke-linecap="round"/>
    <rect x="175" y="95" width="70" height="50" fill="#18181b" stroke="#f8fafc" stroke-width="2"/>
    <text x="210" y="125" font-family="monospace" font-size="13" fill="#ffffff" text-anchor="middle">U1 MCU</text>
    <rect x="44" y="68" width="24" height="24" rx="4" fill="#d4af37"/>
    <rect x="44" y="148" width="24" height="24" rx="4" fill="#d4af37"/>
    <rect x="340" y="103" width="24" height="24" rx="4" fill="#d4af37"/>
    <rect x="350" y="188" width="24" height="24" rx="4" fill="#d4af37"/>
    <text x="220" y="295" font-family="monospace" font-size="12" fill="#a7f3d0" text-anchor="middle">REFERENCE PHOTO OVERLAY — TRACE OVER BOARD</text>
  </svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

// ============================================================================
// 4. PCB ANTENNA GENERATOR (MIFA / MEANDER MONOPOLE FOR TARGET FREQUENCY)
// ============================================================================

export interface AntennaGeneratorOptions {
  frequencyMhz: number; // e.g., 2450, 915, 868, 433
  topology: 'mifa' | 'meander_monopole' | 'inverted_f';
  layer: 'F.Cu' | 'B.Cu';
  traceWidthMm: number;
  er?: number; // Substrate dielectric constant, default 4.4 (FR-4)
}

export function computeAntennaMetrics(options: AntennaGeneratorOptions): {
  wavelengthFreeSpaceMm: number;
  quarterWaveEffectiveMm: number;
  widthMm: number;
  heightMm: number;
  bandwidthEstimateMhz: number;
} {
  const freq = Math.max(100, Math.min(10000, options.frequencyMhz || 2450));
  const er = options.er || 4.4;
  const erEff = (er + 1) / 2;
  const lambda0 = 299792.458 / freq; // mm
  const quarterWaveEff = lambda0 / (4 * Math.sqrt(erEff));
  const widthMm = Number(Math.max(8, Math.min(28, quarterWaveEff * 0.65)).toFixed(2));
  const heightMm = Number(Math.max(5.5, Math.min(16, quarterWaveEff * 0.34)).toFixed(2));
  const bw = Math.round(freq * (options.topology === 'mifa' ? 0.045 : 0.038));

  return {
    wavelengthFreeSpaceMm: Number(lambda0.toFixed(1)),
    quarterWaveEffectiveMm: Number(quarterWaveEff.toFixed(2)),
    widthMm,
    heightMm,
    bandwidthEstimateMhz: bw,
  };
}

export function generatePcbAntenna(
  project: Project,
  options: AntennaGeneratorOptions
): { project: Project; summary: string } {
  const metrics = computeAntennaMetrics(options);
  const bounds = getBoardBounds(project);
  const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');
  if (!pcbSheet) return { project, summary: 'No PCB sheet found' };

  const antCount =
    pcbSheet.items.filter((i) => i.type === 'pcb_footprint' && i.props.refDes.startsWith('ANT'))
      .length + 1;
  const refDes = `ANT${antCount}`;

  // Place antenna near top edge of board for best RF radiation clearance
  const centerX = snapPoint({ x: bounds.centerX, y: bounds.y + metrics.heightMm / 2 + 2.5 }, PCB_GRID).x;
  const centerY = snapPoint({ x: bounds.centerX, y: bounds.y + metrics.heightMm / 2 + 2.5 }, PCB_GRID).y;

  const w = metrics.widthMm;
  const h = metrics.heightMm;
  const left = centerX - w / 2;
  const top = centerY - h / 2;
  const bottom = centerY + h / 2;

  const feedPadX = Number((left + 2.0).toFixed(3));
  const gndPadX = Number((left + 4.2).toFixed(3));
  const padY = Number(bottom.toFixed(3));

  const pads: PadDef[] = [
    {
      number: '1',
      offset: { x: Number((feedPadX - centerX).toFixed(3)), y: Number((padY - centerY).toFixed(3)) },
      width: 1.1,
      height: 1.5,
      shape: 'rect',
      layers: [options.layer],
      net: 'RF_FEED',
    },
  ];

  if (options.topology !== 'meander_monopole') {
    pads.push({
      number: '2',
      offset: { x: Number((gndPadX - centerX).toFixed(3)), y: Number((padY - centerY).toFixed(3)) },
      width: 1.1,
      height: 1.5,
      shape: 'rect',
      layers: [options.layer],
      net: 'GND',
    });
  }

  const fp: PcbFootprintItem = {
    id: `fp_${refDes}_${Date.now()}`,
    type: 'pcb_footprint',
    transform: { x: centerX, y: centerY, rotation: 0, layer: options.layer },
    props: {
      refDes,
      value: `${options.frequencyMhz}MHz_${options.topology.toUpperCase()}`,
      footprintName: `RF_Antenna:PCB_${options.topology.toUpperCase()}_${options.frequencyMhz}MHz`,
      courtyard: { width: Number((w + 1.5).toFixed(2)), height: Number((h + 2.0).toFixed(2)) },
      pads,
    },
  };

  // Synthesize meandered radiator trace matching target effective quarter-wavelength
  const meanderPts: Point[] = [{ x: feedPadX, y: padY }];
  meanderPts.push({ x: feedPadX, y: top + 0.6 });

  const numFingers = options.frequencyMhz < 1000 ? 7 : 4;
  const startFingerX = feedPadX + 1.8;
  const endFingerX = left + w - 0.8;
  const stepX = (endFingerX - startFingerX) / Math.max(1, numFingers);

  for (let i = 0; i < numFingers; i++) {
    const xA = Number((startFingerX + i * stepX).toFixed(3));
    const xB = Number((startFingerX + (i + 1) * stepX).toFixed(3));
    const yHigh = Number((top + 0.6).toFixed(3));
    const yLow = Number((bottom - 1.4).toFixed(3));
    if (i % 2 === 0) {
      meanderPts.push({ x: xA, y: yHigh });
      meanderPts.push({ x: xA, y: yLow });
      meanderPts.push({ x: xB, y: yLow });
    } else {
      meanderPts.push({ x: xA, y: yLow });
      meanderPts.push({ x: xA, y: yHigh });
      meanderPts.push({ x: xB, y: yHigh });
    }
  }

  const mainTrace: PcbTraceItem = {
    id: `tr_${refDes}_radiator_${Date.now()}`,
    type: 'pcb_trace',
    transform: { x: 0, y: 0, rotation: 0, layer: options.layer },
    props: {
      points: meanderPts,
      width: Math.max(0.25, options.traceWidthMm),
      net: 'RF_FEED',
    },
  };

  const newItems: AnyItem[] = [fp, mainTrace];

  if (options.topology !== 'meander_monopole') {
    // Add MIFA / IFA ground shorting stub
    const stubTrace: PcbTraceItem = {
      id: `tr_${refDes}_stub_${Date.now()}`,
      type: 'pcb_trace',
      transform: { x: 0, y: 0, rotation: 0, layer: options.layer },
      props: {
        points: [
          { x: gndPadX, y: padY },
          { x: gndPadX, y: Number((top + 1.8).toFixed(3)) },
          { x: feedPadX, y: Number((top + 1.8).toFixed(3)) },
        ],
        width: Math.max(0.25, options.traceWidthMm),
        net: 'GND',
      },
    };
    newItems.push(stubTrace);
  }

  return {
    project: {
      ...project,
      sheets: project.sheets.map((s) =>
        s.kind === 'pcb' ? { ...s, items: [...s.items, ...newItems] } : s
      ),
    },
    summary: `Generated ${options.frequencyMhz} MHz ${options.topology.toUpperCase()} PCB antenna (${refDes}, λ/4 = ${metrics.quarterWaveEffectiveMm} mm)`,
  };
}

// ============================================================================
// 5. PLANAR SPIRAL COIL INDUCTOR GENERATOR WITH REAL-TIME INDUCTANCE FORMULA
// ============================================================================

export interface PlanarCoilOptions {
  turns: number; // N
  traceWidthMm: number; // w
  spacingMm: number; // s
  innerDiameterMm: number; // din
  shape: 'square' | 'octagonal' | 'circular';
  layer: 'F.Cu' | 'B.Cu';
}

export interface PlanarCoilMetrics {
  inductanceNh: number;
  inductanceUh: number;
  outerDiameterMm: number;
  totalLengthMm: number;
  dcResistanceOhm: number;
}

/**
 * Modified Wheeler / Mohan Planar Spiral Inductance Formula:
 * L = (K1 * mu0 * N^2 * d_avg) / (1 + K2 * rho)
 */
export function computePlanarCoilMetrics(options: PlanarCoilOptions): PlanarCoilMetrics {
  const N = Math.max(1, Math.min(40, options.turns));
  const w = Math.max(0.12, options.traceWidthMm);
  const s = Math.max(0.12, options.spacingMm);
  const dIn = Math.max(1.0, options.innerDiameterMm);
  const dOut = dIn + 2 * N * w + 2 * (N - 1) * s;
  const dAvg = (dOut + dIn) / 2;
  const rho = (dOut - dIn) / (dOut + dIn);

  const coeffs: Record<PlanarCoilOptions['shape'], { k1: number; k2: number; perimFactor: number }> = {
    square: { k1: 2.34, k2: 2.75, perimFactor: 4.0 },
    octagonal: { k1: 2.25, k2: 3.55, perimFactor: 3.31 },
    circular: { k1: 2.23, k2: 3.45, perimFactor: Math.PI },
  };

  const { k1, k2, perimFactor } = coeffs[options.shape];
  const mu0 = 4 * Math.PI * 1e-7; // H/m
  const dAvgMeters = dAvg * 1e-3;
  const inductanceHenries = (k1 * mu0 * N * N * dAvgMeters) / (1 + k2 * rho);
  const inductanceNh = Number((inductanceHenries * 1e9).toFixed(1));
  const inductanceUh = Number((inductanceHenries * 1e6).toFixed(3));

  const totalLengthMm = Number((N * dAvg * perimFactor).toFixed(1));
  // 1 oz copper thickness = 0.035 mm, resistivity rho_Cu = 1.68e-8 Ohm*m
  const crossSectionMm2 = w * 0.035;
  const dcResistanceOhm = Number(((0.0172 * (totalLengthMm / 1000)) / crossSectionMm2).toFixed(3));

  return {
    inductanceNh,
    inductanceUh,
    outerDiameterMm: Number(dOut.toFixed(2)),
    totalLengthMm,
    dcResistanceOhm,
  };
}

export function generatePlanarSpiralCoil(
  project: Project,
  options: PlanarCoilOptions
): { project: Project; summary: string } {
  const metrics = computePlanarCoilMetrics(options);
  const bounds = getBoardBounds(project);
  const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');
  if (!pcbSheet) return { project, summary: 'No PCB sheet found' };

  const coilCount =
    pcbSheet.items.filter((i) => i.type === 'pcb_footprint' && i.props.refDes.startsWith('L'))
      .length + 1;
  const refDes = `L${coilCount}`;
  const cx = bounds.centerX;
  const cy = bounds.centerY;

  const pitch = options.traceWidthMm + options.spacingMm;
  const rInner = options.innerDiameterMm / 2;
  const spiralPts: Point[] = [];

  const stepsPerTurn =
    options.shape === 'square' ? 4 : options.shape === 'octagonal' ? 8 : 24;
  const totalSteps = Math.round(options.turns * stepsPerTurn);

  for (let step = 0; step <= totalSteps; step++) {
    const turnFraction = step / stepsPerTurn;
    const r = rInner + turnFraction * pitch;
    const angle = (step / stepsPerTurn) * Math.PI * 2;

    if (options.shape === 'square') {
      const idx = step % 4;
      const sx = idx === 0 || idx === 1 ? r : -r;
      const sy = idx === 1 || idx === 2 ? r : -r;
      spiralPts.push({
        x: Number((cx + sx).toFixed(3)),
        y: Number((cy + sy).toFixed(3)),
      });
    } else {
      spiralPts.push({
        x: Number((cx + Math.cos(angle) * r).toFixed(3)),
        y: Number((cy + Math.sin(angle) * r).toFixed(3)),
      });
    }
  }

  const startPt = spiralPts[0];
  const endPt = spiralPts[spiralPts.length - 1];
  const outerPadPt = {
    x: Number((endPt.x + 1.4).toFixed(3)),
    y: Number(endPt.y.toFixed(3)),
  };
  spiralPts.push(outerPadPt);

  // Add return bridge on opposite copper layer from center via to outer terminal pad 2
  const oppositeLayer: 'F.Cu' | 'B.Cu' = options.layer === 'F.Cu' ? 'B.Cu' : 'F.Cu';
  const innerReturnPadPt = {
    x: Number((cx - metrics.outerDiameterMm / 2 - 1.4).toFixed(3)),
    y: Number(cy.toFixed(3)),
  };

  const fp: PcbFootprintItem = {
    id: `fp_${refDes}_${Date.now()}`,
    type: 'pcb_footprint',
    transform: { x: cx, y: cy, rotation: 0, layer: options.layer },
    props: {
      refDes,
      value:
        metrics.inductanceNh >= 1000
          ? `${metrics.inductanceUh}uH`
          : `${metrics.inductanceNh}nH`,
      footprintName: `Inductor_PCB:Planar_${options.shape}_${options.turns}T_${metrics.outerDiameterMm}mm`,
      courtyard: {
        width: Number((metrics.outerDiameterMm + 3.6).toFixed(2)),
        height: Number((metrics.outerDiameterMm + 2.0).toFixed(2)),
      },
      pads: [
        {
          number: '1',
          offset: {
            x: Number((outerPadPt.x - cx).toFixed(3)),
            y: Number((outerPadPt.y - cy).toFixed(3)),
          },
          width: 1.2,
          height: 1.2,
          shape: 'rect',
          layers: [options.layer],
          net: `${refDes}_P1`,
        },
        {
          number: '2',
          offset: {
            x: Number((innerReturnPadPt.x - cx).toFixed(3)),
            y: Number((innerReturnPadPt.y - cy).toFixed(3)),
          },
          width: 1.2,
          height: 1.2,
          shape: 'rect',
          layers: ['F.Cu', 'B.Cu'],
          drill: 0.5,
          net: `${refDes}_P2`,
        },
      ],
    },
  };

  const spiralTrace: PcbTraceItem = {
    id: `tr_${refDes}_spiral_${Date.now()}`,
    type: 'pcb_trace',
    transform: { x: 0, y: 0, rotation: 0, layer: options.layer },
    props: {
      points: spiralPts,
      width: options.traceWidthMm,
      net: `${refDes}_P1`,
    },
  };

  const centerVia: PcbViaItem = {
    id: `via_${refDes}_center_${Date.now()}`,
    type: 'pcb_via',
    transform: { x: startPt.x, y: startPt.y, rotation: 0, layer: 'F.Cu' },
    props: {
      diameter: Math.max(0.7, options.traceWidthMm * 2),
      drill: 0.35,
      net: `${refDes}_P2`,
    },
  };

  const returnBridge: PcbTraceItem = {
    id: `tr_${refDes}_return_${Date.now()}`,
    type: 'pcb_trace',
    transform: { x: 0, y: 0, rotation: 0, layer: oppositeLayer },
    props: {
      points: [startPt, innerReturnPadPt],
      width: options.traceWidthMm,
      net: `${refDes}_P2`,
    },
  };

  return {
    project: {
      ...project,
      sheets: project.sheets.map((s) =>
        s.kind === 'pcb'
          ? { ...s, items: [...s.items, fp, spiralTrace, centerVia, returnBridge] }
          : s
      ),
    },
    summary: `Generated ${options.turns}-turn planar coil ${refDes} (${
      metrics.inductanceNh >= 1000 ? `${metrics.inductanceUh} µH` : `${metrics.inductanceNh} nH`
    }, Rdc=${metrics.dcResistanceOhm} Ω)`,
  };
}

// ============================================================================
// 6. QR / DATA MATRIX / BARCODE GENERATOR IN SILK OR COPPER
// ============================================================================

export interface QrBarcodeOptions {
  text: string;
  format: 'qr' | 'datamatrix' | 'barcode128';
  sizeMm: number;
  layer: 'F.SilkS' | 'F.Cu' | 'B.Cu';
}

export function buildMatrixForText(
  text: string,
  format: QrBarcodeOptions['format']
): boolean[][] {
  const clean = text.trim() || 'POCKETEDA-REV1';
  if (format === 'barcode128') {
    // 1D Barcode rendered as tall vertical bars
    const cols: boolean[] = [true, true, false, true, false, true, true, false];
    for (let i = 0; i < clean.length; i++) {
      const code = clean.charCodeAt(i);
      for (let b = 6; b >= 0; b--) {
        cols.push(((code >> b) & 1) === 1);
      }
      cols.push(i % 2 === 0);
    }
    cols.push(true, false, true, true, false, true, true);
    const rows = 12;
    return Array.from({ length: rows }, () => [...cols]);
  }

  const N = format === 'datamatrix' ? 14 : 15;
  const grid: boolean[][] = Array.from({ length: N }, () =>
    Array.from({ length: N }, () => false)
  );

  if (format === 'datamatrix') {
    // Data Matrix L-finder border + alternating clock track
    for (let i = 0; i < N; i++) {
      grid[N - 1][i] = true; // Solid bottom
      grid[i][0] = true; // Solid left
      grid[0][i] = i % 2 === 0; // Alternating top
      grid[i][N - 1] = i % 2 === 1; // Alternating right
    }
    let bitIdx = 0;
    for (let r = 2; r < N - 2; r++) {
      for (let c = 2; c < N - 2; c++) {
        const ch = clean.charCodeAt(bitIdx % clean.length);
        grid[r][c] = ((ch >> (bitIdx % 7)) & 1) === 1 || (r + c + ch) % 3 === 0;
        bitIdx++;
      }
    }
    return grid;
  }

  // QR Matrix with 3 standard 5x5 finder patterns + timing lines + encoded payload
  const drawFinder = (r0: number, c0: number) => {
    for (let r = 0; r < 5; r++) {
      for (let c = 0; c < 5; c++) {
        const isBorder = r === 0 || r === 4 || c === 0 || c === 4;
        const isCenter = r === 2 && c === 2;
        grid[r0 + r][c0 + c] = isBorder || isCenter;
      }
    }
  };
  drawFinder(0, 0);
  drawFinder(0, N - 5);
  drawFinder(N - 5, 0);

  for (let i = 5; i < N - 5; i++) {
    grid[4][i] = i % 2 === 0;
    grid[i][4] = i % 2 === 0;
  }

  let bitIdx = 0;
  for (let r = 0; r < N; r++) {
    for (let c = 0; c < N; c++) {
      const inTopLeft = r < 6 && c < 6;
      const inTopRight = r < 6 && c >= N - 6;
      const inBotLeft = r >= N - 6 && c < 6;
      if (inTopLeft || inTopRight || inBotLeft || r === 4 || c === 4) continue;
      const ch = clean.charCodeAt(bitIdx % clean.length);
      grid[r][c] = (((ch + bitIdx * 17) >> (bitIdx % 6)) & 1) === 1;
      bitIdx++;
    }
  }

  return grid;
}

export function generateQrOrBarcode(
  project: Project,
  options: QrBarcodeOptions
): { project: Project; summary: string } {
  const bounds = getBoardBounds(project);
  const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');
  if (!pcbSheet) return { project, summary: 'No PCB sheet found' };

  const matrix = buildMatrixForText(options.text, options.format);
  const rows = matrix.length;
  const cols = matrix[0]?.length || 1;
  const totalW = Math.max(4, options.sizeMm);
  const totalH =
    options.format === 'barcode128' ? Number((totalW * 0.45).toFixed(2)) : totalW;
  const cellW = totalW / cols;
  const cellH = totalH / rows;

  const cx = bounds.centerX;
  const cy = bounds.centerY;
  const startX = cx - totalW / 2;
  const startY = cy - totalH / 2;

  const qrCount =
    pcbSheet.items.filter((i) => i.type === 'pcb_footprint' && i.props.refDes.startsWith('QR'))
      .length + 1;
  const refDes = `QR${qrCount}`;
  const padLayer: 'F.Cu' | 'B.Cu' = options.layer === 'B.Cu' ? 'B.Cu' : 'F.Cu';

  // Build horizontal run-length trace segments + footprint courtyard
  const newTraces: PcbTraceItem[] = [];
  for (let r = 0; r < rows; r++) {
    let runStartCol: number | null = null;
    for (let c = 0; c <= cols; c++) {
      const active = c < cols ? matrix[r][c] : false;
      if (active && runStartCol === null) {
        runStartCol = c;
      } else if (!active && runStartCol !== null) {
        const x1 = Number((startX + runStartCol * cellW + cellW * 0.25).toFixed(3));
        const x2 = Number((startX + (c - 1) * cellW + cellW * 0.75).toFixed(3));
        const y = Number((startY + (r + 0.5) * cellH).toFixed(3));
        newTraces.push({
          id: `tr_${refDes}_${r}_${runStartCol}_${Date.now()}`,
          type: 'pcb_trace',
          transform: { x: 0, y: 0, rotation: 0, layer: padLayer },
          props: {
            points: [
              { x: x1, y },
              { x: Math.max(x1 + 0.08, x2), y },
            ],
            width: Number(Math.max(0.15, cellH * 0.82).toFixed(3)),
            net: '',
          },
        });
        runStartCol = null;
      }
    }
  }

  const fp: PcbFootprintItem = {
    id: `fp_${refDes}_${Date.now()}`,
    type: 'pcb_footprint',
    transform: { x: cx, y: cy, rotation: 0, layer: padLayer },
    props: {
      refDes,
      value: options.text.slice(0, 18) || 'QR_CODE',
      footprintName: `Marking:${options.format.toUpperCase()}_${totalW.toFixed(1)}mm`,
      courtyard: {
        width: Number((totalW + 1.2).toFixed(2)),
        height: Number((totalH + 1.2).toFixed(2)),
      },
      pads: [],
    },
  };

  return {
    project: {
      ...project,
      sheets: project.sheets.map((s) =>
        s.kind === 'pcb' ? { ...s, items: [...s.items, fp, ...newTraces] } : s
      ),
    },
    summary: `Generated ${options.format.toUpperCase()} "${options.text}" (${totalW}×${totalH} mm) on ${options.layer}`,
  };
}

// ============================================================================
// 7. MOUNTING HOLES GENERATOR (CORNER OR CUSTOM WITH SCREW KEEP-OUT)
// ============================================================================

export interface MountingHoleOptions {
  screwStandard: 'M2' | 'M2.5' | 'M3' | 'M4' | 'custom';
  drillMm: number;
  keepoutDiameterMm: number;
  placement: 'corners_4' | 'corners_2' | 'single_center';
  cornerInsetMm: number;
  platedGrounded: boolean;
}

export const SCREW_PRESETS: Record<
  Exclude<MountingHoleOptions['screwStandard'], 'custom'>,
  { drillMm: number; keepoutDiameterMm: number; label: string }
> = {
  M2: { drillMm: 2.2, keepoutDiameterMm: 4.4, label: 'M2 (2.2mm drill / 4.4mm head)' },
  'M2.5': { drillMm: 2.7, keepoutDiameterMm: 5.4, label: 'M2.5 (2.7mm drill / 5.4mm head)' },
  M3: { drillMm: 3.2, keepoutDiameterMm: 6.4, label: 'M3 (3.2mm drill / 6.4mm head)' },
  M4: { drillMm: 4.3, keepoutDiameterMm: 8.4, label: 'M4 (4.3mm drill / 8.4mm head)' },
};

export function generateMountingHoles(
  project: Project,
  options: MountingHoleOptions
): { project: Project; summary: string } {
  const bounds = getBoardBounds(project);
  const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');
  if (!pcbSheet) return { project, summary: 'No PCB sheet found' };

  const inset = Math.max(2.0, options.cornerInsetMm);
  const positions: Point[] =
    options.placement === 'corners_4'
      ? [
          { x: bounds.x + inset, y: bounds.y + inset },
          { x: bounds.x + bounds.width - inset, y: bounds.y + inset },
          { x: bounds.x + inset, y: bounds.y + bounds.height - inset },
          { x: bounds.x + bounds.width - inset, y: bounds.y + bounds.height - inset },
        ]
      : options.placement === 'corners_2'
        ? [
            { x: bounds.x + inset, y: bounds.y + inset },
            { x: bounds.x + bounds.width - inset, y: bounds.y + bounds.height - inset },
          ]
        : [{ x: bounds.centerX, y: bounds.centerY }];

  const existingMhCount = pcbSheet.items.filter(
    (i) => i.type === 'pcb_footprint' && i.props.refDes.startsWith('MH')
  ).length;

  const newHoles: PcbFootprintItem[] = positions.map((pos, idx) => {
    const refDes = `MH${existingMhCount + idx + 1}`;
    const ringDiam = options.platedGrounded
      ? Number((options.drillMm + 1.8).toFixed(2))
      : Number((options.drillMm + 0.4).toFixed(2));
    return {
      id: `fp_${refDes}_${Date.now()}_${idx}`,
      type: 'pcb_footprint',
      transform: {
        x: Number(pos.x.toFixed(2)),
        y: Number(pos.y.toFixed(2)),
        rotation: 0,
        layer: 'F.Cu',
      },
      props: {
        refDes,
        value: `${options.screwStandard}_${options.drillMm}mm`,
        footprintName: `MountingHole:MountingHole_${options.drillMm}mm_${options.screwStandard}`,
        courtyard: {
          width: options.keepoutDiameterMm,
          height: options.keepoutDiameterMm,
        },
        pads: [
          {
            number: '1',
            offset: { x: 0, y: 0 },
            width: ringDiam,
            height: ringDiam,
            shape: 'circle',
            drill: options.drillMm,
            layers: ['F.Cu', 'B.Cu'],
            net: options.platedGrounded ? 'GND' : '',
          },
        ],
      },
    };
  });

  return {
    project: {
      ...project,
      sheets: project.sheets.map((s) =>
        s.kind === 'pcb' ? { ...s, items: [...s.items, ...newHoles] } : s
      ),
    },
    summary: `Placed ${newHoles.length} × ${options.screwStandard} mounting hole(s) (${options.drillMm} mm drill, ${options.keepoutDiameterMm} mm keep-out)`,
  };
}

// ============================================================================
// 8. PAD & VIA ARRAY GENERATOR (RECTANGULAR GRID WITH EXACT PITCH)
// ============================================================================

export interface PadViaArrayOptions {
  mode: 'smd_pads' | 'tht_pads' | 'vias';
  rows: number;
  cols: number;
  pitchXMm: number;
  pitchYMm: number;
  padWidthMm: number;
  padHeightMm: number;
  drillMm: number;
  numbering: 'row_major' | 'bga_alpha' | 'dip_ccw';
  layer: 'F.Cu' | 'B.Cu';
  net: string;
}

export function generatePadOrViaArray(
  project: Project,
  options: PadViaArrayOptions
): { project: Project; summary: string } {
  const bounds = getBoardBounds(project);
  const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');
  if (!pcbSheet) return { project, summary: 'No PCB sheet found' };

  const rows = Math.max(1, Math.min(20, Math.round(options.rows)));
  const cols = Math.max(1, Math.min(20, Math.round(options.cols)));
  const pitchX = Math.max(0.4, options.pitchXMm);
  const pitchY = Math.max(0.4, options.pitchYMm);
  const totalW = (cols - 1) * pitchX;
  const totalH = (rows - 1) * pitchY;

  const cx = bounds.centerX;
  const cy = bounds.centerY;

  if (options.mode === 'vias') {
    const newVias: PcbViaItem[] = [];
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const vx = Number((cx - totalW / 2 + c * pitchX).toFixed(3));
        const vy = Number((cy - totalH / 2 + r * pitchY).toFixed(3));
        newVias.push({
          id: `via_arr_${Date.now()}_${r}_${c}`,
          type: 'pcb_via',
          transform: { x: vx, y: vy, rotation: 0, layer: 'F.Cu' },
          props: {
            diameter: Math.max(0.45, options.padWidthMm),
            drill: Math.max(0.2, options.drillMm),
            net: options.net.trim(),
          },
        });
      }
    }
    return {
      project: {
        ...project,
        sheets: project.sheets.map((s) =>
          s.kind === 'pcb' ? { ...s, items: [...s.items, ...newVias] } : s
        ),
      },
      summary: `Generated ${rows}×${cols} via array (${newVias.length} vias at ${pitchX}×${pitchY} mm pitch)`,
    };
  }

  // Pad array footprint
  const arrCount =
    pcbSheet.items.filter((i) => i.type === 'pcb_footprint' && i.props.refDes.startsWith('J'))
      .length + 1;
  const refDes = `J${arrCount}`;
  const pads: PadDef[] = [];
  const rowLetters = 'ABCDEFGHJKLMNPQRSTUVWXYZ';

  let seq = 1;
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const ox = Number((-totalW / 2 + c * pitchX).toFixed(3));
      const oy = Number((-totalH / 2 + r * pitchY).toFixed(3));
      const pinName =
        options.numbering === 'bga_alpha'
          ? `${rowLetters[r % rowLetters.length]}${c + 1}`
          : options.numbering === 'dip_ccw' && r === rows - 1
            ? `${rows * cols - c}`
            : `${seq}`;
      seq++;

      pads.push({
        number: pinName,
        offset: { x: ox, y: oy },
        width: Math.max(0.25, options.padWidthMm),
        height: Math.max(0.25, options.padHeightMm),
        shape: options.mode === 'tht_pads' ? 'circle' : 'rect',
        drill: options.mode === 'tht_pads' ? Math.max(0.2, options.drillMm) : undefined,
        layers: options.mode === 'tht_pads' ? ['F.Cu', 'B.Cu'] : [options.layer],
        net: options.net.trim(),
      });
    }
  }

  const fp: PcbFootprintItem = {
    id: `fp_arr_${Date.now()}`,
    type: 'pcb_footprint',
    transform: { x: cx, y: cy, rotation: 0, layer: options.layer },
    props: {
      refDes,
      value: `ARRAY_${rows}x${cols}`,
      footprintName: `Array:PadArray_${rows}x${cols}_P${pitchX}x${pitchY}mm`,
      courtyard: {
        width: Number((totalW + options.padWidthMm + 1.2).toFixed(2)),
        height: Number((totalH + options.padHeightMm + 1.2).toFixed(2)),
      },
      pads,
    },
  };

  return {
    project: {
      ...project,
      sheets: project.sheets.map((s) =>
        s.kind === 'pcb' ? { ...s, items: [...s.items, fp] } : s
      ),
    },
    summary: `Placed ${rows}×${cols} ${options.mode === 'tht_pads' ? 'through-hole' : 'SMD'} pad array (${refDes}, ${pads.length} pads)`,
  };
}

// ============================================================================
// 9. VIA STITCHING GENERATOR (FILL POUR OR BOARD EDGE WITH OBSTACLE AVOIDANCE)
// ============================================================================

export interface ViaStitchingOptions {
  mode: 'full_pour_grid' | 'edge_perimeter';
  net: string;
  pitchMm: number;
  edgeInsetMm: number;
  viaDiameterMm: number;
  viaDrillMm: number;
  clearanceMm: number;
}

export function generateViaStitching(
  project: Project,
  options: ViaStitchingOptions
): { project: Project; summary: string } {
  const bounds = getBoardBounds(project);
  const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');
  if (!pcbSheet) return { project, summary: 'No PCB sheet found' };

  const pitch = Math.max(1.2, options.pitchMm);
  const inset = Math.max(0.8, options.edgeInsetMm);
  const viaDiam = Math.max(0.45, options.viaDiameterMm);
  const viaDrill = Math.max(0.2, Math.min(viaDiam - 0.15, options.viaDrillMm));
  const safeClearance = Math.max(0.25, options.clearanceMm) + viaDiam / 2;
  const targetNet = options.net.trim() || 'GND';

  const footprints = pcbSheet.items.filter(
    (i): i is PcbFootprintItem => i.type === 'pcb_footprint'
  );
  const traces = pcbSheet.items.filter(
    (i): i is PcbTraceItem => i.type === 'pcb_trace'
  );
  const existingVias = pcbSheet.items.filter(
    (i): i is PcbViaItem => i.type === 'pcb_via'
  );

  const isPositionSafe = (pt: Point): boolean => {
    if (!pointInPolygon(pt, bounds.polygon)) return false;

    // Keep away from board outline edges
    for (let i = 0; i < bounds.polygon.length; i++) {
      const a = bounds.polygon[i];
      const b = bounds.polygon[(i + 1) % bounds.polygon.length];
      if (distanceToSegment(pt, a, b).dist < inset - 0.1) return false;
    }

    // Keep away from footprint courtyards and pads (unless same net pad)
    for (const fp of footprints) {
      const isRot = fp.transform.rotation === 90 || fp.transform.rotation === 270;
      const cw = (isRot ? fp.props.courtyard.height : fp.props.courtyard.width) / 2 + safeClearance * 0.7;
      const ch = (isRot ? fp.props.courtyard.width : fp.props.courtyard.height) / 2 + safeClearance * 0.7;
      if (
        Math.abs(pt.x - fp.transform.x) <= cw &&
        Math.abs(pt.y - fp.transform.y) <= ch
      ) {
        return false;
      }
      const pads = getFootprintPadsWorld(fp);
      for (const p of pads) {
        const pr = Math.max(p.pad.width, p.pad.height) / 2 + safeClearance;
        if (Math.hypot(pt.x - p.world.x, pt.y - p.world.y) < pr) {
          return false;
        }
      }
    }

    // Keep away from existing traces
    for (const tr of traces) {
      const pts = tr.props.points;
      const minSep = tr.props.width / 2 + safeClearance;
      for (let i = 0; i < pts.length - 1; i++) {
        if (distanceToSegment(pt, pts[i], pts[i + 1]).dist < minSep) {
          return false;
        }
      }
    }

    // Keep away from existing vias
    for (const v of existingVias) {
      if (
        Math.hypot(pt.x - v.transform.x, pt.y - v.transform.y) <
        v.props.diameter / 2 + safeClearance
      ) {
        return false;
      }
    }

    return true;
  };

  const candidates: Point[] = [];
  const minX = bounds.x + inset;
  const maxX = bounds.x + bounds.width - inset;
  const minY = bounds.y + inset;
  const maxY = bounds.y + bounds.height - inset;

  if (options.mode === 'edge_perimeter') {
    // Perimeter ring along board polygon edges
    for (let x = minX; x <= maxX; x += pitch) {
      candidates.push({ x: Number(x.toFixed(2)), y: Number(minY.toFixed(2)) });
      candidates.push({ x: Number(x.toFixed(2)), y: Number(maxY.toFixed(2)) });
    }
    for (let y = minY + pitch; y <= maxY - pitch; y += pitch) {
      candidates.push({ x: Number(minX.toFixed(2)), y: Number(y.toFixed(2)) });
      candidates.push({ x: Number(maxX.toFixed(2)), y: Number(y.toFixed(2)) });
    }
  } else {
    // Full board stitching grid
    for (let y = minY; y <= maxY; y += pitch) {
      for (let x = minX; x <= maxX; x += pitch) {
        candidates.push({ x: Number(x.toFixed(2)), y: Number(y.toFixed(2)) });
      }
    }
  }

  const stitchedVias: PcbViaItem[] = [];
  for (let i = 0; i < candidates.length; i++) {
    const pt = candidates[i];
    if (!isPositionSafe(pt)) continue;
    const via: PcbViaItem = {
      id: `via_stitch_${Date.now()}_${i}`,
      type: 'pcb_via',
      transform: { x: pt.x, y: pt.y, rotation: 0, layer: 'F.Cu' },
      props: {
        diameter: viaDiam,
        drill: viaDrill,
        net: targetNet,
      },
    };
    stitchedVias.push(via);
    existingVias.push(via);
  }

  return {
    project: {
      ...project,
      sheets: project.sheets.map((s) =>
        s.kind === 'pcb' ? { ...s, items: [...s.items, ...stitchedVias] } : s
      ),
    },
    summary: `Placed ${stitchedVias.length} stitching vias on net ${targetNet} (${options.mode === 'edge_perimeter' ? 'Edge ring' : `${pitch}mm grid`})`,
  };
}

// ============================================================================
// 10. ADD / AUTO-NUMBER DESIGNATORS (R1, C1, U1...)
// ============================================================================

export interface AutoDesignatorOptions {
  direction: 'top_to_bottom' | 'left_to_right';
  startIndex: number;
}

export function autoNumberDesignators(
  project: Project,
  options: AutoDesignatorOptions
): { project: Project; summary: string; renamedCount: number } {
  const schSheet = project.sheets.find((s) => s.kind === 'schematic');
  const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');

  const sortByCoords = <T extends { transform: { x: number; y: number } }>(items: T[]): T[] =>
    [...items].sort((a, b) => {
      if (options.direction === 'top_to_bottom') {
        if (Math.abs(a.transform.y - b.transform.y) > 2.5) {
          return a.transform.y - b.transform.y;
        }
        return a.transform.x - b.transform.x;
      }
      if (Math.abs(a.transform.x - b.transform.x) > 2.5) {
        return a.transform.x - b.transform.x;
      }
      return a.transform.y - b.transform.y;
    });

  const getPrefix = (refDes: string, kind?: string): string => {
    const clean = refDes.replace(/[0-9?]+$/g, '').trim();
    if (clean) return clean;
    if (kind === 'R') return 'R';
    if (kind === 'C') return 'C';
    if (kind === 'LED') return 'D';
    if (kind === 'CONN2') return 'J';
    return 'U';
  };

  const counters: Record<string, number> = {};
  const renameMap = new Map<string, string>();

  if (schSheet) {
    const schComps = sortByCoords(
      schSheet.items.filter(
        (i): i is SchComponentItem =>
          i.type === 'sch_component' && i.props.kind !== 'GND' && i.props.kind !== 'VCC'
      )
    );
    for (const comp of schComps) {
      const prefix = getPrefix(comp.props.refDes, comp.props.kind);
      const nextNum = (counters[prefix] ?? options.startIndex - 1) + 1;
      counters[prefix] = nextNum;
      const newRef = `${prefix}${nextNum}`;
      renameMap.set(comp.props.refDes, newRef);
    }
  }

  if (pcbSheet) {
    const pcbFps = sortByCoords(
      pcbSheet.items.filter((i): i is PcbFootprintItem => i.type === 'pcb_footprint')
    );
    for (const fp of pcbFps) {
      if (renameMap.has(fp.props.refDes)) continue;
      const prefix = getPrefix(fp.props.refDes);
      const nextNum = (counters[prefix] ?? options.startIndex - 1) + 1;
      counters[prefix] = nextNum;
      const newRef = `${prefix}${nextNum}`;
      renameMap.set(fp.props.refDes, newRef);
    }
  }

  let renamedCount = 0;
  for (const [oldRef, newRef] of renameMap.entries()) {
    if (oldRef !== newRef) renamedCount++;
  }

  const nextSheets = project.sheets.map((sheet) => {
    if (sheet.kind === 'schematic') {
      return {
        ...sheet,
        items: sheet.items.map((item) => {
          if (item.type === 'sch_component' && renameMap.has(item.props.refDes)) {
            return {
              ...item,
              props: {
                ...item.props,
                refDes: renameMap.get(item.props.refDes)!,
              },
            };
          }
          return item;
        }),
      };
    }
    if (sheet.kind === 'pcb') {
      return {
        ...sheet,
        items: sheet.items.map((item) => {
          if (item.type === 'pcb_footprint' && renameMap.has(item.props.refDes)) {
            const newRef = renameMap.get(item.props.refDes)!;
            return {
              ...item,
              id: `fp_${newRef}`,
              props: {
                ...item.props,
                refDes: newRef,
              },
            };
          }
          return item;
        }),
      };
    }
    return sheet;
  });

  const synced = syncPcbNetsAndFootprints({
    ...project,
    sheets: nextSheets,
  });

  return {
    project: synced,
    renamedCount,
    summary: `Numbered ${renameMap.size} component designators (${Array.from(renameMap.values()).slice(0, 6).join(', ')}${renameMap.size > 6 ? '...' : ''})`,
  };
}
