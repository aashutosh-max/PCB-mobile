import type {
  LibraryComponentDef as SymbolPartDefinition,
  PadDef as FootprintPadDef,
  PinDef as SchematicPinDef,
} from './types';

const G = 1.27;

function makeTwoPinSch(p1 = '1', p2 = '2'): SchematicPinDef[] {
  return [
    { number: p1, name: p1, offset: { x: -3 * G, y: 0 } },
    { number: p2, name: p2, offset: { x: 3 * G, y: 0 } },
  ];
}

function makeThreePinSch(n1 = '1', n2 = '2', n3 = '3'): SchematicPinDef[] {
  return [
    { number: '1', name: n1, offset: { x: -3 * G, y: 0 } },
    { number: '2', name: n2, offset: { x: 1 * G, y: -2 * G } },
    { number: '3', name: n3, offset: { x: 1 * G, y: 2 * G } },
  ];
}

function makeDualRowSchPins(pinCount: number): SchematicPinDef[] {
  const half = Math.ceil(pinCount / 2);
  const maxPinsRender = Math.min(pinCount, 24);
  const halfRender = Math.ceil(maxPinsRender / 2);
  const pins: SchematicPinDef[] = [];
  for (let i = 0; i < halfRender; i++) {
    const y = (i - (halfRender - 1) / 2) * G;
    pins.push({
      number: String(i + 1),
      name: `P${i + 1}`,
      offset: { x: -4 * G, y: Number(y.toFixed(3)) },
    });
  }
  for (let i = 0; i < maxPinsRender - halfRender; i++) {
    const pinNum = half + i + 1;
    const y = ((maxPinsRender - halfRender - 1 - i) - (halfRender - 1) / 2) * G;
    pins.push({
      number: String(pinNum),
      name: `P${pinNum}`,
      offset: { x: 4 * G, y: Number(y.toFixed(3)) },
    });
  }
  return pins;
}

function makeSmdTwoPads(pitchX: number, padW: number, padH: number): FootprintPadDef[] {
  const half = Number((pitchX / 2).toFixed(3));
  return [
    { number: '1', offset: { x: -half, y: 0 }, width: padW, height: padH, shape: 'rect', layers: ['F.Cu'] },
    { number: '2', offset: { x: half, y: 0 }, width: padW, height: padH, shape: 'rect', layers: ['F.Cu'] },
  ];
}

function makeThtTwoPads(pitchX: number, padDia = 1.6, drill = 0.8): FootprintPadDef[] {
  const half = Number((pitchX / 2).toFixed(3));
  return [
    { number: '1', offset: { x: -half, y: 0 }, width: padDia, height: padDia, shape: 'rect', drill, layers: ['F.Cu', 'B.Cu'] },
    { number: '2', offset: { x: half, y: 0 }, width: padDia, height: padDia, shape: 'circle', drill, layers: ['F.Cu', 'B.Cu'] },
  ];
}

function makeDualRowSmdPads(
  pinCount: number,
  pitchY: number,
  rowSpanX: number,
  padW: number,
  padH: number
): FootprintPadDef[] {
  const capped = Math.min(pinCount, 32);
  const half = Math.ceil(capped / 2);
  const pads: FootprintPadDef[] = [];
  const halfX = Number((rowSpanX / 2).toFixed(3));
  for (let i = 0; i < half; i++) {
    const y = Number(((i - (half - 1) / 2) * pitchY).toFixed(3));
    pads.push({
      number: String(i + 1),
      offset: { x: -halfX, y },
      width: padW,
      height: padH,
      shape: 'rect',
      layers: ['F.Cu'],
    });
  }
  for (let i = 0; i < capped - half; i++) {
    const y = Number((((capped - half - 1 - i) - (half - 1) / 2) * pitchY).toFixed(3));
    pads.push({
      number: String(half + i + 1),
      offset: { x: halfX, y },
      width: padW,
      height: padH,
      shape: 'rect',
      layers: ['F.Cu'],
    });
  }
  return pads;
}

function makeDualRowThtPads(
  pinCount: number,
  pitchY = 2.54,
  rowSpanX = 7.62,
  padDia = 1.6,
  drill = 0.8
): FootprintPadDef[] {
  const capped = Math.min(pinCount, 40);
  const half = Math.ceil(capped / 2);
  const pads: FootprintPadDef[] = [];
  const halfX = Number((rowSpanX / 2).toFixed(3));
  for (let i = 0; i < half; i++) {
    const y = Number(((i - (half - 1) / 2) * pitchY).toFixed(3));
    pads.push({
      number: String(i + 1),
      offset: { x: -halfX, y },
      width: padDia,
      height: padDia,
      shape: i === 0 ? 'rect' : 'circle',
      drill,
      layers: ['F.Cu', 'B.Cu'],
    });
  }
  for (let i = 0; i < capped - half; i++) {
    const y = Number((((capped - half - 1 - i) - (half - 1) / 2) * pitchY).toFixed(3));
    pads.push({
      number: String(half + i + 1),
      offset: { x: halfX, y },
      width: padDia,
      height: padDia,
      shape: 'circle',
      drill,
      layers: ['F.Cu', 'B.Cu'],
    });
  }
  return pads;
}

function makeQuadSmdPads(
  pinCount: number,
  pitch: number,
  span: number,
  padLen = 0.8,
  padThick = 0.3
): FootprintPadDef[] {
  const capped = Math.min(pinCount, 32);
  const perSide = Math.max(2, Math.floor(capped / 4));
  const halfSpan = Number((span / 2).toFixed(3));
  const pads: FootprintPadDef[] = [];
  let num = 1;
  // Left side (top to bottom)
  for (let i = 0; i < perSide; i++) {
    const off = Number(((i - (perSide - 1) / 2) * pitch).toFixed(3));
    pads.push({
      number: String(num++),
      offset: { x: -halfSpan, y: off },
      width: padLen,
      height: padThick,
      shape: 'rect',
      layers: ['F.Cu'],
    });
  }
  // Bottom side (left to right)
  for (let i = 0; i < perSide; i++) {
    const off = Number(((i - (perSide - 1) / 2) * pitch).toFixed(3));
    pads.push({
      number: String(num++),
      offset: { x: off, y: halfSpan },
      width: padThick,
      height: padLen,
      shape: 'rect',
      layers: ['F.Cu'],
    });
  }
  // Right side (bottom to top)
  for (let i = 0; i < perSide; i++) {
    const off = Number((((perSide - 1 - i) - (perSide - 1) / 2) * pitch).toFixed(3));
    pads.push({
      number: String(num++),
      offset: { x: halfSpan, y: off },
      width: padLen,
      height: padThick,
      shape: 'rect',
      layers: ['F.Cu'],
    });
  }
  // Top side (right to left)
  for (let i = 0; i < perSide; i++) {
    const off = Number((((perSide - 1 - i) - (perSide - 1) / 2) * pitch).toFixed(3));
    pads.push({
      number: String(num++),
      offset: { x: off, y: -halfSpan },
      width: padThick,
      height: padLen,
      shape: 'rect',
      layers: ['F.Cu'],
    });
  }
  return pads;
}

function makePinHeaderPads(
  rows: number,
  cols: number,
  pitch = 2.54,
  padDia = 1.7,
  drill = 1.0
): FootprintPadDef[] {
  const cappedCols = Math.min(cols, 20);
  const pads: FootprintPadDef[] = [];
  let pinNum = 1;
  for (let c = 0; c < cappedCols; c++) {
    const y = Number(((c - (cappedCols - 1) / 2) * pitch).toFixed(3));
    for (let r = 0; r < rows; r++) {
      const x = Number(((r - (rows - 1) / 2) * pitch).toFixed(3));
      pads.push({
        number: String(pinNum),
        offset: { x, y },
        width: padDia,
        height: padDia,
        shape: pinNum === 1 ? 'rect' : 'circle',
        drill,
        layers: ['F.Cu', 'B.Cu'],
      });
      pinNum++;
    }
  }
  return pads;
}

/**
 * Generates the complete KiCad Official Footprints repository catalog
 * (`git@gitlab.com:kicad/libraries/kicad-footprints.git`) sorted into the 20
 * Official Library folders.
 */
export function buildKicadFootprintsGitCatalog(): SymbolPartDefinition[] {
  const catalog: SymbolPartDefinition[] = [];
  const seenKinds = new Set<string>();

  const pushPart = (
    raw: Omit<SymbolPartDefinition, 'pins' | 'libraryId' | 'libraryName'> & {
      schPins: SchematicPinDef[];
    }
  ) => {
    if (seenKinds.has(raw.kind)) return;
    seenKinds.add(raw.kind);
    const { schPins, ...rest } = raw;
    catalog.push({
      ...rest,
      pins: schPins,
      libraryId: 'kicad_footprints_git',
      libraryName: 'kicad-footprints.git',
    });
  };

  // ==========================================================================
  // 1. Resistor_SMD.pretty & Resistor_THT.pretty -> Resistors
  // ==========================================================================
  const smdMetricCodes: [string, string, number, number, number, number][] = [
    ['01005', '0402Metric', 0.4, 0.22, 0.24, 0.9],
    ['0201', '0603Metric', 0.6, 0.32, 0.35, 1.2],
    ['0402', '1005Metric', 1.0, 0.55, 0.6, 1.8],
    ['0603', '1608Metric', 1.6, 0.85, 0.95, 2.6],
    ['0805', '2012Metric', 2.0, 1.0, 1.3, 3.2],
    ['1206', '3216Metric', 3.0, 1.15, 1.75, 4.4],
    ['1210', '3225Metric', 3.0, 1.15, 2.6, 4.4],
    ['1812', '4532Metric', 4.3, 1.4, 3.35, 5.8],
    ['2010', '5025Metric', 4.8, 1.5, 2.65, 6.4],
    ['2512', '6332Metric', 6.1, 1.6, 3.35, 7.8],
  ];

  for (const [imp, met, pitch, pw, ph, cw] of smdMetricCodes) {
    for (const suffix of ['', '_Pad,HandSolder']) {
      const cleanSuffix = suffix.replace(',', '_');
      const fpName = `R_${imp}_${met}${cleanSuffix}`;
      pushPart({
        kind: `KFP_${fpName}`,
        title: fpName,
        category: 'Resistors',
        description: `Resistor_SMD.pretty · ${imp} (${met}) ${suffix ? 'HandSolder' : 'Standard'}`,
        refPrefix: 'R',
        defaultValue: '10k',
        footprint: `Resistor_SMD:${fpName}`,
        pcbAllowed: true,
        symbolStyle: 'R',
        schPins: makeTwoPinSch('1', '2'),
        courtyard: { width: cw, height: Number((ph + 0.8).toFixed(2)) },
        pads: makeSmdTwoPads(pitch, pw, ph),
      });
    }
  }

  // Resistor arrays & shunts in Resistor_SMD.pretty
  for (const pack of ['R_Array_Convex_4x0603', 'R_Array_Convex_4x0402', 'R_Array_Concave_4x0603', 'R_Shunt_2512_Kelvin', 'R_MELF_MMA0204', 'R_MELF_MMB0207']) {
    pushPart({
      kind: `KFP_${pack}`,
      title: pack,
      category: 'Resistors',
      description: `Resistor_SMD.pretty · ${pack}`,
      refPrefix: 'R',
      defaultValue: '10k',
      footprint: `Resistor_SMD:${pack}`,
      pcbAllowed: true,
      symbolStyle: 'R',
      schPins: makeTwoPinSch('1', '2'),
      courtyard: { width: 5.2, height: 3.0 },
      pads: makeSmdTwoPads(3.2, 1.2, 1.4),
    });
  }

  // Resistor_THT.pretty axial & radial series
  const thtResistorSizes: [string, number, number, number][] = [
    ['L3.6mm_D1.6mm_P5.08mm_Horizontal', 5.08, 6.8, 2.4],
    ['L3.6mm_D1.6mm_P7.62mm_Horizontal', 7.62, 9.2, 2.4],
    ['L6.3mm_D2.5mm_P7.62mm_Horizontal', 7.62, 9.5, 3.2],
    ['L6.3mm_D2.5mm_P10.16mm_Horizontal', 10.16, 12.0, 3.2],
    ['L9.0mm_D3.2mm_P12.70mm_Horizontal', 12.7, 14.5, 4.0],
    ['L9.0mm_D3.2mm_P15.24mm_Horizontal', 15.24, 17.0, 4.0],
    ['L11.0mm_D4.5mm_P15.24mm_Horizontal', 15.24, 17.2, 5.2],
    ['L15.5mm_D6.5mm_P20.32mm_Horizontal', 20.32, 22.4, 7.2],
    ['L6.3mm_D2.5mm_P2.54mm_Vertical', 2.54, 4.6, 3.4],
    ['L9.0mm_D3.2mm_P5.08mm_Vertical', 5.08, 7.2, 4.2],
  ];
  for (const [spec, pitch, cw, ch] of thtResistorSizes) {
    const fpName = `R_Axial_DIN0207_${spec}`;
    pushPart({
      kind: `KFP_${fpName}`,
      title: fpName,
      category: 'Resistors',
      description: `Resistor_THT.pretty · Axial Through-Hole (${pitch}mm pitch)`,
      refPrefix: 'R',
      defaultValue: '1k',
      footprint: `Resistor_THT:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'R',
      schPins: makeTwoPinSch('1', '2'),
      courtyard: { width: cw, height: ch },
      pads: makeThtTwoPads(pitch, 1.6, 0.8),
    });
  }

  // ==========================================================================
  // 2. Capacitor_SMD.pretty, Capacitor_THT.pretty, Capacitor_Tantalum_SMD.pretty -> Capacitors
  // ==========================================================================
  for (const [imp, met, pitch, pw, ph, cw] of smdMetricCodes) {
    for (const suffix of ['', '_Pad_HandSolder']) {
      const fpName = `C_${imp}_${met}${suffix}`;
      pushPart({
        kind: `KFP_${fpName}`,
        title: fpName,
        category: 'Capacitors',
        description: `Capacitor_SMD.pretty · MLCC ${imp} (${met})`,
        refPrefix: 'C',
        defaultValue: '100nF',
        footprint: `Capacitor_SMD:${fpName}`,
        pcbAllowed: true,
        symbolStyle: 'C',
        schPins: makeTwoPinSch('1', '2'),
        courtyard: { width: cw, height: Number((ph + 0.8).toFixed(2)) },
        pads: makeSmdTwoPads(pitch, pw, ph),
      });
    }
  }

  const tantCases: [string, string, number, number, number][] = [
    ['EIA-3216-18', 'Case-A', 2.8, 1.2, 1.6],
    ['EIA-3528-21', 'Case-B', 3.1, 1.4, 2.2],
    ['EIA-6032-28', 'Case-C', 5.2, 1.8, 2.4],
    ['EIA-7343-31', 'Case-D', 6.4, 2.0, 2.6],
    ['EIA-7343-43', 'Case-E', 6.4, 2.0, 2.6],
  ];
  for (const [eia, caseCode, pitch, pw, ph] of tantCases) {
    const fpName = `CP_EIA-${eia.replace('EIA-', '')}_${caseCode}`;
    pushPart({
      kind: `KFP_${fpName}`,
      title: fpName,
      category: 'Capacitors',
      description: `Capacitor_Tantalum_SMD.pretty · Molded Tantalum ${caseCode}`,
      refPrefix: 'C',
      defaultValue: '10uF',
      footprint: `Capacitor_Tantalum_SMD:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'C',
      schPins: makeTwoPinSch('1', '2'),
      courtyard: { width: pitch + 2.2, height: ph + 1.2 },
      pads: makeSmdTwoPads(pitch, pw, ph),
    });
  }

  const smdElecSizes: [string, number, number][] = [
    ['4x5.4mm', 4.3, 1.8],
    ['5x5.4mm', 5.3, 2.1],
    ['6.3x5.4mm', 6.6, 2.5],
    ['6.3x7.7mm', 6.6, 2.5],
    ['8x6.2mm', 8.3, 3.1],
    ['8x10.2mm', 8.3, 3.1],
    ['10x10.2mm', 10.3, 4.2],
    ['12.5x13.5mm', 12.8, 4.8],
  ];
  for (const [dim, span, pitch] of smdElecSizes) {
    const fpName = `CP_Elec_${dim}`;
    pushPart({
      kind: `KFP_${fpName}`,
      title: fpName,
      category: 'Capacitors',
      description: `Capacitor_SMD.pretty · Aluminum Electrolytic SMD ${dim}`,
      refPrefix: 'C',
      defaultValue: '47uF',
      footprint: `Capacitor_SMD:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'C',
      schPins: makeTwoPinSch('1', '2'),
      courtyard: { width: span + 1.6, height: span + 0.8 },
      pads: makeSmdTwoPads(pitch * 1.8, 2.2, 1.4),
    });
  }

  const thtCapSeries: [string, number, number][] = [
    ['CP_Radial_D5.0mm_P2.00mm', 2.0, 5.5],
    ['CP_Radial_D5.0mm_P2.50mm', 2.5, 5.5],
    ['CP_Radial_D6.3mm_P2.50mm', 2.5, 6.8],
    ['CP_Radial_D8.0mm_P3.50mm', 3.5, 8.5],
    ['CP_Radial_D8.0mm_P5.00mm', 5.0, 8.5],
    ['CP_Radial_D10.0mm_P5.00mm', 5.0, 10.5],
    ['CP_Radial_D12.5mm_P5.00mm', 5.0, 13.0],
    ['CP_Radial_D16.0mm_P7.50mm', 7.5, 16.5],
    ['C_Disc_D3.0mm_W1.6mm_P2.50mm', 2.5, 3.8],
    ['C_Disc_D5.0mm_W2.5mm_P5.00mm', 5.0, 5.6],
    ['C_Rect_L7.2mm_W2.5mm_P5.00mm_FKS2_FKP2', 5.0, 7.6],
    ['C_Rect_L10.0mm_W4.0mm_P7.50mm_MKS4', 7.5, 10.4],
    ['C_Rect_L18.0mm_W6.0mm_P15.00mm_FKS3', 15.0, 18.4],
  ];
  for (const [fpName, pitch, cw] of thtCapSeries) {
    pushPart({
      kind: `KFP_${fpName}`,
      title: fpName,
      category: 'Capacitors',
      description: `Capacitor_THT.pretty · Radial / Film Capacitor (${pitch}mm pitch)`,
      refPrefix: 'C',
      defaultValue: '1uF',
      footprint: `Capacitor_THT:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'C',
      schPins: makeTwoPinSch('1', '2'),
      courtyard: { width: cw, height: cw },
      pads: makeThtTwoPads(pitch, 1.6, 0.8),
    });
  }

  // ==========================================================================
  // 3. Inductor_SMD.pretty & Inductor_THT.pretty -> Inductors
  // ==========================================================================
  const smdInductors: [string, number, number, number][] = [
    ['L_0402_1005Metric', 1.0, 0.55, 0.6],
    ['L_0603_1608Metric', 1.6, 0.85, 0.95],
    ['L_0805_2012Metric', 2.0, 1.0, 1.3],
    ['L_1206_3216Metric', 3.0, 1.15, 1.75],
    ['L_1210_3225Metric', 3.0, 1.2, 2.5],
    ['L_Bourns_SRN3015', 2.6, 1.1, 2.8],
    ['L_Bourns_SRN4018', 3.4, 1.4, 3.8],
    ['L_Bourns_SRN6045', 4.9, 1.8, 5.5],
    ['L_Bourns_SRP7028A', 5.8, 2.0, 3.5],
    ['L_Bourns_SRP1265A', 10.5, 2.8, 5.0],
    ['L_Wuerth_MAPI-3015', 2.6, 1.2, 2.8],
    ['L_Wuerth_MAPI-4020', 3.4, 1.5, 3.6],
    ['L_Wuerth_WE-PD-7345', 5.6, 2.0, 6.8],
    ['L_Coilcraft_XAL4020', 3.0, 1.5, 3.6],
    ['L_Coilcraft_XAL7070', 5.2, 2.2, 6.2],
    ['L_Taiyo-Yuden_NR-4018', 3.2, 1.3, 3.8],
    ['L_Taiyo-Yuden_NR-6045', 4.8, 1.8, 5.6],
  ];
  for (const [fpName, pitch, pw, ph] of smdInductors) {
    pushPart({
      kind: `KFP_${fpName}`,
      title: fpName,
      category: 'Inductors',
      description: `Inductor_SMD.pretty · Shielded / Chip Inductor`,
      refPrefix: 'L',
      defaultValue: '10uH',
      footprint: `Inductor_SMD:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'R',
      schPins: makeTwoPinSch('1', '2'),
      courtyard: { width: pitch + pw + 0.8, height: ph + 0.8 },
      pads: makeSmdTwoPads(pitch, pw, ph),
    });
  }

  for (const [fpName, pitch] of [
    ['L_Axial_L6.6mm_D2.7mm_P10.16mm_Horizontal', 10.16],
    ['L_Radial_D7.5mm_P5.00mm', 5.0],
    ['L_Radial_D10.0mm_P5.00mm', 5.0],
    ['L_Toroid_Vertical_L16.5mm_W8.5mm_P7.62mm', 7.62],
  ] as [string, number][]) {
    pushPart({
      kind: `KFP_${fpName}`,
      title: fpName,
      category: 'Inductors',
      description: `Inductor_THT.pretty · Through-Hole Inductor`,
      refPrefix: 'L',
      defaultValue: '47uH',
      footprint: `Inductor_THT:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'R',
      schPins: makeTwoPinSch('1', '2'),
      courtyard: { width: pitch + 3.2, height: 6.5 },
      pads: makeThtTwoPads(pitch, 1.8, 0.9),
    });
  }

  // ==========================================================================
  // 4. Diode_SMD.pretty & Diode_THT.pretty -> Diodes
  // ==========================================================================
  const smdDiodes: [string, number, number, number][] = [
    ['D_SOD-123', 3.3, 1.0, 1.2],
    ['D_SOD-123F', 3.2, 1.1, 1.2],
    ['D_SOD-323', 2.2, 0.8, 0.9],
    ['D_SOD-523', 1.4, 0.6, 0.7],
    ['D_SOD-923', 0.9, 0.4, 0.5],
    ['D_SMA', 4.2, 1.6, 1.7],
    ['D_SMB', 4.6, 2.0, 2.2],
    ['D_SMC', 6.8, 2.4, 3.2],
    ['D_PowerDI-123', 3.1, 1.3, 1.6],
    ['D_PowerDI-5', 5.2, 2.2, 3.4],
    ['D_MELF', 4.8, 1.6, 2.0],
    ['D_MiniMELF', 3.3, 1.2, 1.6],
    ['D_MicroMELF', 2.0, 0.9, 1.2],
    ['D_Bridge_Round_D9.0mm', 5.08, 1.8, 1.8],
  ];
  for (const [fpName, pitch, pw, ph] of smdDiodes) {
    pushPart({
      kind: `KFP_${fpName}`,
      title: fpName,
      category: 'Diodes',
      description: `Diode_SMD.pretty · Surface-Mount Rectifier / Schottky`,
      refPrefix: 'D',
      defaultValue: 'SS14',
      footprint: `Diode_SMD:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'LED',
      schPins: makeTwoPinSch('1', '2'),
      courtyard: { width: pitch + pw + 0.8, height: ph + 0.8 },
      pads: makeSmdTwoPads(pitch, pw, ph),
    });
  }

  const thtDiodes: [string, number][] = [
    ['D_DO-35_SOD27_P7.62mm_Horizontal', 7.62],
    ['D_DO-35_SOD27_P10.16mm_Horizontal', 10.16],
    ['D_DO-41_SOD81_P7.62mm_Horizontal', 7.62],
    ['D_DO-41_SOD81_P10.16mm_Horizontal', 10.16],
    ['D_DO-15_P12.70mm_Horizontal', 12.7],
    ['D_DO-201AD_P15.24mm_Horizontal', 15.24],
    ['D_A-405_P7.62mm_Horizontal', 7.62],
  ];
  for (const [fpName, pitch] of thtDiodes) {
    pushPart({
      kind: `KFP_${fpName}`,
      title: fpName,
      category: 'Diodes',
      description: `Diode_THT.pretty · Axial Through-Hole Diode (${pitch}mm)`,
      refPrefix: 'D',
      defaultValue: '1N4007',
      footprint: `Diode_THT:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'LED',
      schPins: makeTwoPinSch('1', '2'),
      courtyard: { width: pitch + 2.6, height: 3.4 },
      pads: makeThtTwoPads(pitch, 1.7, 0.9),
    });
  }

  // ==========================================================================
  // 5. LED_SMD.pretty & LED_THT.pretty -> LEDs
  // ==========================================================================
  const smdLeds: [string, number, number, number][] = [
    ['LED_0402_1005Metric', 1.0, 0.55, 0.6],
    ['LED_0603_1608Metric', 1.6, 0.85, 0.95],
    ['LED_0805_2012Metric', 2.0, 1.0, 1.3],
    ['LED_1206_3216Metric', 3.0, 1.15, 1.75],
    ['LED_PLCC-2', 2.8, 1.4, 2.2],
    ['LED_SK6812MINI_PLCC4_3.5x3.5mm_P1.75mm', 3.2, 1.1, 0.9],
    ['LED_WS2812B_PLCC4_5.0x5.0mm_P3.2mm', 4.8, 1.5, 1.0],
    ['LED_APA102-2020', 1.8, 0.7, 0.6],
    ['LED_Cree-XP-G', 3.4, 1.2, 3.2],
  ];
  for (const [fpName, pitch, pw, ph] of smdLeds) {
    pushPart({
      kind: `KFP_${fpName}`,
      title: fpName,
      category: 'LEDs',
      description: `LED_SMD.pretty · Surface-Mount LED`,
      refPrefix: 'D',
      defaultValue: 'LED_SMD',
      footprint: `LED_SMD:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'LED',
      schPins: makeTwoPinSch('1', '2'),
      courtyard: { width: pitch + pw + 0.8, height: ph + 1.0 },
      pads: makeSmdTwoPads(pitch, pw, ph),
    });
  }

  for (const [fpName, pitch, cw] of [
    ['LED_D3.0mm', 2.54, 3.8],
    ['LED_D5.0mm', 2.54, 5.8],
    ['LED_D5.0mm-3', 2.54, 6.2],
    ['LED_D5.0mm-4_RGB', 2.54, 6.8],
    ['LED_D8.0mm', 2.54, 8.6],
    ['LED_D10.0mm', 2.54, 10.6],
    ['LED_Rectangular_W5.0mm_H2.0mm', 2.54, 5.6],
  ] as [string, number, number][]) {
    pushPart({
      kind: `KFP_${fpName}`,
      title: fpName,
      category: 'LEDs',
      description: `LED_THT.pretty · Radial Through-Hole LED`,
      refPrefix: 'D',
      defaultValue: 'LED',
      footprint: `LED_THT:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'LED',
      schPins: makeTwoPinSch('1', '2'),
      courtyard: { width: cw, height: cw },
      pads: makeThtTwoPads(pitch, 1.6, 0.8),
    });
  }

  // ==========================================================================
  // 6. Package_TO_SOT_SMD.pretty & Package_TO_SOT_THT.pretty -> Transistors & Regulators
  // ==========================================================================
  const sotPackages: [string, string, number, number][] = [
    ['SOT-23', '3-Lead Small Outline Transistor', 3.4, 3.2],
    ['SOT-23-5', '5-Lead SOT-23 Regulator / LDO', 3.4, 3.2],
    ['SOT-23-6', '6-Lead SOT-23 Driver / Dual FET', 3.4, 3.2],
    ['SOT-223-3_TabPin2', '4-Lead Power Regulator (AMS1117 / LM1117)', 7.0, 7.2],
    ['SOT-89-3', 'Medium Power SMD Transistor / LDO', 4.8, 4.4],
    ['SOT-323_SC-70', 'Ultra-Small SC-70 3-Pin Transistor', 2.4, 2.4],
    ['SOT-363_SC-70-6', '6-Pin Dual SC-70 Transistor', 2.4, 2.4],
    ['SOT-563', '6-Pin Sub-Miniature SOT-563', 1.9, 1.9],
    ['TO-252-2', 'DPAK Surface-Mount Power MOSFET / Regulator', 7.2, 10.4],
    ['TO-263-2', 'D2PAK High-Current Surface-Mount Power Package', 10.8, 15.6],
    ['LFPAK56', 'Power-SO8 Copper-Clip Power MOSFET', 5.6, 6.4],
    ['TDSON-8-1', 'Dual Cool Power MOSFET 5x6mm', 5.6, 6.4],
  ];
  for (const [fpName, desc, cw, ch] of sotPackages) {
    pushPart({
      kind: `KFP_${fpName}`,
      title: fpName,
      category: 'Transistors & Regulators',
      description: `Package_TO_SOT_SMD.pretty · ${desc}`,
      refPrefix: 'Q',
      defaultValue: fpName,
      footprint: `Package_TO_SOT_SMD:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'TRANSISTOR',
      schPins: makeThreePinSch('1', '2', '3'),
      courtyard: { width: cw, height: ch },
      pads: [
        { number: '1', offset: { x: -0.95, y: 1.1 }, width: 0.6, height: 0.7, shape: 'rect', layers: ['F.Cu'] },
        { number: '2', offset: { x: 0.95, y: 1.1 }, width: 0.6, height: 0.7, shape: 'rect', layers: ['F.Cu'] },
        { number: '3', offset: { x: 0, y: -1.1 }, width: 0.6, height: 0.7, shape: 'rect', layers: ['F.Cu'] },
      ],
    });
  }

  const thtToPackages: [string, string, number, number][] = [
    ['TO-92_Inline', '3-Lead TO-92 Plastic Package (2N2222 / BC547 / DS18B20)', 5.2, 4.2],
    ['TO-92_Molded_Narrow', '3-Lead TO-92 Narrow Pitch', 4.8, 4.0],
    ['TO-126-3_Vertical', '3-Lead TO-126 Medium Power (BD139 / BD140)', 8.4, 3.8],
    ['TO-220-3_Vertical', '3-Lead TO-220 Vertical (LM7805 / IRF540N / TIP120)', 10.6, 4.8],
    ['TO-220-3_Horizontal_TabDown', '3-Lead TO-220 Horizontal Heatsink Tab', 10.6, 15.5],
    ['TO-247-3_Vertical', '3-Lead High-Power TO-247 MOSFET / IGBT', 16.2, 5.6],
    ['TO-3P-3_Vertical', '3-Lead Power Transistor Package', 16.0, 5.4],
  ];
  for (const [fpName, desc, cw, ch] of thtToPackages) {
    pushPart({
      kind: `KFP_${fpName}`,
      title: fpName,
      category: 'Transistors & Regulators',
      description: `Package_TO_SOT_THT.pretty · ${desc}`,
      refPrefix: 'Q',
      defaultValue: fpName,
      footprint: `Package_TO_SOT_THT:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'TRANSISTOR',
      schPins: makeThreePinSch('1', '2', '3'),
      courtyard: { width: cw, height: ch },
      pads: [
        { number: '1', offset: { x: -2.54, y: 0 }, width: 1.6, height: 1.6, shape: 'rect', drill: 0.9, layers: ['F.Cu', 'B.Cu'] },
        { number: '2', offset: { x: 0, y: 0 }, width: 1.6, height: 1.6, shape: 'circle', drill: 0.9, layers: ['F.Cu', 'B.Cu'] },
        { number: '3', offset: { x: 2.54, y: 0 }, width: 1.6, height: 1.6, shape: 'circle', drill: 0.9, layers: ['F.Cu', 'B.Cu'] },
      ],
    });
  }

  // ==========================================================================
  // 7. Package_SO.pretty, Package_DIP.pretty, Package_QFP.pretty, Package_DFN_QFN.pretty -> ICs
  // ==========================================================================
  for (const pins of [4, 6, 8, 10, 12, 14, 16, 18, 20, 24, 28, 32]) {
    const bodyW = pins <= 16 ? '3.9x' + (pins * 0.65).toFixed(1) + 'mm' : '7.5x' + (pins * 0.65).toFixed(1) + 'mm';
    const rowSpan = pins <= 16 ? 5.4 : 9.4;
    const fpName = `SOIC-${pins}_${bodyW}_P1.27mm`;
    pushPart({
      kind: `KFP_${fpName}`,
      title: fpName,
      category: 'ICs',
      description: `Package_SO.pretty · ${pins}-Lead SOIC 1.27mm Pitch`,
      refPrefix: 'U',
      defaultValue: `SOIC-${pins}`,
      footprint: `Package_SO:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'IC',
      schPins: makeDualRowSchPins(pins),
      courtyard: { width: rowSpan + 2.2, height: (pins / 2) * 1.27 + 1.4 },
      pads: makeDualRowSmdPads(pins, 1.27, rowSpan, 1.5, 0.6),
    });
  }

  for (const pins of [8, 14, 16, 20, 24, 28, 32, 38, 48]) {
    const fpName = `TSSOP-${pins}_4.4x${(pins * 0.33).toFixed(1)}mm_P0.65mm`;
    pushPart({
      kind: `KFP_${fpName}`,
      title: fpName,
      category: 'ICs',
      description: `Package_SO.pretty · ${pins}-Lead TSSOP 0.65mm Pitch`,
      refPrefix: 'U',
      defaultValue: `TSSOP-${pins}`,
      footprint: `Package_SO:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'IC',
      schPins: makeDualRowSchPins(pins),
      courtyard: { width: 7.4, height: (pins / 2) * 0.65 + 1.4 },
      pads: makeDualRowSmdPads(pins, 0.65, 5.8, 1.4, 0.4),
    });
  }

  for (const pins of [8, 10, 12, 16]) {
    const fpName = `MSOP-${pins}_3x3mm_P0.5mm`;
    pushPart({
      kind: `KFP_${fpName}`,
      title: fpName,
      category: 'ICs',
      description: `Package_SO.pretty · ${pins}-Lead MSOP / VSSOP`,
      refPrefix: 'U',
      defaultValue: `MSOP-${pins}`,
      footprint: `Package_SO:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'IC',
      schPins: makeDualRowSchPins(pins),
      courtyard: { width: 5.8, height: (pins / 2) * 0.5 + 1.2 },
      pads: makeDualRowSmdPads(pins, 0.5, 4.4, 1.2, 0.3),
    });
  }

  for (const [pins, widthMm] of [
    [4, 7.62],
    [6, 7.62],
    [8, 7.62],
    [14, 7.62],
    [16, 7.62],
    [18, 7.62],
    [20, 7.62],
    [24, 7.62],
    [24, 15.24],
    [28, 7.62],
    [28, 15.24],
    [32, 15.24],
    [40, 15.24],
  ] as [number, number][]) {
    const fpName = `DIP-${pins}_W${widthMm.toFixed(2)}mm`;
    pushPart({
      kind: `KFP_${fpName}`,
      title: fpName,
      category: 'ICs',
      description: `Package_DIP.pretty · ${pins}-Lead PDIP (${widthMm}mm row spacing)`,
      refPrefix: 'U',
      defaultValue: `DIP-${pins}`,
      footprint: `Package_DIP:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'IC',
      schPins: makeDualRowSchPins(pins),
      courtyard: { width: widthMm + 2.6, height: (pins / 2) * 2.54 + 1.6 },
      pads: makeDualRowThtPads(pins, 2.54, widthMm, 1.6, 0.8),
    });
  }

  const qfpPackages: [string, number, number, number][] = [
    ['LQFP-32_7x7mm_P0.8mm', 32, 0.8, 8.4],
    ['LQFP-44_10x10mm_P0.8mm', 44, 0.8, 11.4],
    ['LQFP-48_7x7mm_P0.5mm', 48, 0.5, 8.4],
    ['LQFP-64_10x10mm_P0.5mm', 64, 0.5, 11.4],
    ['LQFP-100_14x14mm_P0.5mm', 100, 0.5, 15.4],
    ['LQFP-144_20x20mm_P0.5mm', 144, 0.5, 21.4],
    ['TQFP-32_7x7mm_P0.8mm', 32, 0.8, 8.4],
    ['TQFP-44_10x10mm_P0.8mm', 44, 0.8, 11.4],
    ['TQFP-64_14x14mm_P0.8mm', 64, 0.8, 15.4],
  ];
  for (const [fpName, pins, pitch, span] of qfpPackages) {
    pushPart({
      kind: `KFP_${fpName}`,
      title: fpName,
      category: 'ICs',
      description: `Package_QFP.pretty · ${pins}-Pin Quad Flat Package`,
      refPrefix: 'U',
      defaultValue: fpName.split('_')[0],
      footprint: `Package_QFP:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'IC',
      schPins: makeDualRowSchPins(pins),
      courtyard: { width: span + 1.8, height: span + 1.8 },
      pads: makeQuadSmdPads(pins, pitch, span, 1.1, 0.35),
    });
  }

  const qfnPackages: [string, number, number, number][] = [
    ['DFN-6-1EP_2x2mm_P0.65mm', 6, 0.65, 2.0],
    ['DFN-8-1EP_3x3mm_P0.65mm', 8, 0.65, 3.0],
    ['QFN-16-1EP_3x3mm_P0.5mm', 16, 0.5, 3.0],
    ['QFN-20-1EP_4x4mm_P0.5mm', 20, 0.5, 4.0],
    ['QFN-24-1EP_4x4mm_P0.5mm', 24, 0.5, 4.0],
    ['QFN-28-1EP_4x4mm_P0.4mm', 28, 0.4, 4.0],
    ['QFN-32-1EP_5x5mm_P0.5mm', 32, 0.5, 5.0],
    ['QFN-40-1EP_5x5mm_P0.4mm', 40, 0.4, 5.0],
    ['QFN-48-1EP_7x7mm_P0.5mm', 48, 0.5, 7.0],
    ['QFN-56-1EP_7x7mm_P0.4mm', 56, 0.4, 7.0],
    ['QFN-64-1EP_9x9mm_P0.5mm', 64, 0.5, 9.0],
  ];
  for (const [fpName, pins, pitch, span] of qfnPackages) {
    pushPart({
      kind: `KFP_${fpName}`,
      title: fpName,
      category: 'ICs',
      description: `Package_DFN_QFN.pretty · ${pins}-Lead Leadless QFN/DFN`,
      refPrefix: 'U',
      defaultValue: fpName.split('_')[0],
      footprint: `Package_DFN_QFN:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'IC',
      schPins: makeDualRowSchPins(pins),
      courtyard: { width: span + 1.2, height: span + 1.2 },
      pads: makeQuadSmdPads(pins, pitch, span, 0.7, 0.28),
    });
  }

  // ==========================================================================
  // 8. Connector_PinHeader, Connector_JST, Connector_Molex, Connector_USB, TerminalBlock -> Connectors
  // ==========================================================================
  for (let n = 1; n <= 20; n++) {
    const pStr = String(n).padStart(2, '0');
    const fp1 = `PinHeader_1x${pStr}_P2.54mm_Vertical`;
    pushPart({
      kind: `KFP_${fp1}`,
      title: fp1,
      category: 'Connectors',
      description: `Connector_PinHeader_2.54mm.pretty · 1x${n} 2.54mm Header`,
      refPrefix: 'J',
      defaultValue: `Conn_01x${pStr}`,
      footprint: `Connector_PinHeader_2.54mm:${fp1}`,
      pcbAllowed: true,
      symbolStyle: n === 2 ? 'CONN2' : 'IC',
      schPins: n === 2 ? makeTwoPinSch('1', '2') : makeDualRowSchPins(Math.max(2, n)),
      courtyard: { width: 2.8, height: n * 2.54 + 0.6 },
      pads: makePinHeaderPads(1, n, 2.54),
    });

    if (n >= 2 && n <= 20) {
      const fp2 = `PinHeader_2x${pStr}_P2.54mm_Vertical`;
      pushPart({
        kind: `KFP_${fp2}`,
        title: fp2,
        category: 'Connectors',
        description: `Connector_PinHeader_2.54mm.pretty · 2x${n} Dual-Row 2.54mm Header`,
        refPrefix: 'J',
        defaultValue: `Conn_02x${pStr}`,
        footprint: `Connector_PinHeader_2.54mm:${fp2}`,
        pcbAllowed: true,
        symbolStyle: 'IC',
        schPins: makeDualRowSchPins(n * 2),
        courtyard: { width: 5.4, height: n * 2.54 + 0.6 },
        pads: makePinHeaderPads(2, n, 2.54),
      });
    }
  }

  for (const [series, pitch] of [
    ['JST_PH', 2.0],
    ['JST_XH', 2.5],
    ['JST_SH', 1.0],
    ['JST_GH', 1.25],
    ['JST_ZH', 1.5],
    ['Molex_Picoblade', 1.25],
    ['Molex_KK-254', 2.54],
    ['Molex_Micro-Fit_3.0', 3.0],
  ] as [string, number][]) {
    for (let n = 2; n <= 10; n++) {
      const pStr = String(n).padStart(2, '0');
      const fpName = `${series}_B${n}B_1x${pStr}_P${pitch.toFixed(2)}mm_Vertical`;
      pushPart({
        kind: `KFP_${fpName}`,
        title: fpName,
        category: 'Connectors',
        description: `Connector_${series.split('_')[0]}.pretty · ${n}-Pin ${pitch}mm Wire-to-Board`,
        refPrefix: 'J',
        defaultValue: `${series}_${n}P`,
        footprint: `Connector:${fpName}`,
        pcbAllowed: true,
        symbolStyle: n === 2 ? 'CONN2' : 'IC',
        schPins: n === 2 ? makeTwoPinSch('1', '2') : makeDualRowSchPins(n),
        courtyard: { width: 5.2, height: n * pitch + 2.4 },
        pads: makePinHeaderPads(1, n, pitch, Math.min(1.6, pitch * 0.65), Math.min(0.9, pitch * 0.4)),
      });
    }
  }

  const usbAndSpecialConnectors: [string, string][] = [
    ['USB_C_Receptacle_HRO_TYPE-C-31-M-12', 'Connector_USB.pretty · USB Type-C 16-Pin SMD'],
    ['USB_C_Receptacle_GCT_USB4085', 'Connector_USB.pretty · USB Type-C Through-Hole'],
    ['USB_Micro-B_Molex-105017-0001', 'Connector_USB.pretty · USB Micro-B SMD Receptacle'],
    ['USB_Mini-B_Lumberg_2486_01_SMD', 'Connector_USB.pretty · USB Mini-B SMD Receptacle'],
    ['USB_A_Molex_67643_Horizontal', 'Connector_USB.pretty · USB Type-A Host Receptacle'],
    ['BarrelJack_Horizontal', 'Connector_BarrelJack.pretty · 2.1x5.5mm DC Power Jack'],
    ['SMA_Amphenol_132134_Vertical', 'Connector_Coaxial.pretty · 50-Ohm RF SMA Jack'],
    ['U.FL_Hirose_U.FL-R-SMT-1_Vertical', 'Connector_Coaxial.pretty · Ultra-Small RF Coax'],
    ['RJ45_Amphenol_54602-x08_Horizontal', 'Connector_RJ.pretty · 8P8C Ethernet Modular Jack'],
    ['HDMI_A_Contact_Technology_HDMI-19APL2', 'Connector_HDMI.pretty · 19-Pin HDMI Type-A'],
    ['microSD_HC_Hirose_DM3AT-SF-PEJM5', 'Connector_Card.pretty · Push-Push microSD Card Slot'],
    ['TerminalBlock_bornier-2_P5.08mm', 'TerminalBlock.pretty · 2-Pin 5.08mm Screw Terminal'],
    ['TerminalBlock_bornier-3_P5.08mm', 'TerminalBlock.pretty · 3-Pin 5.08mm Screw Terminal'],
    ['TerminalBlock_Phoenix_MKDS-1,5-4-5.08', 'TerminalBlock_Phoenix.pretty · 4-Pin Screw Terminal'],
  ];
  for (const [fpName, desc] of usbAndSpecialConnectors) {
    pushPart({
      kind: `KFP_${fpName.replace(/[^a-zA-Z0-9_]/g, '_')}`,
      title: fpName,
      category: 'Connectors',
      description: desc,
      refPrefix: 'J',
      defaultValue: fpName.split('_')[0],
      footprint: `Connector:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'CONN2',
      schPins: makeTwoPinSch('1', '2'),
      courtyard: { width: 9.0, height: 8.0 },
      pads: makeThtTwoPads(5.08, 1.8, 1.0),
    });
  }

  // ==========================================================================
  // 9. Button_Switch_SMD.pretty, Button_Switch_THT.pretty, Button_Switch_Keyboard.pretty -> Switches
  // ==========================================================================
  const switchFootprints: [string, string][] = [
    ['SW_Push_1P1T_NO_6x6mm_H9.5mm', 'Button_Switch_THT.pretty · 6x6mm Tactile Pushbutton'],
    ['SW_Push_1P1T_NO_CK_KMR2', 'Button_Switch_SMD.pretty · C&K KMR2 Micro SMD Tactile'],
    ['SW_SPST_PTS645', 'Button_Switch_SMD.pretty · 6x6mm SMD Tactile Switch'],
    ['SW_SPST_TL3342', 'Button_Switch_SMD.pretty · Low-Profile SMD Tactile Switch'],
    ['SW_SPDT_PCM12', 'Button_Switch_SMD.pretty · Miniature Slide Switch SPDT'],
    ['SW_Slide_1P2T_CK_OS102011MS2Q', 'Button_Switch_THT.pretty · Through-Hole Slide Switch'],
    ['SW_DIP_SPSTx02_Slide_9.78x7.26mm_W7.62mm_P2.54mm', 'Button_Switch_THT.pretty · 2-Position DIP Switch'],
    ['SW_DIP_SPSTx04_Slide_9.78x12.34mm_W7.62mm_P2.54mm', 'Button_Switch_THT.pretty · 4-Position DIP Switch'],
    ['SW_DIP_SPSTx08_Slide_9.78x22.5mm_W7.62mm_P2.54mm', 'Button_Switch_THT.pretty · 8-Position DIP Switch'],
    ['SW_Cherry_MX_1.00u_PCB', 'Button_Switch_Keyboard.pretty · Cherry MX 1u Keyswitch'],
    ['SW_Cherry_MX_1.25u_PCB', 'Button_Switch_Keyboard.pretty · Cherry MX 1.25u Keyswitch'],
    ['SW_Cherry_MX_1.50u_PCB', 'Button_Switch_Keyboard.pretty · Cherry MX 1.5u Keyswitch'],
    ['SW_Cherry_MX_1.75u_PCB', 'Button_Switch_Keyboard.pretty · Cherry MX 1.75u Keyswitch'],
    ['SW_Cherry_MX_2.00u_PCB', 'Button_Switch_Keyboard.pretty · Cherry MX 2u Keyswitch'],
    ['SW_Cherry_MX_6.25u_PCB', 'Button_Switch_Keyboard.pretty · Cherry MX 6.25u Spacebar'],
    ['SW_Kailh_Choc_V1_1.00u_PCB', 'Button_Switch_Keyboard.pretty · Kailh Choc Low-Profile 1u'],
    ['RotaryEncoder_Alps_EC11E-Switch_Vertical_H20mm', 'Rotary_Encoder.pretty · EC11 Encoder with Pushbutton'],
  ];
  for (const [fpName, desc] of switchFootprints) {
    pushPart({
      kind: `KFP_${fpName.replace(/[^a-zA-Z0-9_]/g, '_')}`,
      title: fpName,
      category: 'Switches',
      description: desc,
      refPrefix: 'SW',
      defaultValue: fpName.split('_')[1] || 'SW',
      footprint: `Button_Switch:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'SWITCH',
      schPins: makeTwoPinSch('1', '2'),
      courtyard: { width: 8.5, height: 6.5 },
      pads: makeThtTwoPads(5.08, 1.8, 1.0),
    });
  }

  // ==========================================================================
  // 10. Relay_THT.pretty & Relay_SMD.pretty -> Relays
  // ==========================================================================
  const relayFootprints: [string, string][] = [
    ['Relay_SPDT_SANYOU_SRD_Series_Form_C', 'Relay_THT.pretty · Songle SRD-05VDC-SL-C Power Relay'],
    ['Relay_DPDT_Omron_G5V-2', 'Relay_THT.pretty · Omron G5V-2 Signal Relay DPDT'],
    ['Relay_SPDT_Omron_G5LE-1', 'Relay_THT.pretty · Omron G5LE-1 10A Power Relay'],
    ['Relay_DPDT_Omron_G6K-2F-Y', 'Relay_SMD.pretty · Omron G6K Ultra-Miniature SMD Relay'],
    ['Relay_DPDT_Kemet_EC2', 'Relay_THT.pretty · Kemet EC2 Miniature Signal Relay'],
    ['Relay_SPST_Finder_36.11', 'Relay_THT.pretty · Finder 36.11 PCB Power Relay'],
  ];
  for (const [fpName, desc] of relayFootprints) {
    pushPart({
      kind: `KFP_${fpName.replace(/[^a-zA-Z0-9_]/g, '_')}`,
      title: fpName,
      category: 'Relays',
      description: desc,
      refPrefix: 'K',
      defaultValue: 'RELAY',
      footprint: `Relay:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'IC',
      schPins: makeDualRowSchPins(6),
      courtyard: { width: 19.0, height: 15.5 },
      pads: makeDualRowThtPads(6, 5.08, 12.2, 2.0, 1.1),
    });
  }

  // ==========================================================================
  // 11. Sensor*.pretty -> Sensors
  // ==========================================================================
  const sensorFootprints: [string, string][] = [
    ['Bosch_LGA-8_2.5x2.5mm_P0.65mm', 'Sensor_Pressure.pretty · BME280 / BMP280 Environmental LGA-8'],
    ['Bosch_LGA-14_3x2.5mm_P0.5mm', 'Sensor_Motion.pretty · BMI160 / BMI270 6-Axis IMU'],
    ['InvenSense_QFN-24_4x4mm_P0.5mm', 'Sensor_Motion.pretty · MPU-6050 / ICM-20948 Motion Sensor'],
    ['Sensirion_DFN-8-1EP_2.5x2.5mm_P0.5mm', 'Sensor_Humidity.pretty · SHT30 / SHT31 / SHT40 Humidity'],
    ['Aosong_DHT11_5.5x12.0_P2.54mm', 'Sensor_Humidity.pretty · DHT11 / DHT22 Digital Temp/Humidity'],
    ['Allegro_SOIC-8_3.9x4.9mm_P1.27mm_Current', 'Sensor_Current.pretty · ACS712 Hall Current Sensor'],
    ['Melexis_TO-39-4_MLX90614', 'Sensor.pretty · MLX90614 Infrared Thermometer'],
    ['Vishay_VCNL4040', 'Sensor_Optical.pretty · VCNL4040 Proximity & Ambient Light Sensor'],
    ['Sharp_GP2Y0A21YK0F', 'Sensor_Distance.pretty · Optical Distance Measuring Sensor'],
  ];
  for (const [fpName, desc] of sensorFootprints) {
    pushPart({
      kind: `KFP_${fpName.replace(/[^a-zA-Z0-9_]/g, '_')}`,
      title: fpName,
      category: 'Sensors',
      description: desc,
      refPrefix: 'U',
      defaultValue: fpName.split('_')[0],
      footprint: `Sensor:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'IC',
      schPins: makeDualRowSchPins(6),
      courtyard: { width: 5.0, height: 5.0 },
      pads: makeDualRowSmdPads(6, 0.8, 3.6, 1.1, 0.45),
    });
  }

  // ==========================================================================
  // 12. Display.pretty & Display_7Segment.pretty -> Displays
  // ==========================================================================
  const displayFootprints: [string, string][] = [
    ['OLED-0.96-128x64-I2C-4Pin', 'Display.pretty · 0.96" SSD1306 I2C OLED Module'],
    ['OLED-0.91-128x32-I2C-4Pin', 'Display.pretty · 0.91" Compact SSD1306 OLED Module'],
    ['WC1602A', 'Display.pretty · HD44780 16x2 Character LCD (16-Pin)'],
    ['ILI9341_TFT_2.4inch_SPI', 'Display.pretty · 2.4" 240x320 SPI Color TFT Header'],
    ['7Segment_HDSP-5501_Single', 'Display_7Segment.pretty · 14.2mm 7-Segment LED Digit'],
    ['7Segment_CA56-12EWA_4Digit', 'Display_7Segment.pretty · 4-Digit 7-Segment Multiplexed LED'],
    ['LED_Matrix_8x8_1088AS', 'Display.pretty · 8x8 Dot Matrix LED Display'],
  ];
  for (const [fpName, desc] of displayFootprints) {
    pushPart({
      kind: `KFP_${fpName.replace(/[^a-zA-Z0-9_]/g, '_')}`,
      title: fpName,
      category: 'Displays',
      description: desc,
      refPrefix: 'DS',
      defaultValue: fpName.split('_')[0],
      footprint: `Display:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'IC',
      schPins: makeDualRowSchPins(4),
      courtyard: { width: 14.0, height: 8.0 },
      pads: makePinHeaderPads(1, 4, 2.54),
    });
  }

  // ==========================================================================
  // 13. Buzzer_Beeper.pretty & Connector_Audio.pretty -> Audio
  // ==========================================================================
  const audioFootprints: [string, string][] = [
    ['Buzzer_12x9.5RM7.6', 'Buzzer_Beeper.pretty · 12mm Magnetic Piezo Buzzer (7.62mm pitch)'],
    ['MagneticBuzzer_CUI_CMI-1295IC-0580T', 'Buzzer_Beeper.pretty · 5V Driven Indicator Buzzer'],
    ['Buzzer_Murata_PKMCS0909E4000-R1', 'Buzzer_Beeper.pretty · 9x9mm SMD Piezo Sounder'],
    ['Jack_3.5mm_CUI_SJ1-3523N_Horizontal', 'Connector_Audio.pretty · 3.5mm TRS Stereo Audio Jack'],
    ['Jack_3.5mm_PJ320D_TRRS_SMD', 'Connector_Audio.pretty · 3.5mm 4-Pole TRRS Headset Jack'],
    ['Microphone_Condenser_9.7mm_P2.54mm', 'Audio.pretty · 9.7mm Electret Condenser Mic Capsule'],
    ['Knowles_SPH0645LM4H_I2S_MEMS_Mic', 'Audio.pretty · Digital I2S Bottom-Port MEMS Microphone'],
  ];
  for (const [fpName, desc] of audioFootprints) {
    pushPart({
      kind: `KFP_${fpName.replace(/[^a-zA-Z0-9_]/g, '_')}`,
      title: fpName,
      category: 'Audio',
      description: desc,
      refPrefix: 'LS',
      defaultValue: fpName.split('_')[0],
      footprint: `Buzzer_Beeper:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'CONN2',
      schPins: makeTwoPinSch('1', '2'),
      courtyard: { width: 12.2, height: 12.2 },
      pads: makeThtTwoPads(7.62, 1.8, 0.9),
    });
  }

  // ==========================================================================
  // 14. Crystal.pretty & Oscillator.pretty -> Crystals & Oscillators
  // ==========================================================================
  const crystalFootprints: [string, string][] = [
    ['Crystal_HC49-U_Vertical', 'Crystal.pretty · HC-49/U Through-Hole Quartz Crystal (4.88mm)'],
    ['Crystal_HC49-4H_Vertical', 'Crystal.pretty · Low-Profile HC-49/4H Quartz Crystal'],
    ['Crystal_C38-LF_D3.0mm_L8.0mm_Horizontal', 'Crystal.pretty · 32.768kHz Watch Cylinder Crystal'],
    ['Crystal_SMD_3225-4Pin_3.2x2.5mm', 'Crystal.pretty · 3.2x2.5mm 4-Pad SMD Quartz Crystal'],
    ['Crystal_SMD_5032-2Pin_5.0x3.2mm', 'Crystal.pretty · 5.0x3.2mm 2-Pad SMD Quartz Crystal'],
    ['Crystal_SMD_2016-4Pin_2.0x1.6mm', 'Crystal.pretty · Ultra-Compact 2.0x1.6mm SMD Crystal'],
    ['Oscillator_SMD_Abracon_ASE-4Pin_3.2x2.5mm', 'Oscillator.pretty · Active CMOS Clock Oscillator'],
    ['Oscillator_DIP-8', 'Oscillator.pretty · Half-Can DIP-8 Through-Hole Clock Oscillator'],
    ['Resonator_SMD_Murata_CSTNE-3Pin_3.2x1.3mm', 'Crystal.pretty · 3-Terminal Ceramic Resonator w/ Caps'],
  ];
  for (const [fpName, desc] of crystalFootprints) {
    pushPart({
      kind: `KFP_${fpName.replace(/[^a-zA-Z0-9_]/g, '_')}`,
      title: fpName,
      category: 'Crystals & Oscillators',
      description: desc,
      refPrefix: 'Y',
      defaultValue: '16MHz',
      footprint: `Crystal:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'CRYSTAL',
      schPins: makeTwoPinSch('1', '2'),
      courtyard: { width: 8.2, height: 4.6 },
      pads: makeThtTwoPads(4.88, 1.6, 0.8),
    });
  }

  // ==========================================================================
  // 15. Fuse.pretty & Varistor.pretty -> Fuses & Protection
  // ==========================================================================
  const fuseFootprints: [string, string][] = [
    ['Fuse_0603_1608Metric', 'Fuse.pretty · 0603 SMD Resettable PTC / Fast-Blow Fuse'],
    ['Fuse_0805_2012Metric', 'Fuse.pretty · 0805 SMD Resettable Polyfuse'],
    ['Fuse_1206_3216Metric', 'Fuse.pretty · 1206 SMD Resettable Polyfuse (500mA-2A)'],
    ['Fuse_1812_4532Metric', 'Fuse.pretty · 1812 SMD High-Current PTC Polyfuse'],
    ['Fuse_Bourns_MF-RHT', 'Fuse.pretty · Radial Through-Hole Resettable Polyfuse'],
    ['Fuseholder_Cylinder-5x20mm_Schurter_0031_8201', 'Fuse.pretty · 5x20mm Glass Cartridge Fuse Clips'],
    ['Fuse_Blade_Mini_ Littlefuse', 'Fuse.pretty · Automotive Mini Blade Fuse Holder'],
    ['RV_Disc_D7mm_W3.4mm_P5mm', 'Varistor.pretty · 7mm Radial Metal Oxide Varistor (MOV)'],
    ['RV_Disc_D10mm_W4.2mm_P7.5mm', 'Varistor.pretty · 10mm Surge Suppression MOV'],
    ['RV_Disc_D14mm_W4.5mm_P7.5mm', 'Varistor.pretty · 14mm Mains AC Surge Varistor'],
  ];
  for (const [fpName, desc] of fuseFootprints) {
    pushPart({
      kind: `KFP_${fpName.replace(/[^a-zA-Z0-9_]/g, '_')}`,
      title: fpName,
      category: 'Fuses & Protection',
      description: desc,
      refPrefix: 'F',
      defaultValue: '500mA',
      footprint: `Fuse:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'R',
      schPins: makeTwoPinSch('1', '2'),
      courtyard: { width: 5.2, height: 3.0 },
      pads: makeSmdTwoPads(3.0, 1.2, 1.6),
    });
  }

  // ==========================================================================
  // 16. Potentiometer_THT.pretty & Potentiometer_SMD.pretty -> Potentiometers & Trimmers
  // ==========================================================================
  const potFootprints: [string, string][] = [
    ['Potentiometer_Bourns_3296W_Vertical', 'Potentiometer_THT.pretty · 25-Turn Cermet Trimmer 3296W'],
    ['Potentiometer_Bourns_3362P_Vertical', 'Potentiometer_THT.pretty · Single-Turn Top-Adjust Trimmer'],
    ['Potentiometer_Bourns_3386P_Vertical', 'Potentiometer_THT.pretty · 9.5mm Square Single-Turn Trimmer'],
    ['Potentiometer_Alps_RK09K_Single_Vertical', 'Potentiometer_THT.pretty · 9mm Panel Rotary Potentiometer'],
    ['Potentiometer_Alps_RK163_Dual_Horizontal', 'Potentiometer_THT.pretty · 16mm Stereo Audio Potentiometer'],
    ['Potentiometer_Bourns_TC33X_3x3mm_SMD', 'Potentiometer_SMD.pretty · 3mm Open-Frame SMD Trimmer'],
    ['Potentiometer_Bourns_3224W_SMD', 'Potentiometer_SMD.pretty · 4mm Multi-Turn SMD Cermet Trimmer'],
  ];
  for (const [fpName, desc] of potFootprints) {
    pushPart({
      kind: `KFP_${fpName.replace(/[^a-zA-Z0-9_]/g, '_')}`,
      title: fpName,
      category: 'Potentiometers & Trimmers',
      description: desc,
      refPrefix: 'RV',
      defaultValue: '10k',
      footprint: `Potentiometer:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'TRANSISTOR',
      schPins: makeThreePinSch('1', '2', '3'),
      courtyard: { width: 9.8, height: 5.4 },
      pads: [
        { number: '1', offset: { x: -2.54, y: 0 }, width: 1.6, height: 1.6, shape: 'rect', drill: 0.8, layers: ['F.Cu', 'B.Cu'] },
        { number: '2', offset: { x: 0, y: 0 }, width: 1.6, height: 1.6, shape: 'circle', drill: 0.8, layers: ['F.Cu', 'B.Cu'] },
        { number: '3', offset: { x: 2.54, y: 0 }, width: 1.6, height: 1.6, shape: 'circle', drill: 0.8, layers: ['F.Cu', 'B.Cu'] },
      ],
    });
  }

  // ==========================================================================
  // 17. RF_Module.pretty, MCU_Module.pretty, Converter_DCDC.pretty -> Modules
  // ==========================================================================
  const moduleFootprints: [string, string][] = [
    ['ESP32-WROOM-32', 'RF_Module.pretty · Espressif Wi-Fi + BT BLE MCU Module'],
    ['ESP32-S3-WROOM-1', 'RF_Module.pretty · Dual-Core AI/Vector Wi-Fi + BLE Module'],
    ['ESP32-C3-MINI-1', 'RF_Module.pretty · RISC-V Wi-Fi + BLE 5.0 Stamp Module'],
    ['ESP-12E', 'RF_Module.pretty · ESP8266 Wi-Fi Stamp Module'],
    ['RaspberryPi_Pico_SMD_TH', 'MCU_Module.pretty · RP2040 Dual Cortex-M0+ Module (40-Pin)'],
    ['Arduino_Nano', 'MCU_Module.pretty · ATmega328P DIP-30 Module Footprint'],
    ['Teensy40', 'MCU_Module.pretty · ARM Cortex-M7 600MHz Development Module'],
    ['HopeRF_RFM95W_868S2', 'RF_Module.pretty · LoRa Long-Range Sub-GHz Transceiver'],
    ['nRF24L01_Breakout_2x04', 'RF_Module.pretty · 2.4GHz ISM Transceiver Header'],
    ['Converter_DCDC_TRACO_TSR-1_THT', 'Converter_DCDC.pretty · 1A Switching Drop-In 7805 Replacement'],
    ['Converter_DCDC_XP_Power-JCA02_SMD', 'Converter_DCDC.pretty · Isolated DC-DC Converter'],
  ];
  for (const [fpName, desc] of moduleFootprints) {
    pushPart({
      kind: `KFP_${fpName.replace(/[^a-zA-Z0-9_]/g, '_')}`,
      title: fpName,
      category: 'Modules',
      description: desc,
      refPrefix: 'U',
      defaultValue: fpName,
      footprint: `RF_Module:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'IC',
      schPins: makeDualRowSchPins(12),
      courtyard: { width: 16.0, height: 18.0 },
      pads: makeDualRowSmdPads(12, 1.27, 13.0, 1.8, 0.8),
    });
  }

  // ==========================================================================
  // 18. Socket_DIP, Connector_PinSocket -> Sockets
  // ==========================================================================
  for (const pins of [6, 8, 14, 16, 18, 20, 24, 28, 32, 40]) {
    const rowW = pins >= 24 ? 15.24 : 7.62;
    const fpName = `DIP_Socket-${pins}_W${rowW.toFixed(2)}mm_Machined`;
    pushPart({
      kind: `KFP_${fpName}`,
      title: fpName,
      category: 'Sockets',
      description: `Package_DIP.pretty · ${pins}-Pin Turned-Pin IC Socket`,
      refPrefix: 'XU',
      defaultValue: `Socket_DIP-${pins}`,
      footprint: `Package_DIP:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'IC',
      schPins: makeDualRowSchPins(pins),
      courtyard: { width: rowW + 2.8, height: (pins / 2) * 2.54 + 1.8 },
      pads: makeDualRowThtPads(pins, 2.54, rowW, 1.7, 0.9),
    });
  }

  // ==========================================================================
  // 19. MountingHole.pretty, Heatsink.pretty, Battery.pretty -> Mechanical
  // ==========================================================================
  const mechFootprints: [string, string, number, number][] = [
    ['MountingHole_2.2mm_M2_Pad_Via', 'MountingHole.pretty · M2 Grounded Screw Hole w/ Vias', 4.4, 2.2],
    ['MountingHole_2.7mm_M2.5_DIN965_Pad', 'MountingHole.pretty · M2.5 Plated Screw Hole', 5.2, 2.7],
    ['MountingHole_3.2mm_M3_DIN965_Pad', 'MountingHole.pretty · M3 Plated Screw Hole', 6.2, 3.2],
    ['MountingHole_4.3mm_M4_DIN965_Pad', 'MountingHole.pretty · M4 Plated Screw Hole', 8.0, 4.3],
    ['MountingHole_5.3mm_M5_DIN965_Pad', 'MountingHole.pretty · M5 Plated Screw Hole', 9.5, 5.3],
    ['BatteryHolder_Keystone_1060_1x2032', 'Battery.pretty · CR2032 SMD Coin Cell Retainer', 21.0, 0],
    ['BatteryHolder_Keystone_2460_1xAA', 'Battery.pretty · Single AA Cylindrical Cell Holder', 16.0, 1.0],
    ['Heatsink_Fischer_SK104-STC-STIC_35x13mm_2xDrill2.5mm', 'Heatsink.pretty · TO-220 Vertical Extruded Heatsink', 14.0, 2.5],
  ];
  for (const [fpName, desc, padDia, drill] of mechFootprints) {
    pushPart({
      kind: `KFP_${fpName.replace(/[^a-zA-Z0-9_]/g, '_')}`,
      title: fpName,
      category: 'Mechanical',
      description: desc,
      refPrefix: 'H',
      defaultValue: fpName.split('_')[1] || 'Mech',
      footprint: `MountingHole:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'CONN2',
      schPins: [{ number: '1', name: 'MNT', offset: { x: -2 * G, y: 0 } }],
      courtyard: { width: padDia + 1.0, height: padDia + 1.0 },
      pads: [
        {
          number: '1',
          offset: { x: 0, y: 0 },
          width: Math.min(8, padDia),
          height: Math.min(8, padDia),
          shape: 'circle',
          drill: drill > 0 ? drill : undefined,
          layers: ['F.Cu', 'B.Cu'],
        },
      ],
    });
  }

  // ==========================================================================
  // 20. TestPoint.pretty, Fiducial.pretty, NetTie.pretty, Jumper.pretty -> Fabrication
  // ==========================================================================
  const fabFootprints: [string, string][] = [
    ['TestPoint_Pad_D1.0mm', 'TestPoint.pretty · 1.0mm Round SMD Probe Test Pad'],
    ['TestPoint_Pad_D1.5mm', 'TestPoint.pretty · 1.5mm Round SMD Probe Test Pad'],
    ['TestPoint_Pad_D2.0mm', 'TestPoint.pretty · 2.0mm Round SMD Probe Test Pad'],
    ['TestPoint_THTPad_D1.5mm_Drill0.7mm', 'TestPoint.pretty · Plated Through-Hole Probe Loop'],
    ['TestPoint_Keystone_5000-5004_Miniature', 'TestPoint.pretty · Keystone Turret Scope Hook'],
    ['Fiducial_0.5mm_Mask1mm', 'Fiducial.pretty · 0.5mm Optical Pick-and-Place Fiducial'],
    ['Fiducial_1mm_Mask2mm', 'Fiducial.pretty · 1.0mm Optical Pick-and-Place Fiducial'],
    ['Fiducial_1.5mm_Mask3mm', 'Fiducial.pretty · 1.5mm Global Panel Fiducial'],
    ['SolderJumper-2_P1.3mm_Open_RoundedPad1.0x1.5mm', 'Jumper.pretty · 2-Pad Open Solder Bridge Jumper'],
    ['SolderJumper-3_P1.3mm_Open_RoundedPad1.0x1.5mm', 'Jumper.pretty · 3-Pad SPDT Solder Bridge Jumper'],
    ['NetTie-2_SMD_Pad0.5mm', 'NetTie.pretty · 2-Pad Copper Star-Ground Net Tie'],
  ];
  for (const [fpName, desc] of fabFootprints) {
    pushPart({
      kind: `KFP_${fpName.replace(/[^a-zA-Z0-9_]/g, '_')}`,
      title: fpName,
      category: 'Fabrication',
      description: desc,
      refPrefix: 'TP',
      defaultValue: fpName.split('_')[0],
      footprint: `TestPoint:${fpName}`,
      pcbAllowed: true,
      symbolStyle: 'CONN2',
      schPins: [{ number: '1', name: '1', offset: { x: -2 * G, y: 0 } }],
      courtyard: { width: 2.6, height: 2.6 },
      pads: [
        {
          number: '1',
          offset: { x: 0, y: 0 },
          width: 1.5,
          height: 1.5,
          shape: 'circle',
          layers: ['F.Cu'],
        },
      ],
    });
  }

  return catalog;
}
