import {
  AnyItem,
  BoundingBox,
  LibraryComponentDef,
  LibraryPackage,
  PadDef,
  PcbFootprintItem,
  PinDef,
  Point,
  Rotation,
  SchComponentItem,
  SchematicComponentKind,
  SymbolVisualStyle,
  Transform,
  ViewportTransform,
} from './types';
import { buildKicadFootprintsGitCatalog } from './kicadFootprintsPreset';

export const SCHEMATIC_GRID = 1.27; // mm (50 mil standard KiCad grid)
export const PCB_GRID = 0.5; // mm
export const TOUCH_HIT_SLOP_PX = 22; // screen pixels

export function snapVal(val: number, grid: number): number {
  if (grid <= 0) return val;
  return Math.round(val / grid) * grid;
}

export function snapPoint(pt: Point, grid: number): Point {
  return {
    x: Number(snapVal(pt.x, grid).toFixed(4)),
    y: Number(snapVal(pt.y, grid).toFixed(4)),
  };
}

export function rotatePoint(pt: Point, rotation: Rotation): Point {
  switch (rotation) {
    case 0:
      return { x: pt.x, y: pt.y };
    case 90:
      return { x: -pt.y, y: pt.x };
    case 180:
      return { x: -pt.x, y: -pt.y };
    case 270:
      return { x: pt.y, y: -pt.x };
  }
}

export function transformPoint(localPt: Point, transform: Transform): Point {
  const r = rotatePoint(localPt, transform.rotation);
  return {
    x: Number((transform.x + r.x).toFixed(4)),
    y: Number((transform.y + r.y).toFixed(4)),
  };
}

export function screenToWorld(screenPt: Point, vp: ViewportTransform): Point {
  return {
    x: (screenPt.x - vp.panX) / vp.scale,
    y: (screenPt.y - vp.panY) / vp.scale,
  };
}

export function worldToScreen(worldPt: Point, vp: ViewportTransform): Point {
  return {
    x: worldPt.x * vp.scale + vp.panX,
    y: worldPt.y * vp.scale + vp.panY,
  };
}

export function distance(a: Point, b: Point): number {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

export function distanceToSegment(p: Point, a: Point, b: Point): { dist: number; closest: Point } {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const lenSq = dx * dx + dy * dy;
  if (lenSq === 0) {
    return { dist: distance(p, a), closest: { ...a } };
  }
  let t = ((p.x - a.x) * dx + (p.y - a.y) * dy) / lenSq;
  t = Math.max(0, Math.min(1, t));
  const closest = { x: a.x + t * dx, y: a.y + t * dy };
  return { dist: distance(p, closest), closest };
}

function ccw(A: Point, B: Point, C: Point): number {
  return (C.y - A.y) * (B.x - A.x) - (B.y - A.y) * (C.x - A.x);
}

export function segmentsIntersect(a1: Point, a2: Point, b1: Point, b2: Point): boolean {
  const d1 = ccw(b1, b2, a1);
  const d2 = ccw(b1, b2, a2);
  const d3 = ccw(a1, a2, b1);
  const d4 = ccw(a1, a2, b2);

  if (((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) && ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0))) {
    return true;
  }
  if (Math.abs(d1) < 1e-6 && distanceToSegment(a1, b1, b2).dist < 1e-4) return true;
  if (Math.abs(d2) < 1e-6 && distanceToSegment(a2, b1, b2).dist < 1e-4) return true;
  if (Math.abs(d3) < 1e-6 && distanceToSegment(b1, a1, a2).dist < 1e-4) return true;
  if (Math.abs(d4) < 1e-6 && distanceToSegment(b2, a1, a2).dist < 1e-4) return true;
  return false;
}

export function segmentToSegmentDistance(a1: Point, a2: Point, b1: Point, b2: Point): { dist: number; point: Point } {
  if (segmentsIntersect(a1, a2, b1, b2)) {
    return {
      dist: 0,
      point: { x: (a1.x + a2.x + b1.x + b2.x) / 4, y: (a1.y + a2.y + b1.y + b2.y) / 4 },
    };
  }
  const c1 = distanceToSegment(a1, b1, b2);
  const c2 = distanceToSegment(a2, b1, b2);
  const c3 = distanceToSegment(b1, a1, a2);
  const c4 = distanceToSegment(b2, a1, a2);
  const candidates = [
    { dist: c1.dist, point: a1 },
    { dist: c2.dist, point: a2 },
    { dist: c3.dist, point: b1 },
    { dist: c4.dist, point: b2 },
  ];
  candidates.sort((x, y) => x.dist - y.dist);
  return candidates[0];
}

export function getComponentPinsWorld(item: SchComponentItem): { pin: PinDef; world: Point }[] {
  return item.props.pins.map((pin) => ({
    pin,
    world: transformPoint(pin.offset, item.transform),
  }));
}

export function getFootprintPadsWorld(item: PcbFootprintItem): { pad: PadDef; world: Point }[] {
  return item.props.pads.map((pad) => ({
    pad,
    world: transformPoint(pad.offset, item.transform),
  }));
}

const g = SCHEMATIC_GRID;

export function makeDualRowIcDef(
  kind: string,
  title: string,
  category: string,
  description: string,
  defaultValue: string,
  footprint: string,
  leftPins: { number: string; name: string }[],
  rightPins: { number: string; name: string }[],
  libraryId: string,
  libraryName: string,
  pitchMm = 2.54,
  rowSpanMm = 7.62,
  isSmd = false
): LibraryComponentDef {
  const maxSide = Math.max(leftPins.length, rightPins.length);
  const halfSpan = Math.floor((maxSide - 1) / 2) * g;
  const pins: PinDef[] = [
    ...leftPins.map((p, i) => ({
      number: p.number,
      name: p.name,
      offset: { x: -4 * g, y: Number((-halfSpan + i * g).toFixed(4)) },
    })),
    ...rightPins.map((p, i) => ({
      number: p.number,
      name: p.name,
      offset: { x: 4 * g, y: Number((-halfSpan + i * g).toFixed(4)) },
    })),
  ];

  const allPinCount = leftPins.length + rightPins.length;
  const halfPcbSpan = ((maxSide - 1) / 2) * pitchMm;
  const pads: PadDef[] = [
    ...leftPins.map((p, i) => ({
      number: p.number,
      offset: { x: -rowSpanMm / 2, y: Number((-halfPcbSpan + i * pitchMm).toFixed(3)) },
      width: isSmd ? 1.5 : 1.6,
      height: isSmd ? 0.65 : 1.6,
      shape: (p.number === '1' || isSmd ? 'rect' : 'circle') as 'rect' | 'circle',
      drill: isSmd ? undefined : 0.8,
      layers: (isSmd ? ['F.Cu'] : ['F.Cu', 'B.Cu']) as ('F.Cu' | 'B.Cu')[],
    })),
    ...rightPins.map((p, i) => ({
      number: p.number,
      offset: { x: rowSpanMm / 2, y: Number((-halfPcbSpan + i * pitchMm).toFixed(3)) },
      width: isSmd ? 1.5 : 1.6,
      height: isSmd ? 0.65 : 1.6,
      shape: (isSmd ? 'rect' : 'circle') as 'rect' | 'circle',
      drill: isSmd ? undefined : 0.8,
      layers: (isSmd ? ['F.Cu'] : ['F.Cu', 'B.Cu']) as ('F.Cu' | 'B.Cu')[],
    })),
  ];

  return {
    kind,
    title,
    category,
    description: `${description} · ${allPinCount} Pins`,
    refPrefix: 'U',
    defaultValue,
    footprint,
    symbolStyle: 'IC',
    pins,
    courtyard: {
      width: Number((rowSpanMm + 3.0).toFixed(1)),
      height: Number((Math.max(4, maxSide * pitchMm + 2.0)).toFixed(1)),
    },
    pads,
    pcbAllowed: true,
    libraryId,
    libraryName,
  };
}

export const OFFICIAL_FOOTPRINT_CATEGORIES: string[] = [
  'Audio',
  'Capacitors',
  'Connectors',
  'Crystals & Oscillators',
  'Diodes',
  'Displays',
  'Fabrication',
  'Fuses & Protection',
  'ICs',
  'Inductors',
  'LEDs',
  'Mechanical',
  'Modules',
  'Potentiometers & Trimmers',
  'Relays',
  'Resistors',
  'Sensors',
  'Sockets',
  'Switches',
  'Transistors & Regulators',
];

/**
 * Automatically classifies any symbol or footprint (from GitHub .kicad_sym, JSON, or web catalog)
 * into one of the 20 OFFICIAL_FOOTPRINT_CATEGORIES so imported parts appear in their respective folders.
 */
export function classifyComponentCategory(
  name: string,
  refPrefix: string,
  description = '',
  footprint = '',
  sourceName = '',
  rawCategory = ''
): string {
  if (rawCategory && OFFICIAL_FOOTPRINT_CATEGORIES.includes(rawCategory)) {
    return rawCategory;
  }
  const combined = `${name} ${description} ${footprint} ${sourceName} ${rawCategory}`.toLowerCase();
  const ref = refPrefix.replace(/[0-9?]/g, '').toUpperCase();

  if (
    ref === 'RV' ||
    combined.includes('potentiometer') ||
    combined.includes('trimmer') ||
    combined.includes('3296') ||
    combined.includes('bourns')
  ) {
    return 'Potentiometers & Trimmers';
  }
  if (ref === 'R' || combined.includes('resistor') || combined.includes('r_0') || combined.includes('r_1206')) {
    return 'Resistors';
  }
  if (ref === 'C' || combined.includes('capacitor') || combined.includes('c_0') || combined.includes('cp_radial')) {
    return 'Capacitors';
  }
  if (ref === 'L' || ref === 'FB' || combined.includes('inductor') || combined.includes('ferrite') || combined.includes('choke')) {
    return 'Inductors';
  }
  if (
    combined.includes('led') ||
    combined.includes('ws2812') ||
    combined.includes('neopixel') ||
    combined.includes('sk6812') ||
    combined.includes('photodiode')
  ) {
    return 'LEDs';
  }
  if (
    ref === 'F' ||
    combined.includes('fuse') ||
    combined.includes('polyfuse') ||
    combined.includes('ptc') ||
    combined.includes('tvs') ||
    combined.includes('varistor') ||
    combined.includes('esd')
  ) {
    return 'Fuses & Protection';
  }
  if (
    ref === 'D' ||
    combined.includes('diode') ||
    combined.includes('1n4148') ||
    combined.includes('1n400') ||
    combined.includes('1n5819') ||
    combined.includes('schottky') ||
    combined.includes('zener') ||
    combined.includes('rectifier') ||
    combined.includes('ss14')
  ) {
    return 'Diodes';
  }
  if (
    ref === 'Q' ||
    combined.includes('transistor') ||
    combined.includes('mosfet') ||
    combined.includes('bjt') ||
    combined.includes('npn') ||
    combined.includes('pnp') ||
    combined.includes('nmos') ||
    combined.includes('pmos') ||
    combined.includes('regulator') ||
    combined.includes('ldo') ||
    combined.includes('ams1117') ||
    combined.includes('lm78') ||
    combined.includes('lm317') ||
    combined.includes('2n2222') ||
    combined.includes('bc547') ||
    combined.includes('ao3400') ||
    combined.includes('irfz') ||
    combined.includes('uln2003')
  ) {
    return 'Transistors & Regulators';
  }
  if (
    ref === 'SW' ||
    combined.includes('switch') ||
    combined.includes('button') ||
    combined.includes('tactile') ||
    combined.includes('cherry') ||
    combined.includes('encoder') ||
    combined.includes('keyswitch')
  ) {
    return 'Switches';
  }
  if (ref === 'K' || combined.includes('relay') || combined.includes('srd-')) {
    return 'Relays';
  }
  if (
    ref === 'Y' ||
    ref === 'X' ||
    combined.includes('crystal') ||
    combined.includes('oscillator') ||
    combined.includes('xtal') ||
    combined.includes('resonator') ||
    combined.includes('mhz') ||
    combined.includes('32.768')
  ) {
    return 'Crystals & Oscillators';
  }
  if (
    ref === 'BZ' ||
    ref === 'LS' ||
    ref === 'MK' ||
    combined.includes('buzzer') ||
    combined.includes('speaker') ||
    combined.includes('audio') ||
    combined.includes('microphone') ||
    combined.includes('piezo')
  ) {
    return 'Audio';
  }
  if (
    ref === 'DS' ||
    combined.includes('oled') ||
    combined.includes('lcd') ||
    combined.includes('display') ||
    combined.includes('ssd1306') ||
    combined.includes('7seg') ||
    combined.includes('seven_segment') ||
    combined.includes('1602')
  ) {
    return 'Displays';
  }
  if (
    combined.includes('sensor') ||
    combined.includes('bme280') ||
    combined.includes('bmp280') ||
    combined.includes('mpu6050') ||
    combined.includes('dht') ||
    combined.includes('ds18b20') ||
    combined.includes('thermistor') ||
    combined.includes('ntc') ||
    combined.includes('ldr') ||
    combined.includes('photoresistor') ||
    combined.includes('ultrasonic') ||
    combined.includes('hc-sr04') ||
    combined.includes('ina219') ||
    combined.includes('hall')
  ) {
    return 'Sensors';
  }
  if (
    combined.includes('esp32') ||
    combined.includes('esp8266') ||
    combined.includes('wroom') ||
    combined.includes('module') ||
    combined.includes('rf_module') ||
    combined.includes('breakout') ||
    combined.includes('stamp') ||
    combined.includes('pico') ||
    combined.includes('nrf24') ||
    combined.includes('lora')
  ) {
    return 'Modules';
  }
  if (
    ref === 'J' ||
    ref === 'P' ||
    ref === 'CN' ||
    combined.includes('connector') ||
    combined.includes('header') ||
    combined.includes('pinheader') ||
    combined.includes('usb') ||
    combined.includes('jst') ||
    combined.includes('barrel') ||
    combined.includes('terminal') ||
    combined.includes('rj45') ||
    combined.includes('sd_card')
  ) {
    return 'Connectors';
  }
  if (combined.includes('socket') || combined.includes('dip-') && combined.includes('skt')) {
    return 'Sockets';
  }
  if (
    ref === 'H' ||
    combined.includes('mounting') ||
    combined.includes('hole') ||
    combined.includes('standoff') ||
    combined.includes('heatsink') ||
    combined.includes('mechanical')
  ) {
    return 'Mechanical';
  }
  if (
    ref === 'FID' ||
    ref === 'TP' ||
    combined.includes('fiducial') ||
    combined.includes('testpoint') ||
    combined.includes('fabrication') ||
    combined.includes('logo')
  ) {
    return 'Fabrication';
  }
  return 'ICs';
}

function makeTwoPinPart(
  kind: string,
  title: string,
  category: string,
  description: string,
  refPrefix: string,
  defaultValue: string,
  footprint: string,
  symbolStyle: SymbolVisualStyle,
  padPitchMm = 2.0,
  isTht = false
): LibraryComponentDef {
  return {
    kind,
    title,
    category,
    description,
    refPrefix,
    defaultValue,
    footprint,
    symbolStyle,
    pins: [
      { number: '1', name: '1', offset: { x: -3 * g, y: 0 } },
      { number: '2', name: '2', offset: { x: 3 * g, y: 0 } },
    ],
    courtyard: { width: Number((padPitchMm + 2.5).toFixed(1)), height: isTht ? 4.0 : 2.5 },
    pads: [
      {
        number: '1',
        offset: { x: Number((-padPitchMm / 2).toFixed(2)), y: 0 },
        width: isTht ? 1.8 : 1.2,
        height: isTht ? 1.8 : 1.4,
        shape: 'rect',
        drill: isTht ? 0.9 : undefined,
        layers: isTht ? ['F.Cu', 'B.Cu'] : ['F.Cu'],
      },
      {
        number: '2',
        offset: { x: Number((padPitchMm / 2).toFixed(2)), y: 0 },
        width: isTht ? 1.8 : 1.2,
        height: isTht ? 1.8 : 1.4,
        shape: isTht ? 'circle' : 'rect',
        drill: isTht ? 0.9 : undefined,
        layers: isTht ? ['F.Cu', 'B.Cu'] : ['F.Cu'],
      },
    ],
    pcbAllowed: true,
    libraryId: 'builtin_core',
    libraryName: 'Official Library',
  };
}

function makePinHeaderPart(pinCount: number): LibraryComponentDef {
  const halfSpan = ((pinCount - 1) / 2) * g;
  const halfPcb = ((pinCount - 1) / 2) * 2.54;
  return {
    kind: pinCount === 2 ? 'CONN2' : `CONN_1X0${pinCount}`,
    title: `PinHeader_1x0${pinCount}_P2.54mm`,
    category: 'Connectors',
    description: `2.54mm THT Header · ${pinCount} Pads`,
    refPrefix: 'J',
    defaultValue: `CONN_${pinCount}P`,
    footprint: `PinHeader_1x0${pinCount}_P2.54mm`,
    symbolStyle: pinCount === 2 ? 'CONN2' : 'IC',
    pins: Array.from({ length: pinCount }, (_, i) => ({
      number: String(i + 1),
      name: `P${i + 1}`,
      offset: {
        x: pinCount === 2 ? -2 * g : -4 * g,
        y: pinCount === 2 ? (i === 0 ? -g : g) : Number((-halfSpan + i * g).toFixed(4)),
      },
    })),
    courtyard: { width: 3.6, height: Number((pinCount * 2.54 + 1.5).toFixed(1)) },
    pads: Array.from({ length: pinCount }, (_, i) => ({
      number: String(i + 1),
      offset: { x: 0, y: Number((-halfPcb + i * 2.54).toFixed(2)) },
      width: 1.75,
      height: 1.75,
      shape: i === 0 ? 'rect' : 'circle',
      drill: 1.0,
      layers: ['F.Cu', 'B.Cu'],
    })),
    pcbAllowed: true,
    libraryId: 'builtin_core',
    libraryName: 'Official Library',
  };
}

function makeThreePinSOT23Part(
  kind: string,
  title: string,
  category: string,
  description: string,
  refPrefix: string,
  defaultValue: string,
  footprint: string,
  pinNames: [string, string, string] = ['B', 'C', 'E']
): LibraryComponentDef {
  return {
    kind,
    title,
    category,
    description,
    refPrefix,
    defaultValue,
    footprint,
    symbolStyle: 'TRANSISTOR',
    pins: [
      { number: '1', name: pinNames[0], offset: { x: -3 * g, y: 0 } },
      { number: '2', name: pinNames[1], offset: { x: 1 * g, y: -2 * g } },
      { number: '3', name: pinNames[2], offset: { x: 1 * g, y: 2 * g } },
    ],
    courtyard: { width: 4.4, height: 4.0 },
    pads: [
      { number: '1', offset: { x: -0.95, y: 1.1 }, width: 1.0, height: 1.2, shape: 'rect', layers: ['F.Cu'] },
      { number: '2', offset: { x: 0.95, y: 1.1 }, width: 1.0, height: 1.2, shape: 'rect', layers: ['F.Cu'] },
      { number: '3', offset: { x: 0, y: -1.1 }, width: 1.0, height: 1.2, shape: 'rect', layers: ['F.Cu'] },
    ],
    pcbAllowed: true,
    libraryId: 'builtin_core',
    libraryName: 'Official Library',
  };
}

export const BUILTIN_LIBRARY_PARTS: LibraryComponentDef[] = [
  // ================= RESISTORS =================
  {
    kind: 'R',
    title: 'R_0805_2012Metric',
    category: 'Resistors',
    description: 'R_0805 SMD · 2 Pads',
    refPrefix: 'R',
    defaultValue: '1k',
    footprint: 'R_0805',
    symbolStyle: 'R',
    pins: [
      { number: '1', name: '1', offset: { x: -3 * g, y: 0 } },
      { number: '2', name: '2', offset: { x: 3 * g, y: 0 } },
    ],
    courtyard: { width: 4.5, height: 2.5 },
    pads: [
      { number: '1', offset: { x: -1.0, y: 0 }, width: 1.2, height: 1.4, shape: 'rect', layers: ['F.Cu'] },
      { number: '2', offset: { x: 1.0, y: 0 }, width: 1.2, height: 1.4, shape: 'rect', layers: ['F.Cu'] },
    ],
    pcbAllowed: true,
    libraryId: 'builtin_core',
    libraryName: 'Official Library',
  },
  makeTwoPinPart('R_0402_SMD', 'R_0402_1005Metric', 'Resistors', 'R_0402 Ultra-Compact SMD · 2 Pads', 'R', '10k', 'R_0402', 'R', 1.0, false),
  makeTwoPinPart('R_0603_SMD', 'R_0603_1608Metric', 'Resistors', 'R_0603 Standard SMD · 2 Pads', 'R', '4.7k', 'R_0603', 'R', 1.6, false),
  makeTwoPinPart('R_1206_SMD', 'R_1206_3216Metric', 'Resistors', 'R_1206 1/4W Power SMD · 2 Pads', 'R', '100R', 'R_1206', 'R', 3.0, false),
  makeTwoPinPart('R_AXIAL_THT', 'R_Axial_DIN0207_L6.3mm', 'Resistors', 'Axial 1/4W THT Resistor · 2 Pads', 'R', '10k', 'R_Axial_DIN0207', 'R', 7.62, true),
  makeTwoPinPart('R_SHUNT_2512', 'R_2512_6332Metric_Shunt', 'Resistors', 'Current Sense 1W Shunt SMD', 'R', '0.1R', 'R_2512', 'R', 5.0, false),

  // ================= CAPACITORS =================
  {
    kind: 'C',
    title: 'C_0805_2012Metric',
    category: 'Capacitors',
    description: 'C_0805 Ceramic SMD · 2 Pads',
    refPrefix: 'C',
    defaultValue: '100nF',
    footprint: 'C_0805',
    symbolStyle: 'C',
    pins: [
      { number: '1', name: '1', offset: { x: -3 * g, y: 0 } },
      { number: '2', name: '2', offset: { x: 3 * g, y: 0 } },
    ],
    courtyard: { width: 4.5, height: 2.5 },
    pads: [
      { number: '1', offset: { x: -1.0, y: 0 }, width: 1.2, height: 1.4, shape: 'rect', layers: ['F.Cu'] },
      { number: '2', offset: { x: 1.0, y: 0 }, width: 1.2, height: 1.4, shape: 'rect', layers: ['F.Cu'] },
    ],
    pcbAllowed: true,
    libraryId: 'builtin_core',
    libraryName: 'Official Library',
  },
  makeTwoPinPart('C_0402_SMD', 'C_0402_1005Metric', 'Capacitors', 'C_0402 Ceramic Decoupling · 2 Pads', 'C', '100nF', 'C_0402', 'C', 1.0, false),
  makeTwoPinPart('C_0603_SMD', 'C_0603_1608Metric', 'Capacitors', 'C_0603 Ceramic SMD · 2 Pads', 'C', '1uF', 'C_0603', 'C', 1.6, false),
  makeTwoPinPart('C_1206_SMD', 'C_1206_3216Metric', 'Capacitors', 'C_1206 Bulk MLCC SMD · 2 Pads', 'C', '10uF', 'C_1206', 'C', 3.0, false),
  makeTwoPinPart('CP_RADIAL_5MM', 'CP_Radial_D5.0mm_P2.50mm', 'Capacitors', 'Electrolytic Radial Cap 5mm · 2 Pads', 'C', '10uF', 'CP_Radial_D5.0mm', 'C', 2.5, true),
  makeTwoPinPart('CP_RADIAL_8MM', 'CP_Radial_D8.0mm_P3.50mm', 'Capacitors', 'Electrolytic Radial Cap 8mm · 2 Pads', 'C', '100uF', 'CP_Radial_D8.0mm', 'C', 3.5, true),
  makeTwoPinPart('C_DISC_THT', 'C_Disc_D5.0mm_W2.5mm_P5.00mm', 'Capacitors', 'Ceramic Disc Capacitor THT · 2 Pads', 'C', '22pF', 'C_Disc_P5.00mm', 'C', 5.0, true),

  // ================= INDUCTORS =================
  makeTwoPinPart('L_INDUCTOR_0805', 'L_0805_2012Metric', 'Inductors', 'RF/Signal SMD Inductor · 2 Pads', 'L', '4.7uH', 'L_0805', 'R', 2.0, false),
  makeTwoPinPart('L_INDUCTOR_1008', 'L_1008_2520Metric', 'Inductors', 'Power Inductor SMD 10uH · 2 Pads', 'L', '10uH', 'L_1008', 'R', 2.5, false),
  makeTwoPinPart('L_TOROID_THT', 'L_Radial_D7.8mm_P5.00mm', 'Inductors', 'Radial Power Buck Inductor · 2 Pads', 'L', '100uH', 'L_Radial_P5.00mm', 'R', 5.0, true),
  makeTwoPinPart('FB_0805_SMD', 'FerriteBead_0805_2012Metric', 'Inductors', 'EMI Filter Ferrite Bead 600R@100MHz', 'FB', '600R', 'FB_0805', 'R', 2.0, false),

  // ================= LEDS =================
  {
    kind: 'LED',
    title: 'LED_D5.0mm_THT',
    category: 'LEDs',
    description: 'LED 5mm THT · 2 Pads',
    refPrefix: 'D',
    defaultValue: 'RED',
    footprint: 'LED_5mm_THT',
    symbolStyle: 'LED',
    pins: [
      { number: '1', name: 'A', offset: { x: -3 * g, y: 0 } },
      { number: '2', name: 'K', offset: { x: 3 * g, y: 0 } },
    ],
    courtyard: { width: 6.0, height: 4.0 },
    pads: [
      { number: '1', offset: { x: -1.27, y: 0 }, width: 1.8, height: 1.8, shape: 'rect', drill: 0.9, layers: ['F.Cu', 'B.Cu'] },
      { number: '2', offset: { x: 1.27, y: 0 }, width: 1.8, height: 1.8, shape: 'circle', drill: 0.9, layers: ['F.Cu', 'B.Cu'] },
    ],
    pcbAllowed: true,
    libraryId: 'builtin_core',
    libraryName: 'Official Library',
  },
  makeTwoPinPart('LED_3MM_THT', 'LED_D3.0mm_THT', 'LEDs', 'Compact 3mm THT LED · 2 Pads', 'D', 'YELLOW', 'LED_3mm_THT', 'LED', 2.54, true),
  makeTwoPinPart('LED_0603_SMD', 'LED_0603_1608Metric', 'LEDs', 'SMD 0603 Status LED · 2 Pads', 'D', 'BLUE', 'LED_0603', 'LED', 1.6, false),
  makeTwoPinPart('LED_0805_SMD', 'LED_0805_2012Metric', 'LEDs', 'SMD 0805 Indicator LED · 2 Pads', 'D', 'GREEN', 'LED_0805', 'LED', 2.0, false),
  makeDualRowIcDef(
    'LED_WS2812B',
    'LED_WS2812B_PLCC4_5050',
    'LEDs',
    'Addressable RGB NeoPixel LED',
    'WS2812B',
    'LED_WS2812B_5050',
    [
      { number: '1', name: 'VDD' },
      { number: '2', name: 'DOUT' },
    ],
    [
      { number: '4', name: 'DIN' },
      { number: '3', name: 'VSS' },
    ],
    'builtin_core',
    'Official Library',
    2.54,
    5.0,
    true
  ),

  // ================= DIODES =================
  makeTwoPinPart('D_1N4148', 'D_DO-35_SOD27_P7.62mm', 'Diodes', '1N4148 High-Speed Signal Diode', 'D', '1N4148', 'D_DO-35', 'LED', 7.62, true),
  makeTwoPinPart('D_1N4007', 'D_DO-41_SOD81_P10.16mm', 'Diodes', '1N4007 1A 1000V Rectifier Diode', 'D', '1N4007', 'D_DO-41', 'LED', 7.62, true),
  makeTwoPinPart('D_1N5819', 'D_Schottky_DO-41_1N5819', 'Diodes', '1N5819 1A Low-Drop Schottky Diode', 'D', '1N5819', 'D_DO-41', 'LED', 7.62, true),
  makeTwoPinPart('D_SS14_SMA', 'D_SMA_DO-214AC_SS14', 'Diodes', 'SS14 1A 40V SMD Schottky Diode', 'D', 'SS14', 'D_SMA', 'LED', 4.0, false),
  makeTwoPinPart('D_ZENER_3V3', 'D_SOD-123_BZT52C3V3', 'Diodes', '3.3V 500mW SMD Zener Diode', 'D', '3V3_ZENER', 'D_SOD-123', 'LED', 2.8, false),

  // ================= TRANSISTORS & REGULATORS =================
  makeThreePinSOT23Part('Q_2N2222_SOT23', 'SOT-23_NPN_2N2222', 'Transistors & Regulators', 'NPN General Purpose Transistor SOT-23', 'Q', '2N2222', 'SOT-23', ['B', 'C', 'E']),
  makeThreePinSOT23Part('Q_BC547_TO92', 'TO-92_NPN_BC547', 'Transistors & Regulators', 'BC547 Low-Noise NPN Transistor', 'Q', 'BC547', 'TO-92', ['B', 'C', 'E']),
  makeThreePinSOT23Part('Q_2N3906_PNP', 'SOT-23_PNP_2N3906', 'Transistors & Regulators', '2N3906 PNP Switching Transistor', 'Q', '2N3906', 'SOT-23', ['B', 'C', 'E']),
  makeThreePinSOT23Part('Q_AO3400_NMOS', 'SOT-23_NMOS_AO3400A', 'Transistors & Regulators', '30V 5.7A Logic-Level N-MOSFET', 'Q', 'AO3400', 'SOT-23', ['G', 'D', 'S']),
  makeThreePinSOT23Part('Q_IRFZ44N_TO220', 'TO-220-3_NMOS_IRFZ44N', 'Transistors & Regulators', '55V 49A Power N-MOSFET TO-220', 'Q', 'IRFZ44N', 'TO-220-3', ['G', 'D', 'S']),
  makeDualRowIcDef(
    'U_AMS1117_3V3',
    'AMS1117-3.3_SOT223',
    'Transistors & Regulators',
    '1A 3.3V Low-Dropout Linear Regulator',
    'AMS1117-3.3',
    'SOT-223',
    [
      { number: '3', name: 'VIN' },
      { number: '1', name: 'GND' },
    ],
    [
      { number: '2', name: 'VOUT' },
      { number: '4', name: 'TAB' },
    ],
    'builtin_core',
    'Official Library',
    2.3,
    6.2,
    true
  ),
  makeDualRowIcDef(
    'U_LM7805_TO220',
    'LM7805_TO220_5V_Reg',
    'Transistors & Regulators',
    '1.5A +5V Positive Voltage Regulator',
    'LM7805',
    'TO-220-3',
    [
      { number: '1', name: 'IN' },
      { number: '2', name: 'GND' },
    ],
    [
      { number: '3', name: 'OUT' },
      { number: '4', name: 'GND_TAB' },
    ],
    'builtin_core',
    'Official Library',
    2.54,
    5.08,
    false
  ),

  // ================= ICS =================
  {
    kind: 'NE555',
    title: 'DIP-8_W7.62mm (NE555)',
    category: 'ICs',
    description: 'Precision Timer IC DIP-8 · 8 Pads',
    refPrefix: 'U',
    defaultValue: 'NE555',
    footprint: 'DIP-8',
    symbolStyle: 'IC',
    pins: [
      { number: '1', name: 'GND', offset: { x: -4 * g, y: -1 * g } },
      { number: '2', name: 'TRIG', offset: { x: -4 * g, y: 0 * g } },
      { number: '3', name: 'OUT', offset: { x: -4 * g, y: 1 * g } },
      { number: '4', name: 'RST', offset: { x: -4 * g, y: 2 * g } },
      { number: '8', name: 'VCC', offset: { x: 4 * g, y: -1 * g } },
      { number: '7', name: 'DIS', offset: { x: 4 * g, y: 0 * g } },
      { number: '6', name: 'THR', offset: { x: 4 * g, y: 1 * g } },
      { number: '5', name: 'CV', offset: { x: 4 * g, y: 2 * g } },
    ],
    courtyard: { width: 10.5, height: 11.5 },
    pads: [
      { number: '1', offset: { x: -3.81, y: -3.81 }, width: 1.6, height: 1.6, shape: 'rect', drill: 0.8, layers: ['F.Cu', 'B.Cu'] },
      { number: '2', offset: { x: -3.81, y: -1.27 }, width: 1.6, height: 1.6, shape: 'circle', drill: 0.8, layers: ['F.Cu', 'B.Cu'] },
      { number: '3', offset: { x: -3.81, y: 1.27 }, width: 1.6, height: 1.6, shape: 'circle', drill: 0.8, layers: ['F.Cu', 'B.Cu'] },
      { number: '4', offset: { x: -3.81, y: 3.81 }, width: 1.6, height: 1.6, shape: 'circle', drill: 0.8, layers: ['F.Cu', 'B.Cu'] },
      { number: '8', offset: { x: 3.81, y: -3.81 }, width: 1.6, height: 1.6, shape: 'circle', drill: 0.8, layers: ['F.Cu', 'B.Cu'] },
      { number: '7', offset: { x: 3.81, y: -1.27 }, width: 1.6, height: 1.6, shape: 'circle', drill: 0.8, layers: ['F.Cu', 'B.Cu'] },
      { number: '6', offset: { x: 3.81, y: 1.27 }, width: 1.6, height: 1.6, shape: 'circle', drill: 0.8, layers: ['F.Cu', 'B.Cu'] },
      { number: '5', offset: { x: 3.81, y: 3.81 }, width: 1.6, height: 1.6, shape: 'circle', drill: 0.8, layers: ['F.Cu', 'B.Cu'] },
    ],
    pcbAllowed: true,
    libraryId: 'builtin_core',
    libraryName: 'Official Library',
  },
  {
    kind: 'LM358_DUAL_OPAMP',
    title: 'LM358_SOIC-8_Dual_OpAmp',
    category: 'ICs',
    description: 'Low-Power Dual Operational Amplifier',
    refPrefix: 'U',
    defaultValue: 'LM358',
    footprint: 'DIP-8',
    symbolStyle: 'OPAMP',
    pins: [
      { number: '2', name: 'IN-', offset: { x: -3 * g, y: -1 * g } },
      { number: '3', name: 'IN+', offset: { x: -3 * g, y: 1 * g } },
      { number: '1', name: 'OUT', offset: { x: 3 * g, y: 0 } },
      { number: '8', name: 'V+', offset: { x: 0, y: -2 * g } },
      { number: '4', name: 'V-', offset: { x: 0, y: 2 * g } },
    ],
    courtyard: { width: 9.6, height: 7.5 },
    pads: [
      { number: '1', offset: { x: -3.81, y: -2.54 }, width: 1.6, height: 1.6, shape: 'rect', drill: 0.8, layers: ['F.Cu', 'B.Cu'] },
      { number: '2', offset: { x: -3.81, y: 0 }, width: 1.6, height: 1.6, shape: 'circle', drill: 0.8, layers: ['F.Cu', 'B.Cu'] },
      { number: '3', offset: { x: -3.81, y: 2.54 }, width: 1.6, height: 1.6, shape: 'circle', drill: 0.8, layers: ['F.Cu', 'B.Cu'] },
      { number: '4', offset: { x: 3.81, y: 2.54 }, width: 1.6, height: 1.6, shape: 'circle', drill: 0.8, layers: ['F.Cu', 'B.Cu'] },
      { number: '8', offset: { x: 3.81, y: -2.54 }, width: 1.6, height: 1.6, shape: 'circle', drill: 0.8, layers: ['F.Cu', 'B.Cu'] },
    ],
    pcbAllowed: true,
    libraryId: 'builtin_core',
    libraryName: 'Official Library',
  },
  makeDualRowIcDef(
    'U_ATMEGA328P',
    'ATmega328P-PU_AVR_MCU',
    'ICs',
    '8-bit AVR Microcontroller (Arduino Core)',
    'ATmega328P',
    'DIP-8_Core',
    [
      { number: '1', name: 'RST' },
      { number: '2', name: 'RXD' },
      { number: '3', name: 'TXD' },
      { number: '4', name: 'GND' },
    ],
    [
      { number: '8', name: 'VCC' },
      { number: '7', name: 'SCK' },
      { number: '6', name: 'MISO' },
      { number: '5', name: 'MOSI' },
    ],
    'builtin_core',
    'Official Library',
    2.54,
    7.62,
    false
  ),
  makeDualRowIcDef(
    'U_TP4056_CHARGER',
    'TP4056_ESOP8_LiIon_Charger',
    'ICs',
    '1A Standalone Linear Li-Ion Battery Charger',
    'TP4056',
    'SOIC-8',
    [
      { number: '1', name: 'TEMP' },
      { number: '2', name: 'PROG' },
      { number: '3', name: 'GND' },
      { number: '4', name: 'VCC' },
    ],
    [
      { number: '8', name: 'CE' },
      { number: '7', name: 'CHRG' },
      { number: '6', name: 'STDBY' },
      { number: '5', name: 'BAT' },
    ],
    'builtin_core',
    'Official Library',
    1.27,
    5.4,
    true
  ),
  makeDualRowIcDef(
    'U_74HC595',
    '74HC595_Shift_Register',
    'ICs',
    '8-Bit Serial-In Parallel-Out Shift Register',
    '74HC595',
    'SOIC-8',
    [
      { number: '1', name: 'SER' },
      { number: '2', name: 'SRCLK' },
      { number: '3', name: 'RCLK' },
      { number: '4', name: 'GND' },
    ],
    [
      { number: '8', name: 'VCC' },
      { number: '7', name: 'QA' },
      { number: '6', name: 'QB' },
      { number: '5', name: 'QH*' },
    ],
    'builtin_core',
    'Official Library',
    2.54,
    7.62,
    false
  ),

  // ================= CONNECTORS =================
  makePinHeaderPart(2),
  makePinHeaderPart(3),
  makePinHeaderPart(4),
  makePinHeaderPart(6),
  makeDualRowIcDef(
    'J_USB_C_PWR',
    'USB_C_Receptacle_PowerOnly_6P',
    'Connectors',
    'USB Type-C 5V Power & CC Receptacle',
    'USB-C',
    'USB_C_6Pin_SMD',
    [
      { number: '1', name: 'VBUS' },
      { number: '2', name: 'CC1' },
    ],
    [
      { number: '4', name: 'GND' },
      { number: '3', name: 'CC2' },
    ],
    'builtin_core',
    'Official Library',
    2.0,
    6.5,
    true
  ),
  makeTwoPinPart('J_BARREL_DC', 'BarrelJack_DC_2.1x5.5mm', 'Connectors', 'DC Power Barrel Jack THT · 2 Pads', 'J', 'DC_IN', 'BarrelJack_Horizontal', 'CONN2', 5.0, true),
  makeTwoPinPart('J_JST_PH_2P', 'JST_PH_B2B-PH-K_1x02_P2.00mm', 'Connectors', '2.0mm Pitch LiPo Battery Connector', 'J', 'BATT_2P', 'JST_PH_1x02_P2.0mm', 'CONN2', 2.0, true),
  makeTwoPinPart('J_SCREW_2P', 'TerminalBlock_bornier-2_P5.08mm', 'Connectors', '5.08mm Screw Terminal Block · 2 Pads', 'J', 'TERM_2P', 'TerminalBlock_P5.08mm', 'CONN2', 5.08, true),

  // ================= SWITCHES =================
  {
    kind: 'SW_CHERRY_MX',
    title: 'SW_Cherry_MX_2.00u_PCB',
    category: 'Switches',
    description: 'Cherry MX Mechanical Keyswitch PCB Mount',
    refPrefix: 'SW',
    defaultValue: 'CHERRY_MX',
    footprint: 'SW_Cherry_MX_2.00u_PCB',
    symbolStyle: 'SWITCH',
    pins: [
      { number: '1', name: '1', offset: { x: -3 * g, y: 0 } },
      { number: '2', name: '2', offset: { x: 3 * g, y: 0 } },
    ],
    courtyard: { width: 14.0, height: 14.0 },
    pads: [
      { number: '1', offset: { x: -3.81, y: -2.54 }, width: 2.2, height: 2.2, shape: 'rect', drill: 1.5, layers: ['F.Cu', 'B.Cu'] },
      { number: '2', offset: { x: 2.54, y: -5.08 }, width: 2.2, height: 2.2, shape: 'circle', drill: 1.5, layers: ['F.Cu', 'B.Cu'] },
    ],
    pcbAllowed: true,
    libraryId: 'builtin_core',
    libraryName: 'Official Library',
  },
  makeTwoPinPart('SW_TACT_6MM', 'SW_Push_6mm_H4.3mm_THT', 'Switches', '6x6mm Tactile Momentary Pushbutton', 'SW', 'PUSH', 'SW_PUSH_6mm', 'SWITCH', 4.5, true),
  makeTwoPinPart('SW_SLIDE_SPDT', 'SW_SPDT_Slide_PCM12', 'Switches', 'Compact SMD Slide Switch ON/OFF', 'SW', 'PWR_SW', 'SW_Slide_PCM12', 'SWITCH', 3.0, false),
  makeDualRowIcDef(
    'SW_DIP_4P',
    'SW_DIP_x4_W7.62mm_Slide',
    'Switches',
    '4-Position THT DIP Configuration Switch',
    'DIP_SW4',
    'SW_DIP_x4_W7.62mm',
    [
      { number: '1', name: 'S1A' },
      { number: '2', name: 'S2A' },
      { number: '3', name: 'S3A' },
      { number: '4', name: 'S4A' },
    ],
    [
      { number: '8', name: 'S1B' },
      { number: '7', name: 'S2B' },
      { number: '6', name: 'S3B' },
      { number: '5', name: 'S4B' },
    ],
    'builtin_core',
    'Official Library',
    2.54,
    7.62,
    false
  ),

  // ================= AUDIO =================
  makeTwoPinPart('BZ_PIEZO_12MM', 'Buzzer_12x9.5RM7.6', 'Audio', 'Magnetic Piezo Buzzer THT · 2 Pads', 'BZ', 'BUZZER', 'Buzzer_12x9.5RM7.6', 'C', 7.6, true),
  makeTwoPinPart('MK_ELECTRET_9MM', 'Microphone_Electret_9.7mm', 'Audio', 'Omnidirectional Electret Condenser Mic', 'MK', 'MIC', 'Mic_Electret_9.7mm', 'C', 2.54, true),
  makeTwoPinPart('LS_SPEAKER_8OHM', 'Speaker_Pads_8Ohm_1W', 'Audio', 'Mini 8Ω 1W Speaker Wire Pads', 'LS', '8R_1W', 'Speaker_Pads_P5.08mm', 'CONN2', 5.08, true),
  makeDualRowIcDef(
    'J_AUDIO_35MM',
    'Jack_3.5mm_TRS_Stereo',
    'Audio',
    '3.5mm Stereo Headphone Jack THT',
    'TRS_3.5MM',
    'AudioJack_3.5mm_TRS',
    [
      { number: '1', name: 'SLEEVE' },
      { number: '2', name: 'TIP' },
    ],
    [
      { number: '3', name: 'RING' },
      { number: '4', name: 'SW' },
    ],
    'builtin_core',
    'Official Library',
    5.0,
    8.0,
    false
  ),

  // ================= CRYSTALS & OSCILLATORS =================
  makeTwoPinPart('XTAL_HC49', 'Crystal_HC49-4H_Vertical', 'Crystals & Oscillators', '16MHz Quartz Crystal THT · 2 Pads', 'Y', '16MHz', 'Crystal_HC49-4H', 'CRYSTAL', 4.88, true),
  makeTwoPinPart('XTAL_32768_CYL', 'Crystal_AT310_D3.0mm_32.768kHz', 'Crystals & Oscillators', '32.768kHz RTC Tuning Fork Crystal', 'Y', '32.768kHz', 'Crystal_Cylinder_3mm', 'CRYSTAL', 2.0, true),
  makeDualRowIcDef(
    'Y_SMD_3225',
    'Crystal_SMD_3225-4Pin_25MHz',
    'Crystals & Oscillators',
    '4-Pad SMD Quartz Oscillator 25MHz',
    '25MHz',
    'Crystal_SMD_3225-4Pin',
    [
      { number: '1', name: 'XIN' },
      { number: '2', name: 'GND' },
    ],
    [
      { number: '4', name: 'GND2' },
      { number: '3', name: 'XOUT' },
    ],
    'builtin_core',
    'Official Library',
    2.0,
    2.5,
    true
  ),

  // ================= DISPLAYS =================
  makeDualRowIcDef(
    'OLED_SSD1306',
    'OLED_0.96_128x64_I2C',
    'Displays',
    '4-Pin I2C OLED Display Header',
    'SSD1306',
    'OLED_0.96_I2C',
    [
      { number: '1', name: 'GND' },
      { number: '2', name: 'VCC' },
    ],
    [
      { number: '4', name: 'SDA' },
      { number: '3', name: 'SCL' },
    ],
    'builtin_core',
    'Official Library',
    2.54,
    5.08,
    false
  ),
  makeDualRowIcDef(
    'DS_LCD1602_I2C',
    'LCD_1602_I2C_Backpack_4Pin',
    'Displays',
    '16x2 Character LCD I2C Header',
    'LCD1602',
    'PinHeader_1x04_LCD',
    [
      { number: '1', name: 'GND' },
      { number: '2', name: 'VCC' },
    ],
    [
      { number: '4', name: 'SCL' },
      { number: '3', name: 'SDA' },
    ],
    'builtin_core',
    'Official Library',
    2.54,
    5.08,
    false
  ),
  makeDualRowIcDef(
    'DS_7SEG_1DIGIT',
    '7Segment_LED_Display_HDSM531',
    'Displays',
    'Single Digit 7-Segment LED Display',
    '7SEG_RED',
    'Display_7Segment_DIP10',
    [
      { number: '1', name: 'A' },
      { number: '2', name: 'B' },
      { number: '3', name: 'COM' },
    ],
    [
      { number: '6', name: 'F' },
      { number: '5', name: 'G' },
      { number: '4', name: 'C' },
    ],
    'builtin_core',
    'Official Library',
    2.54,
    7.62,
    false
  ),

  // ================= FABRICATION =================
  makeTwoPinPart('FIDUCIAL_1MM', 'Fiducial_1mm_Mask2mm', 'Fabrication', 'Optical Alignment Fiducial Mark', 'FID', 'FID', 'Fiducial_1mm', 'CONN2', 2.0, false),
  makeTwoPinPart('TP_PAD_1.5MM', 'TestPoint_Pad_D1.5mm', 'Fabrication', 'Surface Mount Oscilloscope Probe Pad', 'TP', 'TP_SIG', 'TestPoint_Pad_1.5mm', 'CONN2', 2.0, false),
  makeTwoPinPart('SOLDER_JUMPER_2P', 'SolderJumper-2_P1.3mm_Open', 'Fabrication', '2-Pad PCB Configuration Solder Bridge', 'JP', 'JMP', 'SolderJumper-2_P1.3mm', 'SWITCH', 1.3, false),

  // ================= FUSES & PROTECTION =================
  makeTwoPinPart('FUSE_PTC_1206', 'Fuse_1206_3216Metric', 'Fuses & Protection', 'Resettable PTC Polyfuse 500mA', 'F', '500mA', 'Fuse_1206', 'R', 3.0, false),
  makeTwoPinPart('FUSE_HOLDER_5X20', 'Fuseholder_Cylinder-5x20mm', 'Fuses & Protection', '5x20mm Glass Cartridge Fuse Clips', 'F', '2A_250V', 'Fuseholder_5x20mm', 'R', 15.0, true),
  makeTwoPinPart('D_TVS_SMAJ5.0A', 'D_SMA_TVS_SMAJ5.0A', 'Fuses & Protection', '400W 5V Unidirectional ESD/Surge TVS', 'D', 'SMAJ5.0A', 'D_SMA_TVS', 'LED', 4.0, false),

  // ================= MECHANICAL =================
  makeTwoPinPart('MTG_HOLE_M3', 'MountingHole_3.2mm_M3', 'Mechanical', 'M3 Plated Stand-off Pads', 'H', 'M3', 'MountingHole_3.2mm_M3', 'CONN2', 4.0, true),
  makeTwoPinPart('MTG_HOLE_M2.5', 'MountingHole_2.7mm_M2.5', 'Mechanical', 'M2.5 Plated Stand-off Pads', 'H', 'M2.5', 'MountingHole_2.7mm_M2.5', 'CONN2', 3.5, true),
  makeTwoPinPart('HS_TO220_VERTICAL', 'Heatsink_Fischer_SK104_TO220', 'Mechanical', 'Vertical Aluminum Heatsink Anchor Pins', 'HS', 'HEATSINK', 'Heatsink_TO220', 'CONN2', 10.16, true),

  // ================= MODULES =================
  makeDualRowIcDef(
    'ESP32_WROOM',
    'ESP32-C3-MINI-1_Module',
    'Modules',
    'WiFi/BLE MCU Stamp Module',
    'ESP32-C3',
    'ESP32-C3-MINI',
    [
      { number: '1', name: 'GND' },
      { number: '2', name: '3V3' },
      { number: '3', name: 'EN' },
    ],
    [
      { number: '6', name: 'TX' },
      { number: '5', name: 'RX' },
      { number: '4', name: 'IO8' },
    ],
    'builtin_core',
    'Official Library',
    2.54,
    10.16,
    true
  ),
  makeDualRowIcDef(
    'MOD_RP2040_STAMP',
    'RP2040_Zero_Core_Module',
    'Modules',
    'Dual-Core ARM Cortex-M0+ Stamp Module',
    'RP2040',
    'Module_RP2040_Stamp',
    [
      { number: '1', name: '5V' },
      { number: '2', name: 'GND' },
      { number: '3', name: '3V3' },
      { number: '4', name: 'GP0' },
    ],
    [
      { number: '8', name: 'GP29' },
      { number: '7', name: 'GP28' },
      { number: '6', name: 'SCL' },
      { number: '5', name: 'SDA' },
    ],
    'builtin_core',
    'Official Library',
    2.54,
    12.7,
    true
  ),

  // ================= POTENTIOMETERS & TRIMMERS =================
  makeTwoPinPart('RV_TRIM_3296W', 'Potentiometer_Bourns_3296W', 'Potentiometers & Trimmers', 'Multi-Turn Trimmer Potentiometer', 'RV', '10k_TRIM', 'Bourns_3296W', 'R', 5.08, true),
  makeThreePinSOT23Part('RV_POT_RV09', 'Potentiometer_Alps_RK09K_Single', 'Potentiometers & Trimmers', '9mm Rotary Panel Potentiometer 10k', 'RV', '10k_POT', 'Potentiometer_Alps_RK09', ['1', '2', '3']),

  // ================= RELAYS =================
  makeDualRowIcDef(
    'K_RELAY_SPDT',
    'Relay_SPDT_Sanyou_SRD',
    'Relays',
    '5V Coil 10A SPDT Power Relay',
    'SRD-05VDC',
    'Relay_SPDT_SRD',
    [
      { number: '1', name: 'COIL1' },
      { number: '2', name: 'COIL2' },
    ],
    [
      { number: '4', name: 'NO' },
      { number: '3', name: 'COM' },
    ],
    'builtin_core',
    'Official Library',
    5.08,
    10.16,
    true
  ),
  makeDualRowIcDef(
    'K_SSR_G3MB',
    'Relay_SolidState_Omron_G3MB202P',
    'Relays',
    '5V Input 240VAC 2A Solid State Relay',
    'G3MB-202P',
    'Relay_SSR_G3MB',
    [
      { number: '1', name: 'DC+' },
      { number: '2', name: 'DC-' },
    ],
    [
      { number: '4', name: 'AC_L1' },
      { number: '3', name: 'AC_L2' },
    ],
    'builtin_core',
    'Official Library',
    5.08,
    7.62,
    false
  ),

  // ================= SENSORS =================
  makeDualRowIcDef(
    'U_BME280_SENS',
    'Bosch_BME280_Breakout',
    'Sensors',
    'I2C Temp/Humidity/Pressure Sensor',
    'BME280',
    'Sensor_BME280',
    [
      { number: '1', name: 'VIN' },
      { number: '2', name: 'GND' },
    ],
    [
      { number: '4', name: 'SDA' },
      { number: '3', name: 'SCL' },
    ],
    'builtin_core',
    'Official Library',
    2.54,
    7.62,
    false
  ),
  makeDualRowIcDef(
    'U_MPU6050_IMU',
    'InvenSense_MPU6050_6DOF_IMU',
    'Sensors',
    'I2C 3-Axis Gyro + Accelerometer',
    'MPU6050',
    'Sensor_MPU6050_Breakout',
    [
      { number: '1', name: 'VCC' },
      { number: '2', name: 'GND' },
    ],
    [
      { number: '4', name: 'SDA' },
      { number: '3', name: 'SCL' },
    ],
    'builtin_core',
    'Official Library',
    2.54,
    7.62,
    false
  ),
  makeDualRowIcDef(
    'U_HCSR04_SONAR',
    'HC-SR04_Ultrasonic_Distance_4P',
    'Sensors',
    'Ultrasonic Rangefinder 4-Pin Header',
    'HC-SR04',
    'PinHeader_1x04_HCSR04',
    [
      { number: '1', name: 'VCC' },
      { number: '2', name: 'TRIG' },
    ],
    [
      { number: '4', name: 'GND' },
      { number: '3', name: 'ECHO' },
    ],
    'builtin_core',
    'Official Library',
    2.54,
    5.08,
    false
  ),
  makeTwoPinPart('R_LDR_5MM', 'LDR_Photoresistor_GL5528_5mm', 'Sensors', 'CdS Light Dependent Photoresistor', 'R', 'LDR_10k', 'LDR_D5.0mm_P2.54mm', 'R', 2.54, true),
  makeTwoPinPart('TH_NTC_10K', 'NTC_Thermistor_10k_B3950', 'Sensors', '10kΩ Precision Temperature Thermistor', 'TH', 'NTC_10k', 'Thermistor_R0805', 'R', 2.0, false),

  // ================= SOCKETS =================
  makeDualRowIcDef(
    'SOCKET_DIP8',
    'DIP-8_Socket_W7.62mm',
    'Sockets',
    '8-Pin IC Machined Socket',
    'DIP8_SKT',
    'Socket_DIP-8_W7.62mm',
    [
      { number: '1', name: '1' },
      { number: '2', name: '2' },
      { number: '3', name: '3' },
      { number: '4', name: '4' },
    ],
    [
      { number: '8', name: '8' },
      { number: '7', name: '7' },
      { number: '6', name: '6' },
      { number: '5', name: '5' },
    ],
    'builtin_core',
    'Official Library',
    2.54,
    7.62,
    false
  ),
  makeDualRowIcDef(
    'SOCKET_DIP16',
    'DIP-16_Socket_W7.62mm',
    'Sockets',
    '16-Pin Dual-In-Line IC Socket',
    'DIP16_SKT',
    'Socket_DIP-16_W7.62mm',
    [
      { number: '1', name: '1' },
      { number: '2', name: '2' },
      { number: '3', name: '3' },
      { number: '4', name: '4' },
    ],
    [
      { number: '8', name: '8' },
      { number: '7', name: '7' },
      { number: '6', name: '6' },
      { number: '5', name: '5' },
    ],
    'builtin_core',
    'Official Library',
    2.54,
    7.62,
    false
  ),

  // ================= SCHEMATIC POWER SYMBOLS =================
  {
    kind: 'VCC',
    title: '+5V Power Rail',
    category: 'Connectors',
    description: 'Global Schematic Net (+5V / +3V3)',
    refPrefix: 'PWR',
    defaultValue: '+5V',
    footprint: '',
    symbolStyle: 'VCC',
    pins: [{ number: '1', name: 'VCC', offset: { x: 0, y: 2 * g } }],
    courtyard: { width: 0, height: 0 },
    pads: [],
    pcbAllowed: false,
    libraryId: 'builtin_core',
    libraryName: 'Official Library',
  },
  {
    kind: 'GND',
    title: 'Ground Symbol',
    category: 'Connectors',
    description: 'Global Schematic GND Reference',
    refPrefix: 'GND',
    defaultValue: 'GND',
    footprint: '',
    symbolStyle: 'GND',
    pins: [{ number: '1', name: 'GND', offset: { x: 0, y: -2 * g } }],
    courtyard: { width: 0, height: 0 },
    pads: [],
    pcbAllowed: false,
    libraryId: 'builtin_core',
    libraryName: 'Official Library',
  },

  // ================= KICAD OFFICIAL FOOTPRINTS REPOSITORY (git@gitlab.com:kicad/libraries/kicad-footprints.git) =================
  ...buildKicadFootprintsGitCatalog(),
];

/**
 * Curated KiCAD Official-Style Web Libraries that can be downloaded/installed in 1 tap.
 * Every part uses one of the 20 OFFICIAL_FOOTPRINT_CATEGORIES so they sort directly into their category folders!
 */
export const WEB_LIBRARY_CATALOG: LibraryPackage[] = [
  {
    id: 'kicad_footprints_git_full',
    name: 'kicad-footprints.git (All Official .pretty Libraries)',
    version: '8.0.6',
    author: 'git@gitlab.com:kicad/libraries/kicad-footprints.git',
    description:
      'Complete KiCad Official Footprints Repository preloaded into the Preset Official Library across all 20 category folders (Resistor_SMD, Capacitor_SMD, Package_SO, Package_QFP, Package_DFN_QFN, Connector_JST, USB, Switches, Sensors, Modules & more).',
    sourceUrl: 'git@gitlab.com:kicad/libraries/kicad-footprints.git',
    parts: buildKicadFootprintsGitCatalog(),
  },
  {
    id: 'kicad_mcu_pack',
    name: 'KiCad_MCU_Microcontrollers.kicad_sym',
    version: '8.0.2',
    author: 'KiCad Official Repository',
    description: 'Popular 8-bit & 32-bit microcontrollers (ATtiny85, ESP32-C3-MINI, STM32G030)',
    sourceUrl: 'https://gitlab.com/kicad/libraries/kicad-symbols/-/raw/master/MCU_Microchip_ATtiny.kicad_sym',
    parts: [
      makeDualRowIcDef(
        'ATTINY85_DIP8',
        'ATtiny85-20PU MCU',
        'ICs',
        'DIP-8 AVR 8-bit MCU',
        'ATtiny85',
        'Package_DIP:DIP-8_W7.62mm',
        [
          { number: '1', name: 'PB5/RST' },
          { number: '2', name: 'PB3/ADC3' },
          { number: '3', name: 'PB4/ADC2' },
          { number: '4', name: 'GND' },
        ],
        [
          { number: '8', name: 'VCC' },
          { number: '7', name: 'PB2/SCK' },
          { number: '6', name: 'PB1/MISO' },
          { number: '5', name: 'PB0/MOSI' },
        ],
        'kicad_mcu_pack',
        'KiCad_MCU_Microcontrollers'
      ),
      makeDualRowIcDef(
        'ESP32_C3_MINI',
        'ESP32-C3-MINI-1 WiFi/BLE',
        'Modules',
        'RISC-V WiFi + BLE Module',
        'ESP32-C3',
        'RF_Module:ESP32-C3-MINI-1',
        [
          { number: '1', name: 'GND' },
          { number: '2', name: '3V3' },
          { number: '3', name: 'EN' },
          { number: '4', name: 'IO2' },
          { number: '5', name: 'IO8' },
          { number: '6', name: 'IO9' },
        ],
        [
          { number: '12', name: 'TXD0' },
          { number: '11', name: 'RXD0' },
          { number: '10', name: 'IO19/D+' },
          { number: '9', name: 'IO18/D-' },
          { number: '8', name: 'IO5/SCL' },
          { number: '7', name: 'IO4/SDA' },
        ],
        'kicad_mcu_pack',
        'KiCad_MCU_Microcontrollers',
        2.0,
        10.0,
        true
      ),
      makeDualRowIcDef(
        'STM32G030F6',
        'STM32G030F6P6 Cortex-M0+',
        'ICs',
        'TSSOP-20 (Compact 8-Pin Core)',
        'STM32G030',
        'Package_SO:SOIC-8',
        [
          { number: '1', name: 'VDD' },
          { number: '2', name: 'PA0' },
          { number: '3', name: 'PA1' },
          { number: '4', name: 'NRST' },
        ],
        [
          { number: '8', name: 'VSS' },
          { number: '7', name: 'PA14/SWC' },
          { number: '6', name: 'PA13/SWD' },
          { number: '5', name: 'PA2/TX' },
        ],
        'kicad_mcu_pack',
        'KiCad_MCU_Microcontrollers',
        1.27,
        5.4,
        true
      ),
    ],
  },
  {
    id: 'kicad_analog_opamp',
    name: 'KiCad_Amplifier_Operational.kicad_sym',
    version: '8.0.2',
    author: 'KiCad Official Repository',
    description: 'Precision operational amplifiers & comparators (LM358, MCP6002, TL072)',
    sourceUrl: 'https://gitlab.com/kicad/libraries/kicad-symbols/-/raw/master/Amplifier_Operational.kicad_sym',
    parts: [
      {
        kind: 'LM358_OPAMP',
        title: 'LM358 Dual Op-Amp',
        category: 'ICs',
        description: 'SOIC-8 / DIP-8 Operational Amplifier',
        refPrefix: 'U',
        defaultValue: 'LM358',
        footprint: 'Package_DIP:DIP-8',
        symbolStyle: 'OPAMP',
        pins: [
          { number: '2', name: 'IN-', offset: { x: -3 * g, y: -1 * g } },
          { number: '3', name: 'IN+', offset: { x: -3 * g, y: 1 * g } },
          { number: '1', name: 'OUT', offset: { x: 3 * g, y: 0 } },
          { number: '8', name: 'V+', offset: { x: 0, y: -2 * g } },
          { number: '4', name: 'V-', offset: { x: 0, y: 2 * g } },
        ],
        courtyard: { width: 9.6, height: 7.5 },
        pads: [
          { number: '1', offset: { x: -3.81, y: -2.54 }, width: 1.6, height: 1.6, shape: 'rect', drill: 0.8, layers: ['F.Cu', 'B.Cu'] },
          { number: '2', offset: { x: -3.81, y: 0 }, width: 1.6, height: 1.6, shape: 'circle', drill: 0.8, layers: ['F.Cu', 'B.Cu'] },
          { number: '3', offset: { x: -3.81, y: 2.54 }, width: 1.6, height: 1.6, shape: 'circle', drill: 0.8, layers: ['F.Cu', 'B.Cu'] },
          { number: '4', offset: { x: 3.81, y: 2.54 }, width: 1.6, height: 1.6, shape: 'circle', drill: 0.8, layers: ['F.Cu', 'B.Cu'] },
          { number: '8', offset: { x: 3.81, y: -2.54 }, width: 1.6, height: 1.6, shape: 'circle', drill: 0.8, layers: ['F.Cu', 'B.Cu'] },
        ],
        pcbAllowed: true,
        libraryId: 'kicad_analog_opamp',
        libraryName: 'KiCad_Amplifier_Operational',
      },
      {
        kind: 'MCP6002_OPAMP',
        title: 'MCP6002 Rail-to-Rail Op-Amp',
        category: 'ICs',
        description: '1MHz Low-Power Op-Amp SOIC-8',
        refPrefix: 'U',
        defaultValue: 'MCP6002',
        footprint: 'Package_SO:SOIC-8',
        symbolStyle: 'OPAMP',
        pins: [
          { number: '2', name: 'IN-', offset: { x: -3 * g, y: -1 * g } },
          { number: '3', name: 'IN+', offset: { x: -3 * g, y: 1 * g } },
          { number: '1', name: 'OUT', offset: { x: 3 * g, y: 0 } },
          { number: '8', name: 'VDD', offset: { x: 0, y: -2 * g } },
          { number: '4', name: 'VSS', offset: { x: 0, y: 2 * g } },
        ],
        courtyard: { width: 7.2, height: 6.2 },
        pads: [
          { number: '1', offset: { x: -2.4, y: -1.905 }, width: 1.5, height: 0.65, shape: 'rect', layers: ['F.Cu'] },
          { number: '2', offset: { x: -2.4, y: -0.635 }, width: 1.5, height: 0.65, shape: 'rect', layers: ['F.Cu'] },
          { number: '3', offset: { x: -2.4, y: 0.635 }, width: 1.5, height: 0.65, shape: 'rect', layers: ['F.Cu'] },
          { number: '4', offset: { x: -2.4, y: 1.905 }, width: 1.5, height: 0.65, shape: 'rect', layers: ['F.Cu'] },
          { number: '8', offset: { x: 2.4, y: -1.905 }, width: 1.5, height: 0.65, shape: 'rect', layers: ['F.Cu'] },
        ],
        pcbAllowed: true,
        libraryId: 'kicad_analog_opamp',
        libraryName: 'KiCad_Amplifier_Operational',
      },
    ],
  },
  {
    id: 'kicad_power_transistors',
    name: 'KiCad_Regulator_Transistor.kicad_sym',
    version: '8.0.2',
    author: 'KiCad Official Repository',
    description: 'LDO voltage regulators, NPN BJTs & N-Channel MOSFETs (AMS1117-3.3, 2N2222, AO3400)',
    sourceUrl: 'https://gitlab.com/kicad/libraries/kicad-symbols/-/raw/master/Regulator_Linear.kicad_sym',
    parts: [
      {
        kind: 'Q_NPN_2N2222',
        title: '2N2222 NPN Transistor',
        category: 'Transistors & Regulators',
        description: 'SOT-23 / TO-92 NPN Bipolar Transistor',
        refPrefix: 'Q',
        defaultValue: '2N2222',
        footprint: 'Package_TO_SOT_SMD:SOT-23',
        symbolStyle: 'TRANSISTOR',
        pins: [
          { number: '1', name: 'B', offset: { x: -3 * g, y: 0 } },
          { number: '2', name: 'C', offset: { x: 1 * g, y: -2 * g } },
          { number: '3', name: 'E', offset: { x: 1 * g, y: 2 * g } },
        ],
        courtyard: { width: 4.4, height: 4.0 },
        pads: [
          { number: '1', offset: { x: -0.95, y: 1.1 }, width: 1.0, height: 1.2, shape: 'rect', layers: ['F.Cu'] },
          { number: '2', offset: { x: 0.95, y: 1.1 }, width: 1.0, height: 1.2, shape: 'rect', layers: ['F.Cu'] },
          { number: '3', offset: { x: 0, y: -1.1 }, width: 1.0, height: 1.2, shape: 'rect', layers: ['F.Cu'] },
        ],
        pcbAllowed: true,
        libraryId: 'kicad_power_transistors',
        libraryName: 'KiCad_Regulator_Transistor',
      },
      makeDualRowIcDef(
        'AMS1117_3V3',
        'AMS1117-3.3 LDO Regulator',
        'Transistors & Regulators',
        '1A Low Dropout 3.3V Regulator SOT-223',
        'AMS1117-3.3',
        'Package_TO_SOT_SMD:SOT-223',
        [
          { number: '3', name: 'VIN' },
          { number: '1', name: 'GND' },
        ],
        [
          { number: '2', name: 'VOUT' },
          { number: '4', name: 'TAB' },
        ],
        'kicad_power_transistors',
        'KiCad_Regulator_Transistor',
        2.3,
        6.2,
        true
      ),
    ],
  },
  {
    id: 'kicad_sensors_interfaces',
    name: 'KiCad_Sensor_Interface.kicad_sym',
    version: '8.0.2',
    author: 'KiCad Official Repository',
    description: 'I2C environmental sensors, OLED displays & USB-UART bridges (BME280, SSD1306, CH340N)',
    sourceUrl: 'https://gitlab.com/kicad/libraries/kicad-symbols/-/raw/master/Sensor.kicad_sym',
    parts: [
      makeDualRowIcDef(
        'BME280_I2C',
        'BME280 Temp/Humidity/Pressure',
        'Sensors',
        'Bosch I2C/SPI Environmental Sensor',
        'BME280',
        'Package_LGA:Bosch_LGA-8',
        [
          { number: '1', name: 'GND' },
          { number: '2', name: 'CSB' },
          { number: '3', name: 'SDI/SDA' },
        ],
        [
          { number: '6', name: 'VDD' },
          { number: '5', name: 'VDDIO' },
          { number: '4', name: 'SCK/SCL' },
        ],
        'kicad_sensors_interfaces',
        'KiCad_Sensor_Interface',
        2.54,
        7.62,
        false
      ),
      makeDualRowIcDef(
        'CH340N_USB',
        'CH340N USB-to-UART Bridge',
        'ICs',
        'SOIC-8 USB Serial Converter',
        'CH340N',
        'Package_SO:SOIC-8',
        [
          { number: '1', name: 'UD+' },
          { number: '2', name: 'UD-' },
          { number: '3', name: 'GND' },
          { number: '4', name: 'RTS#' },
        ],
        [
          { number: '8', name: 'VCC' },
          { number: '7', name: 'TXD' },
          { number: '6', name: 'RXD' },
          { number: '5', name: 'V3' },
        ],
        'kicad_sensors_interfaces',
        'KiCad_Sensor_Interface',
        1.27,
        5.4,
        true
      ),
    ],
  },
  {
    id: 'kicad_switches_crystals',
    name: 'KiCad_Switch_Crystal_Conn.kicad_sym',
    version: '8.0.2',
    author: 'KiCad Official Repository',
    description: 'Tactile push-button switches, quartz crystals & 2-pin USB power connectors',
    sourceUrl: 'https://gitlab.com/kicad/libraries/kicad-symbols/-/raw/master/Switch.kicad_sym',
    parts: [
      {
        kind: 'SW_PUSH_6MM',
        title: 'SW_Push Tactile Button',
        category: 'Switches',
        description: '6x6mm Momentary Pushbutton THT',
        refPrefix: 'SW',
        defaultValue: 'RESET',
        footprint: 'Button_Switch_THT:SW_PUSH_6mm',
        symbolStyle: 'SWITCH',
        pins: [
          { number: '1', name: '1', offset: { x: -3 * g, y: 0 } },
          { number: '2', name: '2', offset: { x: 3 * g, y: 0 } },
        ],
        courtyard: { width: 6.5, height: 6.5 },
        pads: [
          { number: '1', offset: { x: -2.25, y: 0 }, width: 1.8, height: 1.8, shape: 'rect', drill: 1.0, layers: ['F.Cu', 'B.Cu'] },
          { number: '2', offset: { x: 2.25, y: 0 }, width: 1.8, height: 1.8, shape: 'circle', drill: 1.0, layers: ['F.Cu', 'B.Cu'] },
        ],
        pcbAllowed: true,
        libraryId: 'kicad_switches_crystals',
        libraryName: 'KiCad_Switch_Crystal_Conn',
      },
      {
        kind: 'XTAL_16MHZ',
        title: 'Crystal 16MHz HC-49',
        category: 'Crystals & Oscillators',
        description: 'HC-49/U Quartz Crystal Resonator',
        refPrefix: 'Y',
        defaultValue: '16MHz',
        footprint: 'Crystal:Crystal_HC49-U_Vertical',
        symbolStyle: 'CRYSTAL',
        pins: [
          { number: '1', name: '1', offset: { x: -3 * g, y: 0 } },
          { number: '2', name: '2', offset: { x: 3 * g, y: 0 } },
        ],
        courtyard: { width: 11.2, height: 5.0 },
        pads: [
          { number: '1', offset: { x: -2.44, y: 0 }, width: 1.8, height: 1.8, shape: 'rect', drill: 0.9, layers: ['F.Cu', 'B.Cu'] },
          { number: '2', offset: { x: 2.44, y: 0 }, width: 1.8, height: 1.8, shape: 'circle', drill: 0.9, layers: ['F.Cu', 'B.Cu'] },
        ],
        pcbAllowed: true,
        libraryId: 'kicad_switches_crystals',
        libraryName: 'KiCad_Switch_Crystal_Conn',
      },
    ],
  },
];

// Runtime map of all registered library parts (built-in + downloaded/imported)
const CUSTOM_LIBRARY_PARTS = new Map<string, LibraryComponentDef>();

export function registerLibraryParts(parts: LibraryComponentDef[]) {
  for (const part of parts) {
    const sortedCategory =
      part.category === 'Mine'
        ? 'Mine'
        : classifyComponentCategory(
            part.title,
            part.refPrefix,
            part.description,
            part.footprint,
            part.libraryName,
            part.category
          );
    CUSTOM_LIBRARY_PARTS.set(part.kind, { ...part, category: sortedCategory });
  }
}

export function unregisterLibraryById(libraryId: string) {
  for (const [key, part] of CUSTOM_LIBRARY_PARTS.entries()) {
    if (part.libraryId === libraryId) {
      CUSTOM_LIBRARY_PARTS.delete(key);
    }
  }
}

export function getAllLibraryParts(): LibraryComponentDef[] {
  const map = new Map<string, LibraryComponentDef>();
  for (const b of BUILTIN_LIBRARY_PARTS) {
    map.set(b.kind, b);
  }
  for (const [k, v] of CUSTOM_LIBRARY_PARTS.entries()) {
    map.set(k, v);
  }
  return Array.from(map.values());
}

export function buildPadsForPins(pins: PinDef[]): {
  courtyard: { width: number; height: number };
  pads: PadDef[];
} {
  if (pins.length <= 2) {
    return {
      courtyard: { width: 4.5, height: 2.5 },
      pads: pins.map((p, idx) => ({
        number: p.number,
        offset: { x: idx === 0 ? -1.0 : 1.0, y: 0 },
        width: 1.2,
        height: 1.4,
        shape: idx === 0 ? 'rect' : 'circle',
        layers: ['F.Cu'],
      })),
    };
  }
  const half = Math.ceil(pins.length / 2);
  const left = pins.slice(0, half);
  const right = pins.slice(half);
  const maxSide = Math.max(left.length, right.length);
  const pitch = 2.54;
  const rowSpan = 7.62;
  const halfSpan = ((maxSide - 1) / 2) * pitch;
  const pads: PadDef[] = [
    ...left.map((p, i) => ({
      number: p.number,
      offset: { x: -rowSpan / 2, y: Number((-halfSpan + i * pitch).toFixed(3)) },
      width: 1.6,
      height: 1.6,
      shape: (i === 0 ? 'rect' : 'circle') as 'rect' | 'circle',
      drill: 0.8,
      layers: ['F.Cu', 'B.Cu'] as ('F.Cu' | 'B.Cu')[],
    })),
    ...right.map((p, i) => ({
      number: p.number,
      offset: { x: rowSpan / 2, y: Number((-halfSpan + i * pitch).toFixed(3)) },
      width: 1.6,
      height: 1.6,
      shape: 'circle' as 'rect' | 'circle',
      drill: 0.8,
      layers: ['F.Cu', 'B.Cu'] as ('F.Cu' | 'B.Cu')[],
    })),
  ];
  return {
    courtyard: {
      width: Number((rowSpan + 3.0).toFixed(1)),
      height: Number(Math.max(4, maxSide * pitch + 2.0).toFixed(1)),
    },
    pads,
  };
}

export function getDefaultSymbolDefs(
  kind: SchematicComponentKind,
  schPins?: PinDef[]
): {
  defaultValue: string;
  footprint: string;
  refPrefix: string;
  symbolStyle: SymbolVisualStyle;
  pins: PinDef[];
  courtyard: { width: number; height: number };
  pads: PadDef[];
} {
  const builtin = BUILTIN_LIBRARY_PARTS.find((p) => p.kind === kind);
  if (builtin) {
    return {
      defaultValue: builtin.defaultValue,
      footprint: builtin.footprint,
      refPrefix: builtin.refPrefix,
      symbolStyle: builtin.symbolStyle,
      pins: builtin.pins,
      courtyard: builtin.courtyard,
      pads: builtin.pads,
    };
  }
  const custom = CUSTOM_LIBRARY_PARTS.get(kind);
  if (custom) {
    return {
      defaultValue: custom.defaultValue,
      footprint: custom.footprint,
      refPrefix: custom.refPrefix,
      symbolStyle: custom.symbolStyle,
      pins: custom.pins,
      courtyard: custom.courtyard,
      pads: custom.pads,
    };
  }
  for (const pkg of WEB_LIBRARY_CATALOG) {
    const found = pkg.parts.find((p) => p.kind === kind);
    if (found) {
      return {
        defaultValue: found.defaultValue,
        footprint: found.footprint,
        refPrefix: found.refPrefix,
        symbolStyle: found.symbolStyle,
        pins: found.pins,
        courtyard: found.courtyard,
        pads: found.pads,
      };
    }
  }
  if (schPins && schPins.length > 0) {
    const synthesized = buildPadsForPins(schPins);
    return {
      defaultValue: kind,
      footprint: schPins.length > 2 ? `DIP-${schPins.length}` : 'R_0805',
      refPrefix: schPins.length > 2 ? 'U' : 'R',
      symbolStyle: schPins.length > 2 ? 'IC' : 'R',
      pins: schPins,
      courtyard: synthesized.courtyard,
      pads: synthesized.pads,
    };
  }
  const fallback = BUILTIN_LIBRARY_PARTS[0];
  return {
    defaultValue: fallback.defaultValue,
    footprint: fallback.footprint,
    refPrefix: fallback.refPrefix,
    symbolStyle: fallback.symbolStyle,
    pins: fallback.pins,
    courtyard: fallback.courtyard,
    pads: fallback.pads,
  };
}

/**
 * Parses either a KiCAD `.kicad_sym` S-expression library file OR a JSON library package
 * fetched from GitHub / web or uploaded by the user, and automatically sorts each symbol
 * into its respective category folder in OFFICIAL_FOOTPRINT_CATEGORIES.
 */
export function parseKiCadOrJsonLibrary(rawText: string, sourceName = 'Web_Library'): LibraryPackage {
  const trimmed = rawText.trim();

  // 1. Check if JSON format
  if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
    const parsed = JSON.parse(trimmed);
    const libId = parsed.id || `lib_${Date.now()}`;
    const libName = parsed.name || sourceName.replace(/\.(json|kicad_sym)$/i, '');
    const rawParts: Partial<LibraryComponentDef>[] = Array.isArray(parsed)
      ? parsed
      : Array.isArray(parsed.parts)
        ? parsed.parts
        : [];
    if (rawParts.length === 0) {
      throw new Error('JSON library contains no component definitions');
    }
    const parts: LibraryComponentDef[] = rawParts.map((rp, idx) => {
      const kind = (rp.kind || `${libName}_${idx + 1}`).replace(/\s+/g, '_').toUpperCase();
      const title = rp.title || kind;
      const refPrefix = rp.refPrefix || 'U';
      const sortedCat = classifyComponentCategory(
        title,
        refPrefix,
        rp.description || '',
        rp.footprint || '',
        sourceName,
        rp.category || ''
      );
      if (Array.isArray(rp.pins) && rp.pins.length > 0 && Array.isArray(rp.pads) && rp.pads.length > 0) {
        return {
          kind,
          title,
          category: sortedCat,
          description: rp.description || `${rp.footprint || 'Custom'} · ${rp.pins.length} Pins`,
          refPrefix,
          defaultValue: rp.defaultValue || title,
          footprint: rp.footprint || 'Custom_DIP',
          symbolStyle: rp.symbolStyle || 'IC',
          pins: rp.pins,
          courtyard: rp.courtyard || { width: 8, height: 8 },
          pads: rp.pads,
          pcbAllowed: rp.pcbAllowed ?? true,
          libraryId: libId,
          libraryName: libName,
        };
      }
      return makeDualRowIcDef(
        kind,
        title,
        sortedCat,
        rp.description || 'Imported Web Component',
        rp.defaultValue || title,
        rp.footprint || 'Package_DIP:DIP-8',
        [
          { number: '1', name: 'IN1' },
          { number: '2', name: 'IN2' },
          { number: '3', name: 'GND' },
        ],
        [
          { number: '6', name: 'VCC' },
          { number: '5', name: 'OUT2' },
          { number: '4', name: 'OUT1' },
        ],
        libId,
        libName
      );
    });
    return {
      id: libId,
      name: libName,
      version: parsed.version || '1.0',
      author: parsed.author || 'Imported JSON Library',
      description: parsed.description || `${parts.length} components imported from ${sourceName}`,
      parts,
    };
  }

  // 2. Parse KiCAD `.kicad_sym` S-expression format
  if (trimmed.includes('(kicad_symbol_lib') || trimmed.includes('(symbol ')) {
    const libId = `kicad_${Date.now()}`;
    const libName = sourceName.replace(/\.(kicad_sym|sym)$/i, '') || 'KiCad_Web_Lib';

    // Find top-level symbol names (ignoring sub-unit symbols like Name_0_1 or Name_1_1)
    const symbolRegex = /\(symbol\s+"([^"]+)"([\s\S]*?)(?=\n\s*\(symbol\s+"[^"]+"\s+\((?:pin_names|in_bom|power|extends)|$)/g;
    const parts: LibraryComponentDef[] = [];
    let match: RegExpExecArray | null;

    while ((match = symbolRegex.exec(trimmed)) !== null && parts.length < 80) {
      const symName = match[1];
      if (/_\d+_\d+$/.test(symName)) continue;
      const body = match[2];

      const refMatch = /\(property\s+"Reference"\s+"([^"]+)"/.exec(body);
      const valMatch = /\(property\s+"Value"\s+"([^"]+)"/.exec(body);
      const fpMatch = /\(property\s+"Footprint"\s+"([^"]*)"/.exec(body);
      const descMatch = /\(property\s+"Description"\s+"([^"]*)"/.exec(body);
      const kwMatch = /\(property\s+"ki_keywords"\s+"([^"]*)"/.exec(body);

      const refPrefix = (refMatch?.[1] || 'U').replace(/[0-9?]/g, '') || 'U';
      const defaultValue = valMatch?.[1] || symName;
      const footprint = fpMatch?.[1] || 'Package_DIP:DIP-8';
      const desc = descMatch?.[1] || kwMatch?.[1] || `KiCad Symbol ${symName}`;

      const sortedCat = classifyComponentCategory(
        symName,
        refPrefix,
        desc,
        footprint,
        libName
      );

      // Extract pins from `(pin ... (name "...") (number "..."))`
      const pinRegex = /\(pin\s+\w+\s+\w+[\s\S]*?\(name\s+"([^"]*)"[\s\S]*?\(number\s+"([^"]+)"/g;
      const extractedPins: { number: string; name: string }[] = [];
      const seenPinNums = new Set<string>();
      let pm: RegExpExecArray | null;
      while ((pm = pinRegex.exec(body)) !== null && extractedPins.length < 16) {
        const pName = pm[1] === '~' ? `P${pm[2]}` : pm[1];
        const pNum = pm[2];
        if (!seenPinNums.has(pNum)) {
          seenPinNums.add(pNum);
          extractedPins.push({ number: pNum, name: pName });
        }
      }

      if (extractedPins.length === 0) {
        extractedPins.push(
          { number: '1', name: '1' },
          { number: '2', name: '2' }
        );
      }

      const kind = `KICAD_${symName.replace(/[^a-zA-Z0-9]/g, '_').toUpperCase()}`;

      if (
        extractedPins.length === 2 &&
        (refPrefix === 'R' ||
          refPrefix === 'C' ||
          refPrefix === 'D' ||
          refPrefix === 'L' ||
          refPrefix === 'SW' ||
          refPrefix === 'Y' ||
          refPrefix === 'F')
      ) {
        const style: SymbolVisualStyle =
          refPrefix === 'C'
            ? 'C'
            : refPrefix === 'D'
              ? 'LED'
              : refPrefix === 'SW'
                ? 'SWITCH'
                : refPrefix === 'Y'
                  ? 'CRYSTAL'
                  : 'R';
        parts.push({
          kind,
          title: symName,
          category: sortedCat,
          description: desc.slice(0, 48),
          refPrefix,
          defaultValue,
          footprint: footprint || 'R_0805',
          symbolStyle: style,
          pins: [
            { number: extractedPins[0].number, name: extractedPins[0].name, offset: { x: -3 * g, y: 0 } },
            { number: extractedPins[1].number, name: extractedPins[1].name, offset: { x: 3 * g, y: 0 } },
          ],
          courtyard: { width: 4.5, height: 2.5 },
          pads: [
            { number: extractedPins[0].number, offset: { x: -1.0, y: 0 }, width: 1.2, height: 1.4, shape: 'rect', layers: ['F.Cu'] },
            { number: extractedPins[1].number, offset: { x: 1.0, y: 0 }, width: 1.2, height: 1.4, shape: 'rect', layers: ['F.Cu'] },
          ],
          pcbAllowed: true,
          libraryId: libId,
          libraryName: libName,
        });
      } else if (extractedPins.length === 3 && refPrefix === 'Q') {
        parts.push(
          makeThreePinSOT23Part(
            kind,
            symName,
            sortedCat,
            desc.slice(0, 48),
            'Q',
            defaultValue,
            footprint || 'SOT-23',
            [extractedPins[0].name, extractedPins[1].name, extractedPins[2].name]
          )
        );
      } else {
        const half = Math.ceil(extractedPins.length / 2);
        const leftPins = extractedPins.slice(0, half);
        const rightPins = extractedPins.slice(half);
        parts.push(
          makeDualRowIcDef(
            kind,
            symName,
            sortedCat,
            desc.slice(0, 42),
            defaultValue,
            footprint || `DIP-${extractedPins.length}`,
            leftPins,
            rightPins,
            libId,
            libName
          )
        );
      }
    }

    if (parts.length === 0) {
      throw new Error('No valid symbols found in .kicad_sym file');
    }

    return {
      id: libId,
      name: libName,
      version: 'KiCad 8',
      author: 'KiCad .kicad_sym Import',
      description: `${parts.length} symbols parsed from ${sourceName}`,
      parts,
    };
  }

  // 3. Parse KiCAD `.kicad_mod` S-expression footprint format `(footprint "..." ...)` or `(module "..." ...)`
  if (trimmed.includes('(footprint ') || trimmed.includes('(module ')) {
    const libId = `kicad_mod_${Date.now()}`;
    const libName = sourceName.replace(/\.(kicad_mod|mod|pretty)$/i, '') || 'KiCad_Footprint';
    const fpBlocks = trimmed
      .split(/(?=\(\s*(?:footprint|module)\s+)/g)
      .filter((b) => /^\(\s*(?:footprint|module)\s+/.test(b.trim()));

    const parts: LibraryComponentDef[] = [];
    for (const block of fpBlocks) {
      const nameMatch = /\(\s*(?:footprint|module)\s+"?([^"\s)]+)"?/.exec(block);
      const fpName = nameMatch?.[1] || libName;
      const descrMatch = /\(descr\s+"([^"]*)"\)/.exec(block);
      const tagsMatch = /\(tags\s+"([^"]*)"\)/.exec(block);
      const desc = descrMatch?.[1] || tagsMatch?.[1] || `KiCad Footprint ${fpName}`;

      // Extract pads: (pad "1" smd rect (at -1.0 0) (size 1.2 1.4) (layers "F.Cu" ...))
      const padRegex =
        /\(pad\s+"?([^"\s)]+)"?\s+(smd|thru_hole|np_thru_hole)\s+(rect|roundrect|circle|oval|trapezoid|custom)[\s\S]*?\(at\s+(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)(?:\s+(-?\d+(?:\.\d+)?))?\)[\s\S]*?\(size\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\)(?:[\s\S]*?\(drill\s+(?:oval\s+)?(\d+(?:\.\d+)?))?/g;
      const pads: PadDef[] = [];
      let pm: RegExpExecArray | null;
      while ((pm = padRegex.exec(block)) !== null && pads.length < 64) {
        const padNum = pm[1] || String(pads.length + 1);
        const padType = pm[2];
        const rawShape = pm[3];
        const x = parseFloat(pm[4]) || 0;
        const y = parseFloat(pm[5]) || 0;
        const w = parseFloat(pm[7]) || 1.2;
        const h = parseFloat(pm[8]) || 1.2;
        const drill = pm[9] ? parseFloat(pm[9]) : padType === 'thru_hole' ? 0.8 : undefined;
        pads.push({
          number: padNum,
          offset: { x: Number(x.toFixed(3)), y: Number(y.toFixed(3)) },
          width: Number(w.toFixed(3)),
          height: Number(h.toFixed(3)),
          shape: rawShape === 'circle' ? 'circle' : rawShape === 'oval' ? 'oval' : 'rect',
          ...(drill ? { drill } : {}),
          layers: padType === 'smd' ? ['F.Cu'] : ['F.Cu', 'B.Cu'],
        });
      }

      if (pads.length === 0) {
        pads.push(
          { number: '1', offset: { x: -1.27, y: 0 }, width: 1.4, height: 1.4, shape: 'rect', layers: ['F.Cu'] },
          { number: '2', offset: { x: 1.27, y: 0 }, width: 1.4, height: 1.4, shape: 'rect', layers: ['F.Cu'] }
        );
      }

      let minX = -2,
        maxX = 2,
        minY = -1.5,
        maxY = 1.5;
      for (const p of pads) {
        minX = Math.min(minX, p.offset.x - p.width / 2);
        maxX = Math.max(maxX, p.offset.x + p.width / 2);
        minY = Math.min(minY, p.offset.y - p.height / 2);
        maxY = Math.max(maxY, p.offset.y + p.height / 2);
      }

      const sortedCat = classifyComponentCategory(fpName, 'U', desc, fpName, sourceName);
      const refPrefix =
        sortedCat === 'Resistors'
          ? 'R'
          : sortedCat === 'Capacitors'
            ? 'C'
            : sortedCat === 'Inductors'
              ? 'L'
              : sortedCat === 'Diodes & LEDs'
                ? 'D'
                : sortedCat === 'Transistors & Regulators'
                  ? 'Q'
                  : sortedCat === 'Connectors' || sortedCat === 'Sockets'
                    ? 'J'
                    : sortedCat === 'Switches'
                      ? 'SW'
                      : sortedCat === 'Crystals & Oscillators'
                        ? 'Y'
                        : sortedCat === 'Fuses & Protection'
                          ? 'F'
                          : sortedCat === 'Relays'
                            ? 'K'
                            : 'U';

      const uniqueNums = Array.from(new Set(pads.map((p) => p.number))).slice(0, 24);
      const pins: PinDef[] =
        uniqueNums.length <= 2
          ? uniqueNums.map((num, idx) => ({
              number: num,
              name: num,
              offset: { x: idx === 0 ? -3 * g : 3 * g, y: 0 },
            }))
          : uniqueNums.map((num, idx) => {
              const half = Math.ceil(uniqueNums.length / 2);
              const isLeft = idx < half;
              const rowIdx = isLeft ? idx : idx - half;
              const yStart = -Math.floor(half / 2) * g;
              return {
                number: num,
                name: `P${num}`,
                offset: {
                  x: isLeft ? -4 * g : 4 * g,
                  y: Number((yStart + rowIdx * g).toFixed(4)),
                },
              };
            });

      const kind = `KICAD_MOD_${fpName.replace(/[^a-zA-Z0-9]/g, '_').toUpperCase()}`;
      parts.push({
        kind,
        title: fpName,
        category: sortedCat,
        description: desc.slice(0, 56),
        refPrefix,
        defaultValue: fpName,
        footprint: fpName,
        symbolStyle:
          refPrefix === 'R'
            ? 'R'
            : refPrefix === 'C'
              ? 'C'
              : refPrefix === 'D'
                ? 'LED'
                : refPrefix === 'Q'
                  ? 'TRANSISTOR'
                  : refPrefix === 'SW'
                    ? 'SWITCH'
                    : refPrefix === 'Y'
                      ? 'CRYSTAL'
                      : 'IC',
        pins,
        courtyard: {
          width: Number(Math.max(3.0, maxX - minX + 1.2).toFixed(2)),
          height: Number(Math.max(2.5, maxY - minY + 1.2).toFixed(2)),
        },
        pads,
        pcbAllowed: true,
        libraryId: libId,
        libraryName: libName,
      });
    }

    return {
      id: libId,
      name: libName,
      version: 'KiCad 8',
      author: 'KiCad .kicad_mod Import',
      description: `${parts.length} footprints parsed from ${sourceName}`,
      parts,
    };
  }

  throw new Error('Unrecognized library format. Expected .kicad_sym, .kicad_mod, or .json');
}

export interface SchematicHitResult {
  item: AnyItem;
  pin?: { pin: PinDef; world: Point };
  distance: number;
}

export function hitTestSchematic(
  items: AnyItem[],
  worldPt: Point,
  scalePxPerMm: number,
  hitSlopPx: number = TOUCH_HIT_SLOP_PX
): SchematicHitResult | null {
  const slopMm = Math.max(1.5, hitSlopPx / Math.max(scalePxPerMm, 1));

  let bestPinHit: SchematicHitResult | null = null;
  for (const item of items) {
    if (item.type === 'sch_component') {
      const pins = getComponentPinsWorld(item);
      for (const p of pins) {
        const d = distance(worldPt, p.world);
        if (d <= slopMm * 0.85 && (!bestPinHit || d < bestPinHit.distance)) {
          bestPinHit = { item, pin: p, distance: d };
        }
      }
    }
  }
  if (bestPinHit) return bestPinHit;

  let bestHit: SchematicHitResult | null = null;
  for (let i = items.length - 1; i >= 0; i--) {
    const item = items[i];
    if (item.type === 'sch_component') {
      const pinCount = item.props.pins.length;
      const radius = pinCount > 4 ? Math.max(4.5, (pinCount / 4) * SCHEMATIC_GRID + 1.5) : 2.8;
      const d = distance(worldPt, { x: item.transform.x, y: item.transform.y });
      if (d <= radius + slopMm * 0.6 && (!bestHit || d < bestHit.distance)) {
        bestHit = { item, distance: d };
      }
    } else if (item.type === 'sch_label') {
      const d = distance(worldPt, { x: item.transform.x, y: item.transform.y });
      if (d <= 2.2 + slopMm * 0.6 && (!bestHit || d < bestHit.distance)) {
        bestHit = { item, distance: d };
      }
    } else if (item.type === 'sch_wire') {
      const pts = item.props.points;
      for (let j = 0; j < pts.length - 1; j++) {
        const { dist } = distanceToSegment(worldPt, pts[j], pts[j + 1]);
        if (dist <= slopMm * 0.75 && (!bestHit || dist < bestHit.distance)) {
          bestHit = { item, distance: dist };
        }
      }
    }
  }

  return bestHit;
}

export function getOutlinePolygonPoints(item: {
  transform: { x: number; y: number };
  props: { width: number; height: number; points?: Point[] };
}): Point[] {
  if (item.props.points && item.props.points.length >= 3) {
    return item.props.points;
  }
  const { x, y } = item.transform;
  const { width, height } = item.props;
  return [
    { x, y },
    { x: x + width, y },
    { x: x + width, y: y + height },
    { x, y: y + height },
  ];
}

export interface PcbHitResult {
  item: AnyItem;
  pad?: { pad: PadDef; world: Point };
  distance: number;
}

export function hitTestPCB(
  items: AnyItem[],
  worldPt: Point,
  scalePxPerMm: number,
  hitSlopPx: number = TOUCH_HIT_SLOP_PX
): PcbHitResult | null {
  const slopMm = Math.max(1.2, hitSlopPx / Math.max(scalePxPerMm, 1));

  let bestPadHit: PcbHitResult | null = null;
  for (const item of items) {
    if (item.type === 'pcb_footprint') {
      const pads = getFootprintPadsWorld(item);
      for (const p of pads) {
        const d = distance(worldPt, p.world);
        const padRadius = Math.max(p.pad.width, p.pad.height) / 2;
        if (d <= padRadius + slopMm * 0.75 && (!bestPadHit || d < bestPadHit.distance)) {
          bestPadHit = { item, pad: p, distance: d };
        }
      }
    }
  }
  if (bestPadHit) return bestPadHit;

  let bestHit: PcbHitResult | null = null;
  for (let i = items.length - 1; i >= 0; i--) {
    const item = items[i];
    if (item.type === 'pcb_via') {
      const d = distance(worldPt, { x: item.transform.x, y: item.transform.y });
      if (d <= item.props.diameter / 2 + slopMm * 0.7 && (!bestHit || d < bestHit.distance)) {
        bestHit = { item, distance: d };
      }
    } else if (item.type === 'pcb_footprint') {
      const { width, height } = item.props.courtyard;
      const isRot = item.transform.rotation === 90 || item.transform.rotation === 270;
      const hw = (isRot ? height : width) / 2 + slopMm * 0.4;
      const hh = (isRot ? width : height) / 2 + slopMm * 0.4;
      const dx = Math.abs(worldPt.x - item.transform.x);
      const dy = Math.abs(worldPt.y - item.transform.y);
      if (dx <= hw && dy <= hh) {
        const d = Math.hypot(dx, dy);
        if (!bestHit || d < bestHit.distance) {
          bestHit = { item, distance: d };
        }
      }
    } else if (item.type === 'pcb_trace') {
      const pts = item.props.points;
      for (let j = 0; j < pts.length - 1; j++) {
        const { dist } = distanceToSegment(worldPt, pts[j], pts[j + 1]);
        if (dist <= item.props.width / 2 + slopMm * 0.7 && (!bestHit || dist < bestHit.distance)) {
          bestHit = { item, distance: dist };
        }
      }
    } else if (item.type === 'pcb_outline') {
      const corners = getOutlinePolygonPoints(item);
      for (let j = 0; j < corners.length; j++) {
        const { dist } = distanceToSegment(worldPt, corners[j], corners[(j + 1) % corners.length]);
        if (dist <= slopMm * 0.85 && (!bestHit || dist < bestHit.distance)) {
          bestHit = { item, distance: dist };
        }
      }
    }
  }

  return bestHit;
}

export function computeSheetBounds(items: AnyItem[]): BoundingBox {
  if (items.length === 0) {
    return { minX: -20, minY: -20, maxX: 60, maxY: 60 };
  }
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;

  const expand = (x: number, y: number, pad = 2) => {
    if (x - pad < minX) minX = x - pad;
    if (y - pad < minY) minY = y - pad;
    if (x + pad > maxX) maxX = x + pad;
    if (y + pad > maxY) maxY = y + pad;
  };

  for (const item of items) {
    if (item.type === 'sch_wire' || item.type === 'pcb_trace') {
      for (const p of item.props.points) {
        expand(p.x, p.y, 2);
      }
    } else if (item.type === 'pcb_outline') {
      const pts = getOutlinePolygonPoints(item);
      for (const p of pts) {
        expand(p.x, p.y, 3);
      }
    } else {
      expand(item.transform.x, item.transform.y, 5);
    }
  }

  return { minX, minY, maxX, maxY };
}
