import {
  distance,
  distanceToSegment,
  getFootprintPadsWorld,
  getOutlinePolygonPoints,
  segmentToSegmentDistance,
} from './geometry';
import { computeNetlist, computeRatsnest } from './netlist';
import {
  DRCViolation,
  PcbFootprintItem,
  PcbOutlineItem,
  PcbTraceItem,
  PcbViaItem,
  Project,
} from './types';

/**
 * Runs Design Rule Check (DRC) on the PCB sheet and returns all violations.
 */
export function runDRC(project: Project): DRCViolation[] {
  const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');
  if (!pcbSheet) return [];

  const rules = project.rules;
  const violations: DRCViolation[] = [];
  const netlist = computeNetlist(project);

  const footprints = pcbSheet.items.filter((i): i is PcbFootprintItem => i.type === 'pcb_footprint');
  const traces = pcbSheet.items.filter((i): i is PcbTraceItem => i.type === 'pcb_trace');
  const vias = pcbSheet.items.filter((i): i is PcbViaItem => i.type === 'pcb_via');
  const outlines = pcbSheet.items.filter((i): i is PcbOutlineItem => i.type === 'pcb_outline');
  const boardOutline = outlines[0];

  // 1. Unrouted nets (ratsnest lines remaining)
  const ratsnest = computeRatsnest(project);
  for (const rat of ratsnest) {
    violations.push({
      id: `drc_unrouted_${rat.id}`,
      type: 'unrouted_net',
      severity: 'warning',
      message: `Unrouted net ${rat.net}: ${rat.fromRef} to ${rat.toRef}`,
      position: {
        x: Number(((rat.from.x + rat.to.x) / 2).toFixed(2)),
        y: Number(((rat.from.y + rat.to.y) / 2).toFixed(2)),
      },
      layer: 'F.Cu',
      itemIds: [],
    });
  }

  // 2. Trace width check
  for (const trace of traces) {
    if (trace.props.width < rules.minTraceWidth - 1e-4) {
      const midPt = trace.props.points[Math.floor(trace.props.points.length / 2)] || trace.transform;
      violations.push({
        id: `drc_width_${trace.id}`,
        type: 'trace_width',
        severity: 'error',
        message: `Trace width ${trace.props.width.toFixed(2)}mm < min ${rules.minTraceWidth.toFixed(2)}mm`,
        position: { x: midPt.x, y: midPt.y },
        layer: trace.transform.layer,
        itemIds: [trace.id],
      });
    }
  }

  // 3. Via drill & annular ring check
  for (const via of vias) {
    if (via.props.drill < rules.minViaDrill - 1e-4) {
      violations.push({
        id: `drc_viadrill_${via.id}`,
        type: 'via_drill',
        severity: 'error',
        message: `Via drill ${via.props.drill.toFixed(2)}mm < min ${rules.minViaDrill.toFixed(2)}mm`,
        position: { x: via.transform.x, y: via.transform.y },
        layer: 'F.Cu',
        itemIds: [via.id],
      });
    }
    const annularRing = (via.props.diameter - via.props.drill) / 2;
    if (annularRing < rules.minAnnularRing - 1e-4) {
      violations.push({
        id: `drc_annular_${via.id}`,
        type: 'annular_ring',
        severity: 'error',
        message: `Via annular ring ${annularRing.toFixed(2)}mm < min ${rules.minAnnularRing.toFixed(2)}mm`,
        position: { x: via.transform.x, y: via.transform.y },
        layer: 'F.Cu',
        itemIds: [via.id],
      });
    }
  }

  // 4. Trace-to-Trace clearance on same copper layer
  for (let i = 0; i < traces.length; i++) {
    for (let j = i + 1; j < traces.length; j++) {
      const t1 = traces[i];
      const t2 = traces[j];
      if (t1.transform.layer !== t2.transform.layer) continue;
      if (t1.props.net && t2.props.net && t1.props.net === t2.props.net) continue;

      const p1 = t1.props.points;
      const p2 = t2.props.points;
      const minRequiredCenterDist = (t1.props.width + t2.props.width) / 2 + rules.minClearance;

      let violationReported = false;
      for (let a = 0; a < p1.length - 1 && !violationReported; a++) {
        for (let b = 0; b < p2.length - 1 && !violationReported; b++) {
          const { dist, point } = segmentToSegmentDistance(p1[a], p1[a + 1], p2[b], p2[b + 1]);
          if (dist < minRequiredCenterDist - 1e-3) {
            const actualClearance = Math.max(0, dist - (t1.props.width + t2.props.width) / 2);
            violations.push({
              id: `drc_clr_tt_${t1.id}_${t2.id}`,
              type: 'clearance',
              severity: 'error',
              message: `Trace clearance ${actualClearance.toFixed(2)}mm < ${rules.minClearance.toFixed(2)}mm (${t1.props.net || 'unassigned'} vs ${t2.props.net || 'unassigned'})`,
              position: point,
              layer: t1.transform.layer,
              itemIds: [t1.id, t2.id],
            });
            violationReported = true;
          }
        }
      }
    }
  }

  // 5. Pad-to-Trace clearance
  for (const fp of footprints) {
    const pads = getFootprintPadsWorld(fp);
    for (const p of pads) {
      const padNet = netlist.padNetMap[`${fp.props.refDes}:${p.pad.number}`] || p.pad.net || '';
      const padRadius = Math.min(p.pad.width, p.pad.height) / 2;

      for (const trace of traces) {
        if (!p.pad.layers.includes(trace.transform.layer as 'F.Cu' | 'B.Cu')) continue;
        if (padNet && trace.props.net && padNet === trace.props.net) continue;

        const pts = trace.props.points;
        for (let a = 0; a < pts.length - 1; a++) {
          const { dist } = distanceToSegment(p.world, pts[a], pts[a + 1]);
          const minAllowed = padRadius + trace.props.width / 2 + rules.minClearance;
          if (dist < minAllowed - 1e-3) {
            // Check if trace actually terminates on this pad (e.g., unassigned trace connected to pad)
            const startsOrEndsOnPad =
              distance(p.world, pts[0]) <= padRadius + 0.1 ||
              distance(p.world, pts[pts.length - 1]) <= padRadius + 0.1;
            if (!trace.props.net && startsOrEndsOnPad) continue;

            const actualClr = Math.max(0, dist - padRadius - trace.props.width / 2);
            violations.push({
              id: `drc_clr_pt_${fp.id}_${p.pad.number}_${trace.id}`,
              type: 'clearance',
              severity: 'error',
              message: `Pad ${fp.props.refDes}.${p.pad.number} to trace clearance ${actualClr.toFixed(2)}mm < ${rules.minClearance.toFixed(2)}mm`,
              position: p.world,
              layer: trace.transform.layer,
              itemIds: [fp.id, trace.id],
            });
            break;
          }
        }
      }
    }
  }

  // 6. Courtyard overlap between footprints
  for (let i = 0; i < footprints.length; i++) {
    for (let j = i + 1; j < footprints.length; j++) {
      const f1 = footprints[i];
      const f2 = footprints[j];
      const rot1 = f1.transform.rotation === 90 || f1.transform.rotation === 270;
      const rot2 = f2.transform.rotation === 90 || f2.transform.rotation === 270;
      const hw1 = (rot1 ? f1.props.courtyard.height : f1.props.courtyard.width) / 2;
      const hh1 = (rot1 ? f1.props.courtyard.width : f1.props.courtyard.height) / 2;
      const hw2 = (rot2 ? f2.props.courtyard.height : f2.props.courtyard.width) / 2;
      const hh2 = (rot2 ? f2.props.courtyard.width : f2.props.courtyard.height) / 2;

      const dx = Math.abs(f1.transform.x - f2.transform.x);
      const dy = Math.abs(f1.transform.y - f2.transform.y);
      if (dx < hw1 + hw2 - 0.1 && dy < hh1 + hh2 - 0.1) {
        violations.push({
          id: `drc_courtyard_${f1.id}_${f2.id}`,
          type: 'courtyard_overlap',
          severity: 'error',
          message: `Footprints ${f1.props.refDes} and ${f2.props.refDes} overlap`,
          position: {
            x: (f1.transform.x + f2.transform.x) / 2,
            y: (f1.transform.y + f2.transform.y) / 2,
          },
          layer: 'F.SilkS',
          itemIds: [f1.id, f2.id],
        });
      }
    }
  }

  // 7. Board outline boundary check
  if (boardOutline) {
    const polyPts = getOutlinePolygonPoints(boardOutline);
    let minX = boardOutline.transform.x;
    let minY = boardOutline.transform.y;
    let maxX = minX + boardOutline.props.width;
    let maxY = minY + boardOutline.props.height;
    if (polyPts.length >= 3) {
      minX = Math.min(...polyPts.map((p) => p.x));
      minY = Math.min(...polyPts.map((p) => p.y));
      maxX = Math.max(...polyPts.map((p) => p.x));
      maxY = Math.max(...polyPts.map((p) => p.y));
    }

    for (const fp of footprints) {
      const { x, y } = fp.transform;
      if (x < minX || x > maxX || y < minY || y > maxY) {
        violations.push({
          id: `drc_oob_${fp.id}`,
          type: 'out_of_bounds',
          severity: 'error',
          message: `Footprint ${fp.props.refDes} is outside board outline`,
          position: { x, y },
          layer: 'Edge.Cuts',
          itemIds: [fp.id, boardOutline.id],
        });
      }
    }
  }

  return violations;
}
