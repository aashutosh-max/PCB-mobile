import {
  distance,
  distanceToSegment,
  getFootprintPadsWorld,
  getOutlinePolygonPoints,
  segmentToSegmentDistance,
} from './geometry';
import { computeNetlist, computeRatsnest } from './netlist';
import {
  AnyItem,
  PcbFootprintItem,
  PcbOutlineItem,
  PcbTraceItem,
  PcbViaItem,
  Point,
  Project,
} from './types';

export type RoutingFrameworkId =
  | '@tscircuit/capacity-autorouter'
  | '@tscircuit/routing'
  | 'Freerouting'
  | 'Topola'
  | 'KiCadRoutingTools'
  | 'OrthoRoute'
  | 'Quilter'
  | 'DeepPCB'
  | '@easyeda-copilot/router'
  | 'route-rnd (with pcb-rnd)'
  | 'FD-Autoplacer'
  | 'Cherry Blossom'
  | 'cadlab'
  | 'CopperMCP';

export interface RoutingFrameworkSpec {
  id: RoutingFrameworkId;
  name: string;
  tagline: string;
  defaultGridStep: number;
  defaultDiagonal45: boolean;
  defaultViaCost: number;
  bendPenalty: number;
  passes: number;
  netOrdering: 'short_first' | 'long_first' | 'congestion' | 'bus_priority';
  extraClearanceMargin: number;
  autoPlaceMode?: 'fd' | 'sa';
}

export const ROUTING_FRAMEWORKS: RoutingFrameworkSpec[] = [
  {
    id: '@tscircuit/capacity-autorouter',
    name: '@tscircuit/capacity-autorouter',
    tagline: 'Capacity-driven multi-pass mesh & A* autorouter',
    defaultGridStep: 0.25,
    defaultDiagonal45: true,
    defaultViaCost: 14,
    bendPenalty: 0.35,
    passes: 2,
    netOrdering: 'congestion',
    extraClearanceMargin: 0.08,
  },
  {
    id: '@tscircuit/routing',
    name: '@tscircuit/routing',
    tagline: 'Lightweight client-side MST + A* grid router',
    defaultGridStep: 0.25,
    defaultDiagonal45: true,
    defaultViaCost: 12,
    bendPenalty: 0.3,
    passes: 2,
    netOrdering: 'short_first',
    extraClearanceMargin: 0.06,
  },
  {
    id: 'Freerouting',
    name: 'Freerouting',
    tagline: 'Multi-pass rip-up & shove 45° octilinear router',
    defaultGridStep: 0.25,
    defaultDiagonal45: true,
    defaultViaCost: 16,
    bendPenalty: 0.4,
    passes: 3,
    netOrdering: 'congestion',
    extraClearanceMargin: 0.1,
  },
  {
    id: 'Topola',
    name: 'Topola',
    tagline: 'Topological rubberband & octilinear Delaunay router',
    defaultGridStep: 0.25,
    defaultDiagonal45: true,
    defaultViaCost: 18,
    bendPenalty: 0.25,
    passes: 2,
    netOrdering: 'short_first',
    extraClearanceMargin: 0.1,
  },
  {
    id: 'KiCadRoutingTools',
    name: 'KiCadRoutingTools',
    tagline: 'KiCad PNS (Push & Shove) walkaround copper router',
    defaultGridStep: 0.25,
    defaultDiagonal45: true,
    defaultViaCost: 15,
    bendPenalty: 0.42,
    passes: 2,
    netOrdering: 'short_first',
    extraClearanceMargin: 0.08,
  },
  {
    id: 'OrthoRoute',
    name: 'OrthoRoute',
    tagline: 'Strict 90° Manhattan HV/VH orthogonal channel router',
    defaultGridStep: 0.25,
    defaultDiagonal45: false,
    defaultViaCost: 10,
    bendPenalty: 0.5,
    passes: 2,
    netOrdering: 'bus_priority',
    extraClearanceMargin: 0.08,
  },
  {
    id: 'Quilter',
    name: 'Quilter',
    tagline: 'Physics-aware candidate synthesis & DRC-verified router',
    defaultGridStep: 0.25,
    defaultDiagonal45: true,
    defaultViaCost: 14,
    bendPenalty: 0.35,
    passes: 3,
    netOrdering: 'congestion',
    extraClearanceMargin: 0.12,
  },
  {
    id: 'DeepPCB',
    name: 'DeepPCB',
    tagline: 'RL-guided tree search & zero-short copper autorouter',
    defaultGridStep: 0.25,
    defaultDiagonal45: true,
    defaultViaCost: 13,
    bendPenalty: 0.32,
    passes: 3,
    netOrdering: 'long_first',
    extraClearanceMargin: 0.1,
  },
  {
    id: '@easyeda-copilot/router',
    name: '@easyeda-copilot/router',
    tagline: 'Heuristic net-ordering & low-via 2-layer PCB router',
    defaultGridStep: 0.25,
    defaultDiagonal45: true,
    defaultViaCost: 20,
    bendPenalty: 0.38,
    passes: 2,
    netOrdering: 'short_first',
    extraClearanceMargin: 0.08,
  },
  {
    id: 'route-rnd (with pcb-rnd)',
    name: 'route-rnd (with pcb-rnd)',
    tagline: 'Modular multi-strategy grid & line-search router',
    defaultGridStep: 0.5,
    defaultDiagonal45: false,
    defaultViaCost: 14,
    bendPenalty: 0.45,
    passes: 2,
    netOrdering: 'short_first',
    extraClearanceMargin: 0.06,
  },
  {
    id: 'FD-Autoplacer',
    name: 'FD-Autoplacer',
    tagline: 'Force-Directed footprint de-overlap + MST A* router',
    defaultGridStep: 0.25,
    defaultDiagonal45: true,
    defaultViaCost: 12,
    bendPenalty: 0.3,
    passes: 2,
    netOrdering: 'short_first',
    extraClearanceMargin: 0.08,
    autoPlaceMode: 'fd',
  },
  {
    id: 'Cherry Blossom',
    name: 'Cherry Blossom',
    tagline: 'Simulated Annealing placement + congestion-aware router',
    defaultGridStep: 0.25,
    defaultDiagonal45: true,
    defaultViaCost: 13,
    bendPenalty: 0.32,
    passes: 2,
    netOrdering: 'congestion',
    extraClearanceMargin: 0.08,
    autoPlaceMode: 'sa',
  },
  {
    id: 'cadlab',
    name: 'cadlab',
    tagline: 'Compact SMD/THT fanout & bus-channel router',
    defaultGridStep: 0.25,
    defaultDiagonal45: true,
    defaultViaCost: 14,
    bendPenalty: 0.36,
    passes: 2,
    netOrdering: 'bus_priority',
    extraClearanceMargin: 0.08,
  },
  {
    id: 'CopperMCP',
    name: 'CopperMCP',
    tagline: 'Rule-driven MCP copper pathfinder & via optimizer',
    defaultGridStep: 0.25,
    defaultDiagonal45: true,
    defaultViaCost: 15,
    bendPenalty: 0.35,
    passes: 2,
    netOrdering: 'congestion',
    extraClearanceMargin: 0.1,
  },
];

export function getRoutingFrameworkSpec(id?: RoutingFrameworkId): RoutingFrameworkSpec {
  return (
    ROUTING_FRAMEWORKS.find((f) => f.id === id) ||
    ROUTING_FRAMEWORKS[1] // @tscircuit/routing
  );
}

export interface AutorouterConfig {
  framework: RoutingFrameworkId;
  gridStep: number; // mm, e.g. 0.25
  layerMode: 'multi' | 'F.Cu' | 'B.Cu';
  diagonal45: boolean;
  autoRouteAirwires: boolean;
  viaCost: number;
}

export const DEFAULT_AUTOROUTER_CONFIG: AutorouterConfig = {
  framework: '@tscircuit/routing',
  gridStep: 0.25,
  layerMode: 'multi',
  diagonal45: true,
  autoRouteAirwires: true,
  viaCost: 12,
};

export interface AutorouteOptions extends Partial<AutorouterConfig> {
  targetNet?: string;
  specificPair?: {
    from: Point;
    to: Point;
    net: string;
  };
  ripUpExisting?: boolean;
  traceWidth?: number;
  clearance?: number;
  viaDiameter?: number;
  viaDrill?: number;
}

export interface AutorouteResult {
  project: Project;
  framework: RoutingFrameworkId;
  routedConnections: number;
  failedConnections: number;
  addedTraces: number;
  addedVias: number;
  remainingAirwires: number;
  elapsedMs: number;
}

interface PadObstacle {
  id: string;
  world: Point;
  net: string;
  layers: ('F.Cu' | 'B.Cu')[];
  rx?: number;
  ry?: number;
  coreRadius: number;
  clearanceRadius: number;
}

interface MinHeapNode {
  stateIdx: number;
  f: number;
}

class BinaryMinHeap {
  private data: MinHeapNode[] = [];

  get size(): number {
    return this.data.length;
  }

  push(stateIdx: number, f: number): void {
    const node: MinHeapNode = { stateIdx, f };
    this.data.push(node);
    this.bubbleUp(this.data.length - 1);
  }

  pop(): MinHeapNode | undefined {
    if (this.data.length === 0) return undefined;
    const top = this.data[0];
    const bottom = this.data.pop()!;
    if (this.data.length > 0) {
      this.data[0] = bottom;
      this.sinkDown(0);
    }
    return top;
  }

  private bubbleUp(idx: number): void {
    const element = this.data[idx];
    while (idx > 0) {
      const parentIdx = (idx - 1) >> 1;
      const parent = this.data[parentIdx];
      if (element.f >= parent.f) break;
      this.data[parentIdx] = element;
      this.data[idx] = parent;
      idx = parentIdx;
    }
  }

  private sinkDown(idx: number): void {
    const length = this.data.length;
    const element = this.data[idx];
    while (true) {
      const leftIdx = (idx << 1) + 1;
      const rightIdx = leftIdx + 1;
      let swapIdx = -1;

      if (leftIdx < length) {
        if (this.data[leftIdx].f < element.f) {
          swapIdx = leftIdx;
        }
      }
      if (rightIdx < length) {
        const threshold = swapIdx === -1 ? element.f : this.data[leftIdx].f;
        if (this.data[rightIdx].f < threshold) {
          swapIdx = rightIdx;
        }
      }
      if (swapIdx === -1) break;
      this.data[idx] = this.data[swapIdx];
      this.data[swapIdx] = element;
      idx = swapIdx;
    }
  }
}

const DIRS_8: readonly [number, number, number][] = [
  [1, 0, 1.0],
  [-1, 0, 1.0],
  [0, 1, 1.0],
  [0, -1, 1.0],
  [1, 1, Math.SQRT2],
  [1, -1, Math.SQRT2],
  [-1, 1, Math.SQRT2],
  [-1, -1, Math.SQRT2],
];

/**
 * Resolves any overlapping footprints using force-directed repulsion when FD-Autoplacer or Cherry Blossom is active.
 */
function resolveOverlappingFootprints(project: Project): Project {
  const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');
  if (!pcbSheet) return project;
  const footprints = pcbSheet.items.filter(
    (i): i is PcbFootprintItem => i.type === 'pcb_footprint'
  );
  if (footprints.length < 2) return project;

  const outline = pcbSheet.items.find(
    (i): i is PcbOutlineItem => i.type === 'pcb_outline'
  );
  const minX = (outline?.transform.x ?? 4) + 3.5;
  const minY = (outline?.transform.y ?? 4) + 3.5;
  const maxX = minX + Math.max(20, (outline?.props.width ?? 40) - 7);
  const maxY = minY + Math.max(14, (outline?.props.height ?? 28) - 7);

  const positions = footprints.map((fp) => ({
    id: fp.id,
    x: fp.transform.x,
    y: fp.transform.y,
    w: fp.props.courtyard.width + 1.5,
    h: fp.props.courtyard.height + 1.5,
  }));

  let moved = false;
  for (let iter = 0; iter < 16; iter++) {
    for (let i = 0; i < positions.length; i++) {
      for (let j = i + 1; j < positions.length; j++) {
        const a = positions[i];
        const b = positions[j];
        const overlapX = (a.w + b.w) / 2 - Math.abs(a.x - b.x);
        const overlapY = (a.h + b.h) / 2 - Math.abs(a.y - b.y);
        if (overlapX > 0 && overlapY > 0) {
          moved = true;
          const dx = b.x - a.x || 0.5;
          const dy = b.y - a.y || 0.5;
          if (overlapX < overlapY) {
            const push = (overlapX / 2 + 0.5) * Math.sign(dx);
            a.x = Math.max(minX, Math.min(maxX, a.x - push));
            b.x = Math.max(minX, Math.min(maxX, b.x + push));
          } else {
            const push = (overlapY / 2 + 0.5) * Math.sign(dy);
            a.y = Math.max(minY, Math.min(maxY, a.y - push));
            b.y = Math.max(minY, Math.min(maxY, b.y + push));
          }
        }
      }
    }
  }

  if (!moved) return project;

  const posMap = new Map(
    positions.map((p) => [
      p.id,
      {
        x: Math.round(p.x * 2) / 2,
        y: Math.round(p.y * 2) / 2,
      },
    ])
  );

  return {
    ...project,
    sheets: project.sheets.map((s) =>
      s.kind === 'pcb'
        ? {
            ...s,
            items: s.items.map((it) => {
              if (it.type === 'pcb_footprint' && posMap.has(it.id)) {
                const np = posMap.get(it.id)!;
                return {
                  ...it,
                  transform: { ...it.transform, x: np.x, y: np.y },
                };
              }
              return it;
            }),
          }
        : s
    ),
  };
}

/**
 * Client-side MST + 2-Layer A* Grid Autorouter for immediate airwire resolution.
 * Strictly avoids touching any other pads, traces, or vias except at the exact connection points.
 */
export function runMstAStarAutorouter(
  project: Project,
  options: AutorouteOptions = {}
): AutorouteResult {
  const startTime = performance.now();
  const cfg: AutorouterConfig = {
    ...DEFAULT_AUTOROUTER_CONFIG,
    ...options,
  };
  const fwSpec = getRoutingFrameworkSpec(cfg.framework);

  const pcbSheet = project.sheets.find((s) => s.kind === 'pcb');
  if (!pcbSheet) {
    return {
      project,
      framework: cfg.framework,
      routedConnections: 0,
      failedConnections: 0,
      addedTraces: 0,
      addedVias: 0,
      remainingAirwires: 0,
      elapsedMs: 0,
    };
  }

  const traceWidth = options.traceWidth ?? Math.max(0.25, project.rules.minTraceWidth || 0.35);
  const baseClearance = options.clearance ?? Math.max(0.2, project.rules.minClearance || 0.22);
  const clearance = baseClearance + fwSpec.extraClearanceMargin;
  const viaDiameter = options.viaDiameter ?? 0.8;
  const viaDrill = options.viaDrill ?? Math.max(0.3, project.rules.minViaDrill || 0.4);

  let workingProject: Project = project;
  if (fwSpec.autoPlaceMode && !options.specificPair && !options.targetNet) {
    workingProject = resolveOverlappingFootprints(workingProject);
  }

  if (options.ripUpExisting) {
    workingProject = {
      ...workingProject,
      sheets: workingProject.sheets.map((s) =>
        s.kind === 'pcb'
          ? {
              ...s,
              items: s.items.filter((item) => {
                if (item.type === 'pcb_trace' || item.type === 'pcb_via') {
                  if (options.targetNet) {
                    return item.props.net !== options.targetNet;
                  }
                  return false;
                }
                return true;
              }),
            }
          : s
      ),
    };
  }

  const workingPcbSheet = workingProject.sheets.find((s) => s.kind === 'pcb')!;
  const netlist = computeNetlist(workingProject);
  const footprints = workingPcbSheet.items.filter(
    (i): i is PcbFootprintItem => i.type === 'pcb_footprint'
  );
  const existingTraces = workingPcbSheet.items.filter(
    (i): i is PcbTraceItem => i.type === 'pcb_trace'
  );
  const existingVias = workingPcbSheet.items.filter(
    (i): i is PcbViaItem => i.type === 'pcb_via'
  );
  const outlineItem = workingPcbSheet.items.find(
    (i): i is PcbOutlineItem => i.type === 'pcb_outline'
  );

  let airwires = options.specificPair
    ? [
        {
          id: `rat_pair_${Date.now()}`,
          net: options.specificPair.net,
          from: options.specificPair.from,
          to: options.specificPair.to,
          fromRef: 'PAD_A',
          toRef: 'PAD_B',
        },
      ]
    : computeRatsnest(workingProject);

  if (options.targetNet) {
    airwires = airwires.filter((a) => a.net === options.targetNet);
  }

  if (airwires.length === 0) {
    return {
      project: workingProject,
      framework: cfg.framework,
      routedConnections: 0,
      failedConnections: 0,
      addedTraces: 0,
      addedVias: 0,
      remainingAirwires: computeRatsnest(workingProject).length,
      elapsedMs: Math.round(performance.now() - startTime),
    };
  }

  // Order airwires so signal nets and fine-pitch SMD escapes route before global GND/power nets
  const isPowerOrGndNet = (netName: string) =>
    netName === 'GND' ||
    netName.startsWith('+') ||
    netName.startsWith('VCC') ||
    netName.startsWith('VBUS') ||
    netName.startsWith('VIN');

  airwires = [...airwires].sort((a, b) => {
    const aPwr = isPowerOrGndNet(a.net) ? 1 : 0;
    const bPwr = isPowerOrGndNet(b.net) ? 1 : 0;
    if (aPwr !== bPwr) return aPwr - bPwr;

    const da = Math.hypot(a.to.x - a.from.x, a.to.y - a.from.y);
    const db = Math.hypot(b.to.x - b.from.x, b.to.y - b.from.y);
    if (fwSpec.netOrdering === 'long_first') {
      return db - da;
    }
    return da - db;
  });

  // Determine board bounding box for grid discretization
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;

  if (outlineItem) {
    const poly = getOutlinePolygonPoints(outlineItem);
    for (const pt of poly) {
      if (pt.x < minX) minX = pt.x;
      if (pt.y < minY) minY = pt.y;
      if (pt.x > maxX) maxX = pt.x;
      if (pt.y > maxY) maxY = pt.y;
    }
  }

  const pads: PadObstacle[] = [];
  for (const fp of footprints) {
    const isRot90 = fp.transform.rotation === 90 || fp.transform.rotation === 270;
    for (const pw of getFootprintPadsWorld(fp)) {
      const padId = `${fp.props.refDes}:${pw.pad.number}`;
      const padNet =
        netlist.padNetMap[padId] ||
        pw.pad.net ||
        `__UNCONNECTED_${fp.props.refDes}_${pw.pad.number}`;
      const w = isRot90 ? pw.pad.height : pw.pad.width;
      const h = isRot90 ? pw.pad.width : pw.pad.height;
      const coreR = Math.min(w, h) / 2 + 0.05;
      const clearR = coreR + traceWidth / 2 + clearance;
      pads.push({
        id: padId,
        world: pw.world,
        net: padNet,
        layers: pw.pad.layers,
        rx: w / 2,
        ry: h / 2,
        coreRadius: coreR,
        clearanceRadius: clearR,
      });
      if (pw.world.x - 5 < minX) minX = pw.world.x - 5;
      if (pw.world.y - 5 < minY) minY = pw.world.y - 5;
      if (pw.world.x + 5 > maxX) maxX = pw.world.x + 5;
      if (pw.world.y + 5 > maxY) maxY = pw.world.y + 5;
    }
  }

  for (const aw of airwires) {
    minX = Math.min(minX, aw.from.x - 5, aw.to.x - 5);
    minY = Math.min(minY, aw.from.y - 5, aw.to.y - 5);
    maxX = Math.max(maxX, aw.from.x + 5, aw.to.x + 5);
    maxY = Math.max(maxY, aw.from.y + 5, aw.to.y + 5);
  }

  if (!isFinite(minX)) {
    minX = 0;
    minY = 0;
    maxX = 50;
    maxY = 40;
  }

  const spanX = Math.max(10, maxX - minX);
  const spanY = Math.max(10, maxY - minY);
  let step = Math.max(0.2, Math.min(cfg.gridStep || 0.25, 0.5));
  const maxDim = 260;
  if (spanX / step > maxDim || spanY / step > maxDim) {
    step = Math.max(step, Math.ceil((Math.max(spanX, spanY) / maxDim) * 20) / 20);
  }

  const cols = Math.max(8, Math.ceil(spanX / step) + 1);
  const rows = Math.max(8, Math.ceil(spanY / step) + 1);
  const cellCount = cols * rows;

  const toGridX = (wx: number) =>
    Math.max(0, Math.min(cols - 1, Math.round((wx - minX) / step)));
  const toGridY = (wy: number) =>
    Math.max(0, Math.min(rows - 1, Math.round((wy - minY) / step)));
  const toWorldX = (gx: number) => Number((minX + gx * step).toFixed(3));
  const toWorldY = (gy: number) => Number((minY + gy * step).toFixed(3));

  const allowedLayers: (0 | 1)[] =
    cfg.layerMode === 'F.Cu'
      ? [0]
      : cfg.layerMode === 'B.Cu'
        ? [1]
        : [0, 1];

  const findPadAt = (pt: Point): PadObstacle | undefined => {
    let best: PadObstacle | undefined;
    let bestD = 0.75;
    for (const p of pads) {
      const d = Math.hypot(p.world.x - pt.x, p.world.y - pt.y);
      if (d < bestD) {
        bestD = d;
        best = p;
      }
    }
    return best;
  };

  const gScore = new Float32Array(cellCount * 2);
  const cameFrom = new Int32Array(cellCount * 2);
  const cameDir = new Int8Array(cellCount * 2);
  const closed = new Uint8Array(cellCount * 2);

  const runRoutingPass = (
    orderedAirwires: typeof airwires
  ): {
    allTraces: PcbTraceItem[];
    allVias: PcbViaItem[];
    newItems: AnyItem[];
    routedConnections: number;
    failedConnections: number;
    addedTraces: number;
    addedVias: number;
    failedIndices: number[];
  } => {
    const allTraces: PcbTraceItem[] = [...existingTraces];
    const allVias: PcbViaItem[] = [...existingVias];
    const newItems: AnyItem[] = [];
    let routedConnections = 0;
    let failedConnections = 0;
    let addedTraces = 0;
    let addedVias = 0;
    const failedIndices: number[] = [];

    /**
     * Checks if a continuous copper line segment [a, b] on `layer` avoids touching all other pads, traces, and vias
     * except at the designated `startPad`/`goalPad` or `startPt`/`goalPt` connection points.
     */
    const isSegmentClearOfObstacles = (
      a: Point,
      b: Point,
      layer: 'F.Cu' | 'B.Cu',
      netName: string,
      startPad: PadObstacle | undefined,
      goalPad: PadObstacle | undefined,
      startPt: Point,
      goalPt: Point,
      marginScale = 0.85
    ): boolean => {
      // 1. Check all pads (except the exact startPad and goalPad of this connection)
      for (const pad of pads) {
        if (pad === startPad || pad === goalPad) continue;
        if (!pad.layers.includes(layer)) continue;
        const reqDist = pad.coreRadius + traceWidth / 2 + baseClearance * marginScale;
        if (distanceToSegment(pad.world, a, b).dist < reqDist) {
          return false;
        }
      }

      // 2. Check all traces on the same layer
      for (const tr of allTraces) {
        if (tr.transform.layer !== layer) continue;
        const reqDist = tr.props.width / 2 + traceWidth / 2 + baseClearance * marginScale;
        const pts = tr.props.points;
        for (let i = 0; i < pts.length - 1; i++) {
          const p1 = pts[i];
          const p2 = pts[i + 1];
          if (tr.props.net === netName) {
            // Same-net traces may only touch near the explicit connection points startPt or goalPt
            const nearStart =
              distance(p1, startPt) <= 0.45 ||
              distance(p2, startPt) <= 0.45 ||
              distanceToSegment(startPt, p1, p2).dist <= 0.4;
            const nearGoal =
              distance(p1, goalPt) <= 0.45 ||
              distance(p2, goalPt) <= 0.45 ||
              distanceToSegment(goalPt, p1, p2).dist <= 0.4;
            if (nearStart && (distance(a, startPt) <= 0.6 || distance(b, startPt) <= 0.6)) {
              continue;
            }
            if (nearGoal && (distance(a, goalPt) <= 0.6 || distance(b, goalPt) <= 0.6)) {
              continue;
            }
          }
          if (segmentToSegmentDistance(a, b, p1, p2).dist < reqDist) {
            return false;
          }
        }
      }

      // 3. Check all vias
      for (const v of allVias) {
        const vp = { x: v.transform.x, y: v.transform.y };
        if (v.props.net === netName) {
          if (distance(vp, startPt) <= 0.45 || distance(vp, goalPt) <= 0.45) continue;
        }
        const reqDist = v.props.diameter / 2 + traceWidth / 2 + baseClearance * marginScale;
        if (distanceToSegment(vp, a, b).dist < reqDist) {
          return false;
        }
      }

      return true;
    };

    const isViaClearOfObstacles = (
      viaPt: Point,
      netName: string,
      startPad: PadObstacle | undefined,
      goalPad: PadObstacle | undefined
    ): boolean => {
      const viaR = viaDiameter / 2;
      for (const pad of pads) {
        if (pad === startPad || pad === goalPad) {
          if (distance(viaPt, pad.world) < pad.coreRadius + viaR) return false;
          continue;
        }
        if (distance(viaPt, pad.world) < pad.coreRadius + viaR + baseClearance * 0.85) {
          return false;
        }
      }
      for (const tr of allTraces) {
        if (tr.props.net === netName) continue;
        const reqDist = tr.props.width / 2 + viaR + baseClearance * 0.85;
        const pts = tr.props.points;
        for (let i = 0; i < pts.length - 1; i++) {
          if (distanceToSegment(viaPt, pts[i], pts[i + 1]).dist < reqDist) {
            return false;
          }
        }
      }
      for (const v of allVias) {
        const vp = { x: v.transform.x, y: v.transform.y };
        if (distance(viaPt, vp) < v.props.diameter / 2 + viaR + baseClearance * 0.85) {
          return false;
        }
      }
      return true;
    };

    /**
     * Simplifies grid path points while strictly preserving obstacle clearance on every segment.
     */
    const simplifyGridPointsAware = (
      pts: Point[],
      layer: 'F.Cu' | 'B.Cu',
      netName: string,
      startPad: PadObstacle | undefined,
      goalPad: PadObstacle | undefined,
      startPt: Point,
      goalPt: Point
    ): Point[] => {
      if (pts.length <= 2) return pts;
      const result: Point[] = [pts[0]];
      for (let i = 1; i < pts.length - 1; i++) {
        const prev = result[result.length - 1];
        const curr = pts[i];
        const next = pts[i + 1];
        const dx1 = curr.x - prev.x;
        const dy1 = curr.y - prev.y;
        const dx2 = next.x - curr.x;
        const dy2 = next.y - curr.y;
        const len1 = Math.hypot(dx1, dy1);
        const len2 = Math.hypot(dx2, dy2);
        if (len1 < 1e-4 || len2 < 1e-4) continue;
        const cross = Math.abs((dx1 / len1) * (dy2 / len2) - (dy1 / len1) * (dx2 / len2));
        const dot = (dx1 / len1) * (dx2 / len2) + (dy1 / len1) * (dy2 / len2);
        if (
          cross < 0.02 &&
          dot > 0.98 &&
          isSegmentClearOfObstacles(prev, next, layer, netName, startPad, goalPad, startPt, goalPt)
        ) {
          continue;
        }
        result.push(curr);
      }
      result.push(pts[pts.length - 1]);
      return result;
    };

    const buildBlockedMask = (
      fromPt: Point,
      toPt: Point,
      netName: string,
      startPad: PadObstacle | undefined,
      goalPad: PadObstacle | undefined,
      clearanceScale: number
    ): Uint8Array => {
      const blocked = new Uint8Array(cellCount * 2);
      const effClearance = baseClearance * clearanceScale;

      // 1. Block ALL pads except the exact startPad and goalPad of this connection!
      for (const pad of pads) {
        if (pad === startPad || pad === goalPad) continue;
        const r = pad.coreRadius + traceWidth / 2 + effClearance;
        const gxMin = toGridX(pad.world.x - r);
        const gxMax = toGridX(pad.world.x + r);
        const gyMin = toGridY(pad.world.y - r);
        const gyMax = toGridY(pad.world.y + r);
        const rSq = r * r;

        for (let gy = gyMin; gy <= gyMax; gy++) {
          const wy = toWorldY(gy);
          const dy = wy - pad.world.y;
          for (let gx = gxMin; gx <= gxMax; gx++) {
            const wx = toWorldX(gx);
            const dx = wx - pad.world.x;
            if (dx * dx + dy * dy <= rSq) {
              const cIdx = gy * cols + gx;
              if (pad.layers.includes('F.Cu')) blocked[cIdx * 2] = 1;
              if (pad.layers.includes('B.Cu')) blocked[cIdx * 2 + 1] = 1;
            }
          }
        }
      }

      // 2. Block ALL traces (foreign traces everywhere; same-net traces everywhere except at fromPt/toPt connection points)
      for (const tr of allTraces) {
        const layerIdx = tr.transform.layer === 'B.Cu' ? 1 : 0;
        const isSameNet = tr.props.net === netName;
        const r = tr.props.width / 2 + traceWidth / 2 + effClearance;
        const pts = tr.props.points;
        for (let i = 0; i < pts.length - 1; i++) {
          const a = pts[i];
          const b = pts[i + 1];
          const gxMin = toGridX(Math.min(a.x, b.x) - r);
          const gxMax = toGridX(Math.max(a.x, b.x) + r);
          const gyMin = toGridY(Math.min(a.y, b.y) - r);
          const gyMax = toGridY(Math.max(a.y, b.y) + r);

          for (let gy = gyMin; gy <= gyMax; gy++) {
            const wy = toWorldY(gy);
            for (let gx = gxMin; gx <= gxMax; gx++) {
              const wx = toWorldX(gx);
              const cellPt = { x: wx, y: wy };
              if (isSameNet) {
                if (distance(cellPt, fromPt) <= 0.45 || distance(cellPt, toPt) <= 0.45) {
                  continue;
                }
              }
              if (distanceToSegment(cellPt, a, b).dist <= r) {
                const cIdx = gy * cols + gx;
                blocked[cIdx * 2 + layerIdx] = 1;
              }
            }
          }
        }
      }

      // 3. Block ALL vias (foreign vias everywhere; same-net vias except at fromPt/toPt)
      for (const v of allVias) {
        const vp = { x: v.transform.x, y: v.transform.y };
        if (
          v.props.net === netName &&
          (distance(vp, fromPt) <= 0.45 || distance(vp, toPt) <= 0.45)
        ) {
          continue;
        }
        const r = v.props.diameter / 2 + traceWidth / 2 + effClearance;
        const gxMin = toGridX(vp.x - r);
        const gxMax = toGridX(vp.x + r);
        const gyMin = toGridY(vp.y - r);
        const gyMax = toGridY(vp.y + r);
        const rSq = r * r;
        for (let gy = gyMin; gy <= gyMax; gy++) {
          const wy = toWorldY(gy);
          const dy = wy - vp.y;
          for (let gx = gxMin; gx <= gxMax; gx++) {
            const wx = toWorldX(gx);
            const dx = wx - vp.x;
            if (dx * dx + dy * dy <= rSq) {
              const cIdx = gy * cols + gx;
              blocked[cIdx * 2] = 1;
              blocked[cIdx * 2 + 1] = 1;
            }
          }
        }
      }

      return blocked;
    };

    const runAStarBetween = (
      fromPt: Point,
      toPt: Point,
      netName: string,
      clearanceScale: number
    ): { gx: number; gy: number; layer: 0 | 1 }[] | null => {
      const startPad = findPadAt(fromPt);
      const goalPad = findPadAt(toPt);
      const blocked = buildBlockedMask(
        fromPt,
        toPt,
        netName,
        startPad,
        goalPad,
        clearanceScale
      );

      const startGx = toGridX(fromPt.x);
      const startGy = toGridY(fromPt.y);
      const goalGx = toGridX(toPt.x);
      const goalGy = toGridY(toPt.y);

      const startLayers = allowedLayers.filter((l) =>
        startPad ? startPad.layers.includes(l === 0 ? 'F.Cu' : 'B.Cu') : true
      );
      const goalLayers = allowedLayers.filter((l) =>
        goalPad ? goalPad.layers.includes(l === 0 ? 'F.Cu' : 'B.Cu') : true
      );

      const validStartLayers: (0 | 1)[] =
        startLayers.length > 0 ? startLayers : [allowedLayers[0]];
      const validGoalLayers: (0 | 1)[] =
        goalLayers.length > 0 ? goalLayers : [allowedLayers[0]];

      // Safely unblock ONLY cells at the start/goal pad that do NOT encroach on any other pad or trace!
      const isCellSafeForEndpoint = (gx: number, gy: number, layerIdx: 0 | 1): boolean => {
        const wx = toWorldX(gx);
        const wy = toWorldY(gy);
        const pt = { x: wx, y: wy };
        const layerName: 'F.Cu' | 'B.Cu' = layerIdx === 0 ? 'F.Cu' : 'B.Cu';
        for (const pad of pads) {
          if (pad === startPad || pad === goalPad) continue;
          if (!pad.layers.includes(layerName)) continue;
          if (distance(pt, pad.world) < pad.coreRadius + traceWidth / 2 + baseClearance * 0.75) {
            return false;
          }
        }
        for (const tr of allTraces) {
          if (tr.transform.layer !== layerName || tr.props.net === netName) continue;
          const req = tr.props.width / 2 + traceWidth / 2 + baseClearance * 0.75;
          for (let i = 0; i < tr.props.points.length - 1; i++) {
            if (distanceToSegment(pt, tr.props.points[i], tr.props.points[i + 1]).dist < req) {
              return false;
            }
          }
        }
        return true;
      };

      const startCell = startGy * cols + startGx;
      const goalCell = goalGy * cols + goalGx;
      for (const l of validStartLayers) blocked[startCell * 2 + l] = 0;
      for (const l of validGoalLayers) blocked[goalCell * 2 + l] = 0;

      for (const dy of [-1, 0, 1]) {
        for (const dx of [-1, 0, 1]) {
          const sx = startGx + dx;
          const sy = startGy + dy;
          if (sx >= 0 && sx < cols && sy >= 0 && sy < rows) {
            const cIdx = sy * cols + sx;
            for (const l of validStartLayers) {
              if (isCellSafeForEndpoint(sx, sy, l)) {
                blocked[cIdx * 2 + l] = 0;
              }
            }
          }
          const ex = goalGx + dx;
          const ey = goalGy + dy;
          if (ex >= 0 && ex < cols && ey >= 0 && ey < rows) {
            const cIdx = ey * cols + ex;
            for (const l of validGoalLayers) {
              if (isCellSafeForEndpoint(ex, ey, l)) {
                blocked[cIdx * 2 + l] = 0;
              }
            }
          }
        }
      }

      gScore.fill(Infinity);
      cameFrom.fill(-1);
      cameDir.fill(-1);
      closed.fill(0);

      const heap = new BinaryMinHeap();
      const heuristic = (gx: number, gy: number): number => {
        const dx = Math.abs(goalGx - gx);
        const dy = Math.abs(goalGy - gy);
        if (cfg.diagonal45) {
          return Math.max(dx, dy) + (Math.SQRT2 - 1) * Math.min(dx, dy);
        }
        return dx + dy;
      };

      for (const l of validStartLayers) {
        const sIdx = startCell * 2 + l;
        gScore[sIdx] = 0;
        heap.push(sIdx, heuristic(startGx, startGy));
      }

      const dirLimit = cfg.diagonal45 ? 8 : 4;
      let reachedState = -1;

      while (heap.size > 0) {
        const curr = heap.pop()!;
        const sIdx = curr.stateIdx;
        if (closed[sIdx]) continue;
        closed[sIdx] = 1;

        const cellIdx = sIdx >> 1;
        const layer = (sIdx & 1) as 0 | 1;

        if (cellIdx === goalCell && validGoalLayers.includes(layer)) {
          reachedState = sIdx;
          break;
        }

        const gx = cellIdx % cols;
        const gy = (cellIdx / cols) | 0;
        const prevDir = cameDir[sIdx];
        const baseG = gScore[sIdx];

        // 1. Planar moves on current layer
        for (let d = 0; d < dirLimit; d++) {
          const [dx, dy, moveCost] = DIRS_8[d];
          const nx = gx + dx;
          const ny = gy + dy;
          if (nx < 0 || nx >= cols || ny < 0 || ny >= rows) continue;

          const nCell = ny * cols + nx;
          const nState = nCell * 2 + layer;
          if (closed[nState] || blocked[nState]) continue;

          // Strictly forbid diagonal corner-clipping past any blocked cell
          if (d >= 4) {
            const adj1 = (gy * cols + nx) * 2 + layer;
            const adj2 = (ny * cols + gx) * 2 + layer;
            if (blocked[adj1] || blocked[adj2]) continue;
          }

          const bendPenalty = prevDir !== -1 && prevDir !== d ? fwSpec.bendPenalty : 0;
          const layerBias =
            cfg.layerMode === 'multi'
              ? layer === 0 && dy !== 0 && dx === 0
                ? 0.08
                : layer === 1 && dx !== 0 && dy === 0
                  ? 0.08
                  : 0
              : 0;

          const tentativeG = baseG + moveCost + bendPenalty + layerBias;
          if (tentativeG < gScore[nState]) {
            gScore[nState] = tentativeG;
            cameFrom[nState] = sIdx;
            cameDir[nState] = d;
            heap.push(nState, tentativeG + heuristic(nx, ny));
          }
        }

        // 2. Layer transition (via) move when multi-layer is enabled
        if (cfg.layerMode === 'multi' && cellIdx !== startCell && cellIdx !== goalCell) {
          const otherLayer: 0 | 1 = layer === 0 ? 1 : 0;
          const viaState = cellIdx * 2 + otherLayer;
          if (!closed[viaState] && !blocked[viaState]) {
            const viaWorld = { x: toWorldX(gx), y: toWorldY(gy) };
            if (isViaClearOfObstacles(viaWorld, netName, startPad, goalPad)) {
              const tentativeG = baseG + (cfg.viaCost || fwSpec.defaultViaCost);
              if (tentativeG < gScore[viaState]) {
                gScore[viaState] = tentativeG;
                cameFrom[viaState] = sIdx;
                cameDir[viaState] = prevDir;
                heap.push(viaState, tentativeG + heuristic(gx, gy));
              }
            }
          }
        }
      }

      if (reachedState === -1) return null;

      const path: { gx: number; gy: number; layer: 0 | 1 }[] = [];
      let cur = reachedState;
      while (cur !== -1) {
        const cIdx = cur >> 1;
        const l = (cur & 1) as 0 | 1;
        path.push({
          gx: cIdx % cols,
          gy: (cIdx / cols) | 0,
          layer: l,
        });
        cur = cameFrom[cur];
      }
      path.reverse();
      return path;
    };

    for (let idx = 0; idx < orderedAirwires.length; idx++) {
      const aw = orderedAirwires[idx];
      const startPad = findPadAt(aw.from);
      const goalPad = findPadAt(aw.to);

      let rawPath = runAStarBetween(aw.from, aw.to, aw.net, 1.15);
      if (!rawPath) {
        rawPath = runAStarBetween(aw.from, aw.to, aw.net, 0.9);
      }

      if (!rawPath || rawPath.length === 0) {
        failedConnections++;
        failedIndices.push(idx);
        continue;
      }

      routedConnections++;

      let runStart = 0;
      for (let i = 1; i <= rawPath.length; i++) {
        const isEnd = i === rawPath.length;
        const layerChanged = !isEnd && rawPath[i].layer !== rawPath[runStart].layer;

        if (isEnd || layerChanged) {
          const runNodes = rawPath.slice(runStart, i);
          const runLayer: 'F.Cu' | 'B.Cu' =
            rawPath[runStart].layer === 0 ? 'F.Cu' : 'B.Cu';

          const gridWorldPts: Point[] = runNodes.map((n) => ({
            x: toWorldX(n.gx),
            y: toWorldY(n.gy),
          }));

          const exactStart = {
            x: Number(aw.from.x.toFixed(3)),
            y: Number(aw.from.y.toFixed(3)),
          };
          const exactEnd = {
            x: Number(aw.to.x.toFixed(3)),
            y: Number(aw.to.y.toFixed(3)),
          };

          const worldPts: Point[] = [...gridWorldPts];
          if (runStart === 0 && worldPts.length > 0) {
            if (distance(worldPts[0], exactStart) > 0.01) {
              if (
                worldPts.length >= 2 &&
                isSegmentClearOfObstacles(
                  exactStart,
                  worldPts[1],
                  runLayer,
                  aw.net,
                  startPad,
                  goalPad,
                  exactStart,
                  exactEnd
                )
              ) {
                worldPts[0] = exactStart;
              } else {
                worldPts.unshift(exactStart);
              }
            } else {
              worldPts[0] = exactStart;
            }
          }

          if (isEnd && worldPts.length > 0) {
            const lastIdx = worldPts.length - 1;
            if (distance(worldPts[lastIdx], exactEnd) > 0.01) {
              if (
                worldPts.length >= 2 &&
                isSegmentClearOfObstacles(
                  worldPts[lastIdx - 1],
                  exactEnd,
                  runLayer,
                  aw.net,
                  startPad,
                  goalPad,
                  exactStart,
                  exactEnd
                )
              ) {
                worldPts[lastIdx] = exactEnd;
              } else {
                worldPts.push(exactEnd);
              }
            } else {
              worldPts[lastIdx] = exactEnd;
            }
          }

          const simplified = simplifyGridPointsAware(
            worldPts,
            runLayer,
            aw.net,
            startPad,
            goalPad,
            exactStart,
            exactEnd
          );

          if (simplified.length >= 2) {
            const traceItem: PcbTraceItem = {
              id: `trace_astar_${Date.now()}_${idx}_${runStart}`,
              type: 'pcb_trace',
              transform: {
                x: simplified[0].x,
                y: simplified[0].y,
                rotation: 0,
                layer: runLayer,
              },
              props: {
                points: simplified,
                width: traceWidth,
                net: aw.net,
              },
            };
            allTraces.push(traceItem);
            newItems.push(traceItem);
            addedTraces++;
          }

          if (layerChanged) {
            const viaNode = rawPath[i];
            const viaPt = {
              x: toWorldX(viaNode.gx),
              y: toWorldY(viaNode.gy),
            };
            const viaItem: PcbViaItem = {
              id: `via_astar_${Date.now()}_${idx}_${i}`,
              type: 'pcb_via',
              transform: {
                x: viaPt.x,
                y: viaPt.y,
                rotation: 0,
                layer: 'F.Cu',
              },
              props: {
                diameter: viaDiameter,
                drill: viaDrill,
                net: aw.net,
              },
            };
            allVias.push(viaItem);
            newItems.push(viaItem);
            addedVias++;
          }

          runStart = i - 1;
        }
      }
    }

    return {
      allTraces,
      allVias,
      newItems,
      routedConnections,
      failedConnections,
      addedTraces,
      addedVias,
      failedIndices,
    };
  };

  // Multi-pass rip-up & re-ordering: if any airwire failed on Pass 1, promote failed airwires to route first on Pass 2+
  let bestPass = runRoutingPass(airwires);
  let currentOrder = [...airwires];

  for (let pass = 1; pass < fwSpec.passes && bestPass.failedConnections > 0; pass++) {
    const failedSet = new Set(bestPass.failedIndices);
    const prioritized = [
      ...currentOrder.filter((_, i) => failedSet.has(i)),
      ...currentOrder.filter((_, i) => !failedSet.has(i)),
    ];
    currentOrder = prioritized;
    const candidatePass = runRoutingPass(currentOrder);
    if (
      candidatePass.routedConnections > bestPass.routedConnections ||
      (candidatePass.routedConnections === bestPass.routedConnections &&
        candidatePass.addedVias < bestPass.addedVias)
    ) {
      bestPass = candidatePass;
    }
  }

  const nextProject: Project = {
    ...workingProject,
    updatedAt: Date.now(),
    sheets: workingProject.sheets.map((s) =>
      s.kind === 'pcb' ? { ...s, items: [...s.items, ...bestPass.newItems] } : s
    ),
  };

  return {
    project: nextProject,
    framework: cfg.framework,
    routedConnections: bestPass.routedConnections,
    failedConnections: bestPass.failedConnections,
    addedTraces: bestPass.addedTraces,
    addedVias: bestPass.addedVias,
    remainingAirwires: computeRatsnest(nextProject).length,
    elapsedMs: Math.round(performance.now() - startTime),
  };
}

/**
 * Routes a single manual copper trace on `layer` between `fromPt` and `toPt`,
 * automatically walking around any pads, traces, or vias if a direct 45° line would touch them.
 */
export function routeCleanTraceBetweenPoints(
  project: Project,
  fromPt: Point,
  toPt: Point,
  layer: 'F.Cu' | 'B.Cu',
  netName: string,
  traceWidth: number
): Point[] {
  const res = runMstAStarAutorouter(project, {
    gridStep: 0.25,
    layerMode: layer,
    diagonal45: true,
    specificPair: {
      from: fromPt,
      to: toPt,
      net: netName || '__MANUAL_TRACE__',
    },
    traceWidth,
  });

  if (res.routedConnections > 0) {
    const pcbSheet = res.project.sheets.find((s) => s.kind === 'pcb');
    const lastTrace = pcbSheet?.items
      .filter((i): i is PcbTraceItem => i.type === 'pcb_trace')
      .pop();
    if (lastTrace && lastTrace.props.points.length >= 2) {
      return lastTrace.props.points;
    }
  }

  // Fallback octilinear segment if start/end are in open space
  const dx = toPt.x - fromPt.x;
  const dy = toPt.y - fromPt.y;
  const diag = Math.min(Math.abs(dx), Math.abs(dy));
  const mid: Point = {
    x: Number((fromPt.x + Math.sign(dx) * diag).toFixed(3)),
    y: Number((fromPt.y + Math.sign(dy) * diag).toFixed(3)),
  };
  return diag > 0.05 ? [fromPt, mid, toPt] : [fromPt, toPt];
}
