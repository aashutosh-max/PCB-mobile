# PocketEDA — Mobile-First Schematic & 2-Layer PCB CAD

This archive contains the complete source code and pre-built production bundle (`dist/`) for **PocketEDA**, a mobile-first, installable PWA schematic capture and 2-layer PCB layout tool with 551 preset KiCad footprints, obstacle-avoiding MST + A* autorouting, full Gerber RS-274X + Excellon drill export, and interactive geometry generators.

---

## Option 1: Host Locally with Node.js (Development & Live Editing)

### Prerequisites
- **Node.js** v18+ (includes `npm`)

### Steps
1. **Unzip** `PocketEDA_Full_Source.zip` into a folder:
   ```bash
   unzip PocketEDA_Full_Source.zip -d pocketeda
   cd pocketeda
   ```
2. **Install dependencies**:
   ```bash
   npm install
   ```
3. **Start the local development server**:
   ```bash
   npm run dev
   ```
4. Open **`http://localhost:3000`** in your browser (or open `http://<your-computer-LAN-IP>:3000` on your phone over Wi-Fi).

---

## Option 2: Production Build & Preview with Node.js

```bash
npm run build
npm run preview -- --port 3000 --host 0.0.0.0
```

---

## Option 3: Instant Zero-Install Static Hosting (Using Pre-Built `dist/` Folder)

Because this zip archive also includes the compiled `dist/` directory, you can host the app immediately without running `npm install`:

### Using Python 3 (built into macOS / Linux / Termux on Android):
```bash
cd dist
python3 -m http.server 3000 --bind 0.0.0.0
```
Then open **`http://localhost:3000`** on your device.

### Using `npx serve`:
```bash
npx serve dist -l 3000
```
